//! 🧪 Literal factory identity and actual typed-codec parity.

use geo::BoundingRect;
use semio_framework_os_kernel as store;
use semio_framework_os_kernel::{pack::snapshot::ArtifactPack, DslValue, FromValue, Mutation, MutationDiff};
use semio_framework_plugin::{ArtifactInferenceExecutionRequest, WireArtifactInferenceBudget, WireArtifactInferenceCacheMode};
use semio_s_artifact_gis_gismap::{gis_map_inference_service, gis_map_snapshot_with_derived_children, infer_gis_map_controlled, GisMapSnapshot};
use semio_hub_gis::native_codecs::native_codec_factory_receipts;

fn assert_zero_history<P, M>(parsed: store::os_store::text_format::ParsedDocumentText<P, M>, document_id: &str, dialect: &semio_framework::ArtifactDialect) {
    let envelope = parsed.envelope.into_owners();
    assert_eq!(envelope.id, document_id);
    assert_eq!(envelope.dialect.as_ref(), Some(dialect));
    assert!(envelope.vcs.edits.is_empty());
    assert!(envelope.vcs.changes.is_empty());
    assert!(envelope.vcs.checkpoints.is_empty());
    assert!(envelope.vcs.alternatives.is_empty());
    let cursor = envelope.cursor.expect("genesis cursor");
    assert!(cursor.applied_edit_ids.is_empty());
    assert!(cursor.redo_edit_ids.is_empty());
    assert!(cursor.checkpoint_id.is_none());
}

#[semio_framework_async_macros::async_test]
async fn gis_native_receipts_bind_literal_two_codec_closure_without_identity_or_factory_substitution() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!("../../🔣️.json")).unwrap();
    let document_ids: serde_json::Value = serde_json::from_str(include_str!("../../../../../../🧰️framework/🛍️products/💻️os/🔨️modules/🔌️plugin/🧪️tests/🧫️fixtures/🌱️artifact-document-id-v1/🔣️.json")).unwrap();
    let document_id = document_ids["cases"].as_array().unwrap().iter().find(|row| row["accepted"] == true).unwrap()["documentId"].as_str().unwrap();
    let snapshot = GisMapSnapshot::default();
    let pack = snapshot.encode_pack();
    let (envelope, _) = store::semio_format::unwrap_binary(&pack).unwrap();
    assert_eq!(envelope.envelope_id(), <GisMapSnapshot as pack::snapshot::ArtifactDsl>::envelope_id());
    assert_ne!(envelope.envelope_id(), <GisMapSnapshot as pack::snapshot::ArtifactDsl>::EXTENSION);
    assert_eq!(GisMapSnapshot::decode_pack(&pack).unwrap(), snapshot);
    let receipts = native_codec_factory_receipts().expect("complete inert GIS closure");
    assert_eq!(receipts.len(), fixture["receipts"].as_array().unwrap().len());
    for (receipt, expected) in receipts.into_iter().zip(fixture["receipts"].as_array().unwrap()) {
        let identity = receipt.identity();
        assert_eq!(identity.plugin_id, fixture["pluginId"]);
        assert_eq!(identity.package_id, fixture["packageId"]);
        assert_eq!(identity.package_version, fixture["packageVersion"]);
        assert_eq!(identity.factory_id, expected["factoryId"]);
        assert_eq!(identity.artifact_kind, expected["kind"]);
        assert_eq!(identity.schema, expected["schema"]);
        assert_eq!(identity.extension, expected["extension"]);
        assert_eq!(identity.capability, expected["capability"]);
        let hash = identity.protocol_sha256.iter().map(|byte| format!("{byte:02x}")).collect::<String>();
        assert_eq!(hash, expected["protocolSha256"]);
        let codec = receipt.into_codec().expect("actual typed factory matches immutable receipt");
        assert_eq!(codec.schema, identity.schema);
        assert_eq!(codec.extension, identity.extension);
        assert_eq!(codec.pack_schema_hash, identity.pack_schema_hash);
        assert_ne!(codec.pack_schema_hash, [0; 32]);
        let declared = match identity.schema {
            "gis.map" => store::bare_artifact_codec::<GisMapSnapshot, semio_s_artifact_gis_gismap::GisMapMutation>(identity.schema),
            "gis.terrain" => store::bare_artifact_codec::<semio_s_artifact_gis_gisterrain::GisTerrainSnapshot, semio_s_artifact_gis_gisterrain::GisTerrainMutation>(identity.schema),
            _ => panic!("unhandled GIS schema"),
        };
        assert_eq!(codec.schema, declared.schema);
        assert_eq!(codec.extension, declared.extension);
        assert_eq!(codec.pack_schema_hash, declared.pack_schema_hash);
        let record = match identity.schema {
            "gis.map" => <GisMapSnapshot as ArtifactPack>::record_spec().expect("GIS map structural pack schema"),
            "gis.terrain" => <semio_s_artifact_gis_gisterrain::GisTerrainSnapshot as ArtifactPack>::record_spec().expect("GIS terrain structural pack schema"),
            _ => unreachable!(),
        };
        assert_eq!(codec.pack_schema_hash, pack::record::schema_hash(&record));
        let observed_record = serde_json::json!({
            "keyword": record.keyword.as_deref(),
            "fields": record.fields.iter().map(|field| serde_json::json!({ "id": field.id, "key": field.key, "optional": field.optional })).collect::<Vec<_>>(),
        });
        assert_eq!(observed_record, expected["packRecord"]);
        assert!(std::ptr::fn_addr_eq(codec.compile_dsl, declared.compile_dsl));
        assert!(std::ptr::fn_addr_eq(codec.print_mirror, declared.print_mirror));
        assert!(std::ptr::fn_addr_eq(codec.edit_text_from_envelope, declared.edit_text_from_envelope));
        assert!(std::ptr::fn_addr_eq(codec.apply_ops_binary, declared.apply_ops_binary));
        let dialect: semio_framework::ArtifactDialect = match identity.schema {
            "gis.map" => semio_s_artifact_gis_gismap::GISMAP_DIALECT.into(),
            "gis.terrain" => semio_s_artifact_gis_gisterrain::GISTERRAIN_DIALECT.into(),
            _ => panic!("unhandled GIS genesis dialect"),
        };
        let files = match identity.schema {
            "gis.map" => semio_framework_plugin::artifact_app_genesis_pair::<semio_framework_plugin::EditorApp<semio_s_artifact_gis_gismap::editor::gis2d::Gis2dPlayApp>>(document_id).await,
            "gis.terrain" => semio_framework_plugin::artifact_app_genesis_pair::<semio_framework_plugin::EditorApp<semio_s_artifact_gis_gisterrain::editor::gis3d::Gis3dPlayApp>>(document_id).await,
            _ => panic!("unhandled GIS genesis schema"),
        }
        .expect("package-owned GIS genesis");
        match identity.schema {
            "gis.map" => assert_zero_history(store::os_store::text_format::parse_document_pack::<GisMapSnapshot, semio_s_artifact_gis_gismap::GisMapMutation>(&files.pack, &files.spr).await.unwrap(), document_id, &dialect),
            "gis.terrain" => assert_zero_history(store::os_store::text_format::parse_document_pack::<semio_s_artifact_gis_gisterrain::GisTerrainSnapshot, semio_s_artifact_gis_gisterrain::GisTerrainMutation>(&files.pack, &files.spr).await.unwrap(), document_id, &dialect),
            _ => unreachable!(),
        }
        for row in document_ids["cases"].as_array().unwrap().iter().filter(|row| row["accepted"] == false) {
            let hostile_id = row["documentId"].as_str().unwrap();
            let refused = match identity.schema {
                "gis.map" => semio_framework_plugin::artifact_app_genesis_pair::<semio_framework_plugin::EditorApp<semio_s_artifact_gis_gismap::editor::gis2d::Gis2dPlayApp>>(hostile_id).await.is_err(),
                "gis.terrain" => semio_framework_plugin::artifact_app_genesis_pair::<semio_framework_plugin::EditorApp<semio_s_artifact_gis_gisterrain::editor::gis3d::Gis3dPlayApp>>(hostile_id).await.is_err(),
                _ => panic!("unhandled GIS genesis schema"),
            };
            assert!(refused, "GIS genesis admitted hostile document id {}", row["id"]);
        }
    }
}

#[test]
fn gis_native_controlled_inference_executes_literal_progress_cancel_and_deadline_trace() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!("../../../🧪️tests/🧫️fixtures/💡️inference-control/🔣️.json")).unwrap();
    let features = &fixture["snapshot"];
    let snapshot = gis_map_snapshot_with_derived_children(GisMapSnapshot {
        positions: FromValue::from_value(DslValue::from(&features["positions"])).unwrap(),
        routes: FromValue::from_value(DslValue::from(&features["routes"])).unwrap(),
        regions: FromValue::from_value(DslValue::from(&features["regions"])).unwrap(),
        ..Default::default()
    });
    let pack = snapshot.encode_pack();
    let budgets = WireArtifactInferenceBudget { allocation_bytes: 65_536, work_units: 64, recursion_depth: 16 };
    let request =
        ArtifactInferenceExecutionRequest { policy: b"gis-map-v1", budgets: &budgets, cancellation_id: "neutral-control", previous_state: None, requested_cache_mode: WireArtifactInferenceCacheMode::Cold, canonical_payload: &pack, dependencies: &[] };
    let mut observed = Vec::new();
    let output = infer_gis_map_controlled(&request, &mut |work| {
        observed.push(work);
        Ok(())
    })
    .unwrap();
    assert_eq!(serde_json::to_value(&observed).unwrap(), fixture["checkpoints"]);
    assert_eq!(output.canonical_payload, gis_map_inference_service().infer(&request).unwrap().canonical_payload);
    let value = semio_framework_os_kernel::pack_rt::decode_wire_value(&output.canonical_payload).unwrap();
    let inferred = <semio_s_artifact_gis_gismap::standards::v1::subsets::any::schema::inferences::GisMapInference as FromValue>::from_value(value).unwrap();
    assert_eq!([inferred.position_count, inferred.route_count, inferred.region_count], ["positionCount", "routeCount", "regionCount"].map(|key| fixture["expected"][key].as_u64().unwrap() as usize));
    let proposal = inferred.bounds_proposal(&snapshot, fixture["proposalJobId"].as_str().unwrap()).unwrap();
    let expected: semio_s_artifact_gis_gismap::mutations::GisMapMutation = FromValue::from_value(DslValue::from(&fixture["proposal"])).unwrap();
    assert_eq!(proposal, expected);
    let updated = protocol::apply_diff(proposal.diff(&snapshot).diff(), &snapshot).unwrap();
    assert_eq!(updated.regions.len(), snapshot.regions.len() + 1);
    let restored = proposal.inverse(&snapshot).iter().rev().try_fold(updated.clone(), |state, inverse| protocol::apply_diff(inverse.diff(&state).diff(), &state)).unwrap();
    assert_eq!(restored, snapshot);
    assert!(inferred.bounds_proposal(&updated, fixture["proposalJobId"].as_str().unwrap()).is_err());
    assert!(inferred.bounds_proposal(&snapshot, "untrusted-job").is_err());
    for rejection in fixture["proposalRejections"].as_array().unwrap() {
        let mut candidate = inferred.clone();
        let mut base = snapshot.clone();
        let mut job_id = fixture["proposalJobId"].as_str().unwrap();
        match rejection["case"].as_str().unwrap() {
            "wrong-job" => job_id = "not-a-job",
            "duplicate-id" => {
                base.regions.push(semio_s_artifact_gis_gismap::MapFeature { id: format!("inference-{job_id}"), data: DslValue::Null });
                candidate.region_count = base.regions.len();
            }
            "stale-count" => candidate.position_count += 1,
            "no-bounds" => candidate.bounds = None,
            "non-finite" => candidate.bounds.as_mut().unwrap().lon_min = f64::NAN,
            "out-of-range" => candidate.bounds.as_mut().unwrap().lon_min = -181.0,
            "reversed" => candidate.bounds.as_mut().unwrap().lat_min = 49.0,
            _ => panic!("unhandled proposal rejection"),
        }
        assert_eq!(format!("{:?}", candidate.bounds_proposal(&base, job_id).unwrap_err()), rejection["error"].as_str().unwrap(), "{}", rejection["case"]);
    }
    let bounds = inferred.bounds.unwrap();
    let points = std::iter::once((features["positions"][0]["data"]["lon"].as_f64().unwrap(), features["positions"][0]["data"]["lat"].as_f64().unwrap()))
        .chain(features["routes"][0]["data"]["points"].as_array().unwrap().iter().map(|point| (point[0].as_f64().unwrap(), point[1].as_f64().unwrap())))
        .collect::<Vec<_>>();
    let independent = geo::MultiPoint::<f64>::from(points).bounding_rect().unwrap();
    assert_eq!([bounds.lon_min, bounds.lon_max, bounds.lat_min, bounds.lat_max], [independent.min().x, independent.max().x, independent.min().y, independent.max().y]);
    assert_eq!([bounds.lon_min, bounds.lon_max, bounds.lat_min, bounds.lat_max], ["lonMin", "lonMax", "latMin", "latMax"].map(|key| fixture["expected"]["bounds"][key].as_f64().unwrap()));
    for interruption in fixture["interruptions"].as_array().unwrap() {
        let mut calls = 0;
        let error = match interruption["error"].as_str().unwrap() {
            "cancelled" => "cancelled",
            "expired" => "expired",
            _ => panic!("unhandled interruption error"),
        };
        let output = infer_gis_map_controlled(&request, &mut |work| {
            calls += 1;
            if work == interruption["at"].as_u64().unwrap() {
                return Err(semio_framework_plugin::ArtifactInferenceExecutionError::new(error, "request stopped"));
            }
            Ok(())
        });
        assert_eq!(output.err().unwrap().code, error);
        assert_eq!(calls, interruption["calls"].as_u64().unwrap(), "no work occurs after the first caller interruption");
    }
}

/// 🔬️ Creation-path oracle (ticket 26/09/18 slice TC3b, `📓️tc3-catalog-carried-genesis.md` §2.2):
/// the genesis pair the GUEST producer emits — `artifact_app_genesis_pair`, the single
/// implementation behind `world actor`'s `codec.genesis` export and therefore behind every
/// hub-side creation — must be byte-for-byte the pair the LINKED GIS codec produces and accepts.
/// GIS is the one package where both halves exist in one process, so it is the only place this
/// equality can be asserted without a built component, and it is exactly the equality the headless
/// hub relies on when it stops linking a genesis table at all: the hub validates a guest genesis
/// through `TrustedArtifactCodec::validate_pair`, which for GIS is still the linked
/// `ArtifactCodec::print_mirror`, and then hands the same bytes to the store forever after.
#[semio_framework_async_macros::async_test]
async fn gis_guest_genesis_is_byte_for_byte_the_linked_codec_pair_on_one_generation() {
    let document_ids: serde_json::Value = serde_json::from_str(include_str!("../../../../../../🧰️framework/🛍️products/💻️os/🔨️modules/🔌️plugin/🧪️tests/🧫️fixtures/🌱️artifact-document-id-v1/🔣️.json")).unwrap();
    let document_id = document_ids["cases"].as_array().unwrap().iter().find(|row| row["accepted"] == true).unwrap()["documentId"].as_str().unwrap();
    for receipt in native_codec_factory_receipts().expect("complete inert GIS closure") {
        let identity = receipt.identity();
        let schema = identity.schema;
        let codec = receipt.into_codec().expect("linked GIS codec");
        let guest = match schema {
            "gis.map" => semio_framework_plugin::artifact_app_genesis_pair::<semio_framework_plugin::EditorApp<semio_s_artifact_gis_gismap::editor::gis2d::Gis2dPlayApp>>(document_id).await,
            "gis.terrain" => semio_framework_plugin::artifact_app_genesis_pair::<semio_framework_plugin::EditorApp<semio_s_artifact_gis_gisterrain::editor::gis3d::Gis3dPlayApp>>(document_id).await,
            _ => panic!("unhandled GIS genesis schema"),
        }
        .expect("guest genesis producer");
        assert!(!guest.pack.is_empty() && !guest.spr.is_empty(), "{schema} guest genesis is a complete pair");
        // 🪞️ The linked codec ACCEPTS the guest pair: it prints a mirror of it without error, which
        // is precisely the fence `materialize_selected_genesis` applies twice before publication.
        let mirror = (codec.print_mirror)(&guest.pack, &guest.spr).await.expect("linked GIS codec prints the guest genesis pair");
        assert!(!mirror.dsl.is_empty(), "{schema} guest genesis prints a nonempty mirror");
        // 🧬️ …and REPRODUCES it: decoding the guest pair with the linked package's own concrete
        // snapshot and mutation types and reprinting it must return the identical pack, spr and ops.
        let reprinted = match schema {
            "gis.map" => {
                let parsed = store::os_store::text_format::parse_document_pack::<GisMapSnapshot, semio_s_artifact_gis_gismap::GisMapMutation>(&guest.pack, &guest.spr).await.unwrap();
                let envelope = parsed.into_envelope();
                let printed = store::os_store::text_format::print_document_pack(&envelope).await;
                drop(envelope.into_owners());
                printed
            }
            "gis.terrain" => {
                let parsed = store::os_store::text_format::parse_document_pack::<semio_s_artifact_gis_gisterrain::GisTerrainSnapshot, semio_s_artifact_gis_gisterrain::GisTerrainMutation>(&guest.pack, &guest.spr).await.unwrap();
                let envelope = parsed.into_envelope();
                let printed = store::os_store::text_format::print_document_pack(&envelope).await;
                drop(envelope.into_owners());
                printed
            }
            _ => unreachable!(),
        }
        .expect("linked GIS types reprint the guest genesis pair");
        assert_eq!(reprinted.pack, guest.pack, "{schema} pack differs between the guest producer and the linked codec");
        assert_eq!(reprinted.spr, guest.spr, "{schema} spr differs between the guest producer and the linked codec");
        assert_eq!(reprinted.ops, guest.ops, "{schema} ops differ between the guest producer and the linked codec");
    }
}

/// 🧬️ Generator and law of `📇️native-codecs/🔣️.json`'s `packSchemaHash`: each receipt's value is the live
/// `pack::record::schema_hash` the hub's linked GIS codec binds, so the trusted-catalog bootstrap reads it instead of
/// deriving it. With `SEMIO_NATIVE_CODEC_PROJECTION=write` (the gis `native-codec-projection` verb) the committed
/// values are written in place; otherwise the committed projection must already equal the live receipts.
#[test]
fn native_codec_projection_pack_schema_hashes_equal_live_receipts() {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../📇️native-codecs/🔣️.json");
    let committed = std::fs::read_to_string(&path).unwrap();
    let mut generated = committed.clone();
    let protocol_key = "\"protocolSha256\": \"";
    let hash_key = ",\n      \"packSchemaHash\": \"";
    for receipt in native_codec_factory_receipts().expect("complete inert GIS closure") {
        let identity = receipt.identity();
        let hash = identity.pack_schema_hash.iter().map(|byte| format!("{byte:02x}")).collect::<String>();
        let row = generated.find(&format!("\"factoryId\": \"{}\"", identity.factory_id)).unwrap_or_else(|| panic!("projection omits {}", identity.factory_id));
        let protocol_end = row + generated[row..].find(protocol_key).expect("receipt carries protocolSha256") + protocol_key.len() + 64 + 1;
        if generated[protocol_end..].starts_with(hash_key) {
            let start = protocol_end + hash_key.len();
            generated.replace_range(start..start + 64, &hash);
        } else {
            generated.insert_str(protocol_end, &format!("{hash_key}{hash}\""));
        }
    }
    if std::env::var("SEMIO_NATIVE_CODEC_PROJECTION").as_deref() == Ok("write") {
        std::fs::write(&path, &generated).unwrap();
    } else {
        assert_eq!(generated, committed, "GIS native codec projection is stale: run the gis native-codec-projection verb");
    }
}
