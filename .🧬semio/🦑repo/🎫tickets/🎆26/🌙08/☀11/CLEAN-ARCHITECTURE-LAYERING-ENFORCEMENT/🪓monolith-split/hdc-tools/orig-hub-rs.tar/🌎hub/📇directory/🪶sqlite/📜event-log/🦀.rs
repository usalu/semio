//! 📜️ The append-only directory event log and projection rebuild.

use super::*;

impl SqliteDirectory {
    //#region EventLog
    pub(super) async fn append_decided_events(&self, events: &[NewDirectoryEvent]) -> DirectoryResult<DirectoryAppendOutcomeV1> {
        if events.iter().any(|event| matches!(&event.body, DirectoryEventBody::ArtifactCheckpointPublished { .. } | DirectoryEventBody::InviteRedeemed { .. })) {
            return Err(DirectoryError::Conflict("event requires its verified authority append seam".into()));
        }
        let mut conn = self.lock()?;
        let tx = conn.transaction_with_behavior(rusqlite::TransactionBehavior::Immediate).map_err(backend)?;
        let mut persisted = Vec::with_capacity(events.len());
        for event in events {
            if let Some(reason) = self.projection_rejection(&tx, &event.body)? {
                tx.rollback().map_err(backend)?;
                return Ok(DirectoryAppendOutcomeV1::RejectedBeforeCommit(reason));
            }
            let full = self.persist_event(&tx, event)?;
            self.project(&tx, &full)?;
            self.append_cas_release(&tx, &full)?;
            persisted.push(full);
        }
        tx.commit().map_err(backend)?;
        #[cfg(test)]
        if self.append_commit_ack_failure.swap(false, std::sync::atomic::Ordering::SeqCst) {
            return Err(DirectoryError::Backend("injected uncertain append commit acknowledgement".into()));
        }
        Ok(DirectoryAppendOutcomeV1::Appended(persisted))
    }

    pub(super) async fn append_decided_events_with_admin_effect(&self, events: &[NewDirectoryEvent], effect: &NewAdminOperationEffectReceiptV1) -> AdminEffectCommitV1<Vec<DirectoryEvent>> {
        if events.is_empty() || events.iter().any(|event| matches!(&event.body, DirectoryEventBody::ArtifactCheckpointPublished { .. } | DirectoryEventBody::InviteRedeemed { .. })) {
            return AdminEffectCommitV1::RejectedBeforeCommit;
        }
        let mut conn = match self.lock() {
            Ok(conn) => conn,
            Err(_) => return AdminEffectCommitV1::Indeterminate,
        };
        let tx = match conn.transaction_with_behavior(rusqlite::TransactionBehavior::Immediate) {
            Ok(tx) => tx,
            Err(_) => return AdminEffectCommitV1::Indeterminate,
        };
        let mut persisted = Vec::with_capacity(events.len());
        for event in events {
            if admin_effect_try!(tx, self.projection_rejection(&tx, &event.body)).is_some() {
                return admin_effect_rollback(tx);
            }
            let full = admin_effect_try!(tx, self.persist_event(&tx, event));
            admin_effect_try!(tx, self.project(&tx, &full));
            admin_effect_try!(tx, self.append_cas_release(&tx, &full));
            persisted.push(full);
        }
        let receipt = admin_effect_try!(tx, admin_operation_effect_receipt_v1(effect, &persisted));
        admin_effect_try!(tx, insert_admin_operation_effect_receipt(&tx, &receipt));
        if tx.commit().is_err() {
            return AdminEffectCommitV1::Indeterminate;
        }
        #[cfg(test)]
        if self.append_commit_ack_failure.swap(false, std::sync::atomic::Ordering::SeqCst) {
            return AdminEffectCommitV1::Indeterminate;
        }
        AdminEffectCommitV1::Applied(persisted)
    }

    pub(super) async fn events_since(&self, since_seq: u64, limit: usize) -> DirectoryResult<Vec<DirectoryEvent>> {
        #[cfg(test)]
        if self.event_read_failure.swap(false, std::sync::atomic::Ordering::SeqCst) {
            return Err(DirectoryError::Backend("injected directory event read failure".into()));
        }
        let (since_seq, limit) = bounded_event_read(since_seq, limit)?;
        let conn = self.lock()?;
        let mut stmt = conn.prepare("SELECT seq, id, hlc_physical, hlc_logical, actor_kind, actor_id, space_id, user_id, payload, recorded_at FROM hub_directory_event WHERE seq > ?1 ORDER BY seq LIMIT ?2").map_err(backend)?;
        let rows = stmt.query_map(rusqlite::params![since_seq, limit], event_row).map_err(backend)?;
        rows.collect::<Result<Vec<_>, _>>().map_err(backend)
    }

    pub(super) async fn head_seq(&self) -> DirectoryResult<u64> {
        let seq: Option<i64> = self.lock()?.query_row("SELECT MAX(seq) FROM hub_directory_event", [], |row| row.get(0)).map_err(backend)?;
        u64::try_from(seq.unwrap_or(0)).map_err(backend)
    }

    pub(super) async fn rebuild_projections(&self) -> DirectoryResult<u64> {
        self.rebuild_projections_controlled(&UNCONTROLLED_PROJECTION_REBUILD).await
    }

    pub(super) async fn rebuild_projections_controlled(&self, control: &dyn ProjectionRebuildControl) -> DirectoryResult<u64> {
        let mut conn = self.lock()?;
        let tx = conn.transaction_with_behavior(rusqlite::TransactionBehavior::Immediate).map_err(backend)?;
        let event_count: i64 = tx.query_row("SELECT COUNT(*) FROM hub_directory_event", [], |row| row.get(0)).map_err(backend)?;
        let total = u64::try_from(event_count).map_err(backend)?;
        checkpoint_projection_rebuild(control, 0, total)?;
        tx.execute_batch(
            "CREATE TEMP TABLE hub_rebuild_user AS SELECT * FROM hub_user;
             CREATE TEMP TABLE hub_rebuild_auth_session AS SELECT * FROM hub_auth_session;
             CREATE TEMP TABLE hub_rebuild_sync_binding AS SELECT id, auth_session_id, user_id FROM hub_sync_session;
             CREATE TEMP TABLE hub_rebuild_space_invite AS SELECT * FROM hub_space_invite;",
        )
        .map_err(|error| DirectoryError::Backend(format!("SQLite projection rebuild credential snapshot: {error}")))?;
        tx.execute_batch(
            "DELETE FROM hub_artifact_cas_reservation; DELETE FROM hub_artifact_cas_reference; DELETE FROM hub_artifact_retention; DELETE FROM hub_artifact_checkpoint_private; DELETE FROM hub_artifact_checkpoint; DELETE FROM hub_document_index; DELETE FROM hub_document_descriptor; DELETE FROM hub_space_membership; DELETE FROM hub_space; DELETE FROM hub_user;",
        )
        .map_err(|error| DirectoryError::Backend(format!("SQLite projection rebuild truncation: {error}")))?;
        tx.execute_batch(
            "INSERT INTO hub_user (id, email, display_name, password_hash, sso_subject, sso_provider, created_at)
             SELECT id, email, display_name, password_hash, sso_subject, sso_provider, created_at FROM hub_rebuild_user;",
        )
        .map_err(|error| DirectoryError::Backend(format!("SQLite projection rebuild identity restore: {error}")))?;
        let mut replayed = 0u64;
        let mut cursor = 0i64;
        const PAGE: i64 = 512;
        while replayed < total {
            let events: Vec<DirectoryEvent> = {
                let mut stmt = tx.prepare("SELECT seq, id, hlc_physical, hlc_logical, actor_kind, actor_id, space_id, user_id, payload, recorded_at FROM hub_directory_event WHERE seq > ?1 ORDER BY seq LIMIT ?2").map_err(backend)?;
                let mapped = stmt.query_map(rusqlite::params![cursor, PAGE], event_row).map_err(backend)?;
                mapped.collect::<Result<Vec<_>, _>>().map_err(backend)?
            };
            if events.is_empty() {
                return Err(DirectoryError::Backend("directory event replay ended before its counted head".into()));
            }
            for event in &events {
                cursor = i64::try_from(event.seq).map_err(backend)?;
                self.project(&tx, event).map_err(|error| DirectoryError::Backend(format!("SQLite projection rebuild event {}: {error}", event.seq)))?;
                if matches!(&event.body, DirectoryEventBody::ArtifactCheckpointPublished { .. }) {
                    let checkpoint = tx
                        .query_row("SELECT payload FROM hub_artifact_authority_journal WHERE event_seq = ?1", rusqlite::params![cursor], verified_checkpoint_row)
                        .optional()
                        .map_err(backend)?
                        .ok_or_else(|| DirectoryError::Backend(format!("missing private authority journal for checkpoint event {}", event.seq)))?;
                    self.project_verified_checkpoint(&tx, event, &checkpoint)?;
                }
                replayed += 1;
                checkpoint_projection_rebuild(control, replayed, total)?;
            }
        }
        let ledger_rows: Vec<(i64, String, String, Option<String>, Option<Vec<u8>>, Option<i64>, Option<i64>, Option<Vec<u8>>)> = {
            let mut statement = tx.prepare("SELECT generation, operation, space_id, document_id, checkpoint_id, write_epoch, expires_at_ms, plan FROM hub_artifact_cas_ledger_journal ORDER BY generation").map_err(backend)?;
            let mapped = statement.query_map([], |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?, row.get(4)?, row.get(5)?, row.get(6)?, row.get(7)?))).map_err(backend)?;
            mapped.collect::<Result<Vec<_>, _>>().map_err(backend)?
        };
        for (generation, operation, space_id, document_id, checkpoint_id, write_epoch, expires_at_ms, plan) in ledger_rows {
            match operation.as_str() {
                "reserve" => {
                    let plan = decode_artifact_cas_ownership_v1(plan.as_deref().ok_or_else(|| DirectoryError::Backend("artifact CAS reserve journal plan missing".into()))?).map_err(|error| DirectoryError::Backend(error.to_string()))?;
                    let reservation = ArtifactCasReservation::unfenced(
                        plan,
                        u64::try_from(generation).map_err(backend)?,
                        u64::try_from(write_epoch.ok_or_else(|| DirectoryError::Backend("artifact CAS reserve journal epoch missing".into()))?).map_err(backend)?,
                        u64::try_from(expires_at_ms.ok_or_else(|| DirectoryError::Backend("artifact CAS reserve journal expiry missing".into()))?).map_err(backend)?,
                    );
                    Self::cas_project_reserve(&tx, &reservation)?;
                }
                "publish" => {
                    let plan = decode_artifact_cas_ownership_v1(plan.as_deref().ok_or_else(|| DirectoryError::Backend("artifact CAS publish journal plan missing".into()))?).map_err(|error| DirectoryError::Backend(error.to_string()))?;
                    let reservation = ArtifactCasReservation::unfenced(
                        plan,
                        u64::try_from(generation).map_err(backend)?,
                        u64::try_from(write_epoch.ok_or_else(|| DirectoryError::Backend("artifact CAS publish journal epoch missing".into()))?).map_err(backend)?,
                        u64::try_from(expires_at_ms.ok_or_else(|| DirectoryError::Backend("artifact CAS publish journal expiry missing".into()))?).map_err(backend)?,
                    );
                    Self::cas_project_publish(&tx, &reservation, generation)?;
                }
                "retention" | "space-delete" => {
                    let checkpoint_id = checkpoint_id.map(|bytes| bytes.try_into().map(ArtifactHash).map_err(|_: Vec<u8>| DirectoryError::Backend("artifact CAS release journal checkpoint width".into()))).transpose()?;
                    Self::cas_project_release(&tx, &operation, &space_id, document_id.as_deref(), checkpoint_id)?;
                }
                _ => return Err(DirectoryError::Backend("artifact CAS ledger operation is invalid".into())),
            }
        }
        tx.execute_batch(
            "INSERT INTO hub_auth_session (id, selector, secret_digest, user_id, identity_provider, identity_subject_digest, issued_at, expires_at, revoked_at, revoked_reason, authorization_generation, device_instance_id, session_kind)
             SELECT id, selector, secret_digest, user_id, identity_provider, identity_subject_digest, issued_at, expires_at, revoked_at, revoked_reason, authorization_generation, device_instance_id, session_kind FROM hub_rebuild_auth_session;
             UPDATE hub_sync_session
             SET auth_session_id = (SELECT auth_session_id FROM hub_rebuild_sync_binding WHERE hub_rebuild_sync_binding.id = hub_sync_session.id),
                 user_id = (SELECT user_id FROM hub_rebuild_sync_binding WHERE hub_rebuild_sync_binding.id = hub_sync_session.id)
             WHERE id IN (SELECT id FROM hub_rebuild_sync_binding);
             INSERT INTO hub_space_invite (id, selector, secret_digest, space_id, role, created_at, expires_at, revoked_at, revoked_reason, accepted_at, accepted_event_id)
             SELECT id, selector, secret_digest, space_id, role, created_at, expires_at, revoked_at, revoked_reason, accepted_at, accepted_event_id FROM hub_rebuild_space_invite;
             DROP TABLE hub_rebuild_user;
             DROP TABLE hub_rebuild_auth_session;
             DROP TABLE hub_rebuild_sync_binding;
             DROP TABLE hub_rebuild_space_invite;",
        )
        .map_err(|error| DirectoryError::Backend(format!("SQLite projection rebuild credential restore: {error}")))?;
        tx.commit().map_err(backend)?;
        Ok(replayed)
    }
    //#endregion
}
