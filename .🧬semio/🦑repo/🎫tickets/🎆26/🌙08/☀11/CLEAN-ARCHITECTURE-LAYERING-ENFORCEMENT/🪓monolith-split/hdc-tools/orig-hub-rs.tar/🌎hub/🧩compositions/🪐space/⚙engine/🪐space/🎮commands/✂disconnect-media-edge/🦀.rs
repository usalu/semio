//! 🔗️ 🔗️ S Studio app command — `disconnect-media-edge`.

use semio_hub_space_foundation::config::{SpaceConfig, SpaceConfigMutation};
use semio_framework_os::workflow::DisconnectEdge;
use semio_framework_os::{WorkflowMutation, WorkflowSnapshot};
use semio_framework_plugin::{ArtifactView, ConfigView, Emit, Fault};

#[derive(Clone, Debug, PartialEq, value_derive::ToValue, value_derive::FromValue, semio_framework_dsl_record_derive::DslRecord, semio_framework_value::RetireOwned)]
#[dsl(keyword = "disconnect-media-edge")]
pub struct DisconnectMediaEdge {
    pub edge_id: String,
}

pub fn handle(payload: &DisconnectMediaEdge, _doc: &ArtifactView<'_, WorkflowSnapshot>, _cfg: &ConfigView<'_, SpaceConfig>) -> Result<Emit<WorkflowMutation, SpaceConfigMutation>, Fault> {
    Ok(Emit::mutations(vec![WorkflowMutation::DisconnectEdge(DisconnectEdge { edge_id: payload.edge_id.clone() })]))
}
