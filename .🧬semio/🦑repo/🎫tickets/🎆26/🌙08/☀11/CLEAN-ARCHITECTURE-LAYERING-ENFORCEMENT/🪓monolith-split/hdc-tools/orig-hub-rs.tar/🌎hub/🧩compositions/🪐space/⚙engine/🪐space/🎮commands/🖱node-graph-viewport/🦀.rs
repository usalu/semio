//! 🖱️ 🖱️ S Studio app command — `node-graph-viewport`.

use semio_hub_space_foundation::config::{SpaceConfig, SpaceConfigMutation, CameraSetting, SpaceWindowCamera};
use semio_framework_os::{WorkflowMutation, WorkflowSnapshot};
use semio_framework_os_kernel::Viewport2d;
use semio_framework_plugin::{ArtifactView, ConfigView, Emit, Fault};

#[derive(Clone, Debug, PartialEq, value_derive::ToValue, value_derive::FromValue, semio_framework_dsl_record_derive::DslRecord, semio_framework_value::RetireOwned)]
#[dsl(keyword = "node-graph-viewport")]
pub struct NodeGraphViewport {
    #[dsl(block)]
    pub viewport: Viewport2d,
}

pub fn handle(payload: &NodeGraphViewport, _doc: &ArtifactView<'_, WorkflowSnapshot>, _cfg: &ConfigView<'_, SpaceConfig>) -> Result<Emit<WorkflowMutation, SpaceConfigMutation>, Fault> {
    let viewport = payload.viewport;
    let camera = SpaceWindowCamera { x: viewport.x, y: viewport.y, zoom: viewport.zoom };
    Ok(Emit::config(vec![SpaceConfigMutation::SetCamera(CameraSetting { window_id: semio_hub_space_foundation::S_PLAY_WINDOW_WORKFLOW.into(), camera })]))
}
