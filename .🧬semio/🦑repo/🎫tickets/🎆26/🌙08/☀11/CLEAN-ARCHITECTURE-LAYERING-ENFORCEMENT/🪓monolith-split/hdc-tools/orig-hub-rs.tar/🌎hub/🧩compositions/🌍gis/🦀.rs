//! 🌍️ GIS composition of independently owned map and terrain artifacts.

extern crate semio_framework_os_kernel as protocol;
extern crate semio_framework_os_kernel as store;
#[path = "📇️native-codecs/🦀️.rs"]
pub mod native_codecs;
#[path = "💡️inference/🦀️.rs"]
pub mod inference;

use semio_framework_plugin::__semio_dispatch_PluginApp;
use semio_framework_plugin::kernel::{ActivationEvent, CapabilityId, CapabilityRequest};
use semio_framework_plugin::plugin_app_close_prelude::*;
use semio_framework_plugin::{ExecutionMode, HostMediaHandlerDeclaration, Plugin, PluginApp};
use semio_framework_plugin::PluginBuilder;

//#region ✏️Editor
/// ✏️ Surface re-export so bundling crates (🎪️demonstrator) can name `gis::editor::gis2d::…`
/// exactly as they name `cad::editor::cad::…` — same shape as 📐️cad/🏭️process/🪵️sourcing.
pub mod editor {
    pub use semio_s_artifact_gis_gismap::editor::*;
}
//#endregion ✏️Editor

//#region 🗃️Apps
semio_framework_dispatch_macros::dyn_enum_close! {
    /// 🗃️ Closed runtime app fleet for both GIS artifact surfaces.
    pub enum GisApps: PluginApp {
        Gis2dEditor(VcsArtifactApp<EditorApp<semio_s_artifact_gis_gismap::editor::gis2d::Gis2dPlayApp>, semio_s_artifact_stdio_semio::SemioMembers>),
        GisMapViewer(VcsArtifactApp<ViewerApp<semio_s_artifact_gis_gismap::viewer::gismap::GisMapViewer>, semio_s_artifact_stdio_semio::SemioMembers>),
        Gis3dEditor(VcsArtifactApp<EditorApp<semio_s_artifact_gis_gisterrain::editor::gis3d::Gis3dPlayApp>>),
        GisTerrainViewer(VcsArtifactApp<ViewerApp<semio_s_artifact_gis_gisterrain::viewer::gisterrain::GisTerrainViewer>>),
    }
}
//#endregion 🗃️Apps

/// 🔌️ Composes map and terrain editors, viewers and native media capabilities.
pub fn plugin() -> Result<Plugin<GisApps>, PluginAssemblyError> {
    let dependency = semio_hub_stdio_catalog::native_artifact_catalog_dependency()?;
    let catalog = semio_hub_stdio_catalog::native_artifact_catalog_contribution()?;
    PluginBuilder::<_, GisApps>::new("gis")
        .label("GIS")
        .version("0.1.0")
        .package_id("semio:gis")
        .depends_on(dependency.plugin_id, dependency.version)
        .contributes_topic(catalog)
        .contributes_topic(TopicContribution::new(protocol::os_directory::client::DOCUMENT_HTTP_PORT_TOPIC, semio_framework_value::ToValue::to_value(&semio_s_artifact_gis_gismap::inference_client::declaration())))
        .artifact_kind(semio_s_artifact_gis_gismap::artifact_kind())
        .artifact_kind(semio_s_artifact_gis_gisterrain::artifact_kind())
        .artifact(semio_s_artifact_gis_gismap::declaration().map_err(PluginAssemblyError::definition)?)
        .artifact(semio_s_artifact_gis_gisterrain::declaration().map_err(PluginAssemblyError::definition)?)
        .host_media_handler(HostMediaHandlerDeclaration::two_d_svg_export(
            "s.gis.host-media.two-d-svg",
            semio_s_artifact_gis_gismap::artifact_kind(),
            semio_s_artifact_gis_gismap::GIS_MAP_SCHEMA,
            "gis2d",
            semio_s_artifact_gis_gismap::standards::v1::subsets::any::io::text::snapshot::gis2d_document_json_to_svg,
        )?)
        .editor::<semio_s_artifact_gis_gismap::editor::gis2d::Gis2dPlayApp>(semio_s_artifact_gis_gismap::editor::gis2d::create_gis2d_app())
        .editor_mutation_roster::<semio_s_artifact_gis_gismap::editor::gis2d::Gis2dPlayApp>()
        .viewer::<semio_s_artifact_gis_gismap::viewer::gismap::GisMapViewer>(semio_s_artifact_gis_gismap::viewer::gismap::create_gismap_viewer())
        .viewer_mutation_roster::<semio_s_artifact_gis_gismap::viewer::gismap::GisMapViewer>()
        .editor::<semio_s_artifact_gis_gisterrain::editor::gis3d::Gis3dPlayApp>(semio_s_artifact_gis_gisterrain::editor::gis3d::create_gis3d_app())
        .editor_mutation_roster::<semio_s_artifact_gis_gisterrain::editor::gis3d::Gis3dPlayApp>()
        .viewer::<semio_s_artifact_gis_gisterrain::viewer::gisterrain::GisTerrainViewer>(semio_s_artifact_gis_gisterrain::viewer::gisterrain::create_gisterrain_viewer())
        .viewer_mutation_roster::<semio_s_artifact_gis_gisterrain::viewer::gisterrain::GisTerrainViewer>()
        .activation(ActivationEvent::OnArtifactKind { kind: semio_s_artifact_gis_gismap::artifact_kind().id })
        .activation(ActivationEvent::OnArtifactKind { kind: semio_s_artifact_gis_gisterrain::artifact_kind().id })
        .execution(ExecutionMode::Isolated)
        .requests(CapabilityRequest { id: CapabilityId("artifacts.write".into()), scope: "plugin".into(), reason: "persist gis2d/gis3d editor edits (map features, terrain) to the open gismap document".into(), optional: false })
        .requests(CapabilityRequest { id: CapabilityId("shell.navigate".into()), scope: "plugin".into(), reason: "the `shell` command opens an external basemap/attribution URL (Effect::OpenExternalUrl)".into(), optional: false })
        .try_build()
}

//#region 🧪️SurfaceTests
#[cfg(test)]
#[path = "🧪️tests/🔬️surface/🦀️.rs"]
mod surface_tests;
//#endregion 🧪️SurfaceTests

