//! 🔌️ Plugin root contract — typestate `Plugin::builder` registration for this owner.

use semio_framework_plugin::__semio_dispatch_PluginApp;
use semio_framework_plugin::kernel::{ActivationEvent, CapabilityId, CapabilityRequest};
use semio_framework_plugin::plugin_app_close_prelude::*;
use semio_framework_plugin::{ExecutionMode, Plugin, PluginApp};
use semio_framework_plugin::PluginBuilder;

//#region 🗃️Apps
semio_framework_dispatch_macros::dyn_enum_close! {
    /// 🗃️ Closed runtime app fleet for the declaration-owned mathematical surfaces.
    pub enum MathematicalApps: PluginApp {
        EquationEditor(VcsArtifactApp<EditorApp<crate::editor::equation::EquationPlayApp>, semio_s_artifact_stdio_semio::SemioMembers>),
        EquationViewer(VcsArtifactApp<ViewerApp<crate::viewer::equation::EquationViewer>, semio_s_artifact_stdio_semio::SemioMembers>),
    }
}
//#endregion 🗃️Apps

/// 🔌️ Builds the plugin surface for host registration. Atomic cutover (ticket
/// 26/08/17/CLEAN-ARTIFACT-STANDARD-SUBSET-MECHANISM): `.declare_artifact(...)` (new declaration
/// tree) replaces `.artifact(...)`/`.editor::<>()`/`.viewer::<>()` outright — the old channel is
/// NOT kept alongside it (a second parallel registration channel is the compatibility layer this
/// ticket forbids). The old `.artifact(declaration())` channel's `.composers(...)` registered a
/// native composer entry with NO matching `composer` capability row in `definition()` — the exact
/// bug that shipped this plugin's WASM manifest as `assembly-failed` (every `try_build()` call
/// faulted on the capability-row mismatch); `.declare_artifact(...)`'s io hops are typed
/// `Serializer`/`Deserializer` entries validated by `io_register`, not `ComposerEntry` capability
/// rows, so this cutover fixes the manifest as a side effect, not a separate fix.
/// `.editor_mutation_roster()`/`.viewer_mutation_roster()` stay: they are an orthogonal,
/// still-supported opt-in (`contributor.list-artifact-mutations`) the new declaration tree's
/// `SurfaceDeclaration.mutation_roster` field does not yet wire live (`📓️w1-c-report.md`
/// openQuestion 3) — not a second registration of the artifact/schema/io itself.
/// `.activation(…)`/`.execution(…)`/`.requests(…)` (ticket
/// 26/08/17/MICROKERNEL-POOLED-ACTOR-PLUGIN-RUNTIME M1, `📓️design-abi.md` §3/§6): the host
/// activates one instance whenever a `"computation.equation"` artifact
/// (`crate::artifacts::equation::artifact_kind().id`) is opened, this plugin's actor runs
/// `Isolated` (no cross-plugin extension attachment, the SDK default holds), and it asks the
/// broker for document write access because `EquationPlayApp` persists graph edits back to
/// the open document.
pub fn plugin() -> Result<Plugin<MathematicalApps>, PluginAssemblyError> {
    PluginBuilder::<_, MathematicalApps>::new("mathematical")
        .label("Mathematical")
        .version("0.1.0")
        .package_id("semio:mathematical")
        .declare_artifact(crate::artifacts::equation::artifact())
        .editor_mutation_roster::<crate::editor::equation::EquationPlayApp>()
        .viewer_mutation_roster::<crate::viewer::equation::EquationViewer>()
        .activation(ActivationEvent::OnArtifactKind { kind: crate::artifacts::equation::artifact_kind().id })
        .execution(ExecutionMode::Isolated)
        .requests(CapabilityRequest { id: CapabilityId("artifacts.write".into()), scope: "plugin".into(), reason: "persist mathematical graph edits to the open document".into(), optional: false })
        .try_build()
}

//#region 🧪️SurfaceTests
#[cfg(test)]
#[path = "🧪️tests/🔬️surface/🦀️.rs"]
mod surface_tests;
//#endregion 🧪️SurfaceTests
