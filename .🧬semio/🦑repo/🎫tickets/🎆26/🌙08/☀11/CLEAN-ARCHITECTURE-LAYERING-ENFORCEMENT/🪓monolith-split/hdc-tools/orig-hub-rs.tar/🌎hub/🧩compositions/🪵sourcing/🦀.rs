//! 🔌️ Plugin root contract — typestate `Plugin::builder` registration for this owner.

use semio_framework_plugin::__semio_dispatch_PluginApp;
use semio_framework_plugin::kernel::{ActivationEvent, CapabilityId, CapabilityRequest};
use semio_framework_plugin::plugin_app_close_prelude::*;
use semio_framework_plugin::{ExecutionMode, Plugin, PluginApp};
use semio_framework_plugin::PluginBuilder;

//#region 🗃️Apps
semio_framework_dispatch_macros::dyn_enum_close! {
    /// 🗃️ Closed runtime app fleet for the sourcing editor and viewer surfaces — over `SemioMembers`, the
    /// roster that opens the composed `s.stdio.semio` kit catalogue child every curation carries.
    pub enum SourcingApps: PluginApp {
        Editor(VcsArtifactApp<EditorApp<crate::editor::sourcing::SourcingCurationApp>, semio_s_artifact_stdio_semio::SemioMembers>),
        Viewer(VcsArtifactApp<ViewerApp<crate::viewer::sourcing::SourcingViewer>, semio_s_artifact_stdio_semio::SemioMembers>),
    }
}
//#endregion 🗃️Apps

/// 🔌️ Builds the plugin surface for host registration. Atomic cutover (ticket
/// 26/08/17/CLEAN-ARTIFACT-STANDARD-SUBSET-MECHANISM): `.declare_artifact(...)` (new declaration
/// tree) replaces `.artifact(...)`/`.editor::<>()`/`.viewer::<>()` outright — the old channel is
/// NOT kept alongside it (a second parallel registration channel is the compatibility layer this
/// ticket forbids). `.editor_mutation_roster()`/`.viewer_mutation_roster()` stay: they are an
/// orthogonal, still-supported opt-in (`contributor.list-artifact-mutations`) the new declaration
/// tree's `SurfaceDeclaration.mutation_roster` field does not yet wire live (`📓️w1-c-report.md`
/// openQuestion 3) — not a second registration of the artifact/schema/io itself.
/// `.activation(…)`/`.execution(…)`/`.requests(…)` (ticket
/// 26/08/17/MICROKERNEL-POOLED-ACTOR-PLUGIN-RUNTIME M2, `📓️design-abi.md` §3): the host activates
/// one instance whenever a `"catalogue.sourcing"` artifact (`crate::artifacts::curation::
/// artifact_kind().id`) is opened, this plugin's actor runs `Isolated` (no publisher trust assumed
/// beyond the sandbox default — nothing in this crate's own effects, all UI-chrome/RPC `Effect`
/// variants with no documented `CapabilityId`, justifies otherwise), and it asks the broker for
/// document write access to persist edits.
pub fn plugin() -> Result<Plugin<SourcingApps>, PluginAssemblyError> {
    PluginBuilder::<_, SourcingApps>::new("sourcing")
        .label("Sourcing")
        .version("0.1.0")
        .package_id("semio:sourcing")
        .declare_artifact(crate::artifacts::curation::artifact())
        .editor_mutation_roster::<crate::editor::sourcing::SourcingCurationApp>()
        .viewer_mutation_roster::<crate::viewer::sourcing::SourcingViewer>()
        .activation(ActivationEvent::OnArtifactKind { kind: crate::artifacts::curation::artifact_kind().id })
        .execution(ExecutionMode::Isolated)
        .requests(CapabilityRequest { id: CapabilityId("artifacts.write".into()), scope: "plugin".into(), reason: "persist sourcing catalogue edits to the open document".into(), optional: false })
        .try_build()
}

//#region 🧪️Tests
#[cfg(test)]
#[path = "🧪️tests/🔬️surface/🦀️.rs"]
mod surface_tests;
//#endregion 🧪️Tests
