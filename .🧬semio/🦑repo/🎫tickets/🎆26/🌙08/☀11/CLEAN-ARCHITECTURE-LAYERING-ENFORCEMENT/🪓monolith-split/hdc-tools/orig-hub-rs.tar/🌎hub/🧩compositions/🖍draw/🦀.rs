//! 🔌️ Plugin root contract — typestate `Plugin::builder` registration for this owner.

use semio_framework_plugin::__semio_dispatch_PluginApp;
use semio_framework_plugin::kernel::{ActivationEvent, CapabilityId, CapabilityRequest};
use semio_framework_plugin::plugin_app_close_prelude::*;
use semio_framework_plugin::{ExecutionMode, Plugin, PluginApp};
use semio_framework_plugin::PluginBuilder;

//#region 🗃️Apps
semio_framework_dispatch_macros::dyn_enum_close! {
    /// 🗃️ Closed runtime app fleet for the draw editor and viewer.
    pub enum DrawApps: PluginApp {
        Editor(VcsArtifactApp<EditorApp<semio_s_artifact_draw_drawing_editor::DrawingPlayApp>>),
        Viewer(VcsArtifactApp<ViewerApp<semio_s_artifact_draw_drawing_viewer::DrawingViewer>>),
    }
}
//#endregion 🗃️Apps

/// 🔌️ Builds the plugin surface for host registration. Atomic cutover (ticket
/// 26/08/17/CLEAN-ARTIFACT-STANDARD-SUBSET-MECHANISM): `.declare_artifact(…)` (new declaration
/// tree) replaces `.artifact(declaration())`/`.editor::<>()`/`.viewer::<>()` outright — the old
/// channel is NOT kept alongside it (a second parallel registration channel is the compatibility
/// layer this ticket forbids). `.editor_mutation_roster()`/`.viewer_mutation_roster()` stay: they
/// are an orthogonal, still-supported opt-in (`contributor.list-artifact-mutations`) the new
/// declaration tree's `SurfaceDeclaration.mutation_roster` does not yet wire live (`📓️w1-c-report.md`
/// openQuestion 3) — not a second registration of the artifact/schema/io itself.
/// `.activation(…)`/`.execution(…)`/`.requests(…)` (ticket
/// 26/08/17/MICROKERNEL-POOLED-ACTOR-PLUGIN-RUNTIME M1, `📓️design-abi.md` §3/§6): the host
/// activates one instance whenever a `"2d.drawing"` artifact
/// (`semio_s_artifact_draw_drawing_model::artifact_kind().id`) is opened, this plugin's actor runs `Isolated`
/// (no cross-plugin extension attachment; the canvas gesture FSM's own `loop`s are microstep- and
/// mailbox-bounded within one turn, not a self-tick/`pending_effects` poll — the SDK default
/// holds), and it asks the broker for document write access because `DrawingPlayApp` persists edits
/// back to the open document. No quota declared: draw's ~14 `Effect` call sites
/// (`LoadDocument`/`SetActiveUtility`/`ReplayShellCommand`) are per-turn UI/document effects with
/// no evidence of long-running computation, large held buffers, or high-frequency timers.
pub fn plugin() -> Result<Plugin<DrawApps>, PluginAssemblyError> {
    PluginBuilder::<_, DrawApps>::new("draw")
        .label("Draw")
        .version("0.1.0")
        .package_id("semio:draw")
        .declare_artifact(semio_s_artifact_draw_drawing::artifact())
        .editor_mutation_roster::<semio_s_artifact_draw_drawing_editor::DrawingPlayApp>()
        .viewer_mutation_roster::<semio_s_artifact_draw_drawing_viewer::DrawingViewer>()
        .activation(ActivationEvent::OnArtifactKind { kind: semio_s_artifact_draw_drawing_model::artifact_kind().id })
        .execution(ExecutionMode::Isolated)
        .requests(CapabilityRequest { id: CapabilityId("artifacts.write".into()), scope: "plugin".into(), reason: "persist draw edits to the open document".into(), optional: false })
        .try_build()
}

//#region 🧪️SurfaceTests
/// 🧪️ Contract §2.5 surface guarantees: a viewer never mutates the document (type + runtime proof)
/// and both surfaces share one dialect coordinate.
#[cfg(test)]
#[path = "🧪️tests/🔬️surface/🦀️.rs"]
mod surface_tests;
//#endregion 🧪️SurfaceTests

#[cfg(all(test,not(target_arch="wasm32")))]
#[path="🧪️tests/🌐️guest/🦀️.rs"]
mod guest_instance_tests;
