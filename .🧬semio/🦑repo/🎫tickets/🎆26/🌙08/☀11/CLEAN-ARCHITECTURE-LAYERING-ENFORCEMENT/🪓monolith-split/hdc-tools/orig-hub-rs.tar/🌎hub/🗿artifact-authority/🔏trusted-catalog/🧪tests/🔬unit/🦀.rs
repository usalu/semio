use directory::os_directory::io::binary::artifact_hash::hex_lower;

use semio_hub_artifact_authority::adapters::AUTHORITY_MAX_DIAGNOSTIC_BYTES;
use semio_hub_native_openable::NativeCodecProviderSetV1;
use semio_hub_trusted_catalog_contract::schema::{TrustedBundleBrowserActorV1, TrustedBundleCodecV1, TrustedBundleComponentV1, TrustedBundlePluginModuleV1, TrustedBundleProfileOpenTargetV1};
use semio_hub_artifact_authority::{AuthorityLimits, AuthorityOperationControl};
use directory::os_store::{serialization::ArtifactPackFiles, text_format::ArtifactTextFiles, VcsError, codec_registry::document_codec};
use std::io::Write;
use std::path::PathBuf;
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

static FIXTURE_SEQUENCE: AtomicUsize = AtomicUsize::new(0);

/// 🧊️ The residency a hub applies unless configured is exactly the `default` and `const` values
/// `TrustedCatalogGuestResidencyV1` declares, an operator's `residentComponentBytes` is admitted only within the
/// declared bounds, a catalog load never verifies more guests at once than the declared bound, and the state the
/// admin route reports carries exactly the fields `TrustedCatalogGuestResidencyStateV1` requires.
#[test]
fn guest_residency_bounds_are_the_declared_schema_values() {
    let module: serde_json::Value = serde_json::from_str(semio_hub_trusted_catalog_contract::schema::TRUSTED_CATALOG_SCHEMA_JSON).unwrap();
    let residency = &module["$defs"]["TrustedCatalogGuestResidencyV1"];
    let declared = &residency["properties"];
    let bytes = &declared["residentComponentBytes"];
    assert_eq!(bytes["default"].as_u64(), Some(TRUSTED_CATALOG_GUEST_RESIDENCY.resident_component_bytes));
    assert_eq!(bytes["minimum"].as_u64(), Some(*semio_hub_trusted_catalog_contract::schema::TRUSTED_CATALOG_GUEST_RESIDENCY_BYTES_BOUNDS.start()));
    assert_eq!(bytes["maximum"].as_u64(), Some(*semio_hub_trusted_catalog_contract::schema::TRUSTED_CATALOG_GUEST_RESIDENCY_BYTES_BOUNDS.end()));
    assert_eq!(declared["concurrentVerifications"]["const"].as_u64(), Some(TRUSTED_CATALOG_GUEST_RESIDENCY.concurrent_verifications as u64));
    assert_eq!(declared["accessCountCeiling"]["const"].as_u64(), Some(u64::from(TRUSTED_CATALOG_GUEST_RESIDENCY.access_count_ceiling)));
    assert_eq!(declared["accessCountAgingPerGuest"]["const"].as_u64(), Some(TRUSTED_CATALOG_GUEST_RESIDENCY.access_count_aging_per_guest));
    assert_eq!(residency["required"].as_array().unwrap().len(), declared.as_object().unwrap().len(), "every declared bound is required");
    assert!(guest_verification_concurrency() >= 1 && guest_verification_concurrency() <= TRUSTED_CATALOG_GUEST_RESIDENCY.concurrent_verifications);
    let configured = |value: Option<&str>| TrustedCatalogGuestResidencyV1::configured(value).map(|residency| residency.resident_component_bytes);
    assert_eq!(configured(None), Ok(TRUSTED_CATALOG_GUEST_RESIDENCY.resident_component_bytes));
    assert_eq!(configured(Some(" ")), Ok(TRUSTED_CATALOG_GUEST_RESIDENCY.resident_component_bytes));
    assert_eq!(configured(Some("0")), Ok(0));
    assert_eq!(configured(Some("67108864")), Ok(67_108_864));
    assert_eq!(configured(Some("17179869184")), Ok(17_179_869_184));
    for refused in ["17179869185", "-1", "64MiB", "1e9", "0x10"] {
        assert!(configured(Some(refused)).is_err(), "{refused} is refused");
    }
    let state = serde_json::to_value(TrustedCatalogGuestResidencyStateV1::default()).unwrap();
    let required: BTreeSet<&str> = module["$defs"]["TrustedCatalogGuestResidencyStateV1"]["required"].as_array().unwrap().iter().map(|field| field.as_str().unwrap()).collect();
    assert_eq!(state.as_object().unwrap().keys().map(String::as_str).collect::<BTreeSet<_>>(), required, "the reported state is exactly the schema's fields");
}

/// 🗃️ A remembered verification answers only for exactly its component, schema and engine; a record
/// edited to claim another hash, another engine or another component is a miss, never a verdict.
#[tokio::test]
async fn a_guest_codec_verification_is_recalled_only_for_its_exact_key() {
    let root = std::env::temp_dir().join(format!("guest-codec-verifications-{}-{}", std::process::id(), FIXTURE_SEQUENCE.fetch_add(1, Ordering::SeqCst)));
    let cache = GuestCodecVerificationCacheV1::at(root.clone(), "owned-engine-v1:aa:fuel-1");
    let component = [7u8; 32];
    let observed = [9u8; 32];
    assert_eq!(cache.recall(&component, "note.document").await, None, "a cold cache recalls nothing");
    assert!(cache.remember(&component, "note.document", &observed).await);
    assert_eq!(cache.recall(&component, "note.document").await, Some(observed));
    assert_eq!(cache.recall(&component, "draw.document").await, None, "another schema is another key");
    assert_eq!(cache.recall(&[8u8; 32], "note.document").await, None, "another component is another key");
    assert_eq!(GuestCodecVerificationCacheV1::at(root.clone(), "owned-engine-v1:ab:fuel-1").recall(&component, "note.document").await, None, "a changed engine verifies afresh");
    assert_eq!(GuestCodecVerificationCacheV1::disabled().recall(&component, "note.document").await, None);
    let file = std::fs::read_dir(&root).unwrap().next().unwrap().unwrap().path();
    let module: serde_json::Value = serde_json::from_str(semio_hub_trusted_catalog_contract::schema::TRUSTED_CATALOG_SCHEMA_JSON).unwrap();
    let stored: serde_json::Value = serde_json::from_slice(&std::fs::read(&file).unwrap()).unwrap();
    let required: Vec<&str> = module["$defs"]["GuestCodecVerificationV1"]["required"].as_array().unwrap().iter().map(|field| field.as_str().unwrap()).collect();
    assert_eq!(stored.as_object().unwrap().keys().map(String::as_str).collect::<BTreeSet<_>>(), required.iter().copied().collect(), "the record is exactly the schema's fields");
    let forged = String::from_utf8(std::fs::read(&file).unwrap()).unwrap().replace(&"09".repeat(32), &"0a".repeat(32));
    std::fs::write(&file, forged).unwrap();
    assert_eq!(cache.recall(&component, "note.document").await, Some([10u8; 32]), "a record is only a memory; the loader compares it with the trust record");
    std::fs::write(&file, b"{not json").unwrap();
    assert_eq!(cache.recall(&component, "note.document").await, None, "an unreadable record is a miss");
    std::fs::remove_dir_all(&root).unwrap();
}

/// 🪪️ A hub's verification memory is keyed by the owned engine and lives inside its trusted catalog:
/// any build of the same engine at the same data root — another path, a copy, a re-signed binary —
/// recalls what one verified, and copying `trusted-catalog/` carries the memory with it.
#[tokio::test]
async fn a_guest_codec_verification_is_keyed_by_the_engine_and_travels_with_the_catalog() {
    let data = std::env::temp_dir().join(format!("guest-codec-engine-{}-{}", std::process::id(), FIXTURE_SEQUENCE.fetch_add(1, Ordering::SeqCst)));
    let engine = guest_codec_engine_identity();
    assert!(engine.starts_with("owned-engine-v1:") && engine.ends_with(&format!(":fuel-{}", GUEST_CODEC_BUDGET.fuel)), "{engine}");
    assert_eq!(engine, guest_codec_engine_identity(), "the identity is a pure function of the engine");
    let component = [3u8; 32];
    let observed = [5u8; 32];
    assert!(GuestCodecVerificationCacheV1::beside(&data).remember(&component, "note.document", &observed).await);
    assert!(data.join("trusted-catalog").join("guest-codec-verifications").is_dir());
    assert_eq!(GuestCodecVerificationCacheV1::beside(&data).recall(&component, "note.document").await, Some(observed));
    let copied = data.with_extension("copy");
    std::fs::create_dir_all(copied.join("trusted-catalog")).unwrap();
    std::fs::rename(data.join("trusted-catalog").join("guest-codec-verifications"), copied.join("trusted-catalog").join("guest-codec-verifications")).unwrap();
    assert_eq!(GuestCodecVerificationCacheV1::beside(&copied).recall(&component, "note.document").await, Some(observed), "the memory travels with the catalog tree");
    assert_eq!(GuestCodecVerificationCacheV1::beside(&data).recall(&component, "note.document").await, None);
    std::fs::remove_dir_all(&data).unwrap();
    std::fs::remove_dir_all(&copied).unwrap();
}

/// 🧊️ A residency ledger over byte-charged test values, `budget` bytes.
fn residency_ledger(budget: u64) -> Arc<GuestResidencyLedgerV1<Vec<u8>>> {
    GuestResidencyLedgerV1::new(TrustedCatalogGuestResidencyV1 { resident_component_bytes: budget, ..TRUSTED_CATALOG_GUEST_RESIDENCY })
}

/// 🧪️ One operation's `calls` codec calls on `slot`; a compile answers the SHA-256 of the slot's own `source`.
async fn residency_operation(control: &TestControl, slot: &GuestResidencyV1<Vec<u8>>, source: &[u8], calls: usize, compiles: &AtomicUsize) -> Vec<u8> {
    let context = control.context();
    let mut answers = Vec::with_capacity(calls);
    for _ in 0..calls {
        let value = slot
            .acquire(&context, || async {
                compiles.fetch_add(1, Ordering::SeqCst);
                Ok::<_, AuthorityError>(Sha256::digest(source).to_vec())
            })
            .await
            .unwrap();
        answers.push(value.as_ref().clone());
    }
    assert!(answers.windows(2).all(|pair| pair[0] == pair[1]), "every call of one operation answers the same guest");
    answers.pop().unwrap()
}

/// 🧊️ A compiled guest that fits stays resident, a resident guest serves later operations without compiling
/// again, and idleness alone releases nothing.
#[tokio::test]
async fn a_compiled_guest_that_fits_stays_resident_and_idleness_releases_nothing() {
    let (control, compiles) = (TestControl::new(), AtomicUsize::new(0));
    let ledger = residency_ledger(2_000);
    let (a, b) = (ledger.register(1_000), ledger.register(1_000));
    residency_operation(&control, &a, b"a", 1, &compiles).await;
    residency_operation(&control, &b, b"b", 1, &compiles).await;
    residency_operation(&control, &a, b"a", 1, &compiles).await;
    tokio::time::sleep(std::time::Duration::from_millis(20)).await;
    assert!(a.is_resident() && b.is_resident(), "idleness alone releases nothing");
    assert_eq!(ledger.state(), TrustedCatalogGuestResidencyStateV1 { budget_bytes: 2_000, registered_guests: 2, resident_guests: 2, resident_bytes: 2_000, footprint_bytes: 0, hits: 1, compiles: 2, admitted: 2, bypassed: 0, released: 0, compile_micros: ledger.state().compile_micros });
}

/// 🧮️ An operation counts one use however many calls it makes, a guest that does not fit serves every call
/// of the operation that compiled it and is dropped with it, and it displaces the least recently used
/// resident guest only once it has been used in more operations than that guest.
#[tokio::test]
async fn one_operation_counts_one_use_and_an_unadmitted_guest_lives_exactly_as_long_as_its_operation() {
    let (control, compiles) = (TestControl::new(), AtomicUsize::new(0));
    let ledger = residency_ledger(1_000);
    let (a, b) = (ledger.register(1_000), ledger.register(1_000));
    residency_operation(&control, &a, b"a", 3, &compiles).await;
    assert_eq!(compiles.load(Ordering::SeqCst), 1);
    assert!(a.is_resident());
    residency_operation(&control, &b, b"b", 3, &compiles).await;
    assert_eq!(compiles.load(Ordering::SeqCst), 2, "the unadmitted guest served all three calls of its operation from one compile");
    assert!(!b.is_resident() && a.is_resident(), "a guest used in no more operations than the one it would release does not displace it");
    assert_eq!(ledger.state().resident_guests, 1, "the unadmitted guest was dropped with its operation");
    residency_operation(&control, &b, b"b", 3, &compiles).await;
    assert!(!b.is_resident(), "one use each: a tie keeps the resident guest");
    residency_operation(&control, &b, b"b", 1, &compiles).await;
    assert!(b.is_resident() && !a.is_resident(), "a guest used in more operations displaces the least recently used one");
    assert_eq!(compiles.load(Ordering::SeqCst), 4);
    let state = ledger.state();
    assert_eq!((state.admitted, state.bypassed, state.released, state.hits), (2, 2, 1, 6));
}

/// 🔒️ A resident guest a running operation holds is never released, even for a guest used in more
/// operations, and a zero budget keeps nothing resident while operations that reach a guest at once still
/// share its one compile.
#[tokio::test]
async fn held_guests_are_never_released_and_a_zero_budget_keeps_nothing_resident() {
    let (control, compiles) = (TestControl::new(), AtomicUsize::new(0));
    let ledger = residency_ledger(1_000);
    let (a, b) = (ledger.register(1_000), ledger.register(1_000));
    residency_operation(&control, &b, b"b", 1, &compiles).await;
    let holding = control.context();
    let held = b.acquire(&holding, || async { Ok::<_, AuthorityError>(b"never".to_vec()) }).await.unwrap();
    for _ in 0..4 {
        residency_operation(&control, &a, b"a", 1, &compiles).await;
    }
    assert!(b.is_resident() && !a.is_resident(), "the held guest stays although the other was used in more operations");
    assert_eq!(compiles.load(Ordering::SeqCst), 5);
    drop((held, holding));
    residency_operation(&control, &a, b"a", 1, &compiles).await;
    assert!(a.is_resident() && !b.is_resident(), "once released by its operation, the less used guest makes room");
    let zero = residency_ledger(0);
    let (c, zero_compiles) = (zero.register(1), AtomicUsize::new(0));
    let first = control.context();
    let shared = c.acquire(&first, || async { Ok::<_, AuthorityError>(b"c".to_vec()) }).await.unwrap();
    let second = control.context();
    let again = c.acquire(&second, || async { Ok::<_, AuthorityError>(b"never".to_vec()) }).await.unwrap();
    assert!(Arc::ptr_eq(&shared, &again), "an operation that reaches a held guest shares its compile");
    drop((shared, again, first, second));
    residency_operation(&control, &c, b"c", 2, &zero_compiles).await;
    assert_eq!(zero_compiles.load(Ordering::SeqCst), 1);
    assert!(!c.is_resident() && zero.state().resident_guests == 0 && zero.state().admitted == 0, "a zero budget keeps nothing resident");
}

/// 🔁️ The scale law: twelve guests of different sizes, budget for a third of their bytes, sixty rounds of a
/// round-robin where every operation makes three codec calls (a creation's genesis and two validations). After
/// the first round the resident set never changes, every round compiles exactly the guests that do not fit —
/// once per operation — every answer is its own guest's, and the resident charge never exceeds the budget once
/// an operation ends. A pure least-recently-used ledger compiles every guest in every round of the same trace.
#[tokio::test]
async fn a_round_robin_over_more_guests_than_fit_keeps_a_stable_resident_set() {
    const SIZES: [u64; 12] = [500, 300, 800, 200, 600, 400, 700, 100, 900, 300, 500, 200];
    const BUDGET: u64 = 2_000;
    const ROUNDS: usize = 60;
    let (control, compiles) = (TestControl::new(), AtomicUsize::new(0));
    let ledger = residency_ledger(BUDGET);
    let slots: Vec<_> = SIZES.iter().map(|size| ledger.register(*size)).collect();
    let sources: Vec<Vec<u8>> = (0..SIZES.len()).map(|index| format!("guest-{index}").into_bytes()).collect();
    let (mut resident_sets, mut compiled_per_round, mut released_per_round) = (Vec::new(), Vec::new(), Vec::new());
    for _ in 0..ROUNDS {
        let before = compiles.load(Ordering::SeqCst);
        for (slot, source) in slots.iter().zip(&sources) {
            assert_eq!(residency_operation(&control, slot, source, 3, &compiles).await, Sha256::digest(source).to_vec(), "a guest answers from its own source, compiled again or not");
            assert!(ledger.state().resident_bytes <= BUDGET, "the resident charge fits the budget once the operation ended");
        }
        compiled_per_round.push(compiles.load(Ordering::SeqCst) - before);
        released_per_round.push(ledger.state().released);
        resident_sets.push(slots.iter().map(GuestResidencyV1::is_resident).collect::<Vec<_>>());
    }
    let resident = resident_sets[1].iter().filter(|resident| **resident).count();
    assert!(resident >= 2, "the budget holds several guests: {resident_sets:?}");
    assert!(resident_sets[1..].windows(2).all(|pair| pair[0] == pair[1]), "the resident set is stable after the first round");
    assert!(compiled_per_round[1..].iter().all(|compiled| *compiled == SIZES.len() - resident), "each round compiles exactly the guests that do not fit: {compiled_per_round:?}");
    assert!(released_per_round.windows(2).skip(1).all(|pair| pair[0] == pair[1]), "no resident guest is released after the first round: {released_per_round:?}");
    let mut lru: Vec<usize> = Vec::new();
    let mut lru_compiles_per_round = Vec::new();
    for _ in 0..ROUNDS {
        let mut compiled = 0;
        for (index, size) in SIZES.iter().enumerate() {
            if let Some(at) = lru.iter().position(|resident| *resident == index) {
                lru.remove(at);
            } else {
                compiled += 1;
                while lru.iter().map(|resident| SIZES[*resident]).sum::<u64>() + size > BUDGET && !lru.is_empty() {
                    lru.remove(0);
                }
            }
            lru.push(index);
        }
        lru_compiles_per_round.push(compiled);
    }
    assert!(lru_compiles_per_round[1..].iter().all(|compiled| *compiled == SIZES.len()), "the same trace thrashes a pure LRU ledger: {lru_compiles_per_round:?}");
}

/// 🌊️ A workload that moved on displaces the guests it left: after a long round-robin, two guests that were
/// never resident become resident within a bounded number of operations (use counts age), and from then on
/// their operations compile nothing.
#[tokio::test]
async fn a_workload_that_moved_on_displaces_the_guests_it_left() {
    const SIZES: [u64; 8] = [400, 400, 400, 400, 400, 400, 400, 400];
    let (control, compiles) = (TestControl::new(), AtomicUsize::new(0));
    let ledger = residency_ledger(1_600);
    let slots: Vec<_> = SIZES.iter().map(|size| ledger.register(*size)).collect();
    for _ in 0..40 {
        for (index, slot) in slots.iter().enumerate() {
            residency_operation(&control, slot, &[index as u8], 1, &compiles).await;
        }
    }
    let cold: Vec<usize> = (0..SIZES.len()).filter(|index| !slots[*index].is_resident()).take(2).collect();
    assert_eq!(cold.len(), 2);
    let aging = TRUSTED_CATALOG_GUEST_RESIDENCY.access_count_aging_per_guest as usize * SIZES.len();
    let mut operations = 0;
    while !(slots[cold[0]].is_resident() && slots[cold[1]].is_resident()) {
        assert!(operations < 2 * aging, "the new workload became resident within two aging windows");
        residency_operation(&control, &slots[cold[operations % 2]], &[cold[operations % 2] as u8], 1, &compiles).await;
        operations += 1;
    }
    let settled = compiles.load(Ordering::SeqCst);
    for operation in 0..20 {
        residency_operation(&control, &slots[cold[operation % 2]], &[cold[operation % 2] as u8], 1, &compiles).await;
    }
    assert_eq!(compiles.load(Ordering::SeqCst), settled, "the new workload's operations compile nothing once resident");
}

/// 🤝️ Operations that reach one guest at once share its single compile, and each of them is a use: eight
/// concurrent operations outnumber the two of a resident guest, so the shared compile is admitted in its place.
#[tokio::test]
async fn concurrent_operations_share_one_compile() {
    let control = TestControl::new();
    let compiles = AtomicUsize::new(0);
    let ledger = residency_ledger(1_000);
    let (hot, cold) = (ledger.register(1_000), ledger.register(1_000));
    for _ in 0..2 {
        residency_operation(&control, &hot, b"hot", 1, &compiles).await;
    }
    let barrier = tokio::sync::Barrier::new(8);
    let operations = (0..8).map(|_| async {
        let context = control.context();
        let value = cold
            .acquire(&context, || async {
                compiles.fetch_add(1, Ordering::SeqCst);
                Ok::<_, AuthorityError>(b"cold".to_vec())
            })
            .await
            .unwrap();
        barrier.wait().await;
        value
    });
    let answers = futures::future::join_all(operations).await;
    assert!(answers.windows(2).all(|pair| Arc::ptr_eq(&pair[0], &pair[1])), "every concurrent operation holds the same compile");
    assert_eq!(compiles.load(Ordering::SeqCst), 2, "one compile for the resident guest, one shared by eight operations");
    assert!(cold.is_resident() && !hot.is_resident(), "the guest eight operations used displaced the one two used");
}

/// 📐️ A test guest whose state grows in a call, as a compiled guest's does when its first codec call assembles its origin.
struct GrowingGuest(std::sync::atomic::AtomicU64);

impl GuestResidentFootprintV1 for GrowingGuest {
    /// 📐️ What the call left the guest holding.
    fn footprint_bytes(&self) -> u64 {
        self.0.load(Ordering::SeqCst)
    }
}

/// 🧪️ One operation's single call on `slot`, after which its guest holds `footprint` bytes beyond its registration.
async fn growing_operation(control: &TestControl, slot: &GuestResidencyV1<GrowingGuest>, footprint: u64) {
    let context = control.context();
    let guest = slot.acquire(&context, || async { Ok::<_, AuthorityError>(GrowingGuest(std::sync::atomic::AtomicU64::new(0))) }).await.unwrap();
    guest.0.store(footprint, Ordering::SeqCst);
    slot.remeasure(&guest, &context).await;
}

/// 📐️ A guest is charged what it holds after each call, not only what it was registered with: one that grew past what the
/// budget has left stays by releasing the least recently used unheld guests when it was used in more operations than they
/// were, a guest that then does not fit is served without staying, and one that grew past the whole budget serves the
/// operation holding it and is dropped with it.
#[tokio::test]
async fn a_guest_that_grows_in_a_call_is_charged_what_it_holds() {
    let control = TestControl::new();
    let ledger = GuestResidencyLedgerV1::<GrowingGuest>::new(TrustedCatalogGuestResidencyV1 { resident_component_bytes: 3_000, ..TRUSTED_CATALOG_GUEST_RESIDENCY });
    let (a, b) = (ledger.register(1_000), ledger.register(1_000));
    growing_operation(&control, &b, 0).await;
    growing_operation(&control, &a, 0).await;
    growing_operation(&control, &a, 0).await;
    assert!(a.is_resident() && b.is_resident());
    assert_eq!((ledger.state().resident_bytes, ledger.state().footprint_bytes), (2_000, 0));
    growing_operation(&control, &a, 1_500).await;
    let grown = ledger.state();
    assert!(a.is_resident() && !b.is_resident(), "the grown guest, used in more operations, displaced the least recently used one");
    assert_eq!((grown.resident_guests, grown.resident_bytes, grown.footprint_bytes, grown.released), (1, 2_500, 1_500, 1));
    growing_operation(&control, &b, 0).await;
    assert!(a.is_resident() && !b.is_resident() && ledger.state().bypassed == 1, "a guest used less often than the grown one is served without staying");
    let context = control.context();
    let guest = a.acquire(&context, || async { Ok::<_, AuthorityError>(GrowingGuest(std::sync::atomic::AtomicU64::new(0))) }).await.unwrap();
    guest.0.store(2_500, Ordering::SeqCst);
    a.remeasure(&guest, &context).await;
    assert!(!a.is_resident() && ledger.state().resident_guests == 1, "a guest grown past the whole budget stays only with the operation holding it");
    drop((guest, context));
    let released = ledger.state();
    assert_eq!((released.resident_guests, released.resident_bytes, released.footprint_bytes, released.released), (0, 0, 0, 2), "and is dropped with it");
}

/// 🧵️ A guest codec call interprets on the blocking pool, never on the worker awaiting it: another
/// task on a one-thread runtime keeps running for the whole call, every fuel observation reaches the
/// caller's context in order, and a cancelled caller is released at its next observation — or within
/// the poll between observations — with the call itself cancelled, as it is when the caller is dropped.
#[test]
fn guest_codec_calls_run_off_the_async_worker_and_relay_their_fuel() {
    let runtime = tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap();
    runtime.block_on(async {
        let control = TestControl::new();
        let context = control.context();
        let ticks = Arc::new(AtomicUsize::new(0));
        let ticker = {
            let ticks = ticks.clone();
            tokio::spawn(async move {
                loop {
                    ticks.fetch_add(1, Ordering::SeqCst);
                    tokio::time::sleep(std::time::Duration::from_millis(5)).await;
                }
            })
        };
        let answer = interpret_off_worker(&context, |_handle, progress, _cancellation| {
            for fuel in [10, 20, 30] {
                std::thread::sleep(std::time::Duration::from_millis(100));
                progress(fuel);
            }
            Ok(42u32)
        })
        .await;
        assert!(matches!(answer, Ok(Ok(42))), "{answer:?}");
        assert!(ticks.load(Ordering::SeqCst) >= 20, "the awaiting worker kept running other tasks: {} ticks", ticks.load(Ordering::SeqCst));
        let relayed: Vec<u64> = control.progress.lock().unwrap().iter().filter(|progress| progress.stage == AuthorityProgressStage::GuestCodecExecuting).map(|progress| progress.completed_units).collect();
        assert_eq!(relayed, vec![10, 20, 30]);
        let observed = |observes: Arc<AtomicBool>| {
            move |_handle: &tokio::runtime::Handle, progress: &mut dyn FnMut(u64), cancellation: &semio_framework_plugin_guest_contract::GuestCallCancellation| -> Result<u32, semio_framework_plugin_guest_contract::TurnFault> {
                progress(1);
                let started = std::time::Instant::now();
                while !cancellation.is_cancelled() && started.elapsed() < std::time::Duration::from_secs(10) {
                    std::thread::sleep(std::time::Duration::from_millis(1));
                }
                observes.store(cancellation.is_cancelled(), Ordering::SeqCst);
                Err(semio_framework_plugin_guest_contract::TurnFault::Cancelled)
            }
        };
        let settled = |observes: Arc<AtomicBool>| async move {
            let started = std::time::Instant::now();
            while !observes.load(Ordering::SeqCst) && started.elapsed() < std::time::Duration::from_secs(1) {
                tokio::time::sleep(std::time::Duration::from_millis(5)).await;
            }
            observes.load(Ordering::SeqCst)
        };
        control.cancelled.store(true, Ordering::SeqCst);
        let refused = Arc::new(AtomicBool::new(false));
        let started = std::time::Instant::now();
        let cancelled = interpret_off_worker(&context, observed(refused.clone())).await;
        assert!(matches!(cancelled, Err(AuthorityError::Cancelled)), "{cancelled:?}");
        assert!(started.elapsed() < std::time::Duration::from_millis(300), "a cancelled caller is released at its next observation, not when the call ends");
        assert!(settled(refused).await, "the released caller cancelled its call");
        let quiet = Arc::new(AtomicBool::new(false));
        let started = std::time::Instant::now();
        let silent = interpret_off_worker(&context, {
            let quiet = quiet.clone();
            move |_handle, _progress, cancellation| {
                while !cancellation.is_cancelled() && started.elapsed() < std::time::Duration::from_secs(10) {
                    std::thread::sleep(std::time::Duration::from_millis(1));
                }
                quiet.store(cancellation.is_cancelled(), Ordering::SeqCst);
                Ok(0u32)
            }
        })
        .await;
        assert!(matches!(silent, Err(AuthorityError::Cancelled)), "{silent:?}");
        assert!(started.elapsed() < GUEST_CALL_CANCELLATION_POLL * 6, "a cancelled caller that sees no observation is released within its poll: {:?}", started.elapsed());
        assert!(settled(quiet).await, "the call that reported nothing was cancelled too");
        control.cancelled.store(false, Ordering::SeqCst);
        let dropped = Arc::new(AtomicBool::new(false));
        let abandoned = tokio::time::timeout(std::time::Duration::from_millis(100), interpret_off_worker(&context, observed(dropped.clone()))).await;
        assert!(abandoned.is_err(), "an uncancelled caller keeps awaiting its call");
        assert!(settled(dropped).await, "dropping the awaiting caller cancelled its call");
        ticker.abort();
    });
}

/// 🛑️ LAW (H11, session 13): a hub asked to stop exits within about a second while its background catalog
/// verification interprets. The shutdown aborts the verification; the aborted verification cancels its guest call,
/// which the interpreter ends at its next step; so dropping the runtime — what the hub's `main` does once `serve`
/// returned — waits for no interpretation. Before the interpreter observed its caller the drop waited for the call's
/// own fuel bound: SIGTERM → exit 17.9–25.2 s on catalog B3 (`📓️wp-h11.md`). The guest's `pack-schema-hash` never
/// returns, so only the cancellation can end it.
#[test]
fn an_aborted_catalog_verification_leaves_no_interpretation_for_the_runtime_to_wait_on() {
    let runtime = tokio::runtime::Builder::new_multi_thread().enable_all().build().unwrap();
    let mut fixture = prepared_fixture();
    install_owned_guest(&mut fixture, OwnedTestHash::Spins);
    let catalog = Arc::new(runtime.block_on(async { load_fixture(&fixture, &[], &TestControl::new().context()).await }).expect("a catalog whose row waits for its guest"));
    let control = Arc::new(TestControl::new());
    let verification = runtime.spawn({
        let (catalog, control) = (catalog.clone(), control.clone());
        async move { catalog.verify_pending_guests(&control.context()).await }
    });
    let interpreting = |control: &TestControl| control.progress.lock().unwrap().iter().any(|progress| progress.stage == AuthorityProgressStage::GuestCompiling && progress.completed_units == 1);
    let waited = std::time::Instant::now();
    while !interpreting(&*control) && waited.elapsed() < std::time::Duration::from_secs(30) {
        std::thread::sleep(std::time::Duration::from_millis(10));
    }
    assert!(interpreting(&*control), "the verification compiled its guest and interprets it");
    std::thread::sleep(std::time::Duration::from_millis(200));
    assert!(!verification.is_finished(), "the spinning guest keeps the verification in flight");
    let started = std::time::Instant::now();
    verification.abort();
    let aborted = runtime.block_on(verification);
    drop(runtime);
    assert!(aborted.is_err_and(|error| error.is_cancelled()), "the shutdown aborted the verification");
    assert!(started.elapsed() < std::time::Duration::from_secs(1), "the runtime was dropped with no interpretation left to wait on: {:?}", started.elapsed());
}

#[test]
fn trusted_descriptor_wire_materialization_matches_neutral_boundaries() {
    let fixture: serde_json::Value = serde_json::from_str(semio_hub_testing::hub_source("../🧰️framework/🛍️products/💻️os/🔨️modules/🎒️pack/🌱️value/🧪️tests/🧫️fixtures/🧮️wire-materialization/🔣️.json")).unwrap();
    for row in fixture["cases"].as_array().unwrap() {
        let encoded = row["rawHex"].as_str().unwrap();
        let bytes: Vec<_> = (0..encoded.len()).step_by(2).map(|index| u8::from_str_radix(&encoded[index..index + 2], 16).unwrap()).collect();
        let limits = &row["limits"];
        let mut options = os_store::PackDecodeOptions::default();
        options.limits.max_file_len = limits["maxFileLen"].as_u64().unwrap();
        options.limits.max_segment_len = limits["maxSegmentLen"].as_u64().unwrap();
        options.limits.max_symbols = u32::try_from(limits["maxSymbols"].as_u64().unwrap()).unwrap();
        options.limits.max_depth = u16::try_from(limits["maxDepth"].as_u64().unwrap()).unwrap();
        options.limits.max_items = limits["maxItems"].as_u64().unwrap();
        options.limits.max_total_alloc = u64::MAX;
        let decoded = os_pack::pack_rt::decode_wire_value_with_options(&bytes, &options);
        match row["grammar"]["outcome"].as_str().unwrap() {
            "accepted" => assert_eq!(serde_json::to_value(decoded.expect("admitted bounded value")).unwrap(), row["grammar"]["value"], "{}", row["id"]),
            "limit" => assert!(matches!(decoded, Err(os_store::PackError::LimitExceeded(_))), "{}: {decoded:?}", row["id"]),
            "malformed" => {
                assert!(matches!(decoded, Err(os_store::PackError::Malformed { .. })), "{}: {decoded:?}", row["id"]);
                assert!(matches!(os_pack::pack_rt::decode_wire_value(&bytes), Err(os_store::PackError::Malformed { .. })), "default wire facade: {}", row["id"]);
            }
            "truncated" => {
                let expected = row["grammar"]["offset"].as_u64().unwrap();
                assert_eq!(expected, bytes.len() as u64);
                assert!(matches!(decoded, Err(os_store::PackError::Truncated(offset)) if offset == expected), "{}: {decoded:?}", row["id"]);
                assert!(matches!(os_pack::pack_rt::decode_wire_value(&bytes), Err(os_store::PackError::Truncated(offset)) if offset == expected), "default wire facade: {}", row["id"]);
            }
            outcome => panic!("unknown bounded wire outcome {outcome}"),
        }
    }
    let mut amplified = Vec::new();
    os_pack::pack_rt::write_varint_u64(&mut amplified, 1);
    os_pack::pack_rt::write_varint_u64(&mut amplified, 2 * 1024 * 1024);
    amplified.resize(amplified.len() + 2 * 1024 * 1024, b'x');
    amplified.extend_from_slice(&[1, 1, 0x11, 0x0c, 32]);
    for _ in 0..32 {
        amplified.extend_from_slice(&[0x06, 0]);
    }
    assert!((amplified.len() as u64) < TRUSTED_DESCRIPTOR_MAX_BYTES);
    let result = decode_package_descriptor(&amplified);
    assert!(matches!(&result, Err(AuthorityError::Catalog(message)) if message.contains("max_total_alloc")), "actual Hub materialization fence: {result:?}");
}

use directory::os_directory::io::binary::artifact_hash::hex_lower;
use std::sync::Arc;
use directory::io::ArtifactCatalogCapability;
use directory::os_store::serialization::ArtifactCodec;
use semio_hub_artifact_authority::{AuthorityError, AuthorityProgress, AuthorityProgressStage, OperationContext, TrustedArtifactIdentity};
use std::collections::BTreeSet;
use directory::os_component_receipt::ComponentReceiptV1;
use directory::os_directory::{DocumentDescriptor, DocumentOpenGrantV1, DocumentOpenSurfaceRoleV1};
use directory::os_directory::schema::DocumentOpenBrowserActorV1;
use semio_framework::{DslValue, PackageDescriptor};
use semio_hub_trusted_catalog::{GUEST_CALL_CANCELLATION_POLL, GUEST_CODEC_BUDGET, GuestCodecVerificationCacheV1, GuestResidencyLedgerV1, GuestResidencyV1, GuestResidentFootprintV1, TrustedCatalogLoadProgressCellV1, TrustedCatalogLoader, TrustedCatalogPublicationOutcome, TrustedCatalogPublisher, VerifiedTrustedCatalog, guest_codec_engine_identity, guest_verification_concurrency, interpret_off_worker};
use semio_framework_hash::{Hasher, Sha256};
use semio_hub_trusted_catalog_descriptor::{MostGeneralDialect, NativeCodecBinding, NativeCodecProviderPackageV1, NativeCodecProviderRequirementV1, NativeCodecProviderSourceV1, TrustedCatalogAsset, TrustedRetainedFile, VerifiedTrustedPackage, append_trusted_profile_dependencies, decode_package_descriptor, descriptor_open_targets, descriptor_open_targets_answer, most_general_dialect, open_target_codec_package, owner_preferred_creation, selected_closure_digest, trusted_profile_generation, validate_bundle, validate_descriptor, validate_descriptor_open_target, validate_native_bindings};
use std::path::Path;
use semio_hub_trusted_catalog_contract::schema::{TRUSTED_BUNDLE_SCHEMA_VERSION, TRUSTED_CATALOG_GUEST_RESIDENCY, TrustedBundleFileV1, TrustedBundleGrantV1, TrustedBundleIdentityV1, TrustedBundleOpenRole, TrustedBundleOpenTargetV1, TrustedBundlePackageRole, TrustedBundlePackageV1, TrustedBundleProfileV1, TrustedBundleRendererTarget, TrustedBundleV1, TrustedCatalogCurrentPointerV1, TrustedCatalogGuestResidencyStateV1, TrustedCatalogGuestResidencyV1, TrustedCatalogPackagePhaseV1, publication_revision};
use semio_hub_artifact_authority::adapters::TRUSTED_CATALOG_MAX_CODECS;
use semio_hub_trusted_catalog_contract::{TRUSTED_COMPONENT_MAX_BYTES, TRUSTED_DESCRIPTOR_MAX_BYTES, TRUSTED_IDENTITY_MAX_BYTES, TRUSTED_READ_CHUNK_BYTES, TrustedCatalogDataRoot, TrustedCatalogGenerationRoot, TrustedCatalogRelativePathV1, catalog, catalog_error, dual_hash, ensure_count, valid_identity, valid_package_id, validate_file};
use directory::os_store;
#[cfg(all(any(test, feature = "testkit"),unix))]
use semio_hub_trusted_catalog_contract::create_fifo_fixture;
#[cfg(any(test,feature="integration-fixtures"))]
use semio_hub_trusted_catalog::{fixture_component_receipt, headless_stdio_fixture_package, write_fixture_plugin_module};
/// 🧳️ Stages exact existing fixture bytes under a real private publication data root.
fn stage_publication_fixture(fixture: &FixtureDirectory, data: &Path) -> serde_json::Value {
    let generation = fixture.bundle["profiles"][0]["generationId"].as_str().unwrap();
    let root = data.join("trusted-catalog/generations").join(generation);
    std::fs::create_dir_all(&root).unwrap();
    for record in fixture.bundle["packages"].as_array().unwrap() {
        let mut paths = vec![record["component"]["path"].as_str().unwrap().to_owned(), record["descriptor"]["path"].as_str().unwrap().to_owned(), record["pluginModule"]["path"].as_str().unwrap().to_owned()];
        if let Some(path) = record["browserActor"]["path"].as_str() {
            paths.push(path.to_owned());
        }
        let manifest: serde_json::Value = serde_json::from_slice(&std::fs::read(fixture.root.join(record["pluginModule"]["path"].as_str().unwrap())).unwrap()).unwrap();
        paths.extend(manifest["files"].as_array().unwrap().iter().map(|file| semio_hub_trusted_catalog_contract::plugin_module::plugin_module_blob_path(file["sha256"].as_str().unwrap())));
        for path in &paths {
            let destination = root.join(path);
            std::fs::create_dir_all(destination.parent().unwrap()).unwrap();
            std::fs::copy(fixture.root.join(path), destination).unwrap();
        }
    }
    let bundle = serde_json::to_vec(&fixture.bundle).unwrap();
    std::fs::write(root.join("trusted-catalog.json"), &bundle).unwrap();
    serde_json::json!({"schema":"semio.hub.trusted-catalog-publication/v1","requestId":"11".repeat(16),"profileId":"fixture","generationId":generation,"bundleSha256":hex_lower(&Sha256::digest(&bundle)),"expectedCurrentSha256":null})
}

/// 🧾️ Keeps indeterminate Windows visibility explicit in platform-neutral native tests.
fn publication_fixture_receipt(outcome: TrustedCatalogPublicationOutcome) -> serde_json::Value {
    let (bytes, expected) = match outcome {
        TrustedCatalogPublicationOutcome::Durable(bytes) => (bytes, "durable"),
        TrustedCatalogPublicationOutcome::Unconfirmed(bytes) => (bytes, "replaced-unconfirmed"),
    };
    let receipt: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
    assert_eq!(receipt["outcome"], expected);
    receipt
}

#[test]
fn trusted_publication_revision_matches_neutral_closed_u64_cases() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!("../🧫️fixtures/📤️publication/🔄️cas.json")).unwrap();
    for row in fixture["cases"].as_array().unwrap() {
        let current = row["currentRevision"].as_str().map(publication_revision).transpose();
        let result = current.and_then(|current| {
            if let Some(expected) = row["expectedRevision"].as_str() {
                if Some(publication_revision(expected)?) != current {
                    return Err(catalog("stale fixture token"));
                }
            }
            current.unwrap_or(0).checked_add(1).ok_or_else(|| catalog("revision exhausted"))
        });
        assert_eq!(result.is_ok(), row["accepted"].as_bool().unwrap(), "{}", row["id"]);
        if let Some(next) = row["nextRevision"].as_str() {
            assert_eq!(result.unwrap().to_string(), next);
        }
    }
}

#[tokio::test]
async fn trusted_publication_cas_races_and_aba_use_real_catalog_loader() {
    let a = prepared_fixture();
    let b = prepared_fixture();
    let data = a.root.join("publication-data");
    let mut command_a = stage_publication_fixture(&a, &data);
    let mut command_b = stage_publication_fixture(&b, &data);
    let provider_a = FixtureProviderSource::new(vec![a.binding()]);
    let provider_b = FixtureProviderSource::new(vec![b.binding()]);
    let control = TestControl::new();
    let context = control.context();
    let initial = publication_fixture_receipt(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&command_a).unwrap(), &provider_a, &context).await.unwrap());
    assert_eq!(initial["publicationRevision"], "1");
    assert!(document_codec(&a.schema).await.unwrap().is_none(), "publication installed a codec");
    command_b["expectedCurrentSha256"] = initial["currentSha256"].clone();
    command_b["requestId"] = "22".repeat(16).into();
    let middle = publication_fixture_receipt(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&command_b).unwrap(), &provider_b, &context).await.unwrap());
    command_a["expectedCurrentSha256"] = middle["currentSha256"].clone();
    command_a["requestId"] = "33".repeat(16).into();
    let restored = publication_fixture_receipt(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&command_a).unwrap(), &provider_a, &context).await.unwrap());
    assert_eq!(restored["publicationRevision"], "3");
    assert_eq!(restored["generationId"], initial["generationId"]);
    assert_ne!(restored["currentSha256"], initial["currentSha256"]);
    let pointer_path = data.join("trusted-catalog/current.json");
    let before = std::fs::read(&pointer_path).unwrap();
    command_a["expectedCurrentSha256"] = initial["currentSha256"].clone();
    assert!(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&command_a).unwrap(), &provider_a, &context).await.is_err());
    assert_eq!(std::fs::read(&pointer_path).unwrap(), before);
    let loaded = TrustedCatalogLoader::load_current(&data, &provider_a, &context).await.unwrap().unwrap();
    assert_eq!(loaded.generation_id(), initial["generationId"].as_str().unwrap());
    command_a["expectedCurrentSha256"] = restored["currentSha256"].clone();
    command_b["expectedCurrentSha256"] = restored["currentSha256"].clone();
    command_a["requestId"] = "44".repeat(16).into();
    command_b["requestId"] = "55".repeat(16).into();
    let bytes_a = serde_json::to_vec(&command_a).unwrap();
    let bytes_b = serde_json::to_vec(&command_b).unwrap();
    let (left, right) = tokio::join!(TrustedCatalogPublisher::publish_current(&data, &bytes_a, &provider_a, &context), TrustedCatalogPublisher::publish_current(&data, &bytes_b, &provider_b, &context));
    assert_ne!(left.is_ok(), right.is_ok(), "competing current token admitted two or zero publishers");
    let winner = publication_fixture_receipt(left.or(right).unwrap());
    assert_eq!(winner["publicationRevision"], "4");
    let provider = if winner["generationId"] == command_a["generationId"] { &provider_a } else { &provider_b };
    assert_eq!(TrustedCatalogLoader::load_current(&data, provider, &context).await.unwrap().unwrap().generation_id(), winner["generationId"].as_str().unwrap());
    let mut maximum = TrustedCatalogCurrentPointerV1::decode(&std::fs::read(&pointer_path).unwrap()).unwrap();
    maximum.publication_revision = u64::MAX.to_string();
    let maximum_bytes = maximum.encode().unwrap();
    std::fs::write(&pointer_path, &maximum_bytes).unwrap();
    let mut exhausted = if winner["generationId"] == command_a["generationId"] { command_a } else { command_b };
    exhausted["expectedCurrentSha256"] = hex_lower(&Sha256::digest(&maximum_bytes)).into();
    assert!(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&exhausted).unwrap(), provider, &context).await.is_err());
    assert_eq!(std::fs::read(&pointer_path).unwrap(), maximum_bytes);
}

struct PublicationLeafSwap {
    path: PathBuf,
    swapped: AtomicBool,
}

impl AuthorityOperationControl for PublicationLeafSwap {
    fn now_ms(&self) -> u64 {
        0
    }
    fn is_cancelled(&self) -> bool {
        false
    }
    fn report(&self, progress: AuthorityProgress) {
        if progress.stage == AuthorityProgressStage::CatalogResolved && !self.swapped.swap(true, Ordering::SeqCst) {
            std::fs::write(&self.path, b"substituted-after-verified-candidate").unwrap();
        }
    }
}

#[tokio::test]
async fn trusted_publication_post_verification_leaf_substitution_preserves_current() {
    for field in ["component", "descriptor", "browserActor", "pluginModule", "bundle"] {
        let a = prepared_fixture();
        let b = prepared_fixture();
        let data = a.root.join("publication-data");
        let command_a = stage_publication_fixture(&a, &data);
        let mut command_b = stage_publication_fixture(&b, &data);
        let provider_a = FixtureProviderSource::new(vec![a.binding()]);
        let provider_b = FixtureProviderSource::new(vec![b.binding()]);
        let control = TestControl::new();
        let context = control.context();
        let current = publication_fixture_receipt(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&command_a).unwrap(), &provider_a, &context).await.unwrap());
        command_b["expectedCurrentSha256"] = current["currentSha256"].clone();
        let relative = if field == "bundle" { "trusted-catalog.json" } else { b.bundle["packages"][0][field]["path"].as_str().unwrap() };
        let path = data.join("trusted-catalog/generations").join(command_b["generationId"].as_str().unwrap()).join(relative);
        let swap = PublicationLeafSwap { path, swapped: AtomicBool::new(false) };
        let swap_context = OperationContext::new(u64::MAX, AuthorityLimits::maximum(), &swap);
        let pointer = data.join("trusted-catalog/current.json");
        let before = std::fs::read(&pointer).unwrap();
        assert!(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&command_b).unwrap(), &provider_b, &swap_context).await.is_err(), "{field}");
        assert!(swap.swapped.load(Ordering::SeqCst));
        assert_eq!(std::fs::read(&pointer).unwrap(), before);
        assert!(document_codec(&b.schema).await.unwrap().is_none(), "failed candidate installed a codec");
        assert_eq!(TrustedCatalogLoader::load_current(&data, &provider_a, &context).await.unwrap().unwrap().generation_id(), current["generationId"].as_str().unwrap());
    }
}

#[tokio::test]
async fn trusted_publication_command_refuses_invalid_authority_before_initial_pointer() {
    let fixture = prepared_fixture();
    let data = fixture.root.join("publication-data");
    let command = stage_publication_fixture(&fixture, &data);
    let provider = FixtureProviderSource::new(vec![fixture.binding()]);
    let control = TestControl::new();
    for field in ["bundlePath", "publicationRevision", "requestId", "expectedCurrentSha256"] {
        let mut rejected = command.clone();
        match field {
            "bundlePath" => rejected[field] = "/untrusted".into(),
            "publicationRevision" => rejected[field] = "1".into(),
            "requestId" => rejected[field] = "".into(),
            _ => {
                rejected.as_object_mut().unwrap().remove(field);
            }
        }
        assert!(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&rejected).unwrap(), &provider, &control.context()).await.is_err(), "{field}");
        assert!(!data.join("trusted-catalog/current.json").exists());
        assert!(provider.calls.lock().unwrap().is_empty());
    }
    control.cancelled.store(true, Ordering::SeqCst);
    assert!(TrustedCatalogPublisher::publish_current(&data, &serde_json::to_vec(&command).unwrap(), &provider, &control.context()).await.is_err());
    assert!(!data.join("trusted-catalog/current.json").exists());
}

struct TestControl {
    cancelled: AtomicBool,
    progress: Mutex<Vec<AuthorityProgress>>,
}

impl TestControl {
    fn new() -> Self {
        Self { cancelled: AtomicBool::new(false), progress: Mutex::new(Vec::new()) }
    }

    fn context(&self) -> OperationContext<'_> {
        OperationContext::new(u64::MAX, AuthorityLimits::maximum(), self)
    }
}

impl AuthorityOperationControl for TestControl {
    fn now_ms(&self) -> u64 {
        0
    }

    fn is_cancelled(&self) -> bool {
        self.cancelled.load(Ordering::SeqCst)
    }

    fn report(&self, progress: AuthorityProgress) {
        self.progress.lock().expect("progress lock").push(progress);
    }
}

struct FixtureProviderSource<'a> {
    bindings: Vec<NativeCodecBinding>,
    calls: Mutex<Vec<String>>,
    failure: Option<&'static str>,
    cancel_after_preview: Option<&'a TestControl>,
    hostile: Option<&'static str>,
    exact_pool: bool,
}

impl FixtureProviderSource<'_> {
    fn new(bindings: Vec<NativeCodecBinding>) -> Self {
        Self { bindings, calls: Mutex::new(Vec::new()), failure: None, cancel_after_preview: None, hostile: None, exact_pool: true }
    }
}

impl NativeCodecProviderSourceV1 for FixtureProviderSource<'_> {
    fn preflight_selection(&self, selected: &[NativeCodecProviderRequirementV1<'_>]) -> Result<(), AuthorityError> {
        if self.exact_pool {
            let bindings = validate_native_bindings(&self.bindings)?;
            if bindings.keys().any(|key| {
                !selected.iter().any(|required| required.package.plugin_id == key.plugin_id && required.package.package_id == key.package_id && required.artifact_kind == key.artifact_kind && required.artifact_schema == key.artifact_schema)
            }) {
                return Err(catalog("no explicit native codec binding matches the selected closure"));
            }
        }
        Ok(())
    }

    fn preview(&self, package: NativeCodecProviderPackageV1<'_>, descriptor: &PackageDescriptor, _context: &OperationContext<'_>) -> Result<Vec<NativeCodecBinding>, AuthorityError> {
        assert_eq!(descriptor.package_id, package.package_id);
        assert_eq!(descriptor.manifest.plugin_id, package.plugin_id);
        assert_eq!(descriptor.manifest.version, package.version);
        self.calls.lock().expect("provider calls").push(package.package_id.to_owned());
        if self.failure == Some(package.package_id) {
            return Err(catalog("selected fixture provider failed"));
        }
        let mut bindings = self.bindings.iter().filter(|binding| binding.plugin_id == package.plugin_id && binding.package_id == package.package_id).cloned().collect::<Vec<_>>();
        if package.plugin_id == "fixture-editor" {
            match self.hostile {
                Some("foreign") => bindings[0].package_id = "semio:unselected".into(),
                Some("missing") => bindings.clear(),
                Some("duplicate") => bindings.push(bindings[0].clone()),
                Some("zero") => bindings[0].codec.pack_schema_hash = [0; 32],
                Some("hash") => bindings[0].codec.pack_schema_hash = [0x22; 32],
                Some("extra") => {
                    let mut extra = bindings[0].clone();
                    extra.artifact_kind = "fixture.extra".into();
                    bindings.push(extra);
                }
                _ => {}
            }
        }
        if let Some(control) = self.cancel_after_preview {
            control.cancelled.store(true, Ordering::SeqCst);
        }
        Ok(bindings)
    }
}

struct FixtureDirectory {
    root: PathBuf,
    bundle_path: PathBuf,
    bundle: serde_json::Value,
    schema: String,
}

impl FixtureDirectory {
    fn persist_bundle(&self) {
        std::fs::write(&self.bundle_path, serde_json::to_vec_pretty(&self.bundle).expect("bundle json")).expect("write bundle");
    }

    fn refresh_profile_generation(&mut self) {
        let bundle: TrustedBundleV1 = serde_json::from_value(self.bundle.clone()).expect("fixture bundle");
        self.bundle["profiles"][0]["selectedClosureSha256"] = hex_lower(&selected_closure_digest(&bundle.profiles[0].selected_closure).expect("fixture closure digest")).into();
        self.bundle["profiles"][0]["generationId"] = trusted_profile_generation(&bundle, &bundle.profiles[0]).expect("fixture generation").into();
    }

    fn component_path(&self, package: usize) -> PathBuf {
        self.root.join(self.bundle["packages"][package]["component"]["path"].as_str().expect("component path"))
    }

    fn binding(&self) -> NativeCodecBinding {
        let binding=NativeCodecBinding::new("fixture-editor", "semio:fixture-editor", "s.fixture.document", None, fixture_codec(&self.schema, [0x11; 32]));assert_eq!(binding.factory_id(),None);binding
    }

    fn rewrite_descriptor(&mut self, index: usize, schema: Option<&str>, dependency: Option<(&str, &str)>) {
        let record = &self.bundle["packages"][index];
        let bytes = descriptor_bytes(
            record["pluginId"].as_str().expect("plugin"),
            record["packageId"].as_str().expect("package"),
            record["version"].as_str().expect("version"),
            schema,
            dependency,
        );
        self.replace_descriptor(index, bytes);
    }

    fn replace_descriptor(&mut self, index: usize, bytes: Vec<u8>) {
        let record = &mut self.bundle["packages"][index];
        record["descriptor"]["byteLength"] = bytes.len().into();
        record["descriptor"]["sha256"] = hex_lower(&Sha256::digest(&bytes)).into();
        if record["browserActor"]["kind"] == "closed-browser-actor" {
            record["browserActor"]["sourceDescriptorByteSha256"] = record["descriptor"]["sha256"].clone();
        }
        attach_fixture_plugin_module(&self.root, record, &bytes);
        std::fs::write(self.root.join(record["descriptor"]["path"].as_str().expect("descriptor path")), bytes).expect("replace descriptor");
        self.refresh_profile_generation();
        self.persist_bundle();
    }

    fn make_two_codec_bindings(&mut self) -> Vec<NativeCodecBinding> {
        let schema = format!("{}.base", self.schema);
        self.bundle["packages"][1]["nativeCodecs"] = serde_json::json!([{ "artifactKind": "s.fixture.document", "artifactSchema": schema, "packSchemaHash": "11".repeat(32) }]);
        self.rewrite_descriptor(1, Some(&schema), None);
        vec![NativeCodecBinding::new("fixture-base", "semio:fixture-base", "s.fixture.document", None, fixture_codec(&schema, [0x11; 32])), self.binding()]
    }
}

impl Drop for FixtureDirectory {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.root);
    }
}

/// 🧩️ (Re)writes one fixture record's shipped receipt and plugin module for its current component and descriptor bytes.
fn attach_fixture_plugin_module(root: &Path, record: &mut serde_json::Value, descriptor: &[u8]) {
    let receipt = fixture_component_receipt(record["pluginId"].as_str().unwrap(), record["packageId"].as_str().unwrap(), record["component"]["sha256"].as_str().unwrap(), record["component"]["byteLength"].as_u64().unwrap(), descriptor);
    record["receipt"] = serde_json::to_value(&receipt).expect("fixture receipt json");
    record["pluginModule"] = write_fixture_plugin_module(root, record["pluginId"].as_str().unwrap(), record["packageId"].as_str().unwrap(), record["version"].as_str().unwrap(), &receipt, descriptor).expect("fixture plugin module");
}

/// 🧱️ The fixture component: the eight-byte WASI component preamble, the smallest bytes a shipped receipt can name.
fn fixture_component_bytes(fixture: &serde_json::Value) -> Vec<u8> {
    fixture["componentHex"].as_str().expect("component hex").as_bytes().chunks_exact(2).map(|pair| u8::from_str_radix(std::str::from_utf8(pair).expect("hex pair"), 16).expect("hex byte")).collect()
}

fn snapshot_json() -> serde_json::Value {
    serde_json::from_str(semio_hub_testing::hub_source("🗿️artifact-authority/🔏️trusted-catalog/🧪️tests/🧫️fixtures/👥️two-package/🔣️.json")).expect("trusted-catalog fixture")
}

fn synthetic_browser_actor(component: &str, descriptor: &str, path: &str) -> serde_json::Value {
    let mut fixture: serde_json::Value = serde_json::from_str(semio_hub_testing::hub_source("🗿️artifact-authority/🔏️trusted-catalog/🧪️tests/🧫️fixtures/🌐️browser-actor/🔣️.json")).unwrap();
    let mut actor = fixture["closed"].take();
    actor["sourceComponentSha256"] = component.into();
    actor["sourceDescriptorByteSha256"] = descriptor.into();
    actor["path"] = path.into();
    actor
}

fn local_stdio_gis_profile_bundle() -> TrustedBundleV1 {
    let version = "0.1.0".to_owned();
    let map_hash = "a1".repeat(32);
    let target = TrustedBundleOpenTargetV1 {
        artifact_kind: "s.gis.gismap".into(),
        artifact_schema: "gis.map".into(),
        pack_schema_hash: map_hash.clone(),
        surface_id: "s.gis.gismap@1/*#editor".into(),
        app_id: "s.gis.gismap@1/*#editor".into(),
        window_kind_id: "gis2d-main".into(),
        role: TrustedBundleOpenRole::Editor,
        renderer_target: TrustedBundleRendererTarget::Wasm,
        parent_dialect: semio_framework::ArtifactDialect { artifact_kind: "s.gis.gismap".into(), standard: "1".into(), subset: "*".into() },
        grant: TrustedBundleGrantV1 { read: true, write: true, observe: true },
    };
    let viewer = TrustedBundleOpenTargetV1 {
        surface_id: "s.gis.gismap@1/*#viewer".into(),
        app_id: "s.gis.gismap@1/*#viewer".into(),
        window_kind_id: "gis2d-view-map".into(),
        role: TrustedBundleOpenRole::Viewer,
        grant: TrustedBundleGrantV1 { read: true, write: false, observe: true },
        ..target.clone()
    };
    let gis_identity = TrustedBundleIdentityV1 { plugin_id: "gis".into(), package_id: "semio:gis".into(), version: version.clone() };
    let stdio_identity = TrustedBundleIdentityV1 { plugin_id: "stdio".into(), package_id: "semio:stdio".into(), version: version.clone() };
    let stdio_codecs = (0u8..29).map(|index| TrustedBundleCodecV1 { artifact_kind: format!("s.stdio.fixture{index:02}"), artifact_schema: format!("stdio.fixture{index:02}"), pack_schema_hash: format!("{:02x}", index + 1).repeat(32) }).collect();
    let packages = vec![
        TrustedBundlePackageV1 {
            plugin_id: "gis".into(),
            package_id: "semio:gis".into(),
            version: version.clone(),
            role: TrustedBundlePackageRole::Plugin,
            execution_protocol: semio_framework::ExecutionProtocol { app_channel_version: directory::os_spr::CHANNEL_VERSION },
            dependencies: vec![stdio_identity.clone()],
            component: TrustedBundleComponentV1 { path: "packages/gis/component.wasm".into(), byte_length: 1, sha256: "11".repeat(32), blake3: "12".repeat(32) },
            descriptor: TrustedBundleFileV1 { path: "packages/gis/descriptor.semio".into(), byte_length: 1, sha256: "13".repeat(32) },
            receipt: ComponentReceiptV1 { wasm_sha256: "11".repeat(32), semantic_descriptor_sha256: "13".repeat(32), ..fixture_component_receipt("gis", "semio:gis", &"11".repeat(32), 8, b"") },
            browser_actor: serde_json::from_value(synthetic_browser_actor(&"11".repeat(32), &"13".repeat(32), "packages/gis/browser/closed-actor.mjs")).unwrap(),
            plugin_module: TrustedBundlePluginModuleV1 { path: "packages/gis/plugin-module.json".into(), byte_length: 1, sha256: "14".repeat(32), blake3: "15".repeat(32) },
            native_codecs: vec![
                TrustedBundleCodecV1 { artifact_kind: "s.gis.gismap".into(), artifact_schema: "gis.map".into(), pack_schema_hash: map_hash },
                TrustedBundleCodecV1 { artifact_kind: "s.gis.gisterrain".into(), artifact_schema: "gis.terrain".into(), pack_schema_hash: "a2".repeat(32) },
            ],
            open_targets: vec![target.clone(), viewer.clone()],
        },
        TrustedBundlePackageV1 {
            plugin_id: "stdio".into(),
            package_id: "semio:stdio".into(),
            version: version.clone(),
            role: TrustedBundlePackageRole::Plugin,
            execution_protocol: semio_framework::ExecutionProtocol { app_channel_version: directory::os_spr::CHANNEL_VERSION },
            dependencies: vec![],
            component: TrustedBundleComponentV1 { path: "packages/stdio/component.wasm".into(), byte_length: 1, sha256: "21".repeat(32), blake3: "22".repeat(32) },
            descriptor: TrustedBundleFileV1 { path: "packages/stdio/descriptor.semio".into(), byte_length: 1, sha256: "23".repeat(32) },
            receipt: ComponentReceiptV1 { wasm_sha256: "21".repeat(32), semantic_descriptor_sha256: "23".repeat(32), ..fixture_component_receipt("stdio", "semio:stdio", &"21".repeat(32), 8, b"") },
            browser_actor: TrustedBundleBrowserActorV1::None {},
            plugin_module: TrustedBundlePluginModuleV1 { path: "packages/stdio/plugin-module.json".into(), byte_length: 1, sha256: "24".repeat(32), blake3: "25".repeat(32) },
            native_codecs: stdio_codecs,
            open_targets: vec![],
        },
    ];
    let selected_closure = vec![gis_identity.clone(), stdio_identity];
    let mut bundle = TrustedBundleV1 {
        schema_version: TRUSTED_BUNDLE_SCHEMA_VERSION,
        profiles: vec![TrustedBundleProfileV1 {
            id: "local-stdio-gis-open-v1".into(),
            selected_closure,
            selected_closure_sha256: "01".repeat(32),
            open_targets: vec![TrustedBundleProfileOpenTargetV1 { package: gis_identity.clone(), target }, TrustedBundleProfileOpenTargetV1 { package: gis_identity, target: viewer }],
            generation_id: "02".repeat(32),
        }],
        packages,
    };
    bundle.profiles[0].selected_closure_sha256 = hex_lower(&selected_closure_digest(&bundle.profiles[0].selected_closure).expect("closure digest"));
    bundle.profiles[0].generation_id = trusted_profile_generation(&bundle, &bundle.profiles[0]).expect("profile generation");
    bundle
}

fn descriptor_bytes(plugin_id: &str, package_id: &str, version: &str, schema: Option<&str>, dependency: Option<(&str, &str)>) -> Vec<u8> {
    encode_descriptor_json(descriptor_json(plugin_id, package_id, version, schema, dependency))
}

/// 🧾️ Encodes one handcrafted descriptor JSON exactly as the publisher's descriptor bytes are encoded.
fn encode_descriptor_json(json: serde_json::Value) -> Vec<u8> {
    let descriptor: PackageDescriptor = serde_json::from_value(json).expect("package descriptor");
    os_pack::pack_rt::encode_wire_value(&semio_framework_value::ToValue::to_value(&descriptor))
}

/// 🏠️ The fixture editor as a HOST of the base package's kind: it declares no kind, hosts `s.fixture.document` from
/// `fixture-base`, and adds a `strict` subset editor beside its whole-standard `*` editor, both opening the one document schema.
fn hosting_descriptor_bytes(schema: &str) -> Vec<u8> {
    let mut json = descriptor_json("fixture-editor", "semio:fixture-editor", "1.2.3", Some(schema), Some(("fixture-base", "1.0.0")));
    let manifest = &mut json["manifest"];
    manifest["artifactKinds"] = serde_json::json!([]);
    manifest["hostedArtifactKinds"] = serde_json::json!([{ "id": "s.fixture.document", "schema": schema, "owner": "fixture-base" }]);
    let mut strict = manifest["apps"][0].clone();
    strict["id"] = "s.fixture.document@1/strict#editor".into();
    strict["controllerId"] = "fixture-editor-strict".into();
    strict["dialect"]["subset"] = "strict".into();
    manifest["apps"].as_array_mut().expect("fixture apps").push(strict);
    encode_descriptor_json(json)
}

/// 🧾️ One handcrafted fixture descriptor as JSON: a plugin declaring `s.fixture.document` with `schema` (editor and viewer of
/// `@1/*`) or nothing, depending on `dependency`.
fn descriptor_json(plugin_id: &str, package_id: &str, version: &str, schema: Option<&str>, dependency: Option<(&str, &str)>) -> serde_json::Value {
    let artifact_kinds = schema.map_or_else(Vec::new, |schema| {
        vec![serde_json::json!({
            "id": "s.fixture.document",
            "label": { "native": { "en": "Fixture Document", "de": "Fixture-Dokument" }, "reuse": { "en": "Fixture Document", "de": "Fixture-Dokument" } },
            "sourceFormat": "fixture",
            "componentKind": "document",
            "dimension": "data",
            "mediaCapability": "meshOnly",
            "mediaType": { "class": "data", "form": "value" },
            "schema": schema,
            "exportFormats": [],
            "importFormats": [],
            "exportStdioKinds": [],
            "importStdioKinds": []
        })]
    });
    let apps = schema.map_or_else(Vec::new, |_| {
        [semio_framework::AppRole::Editor, semio_framework::AppRole::Viewer]
            .into_iter()
            .map(|role| {
                let role = role.as_str();
                serde_json::from_value::<semio_framework::AppDefinition>(serde_json::json!({
                    "id": format!("s.fixture.document@1/*#{role}"),
                    "role": role,
                    "dialect": { "artifactKind": "s.fixture.document", "standard": "1", "subset": "*" },
                    "label": {
                        "native": { "de": format!("Fixture {role}"), "en": format!("Fixture {role}") },
                        "reuse": { "de": format!("Fixture {role}"), "en": format!("Fixture {role}") }
                    },
                    "breadcrumb": ["semio", "fixture", role],
                    "controllerId": format!("fixture-{role}"),
                    "modes": [{
                        "id": if role == "editor" { "edit" } else { "view" },
                        "label": {
                            "native": { "de": if role == "editor" { "Bearbeiten" } else { "Ansehen" }, "en": if role == "editor" { "Edit" } else { "View" } },
                            "reuse": { "de": if role == "editor" { "Bearbeiten" } else { "Ansehen" }, "en": if role == "editor" { "Edit" } else { "View" } }
                        },
                        "iconId": if role == "editor" { "pencil" } else { "eye" },
                        "tools": [],
                        "commands": []
                    }],
                    "defaultModeId": if role == "editor" { "edit" } else { "view" },
                    "windowKinds": [{
                        "id": "fixture-main",
                        "label": {
                            "native": { "de": "Fixture", "en": "Fixture" },
                            "reuse": { "de": "Fixture", "en": "Fixture" }
                        },
                        "bodyKey": "fixture.main",
                        "surfaceKind": "canvas-2d",
                        "iconId": "app-window",
                        "actions": [],
                        "utilities": [],
                        "interactions": [],
                        "capabilities": []
                    }],
                    "panelTabs": [],
                    "keybindings": [],
                    "utilities": [],
                    "tools": [],
                    "commands": [],
                    "interactions": [],
                    "namedLayouts": [],
                    "terminologies": [],
                    "terminologyBreadcrumbs": {},
                    "tutorials": [],
                    "dialogs": [],
                    "mediaInputs": [],
                    "mediaOutputs": [],
                    "artifactKinds": [],
                    "config": { "fields": [] },
                    "commandGrammar": { "variants": [] },
                    "io": {
                        "artifactSchema": "fixture.document",
                        "artifactMediaType": { "class": "data", "form": "value" },
                        "ports": [],
                        "exportFormats": [],
                        "importFormats": [],
                        "artifact": { "id": "s.fixture.document", "name": "Fixture Document", "dimension": "data", "componentKind": "document" }
                    }
                }))
                .expect("handcrafted fixture app")
            })
            .collect()
    });
    let dependencies = dependency.map_or_else(Vec::new, |(plugin_id, version)| vec![serde_json::json!({ "pluginId": plugin_id, "version": format!("={version}") })]);
    serde_json::json!({
        "descriptorVersion": 1,
        "packageId": package_id,
        "role": "plugin",
        "manifest": {
            "pluginId": plugin_id,
            "label": plugin_id,
            "version": version,
            "apps": apps,
            "examples": [],
            "artifactKinds": artifact_kinds,
            "dependencies": dependencies
        },
        "execution": "isolated",
        "executionProtocol": { "appChannelVersion": directory::os_spr::CHANNEL_VERSION }
    })
}

fn prepared_fixture() -> FixtureDirectory {
    let sequence = FIXTURE_SEQUENCE.fetch_add(1, Ordering::SeqCst);
    let schema = format!("fixture.document.catalog.{}.{}@1", std::process::id(), sequence);
    let root = semio_hub_testing::test_artifact_root().join(format!("semio-hub-trusted-catalog-{}-{sequence}", std::process::id()));
    std::fs::create_dir_all(root.join("components")).expect("component directory");
    std::fs::create_dir_all(root.join("descriptors")).expect("descriptor directory");
    std::fs::create_dir_all(root.join("browser")).expect("actor directory");
    std::fs::write(root.join("browser/closed-actor.mjs"), b"abc").expect("synthetic actor, never executed");
    let mut fixture = snapshot_json();
    let mut bundle = fixture["bundle"].take();
    bundle["packages"][0]["nativeCodecs"][0]["artifactSchema"] = schema.clone().into();
    for target in bundle["packages"][0]["openTargets"].as_array_mut().expect("open targets") {
        target["artifactSchema"] = schema.clone().into();
    }
    for entry in bundle["profiles"][0]["openTargets"].as_array_mut().expect("profile open targets") {
        entry["target"]["artifactSchema"] = schema.clone().into();
    }
    let component = fixture_component_bytes(&fixture);
    for index in 0..2 {
        let component_path = root.join(bundle["packages"][index]["component"]["path"].as_str().expect("component path"));
        std::fs::write(component_path, &component).expect("write component");
    }
    let root_descriptor = descriptor_bytes("fixture-editor", "semio:fixture-editor", "1.2.3", Some(&schema), Some(("fixture-base", "1.0.0")));
    let base_descriptor = descriptor_bytes("fixture-base", "semio:fixture-base", "1.0.0", None, None);
    for (index, bytes) in [(0, root_descriptor), (1, base_descriptor)] {
        bundle["packages"][index]["descriptor"]["byteLength"] = bytes.len().into();
        bundle["packages"][index]["descriptor"]["sha256"] = hex_lower(&Sha256::digest(&bytes)).into();
        if index == 0 {
            bundle["packages"][index]["browserActor"]["sourceDescriptorByteSha256"] = bundle["packages"][index]["descriptor"]["sha256"].clone();
        }
        attach_fixture_plugin_module(&root, &mut bundle["packages"][index], &bytes);
        let path = root.join(bundle["packages"][index]["descriptor"]["path"].as_str().expect("descriptor path"));
        std::fs::write(path, bytes).expect("write descriptor");
    }
    let bundle_path = root.join("trusted-catalog.json");
    let mut fixture = FixtureDirectory { root, bundle_path, bundle, schema };
    fixture.refresh_profile_generation();
    fixture.persist_bundle();
    fixture
}

#[cfg(unix)]
fn fixture_file_link(target: &Path, link: &Path) {
    std::os::unix::fs::symlink(target, link).expect("create fixture file symlink");
}

#[cfg(windows)]
fn fixture_file_link(target: &Path, link: &Path) {
    std::os::windows::fs::symlink_file(target, link).expect("create fixture file reparse point");
}

#[cfg(unix)]
fn fixture_directory_link(target: &Path, link: &Path) {
    std::os::unix::fs::symlink(target, link).expect("create fixture directory symlink");
}

#[cfg(windows)]
fn fixture_directory_link(target: &Path, link: &Path) {
    std::os::windows::fs::symlink_dir(target, link).expect("create fixture directory reparse point");
}

async fn assert_linked_fixture_denied(fixture: &FixtureDirectory) {
    let provider = FixtureProviderSource::new(vec![fixture.binding()]);
    let result = TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &provider, &TestControl::new().context()).await;
    assert!(result.is_err(), "linked trusted closure unexpectedly loaded");
    assert!(provider.calls.lock().expect("provider calls").is_empty(), "provider observed linked bytes");
    assert!(document_codec(&fixture.schema).await.expect("codec registry").is_none(), "linked bytes published a codec");
}

/// 🧪️ Loads real GIS assembly metadata and native receipts around synthetic component bytes; component execution is outside this fixture.
async fn prepared_gis_binding_fixture(viewer: bool, foreign_service: bool) -> FixtureDirectory {
    let runtime = semio_framework_plugin::plugin_runtime::PluginRuntime::new(semio_framework_plugin::MountedOwnerPolicyV1::INTERACTIVE_COMPONENT).expect("explicit test mounted owner policy");
    semio_framework_plugin::plugin_runtime::install_plugin_bundle(&runtime, semio_hub_gis::plugin().expect("GIS assembly"));
    let emitted = semio_framework_plugin::describe::describe_plugin(&runtime).await;
    let mut descriptor = decode_package_descriptor(&emitted).expect("actual native GIS descriptor");
    semio_hub_stdio_catalog::validate_native_artifact_catalog_dependency(&descriptor.manifest.dependencies).expect("actual GIS compiled Stdio dependency");
    semio_hub_stdio_catalog::validate_native_artifact_catalog_contributions(&descriptor.manifest.topic_contributions).expect("actual GIS compiled Stdio catalog");
    let component = b"synthetic-gis-component-for-catalog-binding-test";
    let component_sha256 = hex_lower(&Sha256::digest(component));
    let mut component_blake3 = Hasher::new();
    component_blake3.update(component);
    if foreign_service {
        descriptor.contributions.inference_services.iter_mut().find(|service| service.inference_schema == "s.gis.gismap.inference").expect("actual GIS inference declaration").contributor = "foreign".into();
    }
    let bytes = os_pack::pack_rt::encode_wire_value(&semio_framework_value::ToValue::to_value(&descriptor));
    let native_codecs: Vec<_> = semio_hub_gis::native_codecs::native_codec_factory_receipts()
        .expect("actual GIS codec receipts")
        .into_iter()
        .map(|receipt| {
            let identity = receipt.identity();
            serde_json::json!({ "artifactKind": identity.artifact_kind, "artifactSchema": identity.schema, "packSchemaHash": hex_lower(&identity.pack_schema_hash) })
        })
        .collect();
    let corpus: serde_json::Value = serde_json::from_str(include_str!("../../../../🧪️tests/🧫️fixtures/🧊️gis-map-frozen-binding-v1/🔣️.json")).expect("neutral frozen binding corpus");
    let binding = &corpus["binding"];
    let package = serde_json::json!({ "pluginId": descriptor.manifest.plugin_id, "packageId": descriptor.package_id, "version": descriptor.manifest.version });
    let mut target = serde_json::json!({
        "artifactKind": binding["artifact"]["kind"], "artifactSchema": binding["artifact"]["schema"],
        "packSchemaHash": native_codecs.iter().find(|codec| codec["artifactKind"] == binding["artifact"]["kind"]).expect("Map native receipt")["packSchemaHash"],
        "surfaceId": binding["surface"]["surfaceId"], "appId": binding["surface"]["appId"], "windowKindId": binding["surface"]["windowKindId"],
        "role": binding["surface"]["role"], "rendererTarget": binding["surface"]["rendererTarget"],
        "parentDialect": binding["parentDialect"], "grant": binding["grant"]
    });
    if viewer {
        let app = descriptor.manifest.apps.iter().find(|app| app.role == semio_framework::AppRole::Viewer && app.dialect.artifact_kind == "s.gis.gismap").expect("actual Map viewer");
        target["surfaceId"] = app.id.clone().into();
        target["appId"] = app.id.clone().into();
        target["windowKindId"] = app.window_kinds.first().id.clone().into();
        target["role"] = "viewer".into();
        target["grant"]["write"] = false.into();
    }
    let sequence = FIXTURE_SEQUENCE.fetch_add(1, Ordering::SeqCst);
    let root = semio_hub_testing::test_artifact_root().join(format!("gis-binding-catalog-{}-{sequence}", std::process::id()));
    std::fs::create_dir(&root).expect("exclusive GIS binding fixture directory");
    std::fs::write(root.join("component.wasm"), component).expect("write synthetic GIS component");
    std::fs::write(root.join("descriptor.semio"), &bytes).expect("write actual GIS descriptor");
    std::fs::write(root.join("closed-actor.mjs"), b"abc").expect("synthetic actor, never executed");
    let (stdio_identity, stdio_record) = headless_stdio_fixture_package(&root).expect("headless Stdio dependency package");
    let mut bundle = serde_json::json!({
        "schemaVersion": 4,
        "profiles": [{ "id": "frozen-gis-test", "selectedClosure": [package.clone(), stdio_identity.clone()], "selectedClosureSha256": "01".repeat(32),
            "openTargets": [{ "package": package.clone(), "target": target.clone() }], "generationId": "02".repeat(32) }],
        "packages": [{ "pluginId": package["pluginId"], "packageId": package["packageId"], "version": package["version"], "role": "plugin", "dependencies": [stdio_identity],
            "executionProtocol": { "appChannelVersion": descriptor.execution_protocol.app_channel_version },
            "component": { "path": "component.wasm", "byteLength": component.len(), "sha256": component_sha256, "blake3": hex_lower(component_blake3.finalize().as_bytes()) },
            "descriptor": { "path": "descriptor.semio", "byteLength": bytes.len(), "sha256": hex_lower(&Sha256::digest(&bytes)) },
            "browserActor": synthetic_browser_actor(&component_sha256, &hex_lower(&Sha256::digest(&bytes)), "closed-actor.mjs"),
            "nativeCodecs": native_codecs, "openTargets": [target] }, stdio_record]
    });
    attach_fixture_plugin_module(&root, &mut bundle["packages"][0], &bytes);
    let mut fixture = FixtureDirectory { bundle_path: root.join("trusted-catalog.json"), root, bundle, schema: "gis.map".into() };
    fixture.refresh_profile_generation();
    fixture.persist_bundle();
    fixture
}

struct RecordingLinkedProvider {
    previews: Mutex<Vec<String>>,
    fail_gis: bool,
}

impl NativeCodecProviderSourceV1 for RecordingLinkedProvider {
    fn preview(&self, package: NativeCodecProviderPackageV1<'_>, descriptor: &PackageDescriptor, context: &OperationContext<'_>) -> Result<Vec<NativeCodecBinding>, AuthorityError> {
        if self.fail_gis && package.plugin_id == "gis" {
            return Err(catalog("selected GIS provider fixture failure"));
        }
        let bindings = NativeCodecProviderSourceV1::preview(&NativeCodecProviderSetV1::linked(), package, descriptor, context)?;
        self.previews.lock().expect("successful private previews").push(package.plugin_id.to_owned());
        Ok(bindings)
    }
}

fn fixture_compile<'a>(_dsl: &'a str, _ops: &'a str) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<(ArtifactPackFiles, String), VcsError>> + Send + 'a>> {
    Box::pin(async { Err(VcsError::Deserialize("fixture compile is not exercised".to_string())) })
}

fn fixture_print<'a>(_pack: &'a [u8], _spr: &'a [u8]) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<ArtifactTextFiles, VcsError>> + Send + 'a>> {
    Box::pin(async { Ok(ArtifactTextFiles { dsl: String::new(), ops: String::new() }) })
}

fn fixture_edit<'a>(_envelope: &'a directory::os_spr::MutationEnvelope) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<String, VcsError>> + 'a>> {
    Box::pin(async { Ok(String::new()) })
}

fn fixture_apply<'a>(pack: &'a [u8], spr: &'a [u8], _operations: &'a [u8]) -> directory::os_store::serialization::ArtifactCodecApplyFuture<'a> {
    Box::pin(async move { Ok((pack.to_vec(), spr.to_vec(), String::new())) })
}

fn fixture_codec(schema: &str, pack_schema_hash: [u8; 32]) -> ArtifactCodec {
    ArtifactCodec { schema: schema.to_string(), extension: "fixture", native_identity: directory::os_store::serialization::ArtifactNativeSnapshotIdentity::typed::<Vec<u8>>(), snapshot_sqlite: None, pack_schema_hash, compile_dsl: fixture_compile, print_mirror: fixture_print, edit_text_from_envelope: fixture_edit, apply_ops_binary: fixture_apply, replay_envelopes: fixture_apply }
}

async fn expect_load_error(fixture: &FixtureDirectory, bindings: &[NativeCodecBinding], control: &TestControl) -> AuthorityError {
    match load_fixture(fixture, bindings, &control.context()).await {
        Ok(_) => panic!("trusted catalog load unexpectedly succeeded"),
        Err(error) => error,
    }
}

async fn load_fixture(fixture: &FixtureDirectory, bindings: &[NativeCodecBinding], context: &OperationContext<'_>) -> Result<VerifiedTrustedCatalog, AuthorityError> {
    TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &FixtureProviderSource::new(bindings.to_vec()), context).await
}

#[tokio::test]
async fn selected_native_providers_are_descriptor_verified_dependency_first_and_only_selected() {
    let mut single = prepared_fixture();
    single.bundle["packages"][0]["dependencies"] = serde_json::json!([]);
    single.bundle["profiles"][0]["selectedClosure"] = serde_json::json!([
        { "pluginId": "fixture-editor", "packageId": "semio:fixture-editor", "version": "1.2.3" }
    ]);
    single.rewrite_descriptor(0, Some(&single.schema.clone()), None);
    let unselected = NativeCodecBinding::new("unselected", "semio:unselected", "fixture.unselected", None, fixture_codec(&format!("{}.unselected", single.schema), [0x11; 32]));
    let mut source = FixtureProviderSource::new(vec![single.binding(), unselected]);
    source.exact_pool = false;
    let catalog = TrustedCatalogLoader::load_fixture(&single.bundle_path, "fixture", &source, &TestControl::new().context()).await.expect("selected-only catalog");
    assert_eq!(*source.calls.lock().expect("calls"), ["semio:fixture-editor"]);
    assert_eq!(catalog.packages().len(), 1);
    assert_eq!(catalog.codec_count(), 1);
    assert!(document_codec(&format!("{}.unselected", single.schema)).await.expect("registry").is_none());

    let mut pair = prepared_fixture();
    let source = FixtureProviderSource::new(pair.make_two_codec_bindings());
    let catalog = TrustedCatalogLoader::load_fixture(&pair.bundle_path, "fixture", &source, &TestControl::new().context()).await.expect("complete selected closure");
    assert_eq!(*source.calls.lock().expect("calls"), ["semio:fixture-base", "semio:fixture-editor"]);
    assert_eq!(catalog.packages().len(), 2);
    assert_eq!(catalog.codec_count(), 2);
    assert!(document_codec(&pair.schema).await.expect("registry").is_some());
    assert!(document_codec(&format!("{}.base", pair.schema)).await.expect("registry").is_some());
}

#[tokio::test]
async fn gis_native_provider_selection_binds_literal_owner_version_and_cancellation_without_publication() {
    struct SelectionControl {
        cancelled: bool,
        now_ms: u64,
    }
    impl AuthorityOperationControl for SelectionControl {
        fn now_ms(&self) -> u64 {
            self.now_ms
        }
        fn is_cancelled(&self) -> bool {
            self.cancelled
        }
        fn report(&self, _progress: AuthorityProgress) {}
    }
    let _registry = semio_hub_artifact_authority::REAL_LINKED_CODEC_REGISTRY.lock().await;
    let fixture: serde_json::Value = serde_json::from_str(include_str!("../../../📇️native-openable-provider/🧪️tests/🧫️fixtures/🌍️gis-v1/🔣️.json")).unwrap();
    let expected: serde_json::Value = serde_json::from_str(include_str!("../../../../../🌎️hub/🧩️compositions/🌍️gis/📇️native-codecs/🔣️.json")).unwrap();
    assert_eq!(fixture["packageVersion"], expected["packageVersion"]);
    let providers = NativeCodecProviderSetV1::linked();
    let mut published = Vec::new();
    for row in expected["receipts"].as_array().unwrap() {
        published.push(document_codec(row["schema"].as_str().unwrap()).await.unwrap().map(|codec| codec.pack_schema_hash));
    }
    for case in fixture["cases"].as_array().unwrap() {
        let control = SelectionControl { cancelled: case["cancelled"].as_bool().unwrap(), now_ms: case["nowMs"].as_u64().unwrap() };
        let context = OperationContext::new(case["deadlineMs"].as_u64().unwrap(), AuthorityLimits::maximum(), &control);
        let result = providers.preview(case["pluginId"].as_str().unwrap(), case["packageId"].as_str().unwrap(), case["version"].as_str().unwrap(), &context);
        assert_eq!(result.is_ok(), case["accepted"].as_bool().unwrap(), "{}", case["name"]);
        if let Ok(bindings) = result {
            assert_eq!(bindings.len(), case["bindings"].as_u64().unwrap() as usize, "{}", case["name"]);
            assert_eq!(bindings.is_empty(), case["code"] == "unlinked-package", "{}", case["name"]);
            for (binding, row) in bindings.iter().zip(expected["receipts"].as_array().unwrap()) {
                assert_eq!(binding.plugin_id, expected["pluginId"]);
                assert_eq!(binding.package_id, expected["packageId"]);
                assert_eq!(binding.artifact_kind, row["kind"]);
                assert_eq!(binding.codec.schema, row["schema"]);
                assert_eq!(binding.codec.extension, row["extension"]);
                let receipt = semio_hub_gis::native_codecs::native_codec_factory_receipts().unwrap().into_iter().find(|receipt| receipt.identity().schema == binding.codec.schema).unwrap();
                assert_eq!(hex_lower(&receipt.identity().protocol_sha256), row["protocolSha256"]);
                assert_eq!(binding.codec.pack_schema_hash, receipt.into_codec().unwrap().pack_schema_hash);
            }
        }
        for (row, prior) in expected["receipts"].as_array().unwrap().iter().zip(&published) {
            assert_eq!(&document_codec(row["schema"].as_str().unwrap()).await.unwrap().map(|codec| codec.pack_schema_hash), prior, "{} must not publish even a partial codec closure", case["name"]);
        }
    }
}

/// 🧩️ A selected provider that fails, substitutes, conflicts or binds foreign rows publishes nothing; a provider that
/// binds NOTHING for a declared row is no trust failure — the row waits for its component's own answer (the catalog
/// verifies guest rows lazily) and is never served while its component does not give it.
#[tokio::test]
async fn selected_native_provider_failure_substitution_and_conflict_publish_no_partial_closure() {
    for hostile in ["foreign", "missing", "duplicate", "zero", "hash", "extra", "provider-failure", "registry-conflict"] {
        let mut fixture = prepared_fixture();
        let mut source = FixtureProviderSource::new(fixture.make_two_codec_bindings());
        source.hostile = Some(hostile);
        if hostile == "provider-failure" {
            source.failure = Some("semio:fixture-editor");
        }
        if hostile == "registry-conflict" {
            os_store::codec_registry::register_document_codec(fixture_codec(&fixture.schema, [0x22; 32])).expect("prior immutable owner");
        }
        if hostile == "missing" {
            let control = TestControl::new();
            let catalog = TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &source, &control.context()).await.expect("a row no provider binds loads and waits for its component's answer");
            assert_eq!(*source.calls.lock().expect("calls"), ["semio:fixture-base", "semio:fixture-editor"]);
            let pending = catalog.codecs.iter().find(|codec| codec.identity.artifact_schema == fixture.schema).expect("the unbound row's codec");
            assert!(pending.guest.genesis("fixture-document", &control.context()).await.is_err(), "the unbound row is never served: its component does not answer it");
            assert!(document_codec(&fixture.schema).await.expect("registry").is_none(), "no native codec is published for the unbound row");
            continue;
        }
        assert!(TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &source, &TestControl::new().context()).await.is_err(), "{hostile}");
        assert_eq!(*source.calls.lock().expect("calls"), ["semio:fixture-base", "semio:fixture-editor"], "{hostile}");
        assert!(document_codec(&format!("{}.base", fixture.schema)).await.expect("registry").is_none(), "{hostile} published first provider");
        let existing = document_codec(&fixture.schema).await.expect("registry");
        if hostile == "registry-conflict" {
            assert_eq!(existing.expect("prior owner retained").pack_schema_hash, [0x22; 32]);
        } else {
            assert!(existing.is_none(), "{hostile} published second provider");
        }
    }
    {
        let fixture = prepared_fixture();
        let control = TestControl::new();
        let catalog = TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &NativeCodecProviderSetV1::linked(), &control.context()).await.expect("rows the linked providers do not bind wait for their components");
        let pending = catalog.codecs.iter().find(|codec| codec.identity.artifact_schema == fixture.schema).expect("the fixture row's codec");
        assert!(pending.guest.genesis("fixture-document", &control.context()).await.is_err(), "an unlinked row whose component does not answer it is never served");
        assert!(document_codec(&fixture.schema).await.expect("registry").is_none());
    }
}

#[tokio::test]
async fn selected_native_provider_descriptor_and_cancellation_fences_precede_publication() {
    let cases: serde_json::Value = serde_json::from_str(semio_hub_testing::hub_source("🗿️artifact-authority/🔏️trusted-catalog/🧪️tests/🧫️fixtures/🔗️compiled-dependencies/🔣️.json")).unwrap();
    for case in cases["descriptorPreviewCases"].as_array().unwrap() {
        let mut invalid = prepared_fixture();
        let source = FixtureProviderSource::new(invalid.make_two_codec_bindings());
        let index = case["packageIndex"].as_u64().unwrap() as usize;
        let descriptor_path = invalid.root.join(invalid.bundle["packages"][index]["descriptor"]["path"].as_str().expect("descriptor path"));
        std::fs::write(descriptor_path, b"invalid descriptor").expect("hostile descriptor bytes");
        assert!(TrustedCatalogLoader::load_fixture(&invalid.bundle_path, "fixture", &source, &TestControl::new().context()).await.is_err());
        assert_eq!(serde_json::to_value(source.calls.lock().expect("calls").clone()).unwrap(), case["previews"], "{}", case["id"]);
        assert!(document_codec(&invalid.schema).await.expect("registry").is_none());
        assert!(document_codec(&format!("{}.base", invalid.schema)).await.expect("registry").is_none());
    }

    for before in [true, false] {
        let mut fixture = prepared_fixture();
        let control = TestControl::new();
        control.cancelled.store(before, Ordering::SeqCst);
        let mut source = FixtureProviderSource::new(fixture.make_two_codec_bindings());
        source.cancel_after_preview = Some(&control);
        let result = TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &source, &control.context()).await;
        assert!(matches!(result, Err(AuthorityError::Cancelled)));
        let calls = source.calls.lock().expect("calls").clone();
        assert_eq!(calls, if before { Vec::<String>::new() } else { vec!["semio:fixture-base".into()] });
        assert!(document_codec(&fixture.schema).await.expect("registry").is_none());
        assert!(document_codec(&format!("{}.base", fixture.schema)).await.expect("registry").is_none());
    }
}

#[tokio::test]
async fn neutral_fixture_proves_dependency_order_hash_oracles_and_exact_limit_edges() {
    let fixture = snapshot_json();
    let bundle: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("bundle shape");
    assert_eq!(validate_bundle(&bundle, "fixture").expect("valid closure").package_indices, vec![1, 0]);
    let bytes = fixture_component_bytes(&fixture);
    let control = TestControl::new();
    let (sha, internal_blake3) = dual_hash(&bytes, &control.context()).await.expect("dual hash");
    assert_eq!(hex_lower(&sha), fixture["componentSha256"]);
    assert_eq!(hex_lower(&internal_blake3), fixture["componentBlake3"]);
    assert_eq!(blake3::hash(&bytes).to_hex().as_str(), fixture["componentBlake3"]);

    let limits = &fixture["limits"];
    assert_eq!(limits["componentBytesMax"], TRUSTED_COMPONENT_MAX_BYTES);
    assert_eq!(limits["componentBytesMaxPlusOne"], TRUSTED_COMPONENT_MAX_BYTES + 1);
    assert!(validate_file(&TrustedBundleFileV1 { path: "component.wasm".to_string(), byte_length: TRUSTED_COMPONENT_MAX_BYTES, sha256: "11".repeat(32) }, TRUSTED_COMPONENT_MAX_BYTES).is_ok());
    assert!(validate_file(&TrustedBundleFileV1 { path: "component.wasm".to_string(), byte_length: TRUSTED_COMPONENT_MAX_BYTES + 1, sha256: "11".repeat(32) }, TRUSTED_COMPONENT_MAX_BYTES).is_err());
    assert_eq!(limits["descriptorBytesMax"], TRUSTED_DESCRIPTOR_MAX_BYTES);
    assert!(validate_file(&TrustedBundleFileV1 { path: "descriptor.semio".to_string(), byte_length: TRUSTED_DESCRIPTOR_MAX_BYTES, sha256: "11".repeat(32) }, TRUSTED_DESCRIPTOR_MAX_BYTES).is_ok());
    assert!(validate_file(&TrustedBundleFileV1 { path: "descriptor.semio".to_string(), byte_length: TRUSTED_DESCRIPTOR_MAX_BYTES + 1, sha256: "11".repeat(32) }, TRUSTED_DESCRIPTOR_MAX_BYTES).is_err());
    assert!(valid_identity(&"a".repeat(TRUSTED_IDENTITY_MAX_BYTES)));
    assert!(!valid_identity(&"a".repeat(TRUSTED_IDENTITY_MAX_BYTES + 1)));
    assert!(ensure_count(TRUSTED_CATALOG_MAX_CODECS, TRUSTED_CATALOG_MAX_CODECS, "trusted codec count").is_ok());
    assert!(ensure_count(TRUSTED_CATALOG_MAX_CODECS + 1, TRUSTED_CATALOG_MAX_CODECS, "trusted codec count").is_err());
}

#[tokio::test]
async fn loader_retains_exact_bytes_and_independent_identities_before_atomic_codec_activation() {
    let fixture = prepared_fixture();
    let binding = fixture.binding();
    let control = TestControl::new();
    let catalog = load_fixture(&fixture, &[binding], &control.context()).await.expect("verified catalog");
    assert_eq!(catalog.packages().iter().map(VerifiedTrustedPackage::plugin_id).collect::<Vec<_>>(), vec!["fixture-base", "fixture-editor"]);
    let editor = &catalog.packages()[1];
    assert_eq!(editor.package_ref().package.0, "semio:fixture-editor");
    assert_eq!(hex_lower(&editor.package_ref().hash.0), snapshot_json()["componentBlake3"]);
    assert_ne!(editor.plugin_id(), editor.package_ref().package.0);
    assert_eq!(editor.component().byte_length(), 8);
    assert_eq!(&*editor.component().read(&control.context()).await.expect("retained component rereads"), fixture_component_bytes(&snapshot_json()).as_slice());
    assert_eq!(editor.receipt().wasm_sha256, hex_lower(editor.component_sha256()));
    assert_eq!(editor.receipt().semantic_descriptor_sha256, hex_lower(editor.descriptor_sha256()));
    assert_eq!(hex_lower(editor.component_sha256()), snapshot_json()["componentSha256"]);
    assert_eq!(editor.descriptor().manifest.plugin_id, editor.plugin_id());
    assert_eq!(editor.descriptor().manifest.version, editor.version());
    assert_eq!(Sha256::digest(editor.descriptor_bytes()), *editor.descriptor_sha256());
    assert_eq!(catalog.codec_count(), 1);
    assert_eq!(catalog.open_target_count(), 1);
    assert_eq!(catalog.generation_id().len(), 64);
    let descriptor = DocumentDescriptor {
        space_id: "space".into(),
        document_id: "document".into(),
        artifact_kind: "s.fixture.document".into(),
        artifact_schema: fixture.schema.clone(),
        owner: directory::os_directory::DocumentOwner {
            plugin_id: "fixture-editor".into(),
            package_id: "semio:fixture-editor".into(),
            version: "1.2.3".into(),
            package_hash: snapshot_json()["componentSha256"].as_str().expect("component sha256").into(),
        },
        pack_schema_hash: "11".repeat(32),
        bootstrap_version: 1,
        bootstrap_frontier: directory::os_directory::DocumentFrontier { head_seq: 0, commit_seq: 0, epoch: 0 },
        bootstrap_snapshot_hash: "33".repeat(32),
    };
    assert!(catalog.resolve(&TrustedArtifactIdentity::from_descriptor(&descriptor)).await.is_ok(), "the codec and open plan use the same descriptor SHA-256 owner identity");
    let editor = catalog.resolve_document_open(&descriptor, Some("s.fixture.document@1/*#editor"), true).expect("exact editor target");
    assert_eq!(editor.surface.role, DocumentOpenSurfaceRoleV1::Editor);
    assert!(editor.grant.write);
    assert!(catalog.resolve_document_open(&descriptor, Some("s.fixture.document@1/*#viewer"), false).is_none());
    assert!(catalog.resolve_document_open(&descriptor, None, true).is_some());
    assert!(document_codec(&fixture.schema).await.expect("codec registry").is_some());
    let progress = control.progress.lock().expect("progress lock");
    assert_eq!(progress.first().map(|entry| entry.stage), Some(AuthorityProgressStage::Preflight));
    assert_eq!(progress.last().map(|entry| entry.stage), Some(AuthorityProgressStage::CatalogResolved));
    assert!(progress.iter().all(|entry| entry.completed_units <= entry.total_units));
}

/// 🧱 The exact-selection asset accessor is bound to the current generation and to every
/// selected digest: it answers only for the exact descriptor/role/surface the catalog itself
/// resolves, only while the caller-observed generation is still this catalog's own, and the
/// bytes it returns are the very bytes whose SHA-256/BLAKE3 the selection projects.
///
/// 🔁 A rotated (or merely guessed) generation is never served, and no role, surface or
/// descriptor substitution reaches bytes.
#[tokio::test]
async fn selected_execution_target_assets_are_generation_and_digest_bound() {
    let fixture = prepared_fixture();
    let control = TestControl::new();
    let catalog = load_fixture(&fixture, &[fixture.binding()], &control.context()).await.expect("verified catalog");
    let descriptor = DocumentDescriptor {
        space_id: "space".into(),
        document_id: "document".into(),
        artifact_kind: "s.fixture.document".into(),
        artifact_schema: fixture.schema.clone(),
        owner: directory::os_directory::DocumentOwner {
            plugin_id: "fixture-editor".into(),
            package_id: "semio:fixture-editor".into(),
            version: "1.2.3".into(),
            package_hash: snapshot_json()["componentSha256"].as_str().expect("component sha256").into(),
        },
        pack_schema_hash: "11".repeat(32),
        bootstrap_version: 1,
        bootstrap_frontier: directory::os_directory::DocumentFrontier { head_seq: 0, commit_seq: 0, epoch: 0 },
        bootstrap_snapshot_hash: "33".repeat(32),
    };
    let generation = catalog.generation_id().to_string();
    let assets = catalog.assets_for_current_selection(&descriptor, Some("s.fixture.document@1/*#editor"), true, &generation).expect("selected assets");
    let selection = catalog.resolve_document_open(&descriptor, Some("s.fixture.document@1/*#editor"), true).expect("selection");
    assert_eq!(assets.selection, selection);
    let component = assets.component.read(&control.context()).await.expect("selected component rereads");
    assert!(!component.is_empty() && !assets.descriptor.is_empty());
    assert_eq!(hex_lower(&Sha256::digest(&component)), assets.selection.package.component_sha256);
    assert_eq!(semio_framework_hash::hash_bytes(&component), assets.selection.package.component_blake3);
    assert_eq!(hex_lower(&Sha256::digest(&assets.descriptor)), assets.selection.package.descriptor_byte_sha256);
    let actor = assets.browser_actor.as_ref().expect("Wasm selection retains its actor").read(&control.context()).await.expect("selected actor rereads");
    let retained = catalog.packages.iter().find(|package| package.plugin_id == selection.package.plugin_id).unwrap();
    assert!(Arc::ptr_eq(&actor, &retained.browser_actor_asset.as_ref().unwrap().read(&control.context()).await.expect("resident actor")));
    assert_eq!(actor.as_ref(), b"abc");
    assert_eq!(assets.selection.browser_actor, retained.browser_actor);
    assert!(assets.component.byte_length() <= TRUSTED_COMPONENT_MAX_BYTES && assets.descriptor.len() as u64 <= TRUSTED_DESCRIPTOR_MAX_BYTES);
    assert!(catalog.assets_for_current_selection(&descriptor, Some("s.fixture.document@1/*#editor"), true, &"ab".repeat(32)).is_none());
    assert!(catalog.assets_for_current_selection(&descriptor, Some("s.fixture.document@1/*#editor"), false, &generation).is_none());
    assert!(catalog.assets_for_current_selection(&descriptor, Some("s.fixture.document@1/*#viewer"), true, &generation).is_none());
    assert!(catalog.assets_for_current_selection(&descriptor, Some("foreign"), true, &generation).is_none());
    for change in ["plugin", "package", "version", "hash", "kind", "schema", "pack"] {
        let mut candidate = descriptor.clone();
        match change {
            "plugin" => candidate.owner.plugin_id.push_str(".foreign"),
            "package" => candidate.owner.package_id.push_str(".foreign"),
            "version" => candidate.owner.version.push_str("-foreign"),
            "hash" => candidate.owner.package_hash = "ab".repeat(32),
            "kind" => candidate.artifact_kind.push_str(".foreign"),
            "schema" => candidate.artifact_schema.push_str("-foreign"),
            "pack" => candidate.pack_schema_hash = "ab".repeat(32),
            _ => unreachable!(),
        }
        assert!(catalog.assets_for_current_selection(&candidate, Some("s.fixture.document@1/*#editor"), true, &generation).is_none(), "descriptor {change} reached selected bytes");
    }
}

#[tokio::test]
async fn verified_trusted_catalog_document_open_generation_and_resolution_are_exact() {
    let fixture = prepared_fixture();
    let catalog = load_fixture(&fixture, &[fixture.binding()], &TestControl::new().context()).await.expect("verified catalog");
    let descriptor = DocumentDescriptor {
        space_id: "space".into(),
        document_id: "document".into(),
        artifact_kind: "s.fixture.document".into(),
        artifact_schema: fixture.schema.clone(),
        owner: directory::os_directory::DocumentOwner {
            plugin_id: "fixture-editor".into(),
            package_id: "semio:fixture-editor".into(),
            version: "1.2.3".into(),
            package_hash: snapshot_json()["componentSha256"].as_str().expect("component sha256").into(),
        },
        pack_schema_hash: "11".repeat(32),
        bootstrap_version: 1,
        bootstrap_frontier: directory::os_directory::DocumentFrontier { head_seq: 0, commit_seq: 0, epoch: 0 },
        bootstrap_snapshot_hash: "33".repeat(32),
    };
    assert_eq!(catalog.open_target_count(), 1);
    assert_eq!(catalog.generation_id().len(), 64);
    assert!(catalog.generation_id().bytes().all(|byte| byte.is_ascii_digit() || matches!(byte, b'a'..=b'f')));
    let editor = catalog.resolve_document_open(&descriptor, Some("s.fixture.document@1/*#editor"), true).expect("editor");
    assert_eq!(editor.surface.role, DocumentOpenSurfaceRoleV1::Editor);
    assert_eq!(editor.grant, DocumentOpenGrantV1 { read: true, write: true, observe: true });
    assert_eq!(editor.parent_dialect, semio_framework::ArtifactDialect { artifact_kind: "s.fixture.document".into(), standard: "1".into(), subset: "*".into() });
    assert!(catalog.resolve_document_open(&descriptor, Some("s.fixture.document@1/*#viewer"), false).is_none());
    for field in ["artifactKind", "standard", "subset"] {
        let mut changed: TrustedBundleV1 = serde_json::from_value(fixture.bundle.clone()).expect("bundle");
        let dialect = &mut changed.profiles[0].open_targets[0].target.parent_dialect;
        match field {
            "artifactKind" => dialect.artifact_kind.push_str(".foreign"),
            "standard" => dialect.standard.push_str("-foreign"),
            "subset" => dialect.subset.push_str("-foreign"),
            _ => unreachable!(),
        }
        let changed_generation = trusted_profile_generation(&changed, &changed.profiles[0]).unwrap();
        assert_ne!(changed_generation, catalog.generation_id(), "catalog binds parent {field}");
    }
    assert!(catalog.resolve_document_open(&descriptor, Some("s.fixture.document@1/*#viewer"), true).is_none());
    assert!(catalog.resolve_document_open(&descriptor, Some("foreign"), false).is_none());
    let roles: serde_json::Value = serde_json::from_str(include_str!("../🧫️fixtures/🪪️identity-roles/🔣️.json")).unwrap();
    for case in roles["cases"].as_array().unwrap() {
        let mut candidate = descriptor.clone();
        let mut surface = "s.fixture.document@1/*#editor".to_owned();
        match case["change"].as_str().unwrap() {
            "none" => {}
            "blake3-owner" => candidate.owner.package_hash = snapshot_json()["componentBlake3"].as_str().unwrap().to_owned(),
            "descriptor-owner" => candidate.owner.package_hash = hex_lower(catalog.packages()[1].descriptor_sha256()),
            "zero-owner" => candidate.owner.package_hash = "00".repeat(32),
            "bare-kind" => candidate.artifact_kind = "fixture.document".to_owned(),
            "bare-surface" => surface = "fixture.document@1/*#editor".to_owned(),
            _ => panic!("unknown catalog identity role vector"),
        }
        assert_eq!(catalog.resolve(&TrustedArtifactIdentity::from_descriptor(&candidate)).await.is_ok(), case["codec"].as_bool().unwrap(), "codec {}", case["change"]);
        assert_eq!(catalog.resolve_document_open(&candidate, Some(&surface), true).is_some(), case["open"].as_bool().unwrap(), "open {}", case["change"]);
    }
}

#[tokio::test]
async fn trusted_browser_actor_loader_verifies_retains_and_cancels_before_publication() {
    struct ActorControl {
        control: TestControl,
        cancel_after_descriptor: bool,
    }
    impl AuthorityOperationControl for ActorControl {
        fn now_ms(&self) -> u64 {
            0
        }
        fn is_cancelled(&self) -> bool {
            self.control.is_cancelled()
        }
        fn report(&self, progress: AuthorityProgress) {
            if self.cancel_after_descriptor && progress.stage == AuthorityProgressStage::CatalogLoading && progress.completed_units == 6 {
                self.control.cancelled.store(true, Ordering::SeqCst);
            }
            self.control.report(progress);
        }
    }
    let corpus: serde_json::Value = serde_json::from_str(semio_hub_testing::hub_source("🗿️artifact-authority/🔏️trusted-catalog/🧪️tests/🧫️fixtures/🌐️browser-actor/🔣️.json")).unwrap();
    for law in corpus["loadCases"].as_array().unwrap() {
        let mut fixture = prepared_fixture();
        let path = fixture.root.join(fixture.bundle["packages"][0]["browserActor"]["path"].as_str().unwrap());
        if let Some(hex) = law["bodyHex"].as_str() {
            let bytes: Vec<u8> = hex.as_bytes().chunks_exact(2).map(|pair| u8::from_str_radix(std::str::from_utf8(pair).unwrap(), 16).unwrap()).collect();
            std::fs::write(&path, bytes).unwrap();
        } else {
            std::fs::remove_file(&path).unwrap();
        }
        fixture.bundle["packages"][0]["browserActor"]["byteLength"] = law["byteLength"].clone();
        fixture.refresh_profile_generation();
        fixture.persist_bundle();
        let control = ActorControl { control: TestControl::new(), cancel_after_descriptor: law["cancelAfterDescriptor"].as_bool().unwrap() };
        let provider = FixtureProviderSource::new(vec![fixture.binding()]);
        let context = OperationContext::new(u64::MAX, AuthorityLimits::maximum(), &control);
        let result = TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &provider, &context).await;
        let accepted = law["accepted"].as_bool().unwrap();
        assert_eq!(result.is_ok(), accepted, "{}", law["id"]);
        assert_eq!(document_codec(&fixture.schema).await.unwrap().is_some(), accepted, "{} codec publication", law["id"]);
        let calls = provider.calls.lock().unwrap();
        assert_eq!(calls.iter().any(|package| package == "semio:fixture-editor"), accepted, "{} provider preview", law["id"]);
        if let Ok(catalog) = result {
            let package = catalog.packages.iter().find(|package| package.plugin_id == "fixture-editor").unwrap();
            let asset = package.browser_actor_asset.as_ref().unwrap();
            let bytes = asset.read(&context).await.expect("verified actor rereads");
            assert_eq!(bytes.as_ref(), b"abc");
            let selected = catalog.selected_document_open().unwrap();
            assert_eq!(selected.browser_actor, package.browser_actor);
            std::fs::write(&path, b"untrusted replacement").unwrap();
            assert_eq!(bytes.as_ref(), b"abc");
            let DocumentOpenBrowserActorV1::ClosedBrowserActor { sha256, source_component_sha256, source_descriptor_byte_sha256, .. } = &selected.browser_actor else { panic!("required actor") };
            assert_eq!(*sha256, hex_lower(&Sha256::digest(&bytes)));
            assert_eq!(*source_component_sha256, selected.package.component_sha256);
            assert_eq!(*source_descriptor_byte_sha256, selected.package.descriptor_byte_sha256);
            assert!(Arc::ptr_eq(&bytes, &asset.read(&context).await.expect("held actor stays resident")));
            drop(bytes);
            assert!(asset.read(&context).await.is_err(), "a replaced actor file is refused once no reader holds the verified bytes");
        } else if control.cancel_after_descriptor {
            assert!(matches!(result, Err(AuthorityError::Cancelled)));
        }
    }
}

#[tokio::test]
async fn trusted_catalog_opened_root_rejects_linked_roots_leaves_intermediates_and_actors() {
    let leaf = prepared_fixture();
    let leaf_path = leaf.component_path(0);
    let leaf_target = leaf.root.join("components/retained-component.wasm");
    std::fs::write(&leaf_target, std::fs::read(&leaf_path).expect("read component")).expect("write retained component");
    std::fs::remove_file(&leaf_path).expect("remove component leaf");
    fixture_file_link(&leaf_target, &leaf_path);
    assert_linked_fixture_denied(&leaf).await;

    let intermediate = prepared_fixture();
    let components = intermediate.root.join("components");
    let retained_components = intermediate.root.join("retained-components");
    std::fs::rename(&components, &retained_components).expect("retain component directory");
    fixture_directory_link(&retained_components, &components);
    assert_linked_fixture_denied(&intermediate).await;

    let actor = prepared_fixture();
    let actor_path = actor.root.join("browser/closed-actor.mjs");
    let actor_target = actor.root.join("browser/retained-actor.mjs");
    std::fs::write(&actor_target, std::fs::read(&actor_path).expect("read actor")).expect("write retained actor");
    std::fs::remove_file(&actor_path).expect("remove actor leaf");
    fixture_file_link(&actor_target, &actor_path);
    assert_linked_fixture_denied(&actor).await;

    let owner_fixture = prepared_fixture();
    let actual_data = owner_fixture.root.join("owned-data");
    std::fs::create_dir(&actual_data).expect("create owned data root");
    let linked_data = owner_fixture.root.join("linked-data");
    fixture_directory_link(&actual_data, &linked_data);
    let canonical_owner_root = std::fs::canonicalize(&owner_fixture.root).expect("canonical fixture-owned parent root");
    assert!(TrustedCatalogDataRoot::open_server_owned(&canonical_owner_root.join("linked-data")).is_err(), "linked initial data root was admitted");

    let trusted = actual_data.join("trusted-catalog");
    std::fs::create_dir(&trusted).expect("create trusted root");
    let current_target = actual_data.join("retained-current.json");
    std::fs::write(&current_target, b"{}\n").expect("write current target");
    fixture_file_link(&current_target, &trusted.join("current.json"));
    let canonical_data = std::fs::canonicalize(&actual_data).expect("canonical fixture-owned data root");
    let data_root = TrustedCatalogDataRoot::open_server_owned(&canonical_data).expect("open fixture-owned data root");
    assert!(data_root.open_current().is_err(), "linked current pointer was admitted");

    let generations = trusted.join("generations");
    std::fs::create_dir(&generations).expect("create generations root");
    let retained_generation = trusted.join("retained-generation");
    std::fs::create_dir(&retained_generation).expect("create retained generation");
    let generation_id = "ab".repeat(32);
    fixture_directory_link(&retained_generation, &generations.join(&generation_id));
    assert!(data_root.open_generation(&generation_id).is_err(), "linked generation root was admitted");
}

#[tokio::test]
async fn trusted_catalog_opened_handle_is_swap_stable_bounded_and_cancel_safe() {
    let fixture = prepared_fixture();
    let canonical_root = std::fs::canonicalize(&fixture.root).expect("canonical fixture-owned generation root");
    let root = TrustedCatalogGenerationRoot::open_fixture_owned(&canonical_root).expect("opened generation root");
    let relative = TrustedCatalogRelativePathV1::parse(fixture.bundle["packages"][0]["component"]["path"].as_str().expect("component path")).expect("relative component path");
    let opened = root.open_regular(&relative).expect("open retained component handle");
    let component_path = fixture.component_path(0);
    std::fs::rename(&component_path, fixture.root.join("original-component.wasm")).expect("retain opened component inode");
    std::fs::write(&component_path, b"xyz").expect("write substituted component path");
    assert_eq!(opened.read_bounded(3, &TestControl::new().context()).await.expect("read retained handle"), b"abc");
    let provider = FixtureProviderSource::new(vec![fixture.binding()]);
    assert!(TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &provider, &TestControl::new().context()).await.is_err(), "substituted component digest loaded");
    assert!(provider.calls.lock().expect("provider calls").is_empty());
    assert!(document_codec(&fixture.schema).await.expect("codec registry").is_none());

    let zero_path = fixture.root.join("zero.bin");
    std::fs::write(&zero_path, []).expect("write zero file");
    let zero = root.open_regular(&TrustedCatalogRelativePathV1::parse("zero.bin").expect("zero path")).expect("open zero file");
    assert!(zero.read_bounded(1, &TestControl::new().context()).await.is_err());

    let over_path = fixture.root.join("over.bin");
    std::fs::write(&over_path, b"abcd").expect("write over-bound file");
    let over = root.open_regular(&TrustedCatalogRelativePathV1::parse("over.bin").expect("over path")).expect("open over-bound file");
    assert!(over.read_bounded(3, &TestControl::new().context()).await.is_err());

    let growth_path = fixture.root.join("growth.bin");
    std::fs::write(&growth_path, b"abc").expect("write growth file");
    let growth = root.open_regular(&TrustedCatalogRelativePathV1::parse("growth.bin").expect("growth path")).expect("open growth file");
    std::fs::OpenOptions::new().append(true).open(&growth_path).expect("open growth writer").write_all(b"d").expect("grow opened file");
    assert!(growth.read_bounded(4, &TestControl::new().context()).await.is_err(), "opened handle admitted growth within the caller maximum");

    #[cfg(unix)]
    {
        let fifo_path = fixture.root.join("special.fifo");
        create_fifo_fixture(&fifo_path).expect("create FIFO fixture");
        assert!(root.open_regular(&TrustedCatalogRelativePathV1::parse("special.fifo").expect("FIFO path")).is_err(), "opened root admitted a blocking special-file leaf");
    }

    struct CancelAfterTwoCheckpoints(AtomicUsize);
    impl AuthorityOperationControl for CancelAfterTwoCheckpoints {
        fn now_ms(&self) -> u64 {
            0
        }
        fn is_cancelled(&self) -> bool {
            self.0.fetch_add(1, Ordering::SeqCst) >= 2
        }
        fn report(&self, _progress: AuthorityProgress) {}
    }
    let large_path = fixture.root.join("large.bin");
    std::fs::write(&large_path, vec![7u8; 64 * 1024 + 1]).expect("write multi-chunk file");
    let large = root.open_regular(&TrustedCatalogRelativePathV1::parse("large.bin").expect("large path")).expect("open multi-chunk file");
    let cancel = CancelAfterTwoCheckpoints(AtomicUsize::new(0));
    let context = OperationContext::new(u64::MAX, AuthorityLimits::maximum(), &cancel);
    assert!(matches!(large.read_bounded(64 * 1024 + 1, &context).await, Err(AuthorityError::Cancelled)));
}

#[test]
fn trusted_catalog_relative_paths_match_the_neutral_no_link_corpus() {
    let corpus: serde_json::Value = serde_json::from_str(include_str!("../🧫️fixtures/🛡️opened-root/🔣️.json")).expect("opened-root corpus");
    let rows = corpus["relativePaths"].as_array().expect("relative path rows");
    assert_eq!(rows.len(), 15);
    for row in rows {
        let value = row["value"].as_str().expect("relative path value");
        assert_eq!(TrustedCatalogRelativePathV1::parse(value).is_ok(), row["accepted"].as_bool().expect("relative path acceptance"), "{}", row["id"]);
    }
}

#[test]
fn descriptor_projection_rejects_package_conflicts_unknown_fields_and_duplicate_fields() {
    let fixture = snapshot_json();
    let bundle: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("bundle");
    let canonical = descriptor_bytes("fixture-editor", "semio:fixture-editor", "1.2.3", Some("fixture.document@1"), Some(("fixture-base", "1.0.0")));
    decode_package_descriptor(&canonical).unwrap_or_else(|error| panic!("canonical descriptor must decode: {error}"));

    let conflicting = decode_package_descriptor(&descriptor_bytes("fixture-editor", "semio:other-package", "1.2.3", Some("fixture.document@1"), Some(("fixture-base", "1.0.0")))).expect("structurally valid conflicting descriptor");
    let refusal = validate_descriptor(&bundle.packages[0], &conflicting, &bundle.packages).expect_err("package mismatch").to_string();
    assert!(refusal.contains("identity") && refusal.contains("semio:fixture-editor") && refusal.ends_with("packageId"), "{refusal}");

    let mut stale_record = bundle.packages[0].clone();
    let mut stale = decode_package_descriptor(&canonical).expect("canonical descriptor");
    stale_record.execution_protocol.app_channel_version = directory::os_spr::CHANNEL_VERSION - 1;
    stale.execution_protocol.app_channel_version = directory::os_spr::CHANNEL_VERSION - 1;
    let refusal = validate_descriptor(&stale_record, &stale, &bundle.packages).expect_err("a catalog of another app channel").to_string();
    assert!(refusal.contains("semio:fixture-editor") && refusal.contains(&format!("app channel {}", directory::os_spr::CHANNEL_VERSION - 1)) && refusal.contains(&format!("speaks app channel {}", directory::os_spr::CHANNEL_VERSION)), "{refusal}");

    let mut unknown = os_pack::pack_rt::decode_wire_value(&canonical).expect("canonical value");
    let DslValue::Object(fields) = &mut unknown else { panic!("descriptor object") };
    fields.push(("unexpected".to_owned(), DslValue::Null));
    let error = decode_package_descriptor(&os_pack::pack_rt::encode_wire_value(&unknown)).expect_err("unknown descriptor field");
    assert!(error.to_string().contains("unknown field") || error.to_string().contains("canonical schema projection"));

    let mut duplicate = os_pack::pack_rt::decode_wire_value(&canonical).expect("canonical value");
    let DslValue::Object(fields) = &mut duplicate else { panic!("descriptor object") };
    fields.push(("packageId".to_owned(), DslValue::String("semio:fixture-editor".to_owned())));
    assert!(decode_package_descriptor(&os_pack::pack_rt::encode_wire_value(&duplicate)).expect_err("duplicate descriptor field").to_string().contains("duplicate object field"));
    assert!(valid_package_id("semio:fixture-editor"));
    assert!(!valid_package_id("fixture.editor.native"));
    assert!(!valid_package_id("semio:Fixture"));
}

#[tokio::test]
async fn all_trust_failures_precede_activation_and_have_bounded_diagnostics() {
    let mut mutated = prepared_fixture();
    std::fs::write(mutated.component_path(0), b"abd").expect("mutate component");
    let control = TestControl::new();
    let error = expect_load_error(&mutated, &[mutated.binding()], &control).await;
    assert!(error.to_string().contains("digest"));
    assert!(document_codec(&mutated.schema).await.expect("codec registry").is_none());

    let mut descriptor_mutation = prepared_fixture();
    let descriptor_path = descriptor_mutation.root.join(descriptor_mutation.bundle["packages"][0]["descriptor"]["path"].as_str().expect("descriptor path"));
    let mut bytes = std::fs::read(&descriptor_path).expect("descriptor bytes");
    let last = bytes.last_mut().expect("descriptor byte");
    *last ^= 1;
    std::fs::write(descriptor_path, bytes).expect("mutate descriptor");
    let error = expect_load_error(&descriptor_mutation, &[descriptor_mutation.binding()], &control).await;
    assert!(error.to_string().contains("digest"));
    assert!(document_codec(&descriptor_mutation.schema).await.expect("codec registry").is_none());

    let missing = prepared_fixture();
    let context = control.context();
    let loaded = load_fixture(&missing, &[], &context).await.expect("a row no provider answers for loads and waits for its component's answer");
    let owner = loaded.codecs.iter().find(|codec| codec.identity.artifact_schema == missing.schema).expect("the pending row's codec");
    let staged = |catalog: &VerifiedTrustedCatalog| catalog.load_progress().packages[owner.guest.component.position].phase;
    assert_eq!(staged(&loaded), TrustedCatalogPackagePhaseV1::Staged, "nothing interpreted the component during the load");
    let error = owner.guest.genesis("fixture-document", &context).await.expect_err("no codec call runs before its rows are pinned");
    assert!(error.to_string().contains(&missing.schema), "the refusal names the row it was pinning: {error}");
    assert_eq!(staged(&loaded), TrustedCatalogPackagePhaseV1::Refused);
    loaded.verify_pending_guests(&context).await.expect("a refused package does not stop the background pass");
    assert_eq!(loaded.load_progress().packages_refused, 1);
    assert!(owner.guest.genesis("fixture-document", &context).await.expect_err("a refused package refuses every call").to_string().contains(&missing.schema));
    assert!(document_codec(&missing.schema).await.expect("codec registry").is_none());

    let wrong_package = prepared_fixture();
    let lossy = NativeCodecBinding::new("fixture-editor", "semio:fixture-wrong", "s.fixture.document", None, fixture_codec(&wrong_package.schema, [0x11; 32]));
    let error = expect_load_error(&wrong_package, &[lossy], &control).await;
    assert!(error.to_string().contains("no explicit native codec"));
    assert!(document_codec(&wrong_package.schema).await.expect("codec registry").is_none());

    let mut zero = prepared_fixture();
    zero.bundle["packages"][0]["nativeCodecs"][0]["packSchemaHash"] = "00".repeat(32).into();
    zero.persist_bundle();
    let error = expect_load_error(&zero, &[zero.binding()], &control).await;
    assert!(error.to_string().contains("zero"));
    assert!(document_codec(&zero.schema).await.expect("codec registry").is_none());

    let mut detached_open_target = prepared_fixture();
    detached_open_target.bundle["packages"][0]["openTargets"][0]["packSchemaHash"] = "12".repeat(32).into();
    detached_open_target.persist_bundle();
    let error = expect_load_error(&detached_open_target, &[detached_open_target.binding()], &control).await;
    assert!(error.to_string().contains("open target"));
    assert!(document_codec(&detached_open_target.schema).await.expect("codec registry").is_none());

    let mismatch = prepared_fixture();
    let binding = NativeCodecBinding::new("fixture-editor", "semio:fixture-editor", "s.fixture.document", None, fixture_codec(&mismatch.schema, [0x12; 32]));
    let error = expect_load_error(&mismatch, &[binding], &control).await;
    assert!(error.to_string().contains("mismatched"));
    assert!(document_codec(&mismatch.schema).await.expect("codec registry").is_none());

    let cancelled = prepared_fixture();
    let control = TestControl::new();
    control.cancelled.store(true, Ordering::SeqCst);
    assert_eq!(expect_load_error(&cancelled, &[cancelled.binding()], &control).await, AuthorityError::Cancelled);
    assert!(document_codec(&cancelled.schema).await.expect("codec registry").is_none());
    assert!(catalog_error("x".repeat(AUTHORITY_MAX_DIAGNOSTIC_BYTES * 2)).to_string().len() <= AUTHORITY_MAX_DIAGNOSTIC_BYTES + 40);
}

/// 🎲️ What [`owned_test_guest`]'s `pack-schema-hash` does: answer a hash, or loop until its interpretation is ended.
#[derive(Clone, Copy)]
enum OwnedTestHash {
    Answers([u8; 32]),
    Spins,
}

/// 🧩️ A real owned-ABI guest, one memory page and every owned export: `channel-version` answers the host's app channel
/// (the owned codec origin admits it first), `pack-schema-hash` does what `hash` says, `genesis` answers the pair
/// `([1, 2, 3], [4, 5])`, every other export answers nothing. Built byte by byte (the
/// interpreter's own component framing), so a law runs the production interpreter without a plugin build.
fn owned_test_guest(hash: OwnedTestHash) -> Vec<u8> {
    fn uleb(mut value: u64, output: &mut Vec<u8>) {
        loop {
            let byte = (value & 0x7f) as u8;
            value >>= 7;
            output.push(if value == 0 { byte } else { byte | 0x80 });
            if value == 0 {
                return;
            }
        }
    }
    fn sleb(mut value: i64, output: &mut Vec<u8>) {
        loop {
            let byte = (value & 0x7f) as u8;
            value >>= 7;
            let done = (value == 0 && byte & 0x40 == 0) || (value == -1 && byte & 0x40 != 0);
            output.push(if done { byte } else { byte | 0x80 });
            if done {
                return;
            }
        }
    }
    fn section(id: u8, payload: Vec<u8>, output: &mut Vec<u8>) {
        output.push(id);
        uleb(payload.len() as u64, output);
        output.extend(payload);
    }
    let answer = match hash {
        OwnedTestHash::Answers(answer) => answer,
        OwnedTestHash::Spins => [0; 32],
    };
    let hash_output = format!("{{\"Ok\":{}}}", serde_json::to_string(&answer.to_vec()).unwrap()).into_bytes();
    let genesis_output = br#"{"Ok":{"pack":[1,2,3],"spr":[4,5]}}"#.to_vec();
    let channel_output = directory::os_spr::CHANNEL_VERSION.to_string().into_bytes();
    let returning = |offset: i64, output: &[u8]| {
        let mut body = vec![0x00, 0x42];
        sleb(((output.len() as i64) << 32) | offset, &mut body);
        body.push(0x0b);
        body
    };
    let exports = semio_framework_plugin_interpreter::OwnedSemioExport::ALL;
    let (types, bodies): (Vec<u8>, Vec<Vec<u8>>) = exports
        .iter()
        .map(|export| match export {
            semio_framework_plugin_interpreter::OwnedSemioExport::Allocate => (0u8, vec![0x00, 0x41, 0x00, 0x0b]),
            semio_framework_plugin_interpreter::OwnedSemioExport::Deallocate => (1, vec![0x00, 0x0b]),
            semio_framework_plugin_interpreter::OwnedSemioExport::Checkpoint | semio_framework_plugin_interpreter::OwnedSemioExport::Describe => (2, vec![0x00, 0x42, 0x00, 0x0b]),
            semio_framework_plugin_interpreter::OwnedSemioExport::ChannelVersion => (2, returning(3072, &channel_output)),
            semio_framework_plugin_interpreter::OwnedSemioExport::PackSchemaHash => match hash {
                OwnedTestHash::Answers(_) => (3, returning(1024, &hash_output)),
                OwnedTestHash::Spins => (3, vec![0x00, 0x03, 0x40, 0x0c, 0x00, 0x0b, 0x42, 0x00, 0x0b]),
            },
            semio_framework_plugin_interpreter::OwnedSemioExport::Genesis => (3, returning(2048, &genesis_output)),
            _ => (3, vec![0x00, 0x42, 0x00, 0x0b]),
        })
        .unzip();
    let mut core = b"\0asm\x01\0\0\0".to_vec();
    section(1, vec![4, 0x60, 1, 0x7f, 1, 0x7f, 0x60, 2, 0x7f, 0x7f, 0, 0x60, 0, 1, 0x7e, 0x60, 2, 0x7f, 0x7f, 1, 0x7e], &mut core);
    let mut functions = Vec::new();
    uleb(types.len() as u64, &mut functions);
    functions.extend(&types);
    section(3, functions, &mut core);
    section(5, vec![1, 0x00, 1], &mut core);
    let mut export_section = Vec::new();
    uleb(exports.len() as u64 + 1, &mut export_section);
    export_section.push(6);
    export_section.extend(b"memory");
    export_section.extend([2, 0]);
    for (index, export) in exports.iter().enumerate() {
        uleb(export.core_name().len() as u64, &mut export_section);
        export_section.extend(export.core_name().as_bytes());
        export_section.push(0);
        uleb(index as u64, &mut export_section);
    }
    section(7, export_section, &mut core);
    let mut code = Vec::new();
    uleb(bodies.len() as u64, &mut code);
    for body in &bodies {
        uleb(body.len() as u64, &mut code);
        code.extend(body);
    }
    section(10, code, &mut core);
    let mut data = vec![3];
    for (offset, output) in [(1024i64, &hash_output), (2048, &genesis_output), (3072, &channel_output)] {
        data.extend([0x00, 0x41]);
        sleb(offset, &mut data);
        data.push(0x0b);
        uleb(output.len() as u64, &mut data);
        data.extend(output.iter());
    }
    section(11, data, &mut core);
    let mut component = b"\0asm\x0d\0\x01\0".to_vec();
    section(1, core, &mut component);
    component
}

/// 🧩️ Replaces the fixture editor package's component with [`owned_test_guest`] hashing as `hash` says, leaving its
/// one codec row (`0x11 × 32`) to be pinned against the guest: no provider binds it.
fn install_owned_guest(fixture: &mut FixtureDirectory, hash: OwnedTestHash) {
    let bytes = owned_test_guest(hash);
    std::fs::write(fixture.component_path(0), &bytes).expect("owned guest component");
    let sha256 = hex_lower(&Sha256::digest(&bytes));
    let mut blake3 = Hasher::new();
    blake3.update(&bytes);
    let component = &mut fixture.bundle["packages"][0]["component"];
    component["byteLength"] = bytes.len().into();
    component["sha256"] = sha256.clone().into();
    component["blake3"] = hex_lower(blake3.finalize().as_bytes()).into();
    fixture.bundle["packages"][0]["browserActor"]["sourceComponentSha256"] = sha256.into();
    let schema = fixture.schema.clone();
    fixture.rewrite_descriptor(0, Some(&schema), Some(("fixture-base", "1.0.0")));
}

/// 🔐️ LAW (coordinator, session 13): no codec call is ever served from a row its component has not answered as the trust
/// record says — not before the background pass reached it (the first call verifies it itself), not after the guest was
/// released and compiled again (zero residency budget: every operation compiles, the row is verified once), and not from
/// component bytes that changed after the verification. A guest that answers differently refuses every call of its
/// package. Runs the production interpreter on a real owned-ABI guest ([`owned_test_guest`]).
#[tokio::test]
async fn no_codec_call_is_served_from_a_row_its_component_has_not_answered() {
    let control = TestControl::new();
    let answered = |fixture: &FixtureDirectory, catalog: &VerifiedTrustedCatalog| catalog.codecs.iter().position(|codec| codec.identity.artifact_schema == fixture.schema).expect("the fixture row's codec");
    let mut fixture = prepared_fixture();
    install_owned_guest(&mut fixture, OwnedTestHash::Answers([0x11; 32]));
    let catalog = load_fixture(&fixture, &[], &control.context()).await.expect("a catalog whose row waits for its guest");
    catalog.configure_guest_residency(TrustedCatalogGuestResidencyV1 { resident_component_bytes: 0, ..TRUSTED_CATALOG_GUEST_RESIDENCY });
    let owner = &catalog.codecs[answered(&fixture, &catalog)];
    let position = owner.guest.component.position;
    assert_eq!(catalog.load_progress().packages[position].phase, TrustedCatalogPackagePhaseV1::Staged);
    let first = owner.guest.genesis("document-1", &control.context()).await.expect("the row answers as recorded, then the call is served");
    assert_eq!((first.pack.clone(), first.spr.clone()), (vec![1, 2, 3], vec![4, 5]));
    let progress = catalog.load_progress();
    assert_eq!((progress.packages[position].phase, progress.rows_verified), (TrustedCatalogPackagePhaseV1::Ready, 1));
    assert_eq!(catalog.guest_residency().resident_guests, 0, "a zero budget released the guest with its operation");
    let again = owner.guest.genesis("document-1", &control.context()).await.expect("a released guest compiles again and is served");
    assert_eq!((again.pack, again.spr), (first.pack, first.spr), "the reloaded guest answers the same");
    let residency = catalog.guest_residency();
    assert_eq!((residency.compiles, residency.admitted), (2, 0), "the row was verified once; the second operation compiled again");
    assert_eq!(catalog.load_progress().rows_verified, 1);
    std::fs::write(fixture.component_path(0), owned_test_guest(OwnedTestHash::Answers([0x11; 32])).iter().rev().copied().collect::<Vec<u8>>()).expect("tamper the verified component");
    assert!(owner.guest.genesis("document-1", &control.context()).await.is_err(), "bytes that changed after the verification are never compiled, so never served");

    let mut lying = prepared_fixture();
    install_owned_guest(&mut lying, OwnedTestHash::Answers([0x22; 32]));
    let refused = load_fixture(&lying, &[], &control.context()).await.expect("a catalog whose guest will answer differently");
    let liar = &refused.codecs[answered(&lying, &refused)];
    let error = liar.guest.genesis("document-1", &control.context()).await.expect_err("a row answered differently is never served");
    assert!(error.to_string().contains("differs from its trust record"), "{error}");
    refused.verify_pending_guests(&control.context()).await.expect("the background pass records the refusal and moves on");
    assert_eq!(refused.load_progress().packages_refused, 1);
    assert!(liar.guest.genesis("document-2", &control.context()).await.is_err(), "the refusal is permanent for the catalog");

    let mut background = prepared_fixture();
    install_owned_guest(&mut background, OwnedTestHash::Answers([0x11; 32]));
    let verified = load_fixture(&background, &[], &control.context()).await.expect("a catalog verified in the background");
    verified.verify_pending_guests(&control.context()).await.expect("background pass");
    let progress = verified.load_progress();
    assert_eq!((progress.packages_ready, progress.packages_total, progress.rows_verified), (progress.packages_total, 2, 1));
    let served = &verified.codecs[answered(&background, &verified)];
    assert!(served.guest.genesis("document-1", &control.context()).await.is_ok());
}

/// 🧬️ LAW (ticket 26/09/23, H12): a guest `codec` call answers through its owner's codec table and constructs no app,
/// and those answers equal the independently linked native codecs of the plugins this hub links an assembly of — gis
/// and vcs (puzzle's own law covers a third): the same pack-schema hash, the NATIVE codec decodes the table's genesis
/// pair, and both print the same op log of it (the `dsl` renderings differ by design: document text vs the kind's DSL). A schema the bundle declares without owning is
/// refused as unowned. Every plugin contributes at least one owned comparison.
#[tokio::test]
async fn guest_codec_tables_answer_like_the_linked_native_codecs() {
    macro_rules! compare_plugin {
        ($plugin:expr, $codecs:expr) => {{
            let runtime = semio_framework_plugin::plugin_runtime::PluginRuntime::new(semio_framework_plugin::MountedOwnerPolicyV1::INTERACTIVE_COMPONENT).expect("explicit test mounted owner policy");
            semio_framework_plugin::plugin_runtime::install_plugin_bundle(&runtime, $plugin.expect("plugin assembles"));
            let document_id = format!("artifact-{}", "2".repeat(32));
            let (mut owned, mut unowned) = (Vec::new(), 0usize);
            for codec in $codecs {
                match semio_framework_plugin::plugin_runtime::plugin_artifact_pack_schema_hash(&runtime, &codec.schema).await {
                    Err(fault) => {
                        assert!(format!("{fault:?}").contains("owned by no app"), "{}: {fault:?}", codec.schema);
                        unowned += 1;
                    }
                    Ok(hash) => {
                        assert_eq!(hash, codec.pack_schema_hash, "{}: pack-schema hash", codec.schema);
                        let pair = semio_framework_plugin::plugin_runtime::plugin_artifact_genesis(&runtime, &codec.schema, &document_id).await.unwrap_or_else(|fault| panic!("{}: genesis {fault:?}", codec.schema));
                        let guest = semio_framework_plugin::plugin_runtime::plugin_artifact_print_mirror(&runtime, &codec.schema, &pair.pack, &pair.spr).await.unwrap_or_else(|fault| panic!("{}: guest mirror {fault:?}", codec.schema));
                        let native = (codec.print_mirror)(&pair.pack, &pair.spr).await.unwrap_or_else(|error| panic!("{}: native mirror {error:?}", codec.schema));
                        assert_eq!(guest.ops, native.ops, "{}: op-log mirror", codec.schema);
                        assert!(!guest.dsl.is_empty() && !native.dsl.is_empty(), "{}: both render the document", codec.schema);
                        owned.push(codec.schema.clone());
                    }
                }
            }
            (owned, unowned)
        }};
    }
    let gis = compare_plugin!(semio_hub_gis::plugin(), semio_hub_gis::native_codecs::native_codec_factory_receipts().expect("gis receipts").into_iter().map(|receipt| receipt.into_codec().expect("gis codec")));
    let vcs = compare_plugin!(semio_hub_vcs::plugin(), semio_hub_vcs::native_codecs::native_codec_factory_receipts().expect("vcs receipts").into_iter().map(|receipt| receipt.into_codec().expect("vcs codec")));
    for (plugin, (owned, unowned)) in [("gis", &gis), ("vcs", &vcs)] {
        assert!(!owned.is_empty(), "{plugin}: at least one owned kind compared ({unowned} unowned)");
    }
}

/// 📈️ A catalog load reports every selected package into the host's progress cell — phase, component bytes and
/// codec rows — and the counts add up: a load whose rows a linked codec pins ends with every package ready,
/// every component byte read and no row interpreted; the body is exactly `TrustedCatalogLoadProgressV1`.
#[tokio::test]
async fn a_catalog_load_reports_every_package_phase_bytes_and_rows_into_the_hosts_cell() {
    struct ObservedControl(Arc<TrustedCatalogLoadProgressCellV1>);
    impl AuthorityOperationControl for ObservedControl {
        fn now_ms(&self) -> u64 {
            0
        }

        fn is_cancelled(&self) -> bool {
            false
        }

        fn report(&self, _progress: AuthorityProgress) {}
    }
    let fixture = prepared_fixture();
    let control = ObservedControl(Arc::default());
    let context = OperationContext::new(u64::MAX, AuthorityLimits::maximum(), &control);
    let catalog = TrustedCatalogLoader::load_fixture_observed(&fixture.bundle_path, "fixture", &FixtureProviderSource::new(vec![fixture.binding()]), &control.0, &context).await.expect("fixture catalog");
    let observed = control.0.snapshot();
    assert_eq!(observed, catalog.load_progress(), "the catalog keeps reporting into the host's cell");
    assert!(observed.packages_total >= 1 && observed.packages.len() as u64 == observed.packages_total);
    assert_eq!(observed.packages_ready, observed.packages_total, "{observed:?}");
    assert_eq!((observed.packages_refused, observed.rows_verified), (0, 0));
    assert_eq!(observed.component_bytes_read, observed.component_bytes_total);
    assert_eq!(observed.rows_pinned, observed.rows_total);
    assert_eq!(observed.rows_total, observed.packages.iter().map(|package| package.rows).sum::<u64>());
    catalog.verify_pending_guests(&context).await.expect("nothing is pending");
    let module: serde_json::Value = serde_json::from_str(semio_hub_trusted_catalog_contract::schema::TRUSTED_CATALOG_SCHEMA_JSON).unwrap();
    let fields = |def: &str| module["$defs"][def]["required"].as_array().unwrap().iter().map(|field| field.as_str().unwrap().to_string()).collect::<BTreeSet<_>>();
    let body = serde_json::to_value(&observed).unwrap();
    assert_eq!(body.as_object().unwrap().keys().cloned().collect::<BTreeSet<_>>(), fields("TrustedCatalogLoadProgressV1"));
    assert_eq!(body["packages"][0].as_object().unwrap().keys().cloned().collect::<BTreeSet<_>>(), fields("TrustedCatalogPackageProgressV1"));
    let phases: Vec<String> = module["$defs"]["TrustedCatalogPackagePhaseV1"]["enum"].as_array().unwrap().iter().map(|phase| phase.as_str().unwrap().to_string()).collect();
    let spelled: Vec<String> = [TrustedCatalogPackagePhaseV1::Pending, TrustedCatalogPackagePhaseV1::Reading, TrustedCatalogPackagePhaseV1::Staged, TrustedCatalogPackagePhaseV1::Verifying, TrustedCatalogPackagePhaseV1::Ready, TrustedCatalogPackagePhaseV1::Refused]
        .iter()
        .map(|phase| serde_json::to_value(phase).unwrap().as_str().unwrap().to_string())
        .collect();
    assert_eq!(spelled, phases);
}

#[tokio::test]
async fn descriptor_owned_surface_is_required_before_any_catalog_or_codec_publication() {
    for (field, value) in [
        ("artifactKind", serde_json::json!("fixture.document")),
        ("surfaceId", serde_json::json!("s.fixture.document@1/*#foreign")),
        ("appId", serde_json::json!("s.fixture.document@1/*#foreign")),
        ("windowKindId", serde_json::json!("foreign.window")),
        ("role", serde_json::json!("viewer")),
        ("rendererTarget", serde_json::json!("wgpu")),
    ] {
        let mut fixture = prepared_fixture();
        fixture.bundle["packages"][0]["openTargets"][0][field] = value.clone();
        fixture.bundle["profiles"][0]["openTargets"][0]["target"][field] = value;
        fixture.persist_bundle();
        let error = expect_load_error(&fixture, &[fixture.binding()], &TestControl::new()).await;
        assert!(error.to_string().contains("document-open target"), "{field}: {error}");
        assert!(document_codec(&fixture.schema).await.expect("codec registry").is_none(), "{field} published a codec");
    }
}

#[test]
fn descriptor_open_targets_follow_the_one_pairing_rule_and_validate_as_published() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!("../🧫️fixtures/🎯️descriptor-open-targets/🔣️.json")).unwrap();
    let schema = "fixture.document@1";
    for case in fixture["cases"].as_array().unwrap() {
        let name = case["name"].as_str().unwrap();
        let mut descriptor = decode_package_descriptor(&descriptor_bytes("fixture-editor", "semio:fixture-editor", "1.0.0", Some(schema), None)).expect("fixture descriptor");
        descriptor.execution = serde_json::from_value(case["execution"].clone()).expect("execution mode");
        descriptor.manifest.artifact_kinds[0].id = case["kindId"].as_str().unwrap().to_string();
        if case["declaredOn"] == "editor" {
            let kind = descriptor.manifest.artifact_kinds.remove(0);
            descriptor.manifest.apps.iter_mut().find(|app| app.role == semio_framework::AppRole::Editor).expect("editor app").artifact_kinds.push(kind);
        }
        if case["declaredOn"] == "hosted" {
            let kind = descriptor.manifest.artifact_kinds.remove(0);
            descriptor.manifest.hosted_artifact_kinds.push(semio_framework::HostedArtifactKind { id: kind.id, schema: kind.schema, owner: "fixture-owner".into() });
        }
        if case["declaredOn"] == "hosted-presented" {
            let kind = descriptor.manifest.artifact_kinds.remove(0);
            let editor = descriptor.manifest.apps.iter_mut().find(|app| app.role == semio_framework::AppRole::Editor).expect("editor app");
            editor.io.artifact.id = kind.id.clone();
            editor.io.artifact_schema = kind.schema.clone();
            descriptor.manifest.hosted_artifact_kinds.push(semio_framework::HostedArtifactKind { id: kind.id, schema: kind.schema, owner: "fixture-owner".into() });
        }
        if case["declaredOn"] == "plugin-and-editor" {
            let kind = descriptor.manifest.artifact_kinds[0].clone();
            descriptor.manifest.apps.iter_mut().find(|app| app.role == semio_framework::AppRole::Editor).expect("editor app").artifact_kinds.push(kind);
        }
        let bytes = os_pack::pack_rt::encode_wire_value(&semio_framework_value::ToValue::to_value(&descriptor));
        let answer: serde_json::Value = serde_json::from_slice(&descriptor_open_targets_answer(&bytes).expect("open-target answer")).expect("answer json");
        assert_eq!(answer["schema"], fixture["answerSchema"], "{name}");
        let targets = answer["targets"].as_array().unwrap();
        let expected = case["targets"].as_array().unwrap();
        assert_eq!(targets.len(), expected.len(), "{name}: {answer}");
        for (target, expected) in targets.iter().zip(expected) {
            assert_eq!(target["role"], expected["role"], "{name}");
            assert_eq!(target["surfaceId"], expected["surfaceId"], "{name}");
            assert_eq!(target["appId"], expected["surfaceId"], "{name}");
            assert_eq!(target["windowKindId"], fixture["windowKindId"], "{name}");
            assert_eq!(target["artifactKind"], case["kindId"], "{name}");
            assert_eq!(target["artifactSchema"], schema, "{name}");
            assert_eq!(target["rendererTarget"], "wasm", "{name}");
            assert_eq!(target["grant"], serde_json::json!({ "read": true, "write": expected["write"], "observe": true }), "{name}");
            let mut published = target.as_object().unwrap().clone();
            published.insert("packSchemaHash".into(), serde_json::json!("44".repeat(32)));
            let published: TrustedBundleOpenTargetV1 = serde_json::from_value(serde_json::Value::Object(published)).expect("bundle open target");
            assert_eq!(validate_descriptor_open_target(&descriptor, &published).expect("an answered target validates").artifact_kind, "s.fixture.document", "{name}");
        }
    }
    assert!(descriptor_open_targets_answer(&[]).is_err());
}

#[test]
fn bundle_rejects_incomplete_duplicate_conflicting_and_escaping_declarations() {
    let fixture = snapshot_json();
    let mut bundle: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("bundle");
    bundle.packages.pop();
    assert!(validate_bundle(&bundle, "fixture").expect_err("incomplete closure").to_string().contains("incomplete"));

    let mut bundle: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("bundle");
    bundle.packages[1].package_id = bundle.packages[0].package_id.clone();
    assert!(validate_bundle(&bundle, "fixture").expect_err("duplicate package identity").to_string().contains("duplicated"));

    let mut bundle: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("bundle");
    bundle.profiles[0].selected_closure[0].version = "9.9.9".to_string();
    assert!(validate_bundle(&bundle, "fixture").expect_err("conflicting closure identity").to_string().contains("conflicts"));

    let mut bundle: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("bundle");
    bundle.packages[0].component.path = "../escape.wasm".to_string();
    let error = TrustedCatalogRelativePathV1::parse(&bundle.packages[0].component.path).expect_err("escaping path");
    assert!(error.to_string().contains("relative path"));
}

#[test]
fn trusted_profile_generation_binds_zero_target_package_and_every_codec_row() {
    let dependency_fixture: serde_json::Value = serde_json::from_str(semio_hub_testing::hub_source("🗿️artifact-authority/🔏️trusted-catalog/🧪️tests/🧫️fixtures/🔗️compiled-dependencies/🔣️.json")).unwrap();
    for row in dependency_fixture["encodingCases"].as_array().unwrap() {
        let identities: Vec<TrustedBundleIdentityV1> = serde_json::from_value(row["identities"].clone()).unwrap();
        let mut encoded = Vec::new();
        append_trusted_profile_dependencies(&mut encoded, &identities).unwrap();
        assert_eq!(hex_lower(&encoded), row["hex"].as_str().unwrap(), "{}", row["name"]);
    }
    let fixture = snapshot_json();
    let bundle: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("bundle");
    let original = trusted_profile_generation(&bundle, &bundle.profiles[0]).expect("generation");

    let mut component: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("component bundle");
    component.packages[1].component.sha256 = "31".repeat(32);
    assert_ne!(trusted_profile_generation(&component, &component.profiles[0]).expect("component generation"), original, "zero-target component SHA-256 must rotate the profile");

    let mut descriptor: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("descriptor bundle");
    descriptor.packages[1].descriptor.sha256 = "32".repeat(32);
    assert_ne!(trusted_profile_generation(&descriptor, &descriptor.profiles[0]).expect("descriptor generation"), original, "zero-target descriptor SHA-256 must rotate the profile");

    let mut codec: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("codec bundle");
    codec.packages[0].native_codecs[0].pack_schema_hash = "33".repeat(32);
    assert_ne!(trusted_profile_generation(&codec, &codec.profiles[0]).expect("codec generation"), original, "every codec row must rotate the profile");
}

#[test]
fn local_stdio_gis_profile_is_exact_two_packages_thirty_one_codecs_and_opens_every_package_target() {
    let bundle = local_stdio_gis_profile_bundle();
    let selected = validate_bundle(&bundle, "local-stdio-gis-open-v1").expect("closed stdio+GIS profile");
    assert_eq!(selected.package_indices.len(), 2);
    assert_eq!(selected.package_indices, vec![1, 0]);
    assert_eq!(bundle.packages.iter().map(|package| package.native_codecs.len()).sum::<usize>(), 31);
    assert_eq!(bundle.packages.iter().map(|package| package.open_targets.len()).sum::<usize>(), 2);
    let mut writable_viewer = local_stdio_gis_profile_bundle();
    writable_viewer.packages[0].open_targets[1].grant.write = true;
    writable_viewer.profiles[0].open_targets[1].target.grant.write = true;
    assert!(validate_bundle(&writable_viewer, "local-stdio-gis-open-v1").is_err(), "a viewer target never carries a write grant");
    let mut missing_dependency = local_stdio_gis_profile_bundle();
    missing_dependency.packages[0].dependencies.clear();
    assert!(validate_bundle(&missing_dependency, "local-stdio-gis-open-v1").expect_err("missing compiled Stdio dependency").to_string().contains("exact closed"));
    assert_ne!(trusted_profile_generation(&missing_dependency, &missing_dependency.profiles[0]).unwrap(), bundle.profiles[0].generation_id);

    let mut missing_terrain = local_stdio_gis_profile_bundle();
    missing_terrain.packages[0].native_codecs.pop();
    assert!(validate_bundle(&missing_terrain, "local-stdio-gis-open-v1").expect_err("missing Terrain").to_string().contains("exact closed"));

    let mut terrain_target = local_stdio_gis_profile_bundle();
    let mut target = terrain_target.packages[0].open_targets[0].clone();
    target.artifact_kind = "s.gis.gisterrain".into();
    target.artifact_schema = "gis.terrain".into();
    target.pack_schema_hash = "a2".repeat(32);
    target.surface_id = "s.gis.gisterrain@1/*#editor".into();
    target.app_id = target.surface_id.clone();
    target.parent_dialect.artifact_kind = target.artifact_kind.clone();
    terrain_target.packages[0].open_targets.push(target.clone());
    assert!(validate_bundle(&terrain_target, "local-stdio-gis-open-v1").expect_err("a package target the profile does not open").to_string().contains("exact closed"));
    let package = terrain_target.profiles[0].open_targets[0].package.clone();
    terrain_target.profiles[0].open_targets.push(TrustedBundleProfileOpenTargetV1 { package, target });
    terrain_target.profiles[0].generation_id = trusted_profile_generation(&terrain_target, &terrain_target.profiles[0]).expect("profile generation");
    assert!(validate_bundle(&terrain_target, "local-stdio-gis-open-v1").is_ok(), "the terrain target the one rule admits is opened by the profile");

    let mut reordered = local_stdio_gis_profile_bundle();
    reordered.profiles[0].selected_closure.reverse();
    assert!(validate_bundle(&reordered, "local-stdio-gis-open-v1").expect_err("noncanonical closure").to_string().contains("canonical"));
}

/// 🧭️ Editors of committed descriptors that author no persisted document of their own, each with the reason; every
/// other editor surface must open at least one kind through the one rule (coordinator decision, session 12).
const EDITORS_WITHOUT_A_DOCUMENT: [(&str, &str); 3] = [
    ("s.space.home@1/*#editor", "the launcher: its snapshot holds only the catalog generation it lists (`SHomeSnapshot { schema, catalog_generation }`), never user content"),
    ("s.space.studio@1/*#editor", "the `s` shell's studio: it edits the running shell's OS-owned workflow (`semio_framework_os::WorkflowSnapshot`) and has no artifact kind of its own"),
    ("s.playbook.procedural@1/*#editor", "a `playbook.blockKind` module: its snapshot is the host playbook block's render payload (foreign document codec), never a document of its own"),
];

/// 🔗️ The `(artifact kind, schema)` pairs each hub-LINKED package owns: the committed registries the hub's linked native
/// providers and the publisher's `linkedCodecRegistry` read (`🌎️hub/📦️packages/🦀️rust/📜️script.ts`).
fn linked_codec_registries() -> std::collections::BTreeMap<&'static str, BTreeSet<(String, String)>> {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../../✏️s/🔌️plugins");
    let pairs = |path: &str, kind: &str, schema: &str| -> BTreeSet<(String, String)> {
        let registry: serde_json::Value = serde_json::from_slice(&std::fs::read(root.join(path)).expect("committed linked codec registry")).expect("linked codec registry JSON");
        registry["receipts"].as_array().expect("linked codec receipts").iter().map(|row| (row[kind].as_str().expect("receipt kind").to_owned(), row[schema].as_str().expect("receipt schema").to_owned())).collect()
    };
    std::collections::BTreeMap::from([("stdio", pairs("🗄️stdio/🔌️plugin/📇️catalog/📜️native-codec-factories.json", "artifact_kind", "artifact_schema")), ("gis", pairs("🌍️gis/📇️native-codecs/🔣️.json", "kind", "schema"))])
}

/// 🗺️ LAW (census): every editor surface of every committed, isolated package descriptor opens at least one artifact
/// kind through [`descriptor_open_targets`], and every kind a hub-LINKED package opens binds one of its linked native
/// codecs ([`linked_codec_registries`]), so every document kind with an editor is creatable and openable over the hub;
/// the only exceptions are [`EDITORS_WITHOUT_A_DOCUMENT`], and each of those must still exist.
#[test]
fn every_committed_editor_that_edits_a_document_opens_a_kind_through_the_one_rule() {
    let mut pending = vec![PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../../✏️s/🔌️plugins")];
    let mut descriptors = Vec::new();
    while let Some(directory) = pending.pop() {
        for entry in std::fs::read_dir(&directory).unwrap_or_else(|error| panic!("{}: {error}", directory.display())) {
            let path = entry.expect("plugin tree entry").path();
            if path.is_dir() && !matches!(path.file_name().and_then(|name| name.to_str()), Some("dist" | "target" | "node_modules")) {
                pending.push(path);
            } else if path.file_name().and_then(|name| name.to_str()) == Some("🛂️.descriptor.semio") {
                descriptors.push(path);
            }
        }
    }
    let linked = linked_codec_registries();
    let (mut editors, mut unopened, mut unlinked, mut shells) = (0usize, Vec::new(), Vec::new(), std::collections::BTreeSet::new());
    for path in &descriptors {
        let descriptor = decode_package_descriptor(&std::fs::read(path).expect("committed descriptor")).unwrap_or_else(|error| panic!("{}: {error}", path.display()));
        if descriptor.execution != semio_framework::ExecutionMode::Isolated {
            continue;
        }
        let targets = descriptor_open_targets(&descriptor);
        if let Some(owned) = linked.get(descriptor.manifest.plugin_id.as_str()) {
            unlinked.extend(targets.iter().filter(|target| !owned.contains(&(target.artifact_kind.clone(), target.artifact_schema.clone()))).map(|target| format!("{} {} ({})", target.surface_id, target.artifact_kind, path.display())));
        }
        let opened = targets.into_iter().map(|target| target.surface_id).collect::<std::collections::BTreeSet<_>>();
        for app in descriptor.manifest.apps.iter().filter(|app| app.role == semio_framework::AppRole::Editor && app.id == semio_framework::surface_app_id(&app.dialect, app.role)) {
            editors += 1;
            if opened.contains(&app.id) {
                continue;
            }
            match EDITORS_WITHOUT_A_DOCUMENT.iter().find(|(surface, _)| *surface == app.id) {
                Some((surface, _)) => {
                    shells.insert(*surface);
                }
                None => unopened.push(format!("{} ({})", app.id, path.display())),
            }
        }
    }
    assert!(editors > 0, "no committed editor surface found");
    assert!(unopened.is_empty(), "{} of {editors} editor surfaces open no kind: {unopened:#?}", unopened.len());
    assert!(unlinked.is_empty(), "{} open targets of linked packages bind no linked native codec: {unlinked:#?}", unlinked.len());
    assert_eq!(shells.len(), EDITORS_WITHOUT_A_DOCUMENT.len(), "every allow-listed shell still exists and still opens nothing: {shells:?}");
}

mod long {
    use super::*;
use std::sync::Arc;
use semio_framework::DslValue;
use semio_framework_hash::Sha256;
use semio_hub_trusted_catalog::TrustedCatalogLoader;
use semio_hub_trusted_catalog_descriptor::{VerifiedTrustedPackage, decode_package_descriptor};

    #[tokio::test]
    async fn gis_map_binding_constructs_from_loaded_catalog_and_refuses_tampered_retained_bytes() {
        let _registry = semio_hub_artifact_authority::REAL_LINKED_CODEC_REGISTRY.lock().await;
        for (viewer, foreign_service) in [(false, false), (true, false), (false, true)] {
            let fixture = prepared_gis_binding_fixture(viewer, foreign_service).await;
            let control = TestControl::new();
            let catalog = Arc::new(TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "frozen-gis-test", &NativeCodecProviderSetV1::linked(), &control.context()).await.expect("catalog loaded with real GIS receipts"));
            let result = semio_hub_inference_catalog::verified_gis_map_binding(catalog.clone(), &semio_hub_gis::inference::GisMapInferenceBindingV1);
            if foreign_service {
                assert!(matches!(result, Err(semio_hub_inference::InferenceErrorV1::Denied)));
            } else if viewer {
                assert!(result.expect("viewer profile is admissible").is_none());
            } else {
                let binding = result.expect("verified editor binding").expect("GIS Map editor is bound");
                assert!(Arc::ptr_eq(binding.catalog(), &catalog));
                assert_eq!(binding.selection(), catalog.selected_document_open().expect("sole selection"));
                assert_eq!(binding.service().executable_identity(), semio_s_artifact_gis_gismap::gis_map_inference_service().executable_identity());
                let retained = catalog.packages().iter().find(|package| package.plugin_id() == "gis").expect("verified GIS package").component().read(&control.context()).await.expect("verified GIS component rereads").to_vec();
                let digest = binding.digest().to_owned();
                std::fs::write(fixture.component_path(0), b"tampered").expect("mutate fixture backing component");
                assert!(TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "frozen-gis-test", &NativeCodecProviderSetV1::linked(), &control.context()).await.is_err());
                drop(catalog);
                let tampered = binding.catalog().packages().iter().find(|package| package.plugin_id() == "gis").expect("retained GIS package").component().read(&control.context()).await;
                assert!(tampered.is_err() && !retained.is_empty(), "a retained component whose backing file changed must be refused, never served");
                assert_eq!(binding.digest(), digest);
            }
        }
    }

    #[tokio::test]
    async fn linked_stdio_gis_descriptor_failures_never_publish_a_partial_codec_closure() {
        let _registry = semio_hub_artifact_authority::REAL_LINKED_CODEC_REGISTRY.lock().await;
        let corpus: serde_json::Value = serde_json::from_str(semio_hub_testing::hub_source("🗿️artifact-authority/🔏️trusted-catalog/🧪️tests/🧫️fixtures/🔗️compiled-dependencies/🔣️.json")).unwrap();
        let mut fixture = prepared_gis_binding_fixture(false, false).await;
        for receipt in semio_hub_gis::native_codecs::native_codec_factory_receipts().unwrap() {
            let native = receipt.into_codec().unwrap();
            let declared = document_codec(&native.schema).await.unwrap().expect("actual assembled GIS declaration owns its codec");
            assert_eq!(native.schema, declared.schema);
            assert_eq!(native.extension, declared.extension);
            assert_eq!(native.pack_schema_hash, declared.pack_schema_hash);
            assert!(std::ptr::fn_addr_eq(native.compile_dsl, declared.compile_dsl));
            assert!(std::ptr::fn_addr_eq(native.print_mirror, declared.print_mirror));
            assert!(std::ptr::fn_addr_eq(native.edit_text_from_envelope, declared.edit_text_from_envelope));
            assert!(std::ptr::fn_addr_eq(native.apply_ops_binary, declared.apply_ops_binary));
        }
        let baseline = fixture.bundle.clone();
        let originals: Vec<_> = baseline["packages"]
            .as_array()
            .unwrap()
            .iter()
            .map(|record| {
                let path = fixture.root.join(record["descriptor"]["path"].as_str().unwrap());
                (path.clone(), std::fs::read(path).expect("original full descriptor"))
            })
            .collect();
        let schemas: Vec<_> = baseline["packages"].as_array().unwrap().iter().flat_map(|record| record["nativeCodecs"].as_array().unwrap().iter().map(|codec| codec["artifactSchema"].as_str().unwrap().to_owned())).collect();
        assert_eq!(schemas.len(), 31);
        let mut before = Vec::with_capacity(schemas.len());
        for schema in &schemas {
            before.push(document_codec(schema).await.unwrap().map(|codec| (codec.schema, codec.extension, codec.pack_schema_hash)));
        }
        for row in corpus["atomicCases"].as_array().unwrap() {
            fixture.bundle = baseline.clone();
            for (index, (path, bytes)) in originals.iter().enumerate() {
                std::fs::write(path, bytes).expect("restore exact descriptor bytes");
                attach_fixture_plugin_module(&fixture.root, &mut fixture.bundle["packages"][index], bytes);
            }
            let change = row["change"].as_str().unwrap();
            let package = if change == "stdio-catalog" { "stdio" } else { "gis" };
            let index = fixture.bundle["packages"].as_array().unwrap().iter().position(|record| record["pluginId"] == package).unwrap();
            if !matches!(change, "exact" | "gis-provider") {
                let mut descriptor = decode_package_descriptor(&originals[index].1).expect("original authoritative descriptor");
                match change {
                    "stdio-catalog" | "gis-catalog" => descriptor.manifest.topic_contributions.retain(|entry| entry.topic != "stdio.artifact-catalog.v1"),
                    "gis-dependency" => descriptor.manifest.dependencies.clear(),
                    "gis-trailing-byte" | "gis-duplicate-field" => {}
                    _ => panic!("unknown atomic fixture change {change}"),
                }
                let mut value = semio_framework_value::ToValue::to_value(&descriptor);
                if change == "gis-duplicate-field" {
                    let DslValue::Object(fields) = &mut value else { panic!("full descriptor object") };
                    let duplicate = fields.iter().find(|(key, _)| key == "manifest").unwrap().clone();
                    fields.push(duplicate);
                }
                let mut bytes = os_pack::pack_rt::encode_wire_value(&value);
                if change == "gis-trailing-byte" {
                    bytes.push(0);
                }
                let raw_invalid = matches!(change, "gis-trailing-byte" | "gis-duplicate-field");
                assert_eq!(decode_package_descriptor(&bytes).is_err(), raw_invalid, "full descriptor raw gate: {change}");
                let record = &mut fixture.bundle["packages"][index];
                record["descriptor"]["byteLength"] = bytes.len().into();
                record["descriptor"]["sha256"] = hex_lower(&Sha256::digest(&bytes)).into();
                if record["browserActor"]["kind"] == "closed-browser-actor" {
                    record["browserActor"]["sourceDescriptorByteSha256"] = record["descriptor"]["sha256"].clone();
                }
                attach_fixture_plugin_module(&fixture.root, record, &bytes);
                std::fs::write(&originals[index].0, bytes).expect("write resealed complete candidate descriptor");
            }
            fixture.refresh_profile_generation();
            fixture.persist_bundle();
            let providers = RecordingLinkedProvider { previews: Mutex::new(Vec::new()), fail_gis: change == "gis-provider" };
            let control = TestControl::new();
            let result = TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "frozen-gis-test", &providers, &control.context()).await;
            assert_eq!(result.is_ok(), row["accepted"].as_bool().unwrap(), "loader result: {change}: {:?}", result.as_ref().err());
            let previews: Vec<String> = serde_json::from_value(row["previews"].clone()).unwrap();
            assert_eq!(*providers.previews.lock().unwrap(), previews, "successful private preview frontier: {change}");
            if let Ok(catalog) = result {
                assert_eq!(catalog.codec_count(), 31);
                assert_eq!(catalog.packages().iter().map(VerifiedTrustedPackage::plugin_id).collect::<Vec<_>>(), vec!["stdio", "gis"]);
                assert_eq!(catalog.open_target_count(), 1);
                assert_eq!(catalog.selected_document_open().unwrap().package.plugin_id, "gis");
                for schema in &schemas {
                    assert!(document_codec(schema).await.unwrap().is_some(), "complete public codec: {schema}");
                }
            } else {
                for (schema, prior) in schemas.iter().zip(&before) {
                    assert_eq!(&document_codec(schema).await.unwrap().map(|codec| (codec.schema, codec.extension, codec.pack_schema_hash)), prior, "partial public codec after {change}: {schema}");
                }
            }
        }
    }
}

#[tokio::test]
async fn a_loaded_catalog_indexes_and_serves_every_verified_plugin_module_file_and_refuses_a_tampered_one() {
    let fixture = prepared_fixture();
    let provider = FixtureProviderSource::new(vec![fixture.binding()]);
    let control = TestControl::new();
    let catalog = TrustedCatalogLoader::load_fixture(&fixture.bundle_path, "fixture", &provider, &control.context()).await.expect("fixture catalog");
    let index = catalog.plugin_module_index();
    semio_hub_trusted_catalog_contract::plugin_module::validate_plugin_module_index(&index).expect("canonical index");
    assert_eq!(index.generation_id, catalog.generation_id());
    assert_eq!(index.modules.iter().map(|entry| entry.plugin_id.as_str()).collect::<Vec<_>>(), vec!["fixture-base", "fixture-editor"]);
    assert_eq!(index.modules[1].dependencies, vec!["fixture-base".to_owned()]);
    assert_eq!(index.modules[1].dialect_artifact_kinds, vec!["s.fixture.document".to_owned()]);
    assert!(index.modules[0].dialect_artifact_kinds.is_empty(), "a package without apps opens no dialect");
    assert!(index.modules.iter().all(|entry| entry.extends_plugin_id.is_none()), "plugin packages extend nothing");
    for entry in &index.modules {
        let module = catalog.plugin_module(&entry.bundle_sha256).expect("indexed module");
        assert_eq!(hex_lower(&Sha256::digest(module.manifest_bytes())), entry.bundle_sha256);
        assert_eq!(module.manifest_bytes().len() as u64, entry.bundle_byte_length);
        assert_eq!(module.bundle().entry, entry.entry);
        for file in &module.bundle().files {
            let bytes = module.file(&file.path).expect("listed file").read(&control.context()).await.expect("verified file");
            assert_eq!(hex_lower(&Sha256::digest(&bytes)), file.sha256);
        }
    }
    assert!(catalog.plugin_module(&"00".repeat(32)).is_none());
    let editor = catalog.plugin_module(&index.modules[1].bundle_sha256).expect("editor module");
    let bridge = editor.bundle().files.iter().find(|file| file.path.ends_with("🌉️bridge.js")).expect("editor entry");
    assert!(editor.file("fixture-editor/unlisted.js").is_none());
    std::fs::write(fixture.root.join(semio_hub_trusted_catalog_contract::plugin_module::plugin_module_blob_path(&bridge.sha256)), b"tampered").expect("tamper entry");
    assert!(editor.file(&bridge.path).expect("editor entry").read(&control.context()).await.is_err(), "a module file tampered after verification is never served");
    assert!(drain_stream(editor.file(&bridge.path).expect("editor entry")).await.1.is_some(), "a module file tampered after verification never completes its stream");
}

/// 🚰️ Drains one asset stream: the bytes it released and the error that ended it, if any.
async fn drain_stream(asset: &TrustedCatalogAsset) -> (Vec<u8>, Option<AuthorityError>) {
    let mut stream = match asset.stream() {
        Ok(stream) => stream,
        Err(error) => return (Vec::new(), Some(error)),
    };
    let mut released = Vec::new();
    while let Some(chunk) = stream.next_chunk().await {
        match chunk {
            Ok(bytes) => released.extend_from_slice(&bytes),
            Err(error) => return (released, Some(error)),
        }
    }
    (released, None)
}

/// ⚖️ LAW: a verified file is served as a chunked stream with NO request deadline that releases exactly the verified bytes,
/// and a file changed on disk after verification — same length, one byte flipped anywhere, or truncated — ends the stream in
/// an error before its final chunk, so a reader holding the declared length never completes it. The per-request reread
/// under the 8 s execution-target deadline refused every large core module with 500 once a burst loaded the debug hub
/// (S15, session 12: all 7 core modules ≥ 17 MB of catalog B answered 500 at 8.0–8.2 s, `wp-s15/s15-module-burst.ts`).
#[tokio::test]
async fn a_verified_file_streams_its_exact_bytes_without_a_deadline_and_withholds_its_last_chunk_once_tampered() {
    let fixture = prepared_fixture();
    let canonical_root = std::fs::canonicalize(&fixture.root).expect("canonical fixture-owned generation root");
    let root = Arc::new(TrustedCatalogGenerationRoot::open_fixture_owned(&canonical_root).expect("opened generation root"));
    let bytes: Vec<u8> = (0..(3 * TRUSTED_READ_CHUNK_BYTES + 17)).map(|index| (index % 251) as u8).collect();
    let retained = |name: &str| {
        std::fs::write(fixture.root.join(name), &bytes).expect("write multi-chunk module file");
        TrustedCatalogAsset::retained(TrustedRetainedFile::new(Arc::clone(&root), TrustedCatalogRelativePathV1::parse(name).expect("relative path"), bytes.len() as u64, Sha256::digest(&bytes), Some(*Hasher::new().update(&bytes).finalize().as_bytes())))
    };

    let intact = retained("intact.bin");
    assert_eq!(intact.stream().expect("stream").byte_length(), bytes.len() as u64);
    let (released, error) = drain_stream(&intact).await;
    assert!(error.is_none(), "an intact verified file streams to its end: {error:?}");
    assert_eq!(released, bytes, "the stream releases exactly the verified bytes");

    for (name, offset) in [("flip-first.bin", 0), ("flip-middle.bin", TRUSTED_READ_CHUNK_BYTES + 5), ("flip-last.bin", bytes.len() - 1)] {
        let asset = retained(name);
        let mut tampered = bytes.clone();
        tampered[offset] ^= 0xff;
        std::fs::write(fixture.root.join(name), &tampered).expect("tamper after verification");
        let (released, error) = drain_stream(&asset).await;
        assert!(error.is_some(), "{name}: a file changed after verification ends its stream in an error");
        assert!(released.len() < bytes.len(), "{name}: the final chunk is withheld, so the declared length is never completed ({} of {})", released.len(), bytes.len());
    }

    let truncated = retained("truncated.bin");
    std::fs::write(fixture.root.join("truncated.bin"), &bytes[..bytes.len() - 1]).expect("truncate after verification");
    assert!(drain_stream(&truncated).await.1.is_some(), "a truncated file is refused before it streams");

    let (released, error) = drain_stream(&TrustedCatalogAsset::resident(Arc::from(bytes.clone()))).await;
    assert!(error.is_none() && released == bytes, "a resident asset streams the bytes the catalog verified");
}

/// 🏠️ A hosted kind's document-open target binds the ONE declared dependency in the catalog that declares its exact native
/// codec — never a copied row, never an owner read off the kind id (demonstrator's `3d.cad` names no plugin): accepted for a
/// present declared dependency declaring the exact codec; refused by name when none does, when it is absent or undeclared, and
/// when two declared dependencies declare the same exact codec.
#[test]
fn hosted_open_targets_bind_the_owner_codec_or_are_refused_by_name() {
    let fixture = snapshot_json();
    let bundle: TrustedBundleV1 = serde_json::from_value(fixture["bundle"].clone()).expect("bundle");
    let mut host = bundle.packages[0].clone();
    let mut owner = bundle.packages[1].clone();
    let target = host.open_targets[0].clone();
    owner.native_codecs = std::mem::take(&mut host.native_codecs);
    host.dependencies[0].plugin_id = owner.plugin_id.clone();
    let packages = vec![host.clone(), owner.clone()];
    assert_eq!(open_target_codec_package(&packages, &packages[0], &target).expect("hosted target binds the owner codec").plugin_id, owner.plugin_id);
    let refusal = |packages: Vec<TrustedBundlePackageV1>| open_target_codec_package(&packages, &packages[0], &target).expect_err("refused").to_string();
    assert!(refusal(vec![host.clone()]).contains("binds no exact native codec"));
    let mut stranger = host.clone();
    stranger.dependencies.clear();
    assert!(refusal(vec![stranger, owner.clone()]).contains("binds no exact native codec"));
    let mut bare = owner.clone();
    bare.native_codecs.clear();
    assert!(refusal(vec![host.clone(), bare]).contains("binds no exact native codec"));
    let mut twin = owner.clone();
    twin.plugin_id = format!("{}-twin", owner.plugin_id);
    let mut both = host.clone();
    let mut twin_dependency = both.dependencies[0].clone();
    twin_dependency.plugin_id = twin.plugin_id.clone();
    both.dependencies.push(twin_dependency);
    assert!(refusal(vec![both, owner.clone(), twin]).contains("more than one declared dependency"));
    let mut own = host.clone();
    own.native_codecs = owner.native_codecs.clone();
    assert_eq!(open_target_codec_package(&[own.clone()], &own, &target).expect("own codec").plugin_id, own.plugin_id);
}

/// 🌱️ LAW: creation is owner-preferred — the owners' editors decide and a host's editor of the same kind never makes it
/// ambiguous (cad + demonstrator's embedded cad editor → cad, even against a host's more general editor); a kind only hosts
/// create falls to its hosts (a stdio family); within the deciding tier the most general dialect creates (stdio's json
/// `rfc8259/*` over `i-json`, the image family's jpg `jfif-1.01/*` over `baseline`); two owners, two hosts or two standards
/// alone stay ambiguous; nothing creates nothing.
#[test]
fn creation_prefers_the_owners_editor_over_a_hosts() {
    let pick = |owned: &[(&'static str, &str)], hosted: &[(&'static str, &str)]| {
        let tier = |entries: &[(&'static str, &str)]| entries.iter().map(|(name, coordinate)| (*name, semio_framework::ArtifactDialect::parse_coordinate(coordinate).expect("canonical coordinate"))).collect::<Vec<_>>();
        owner_preferred_creation(tier(owned), tier(hosted), |(_, dialect)| dialect).one().map(|(name, _)| name)
    };
    assert_eq!(pick(&[("cad", "s.cad.cad@1/*")], &[("demonstrator", "s.cad.cad@1/*")]), Some("cad"));
    assert_eq!(pick(&[("cad", "s.cad.cad@1/strict")], &[("demonstrator", "s.cad.cad@1/*")]), Some("cad"));
    assert_eq!(pick(&[], &[("stdio-pdf", "s.stdio.pdf@1.7/*")]), Some("stdio-pdf"));
    assert_eq!(pick(&[("stdio i-json", "s.stdio.json@rfc8259/i-json"), ("stdio json", "s.stdio.json@rfc8259/*")], &[]), Some("stdio json"));
    assert_eq!(pick(&[], &[("stdio-image baseline", "s.stdio.jpg@jfif-1.01/baseline"), ("stdio-image jfif", "s.stdio.jpg@jfif-1.01/*")]), Some("stdio-image jfif"));
    assert_eq!(pick(&[("cad", "s.cad.cad@1/*"), ("cad-twin", "s.cad.cad@1/*")], &[("demonstrator", "s.cad.cad@1/*")]), None);
    assert_eq!(pick(&[], &[("demonstrator", "s.cad.cad@1/*"), ("bundle", "s.cad.cad@1/*")]), None);
    assert_eq!(pick(&[], &[("stdio-cad ac1018", "s.stdio.dwg@ac1018/*"), ("stdio-cad ac1024", "s.stdio.dwg@ac1024/*")]), None);
    assert_eq!(pick(&[], &[]), None);
}

/// 🌳️ LAW: the hub's most-general-dialect rule answers every case of the ONE shared fixture — the rule the guest's
/// `artifact_codec_owner` answers `codec.*` by — for the candidates as listed and reversed (order never decides).
#[test]
fn the_most_general_dialect_rule_answers_the_shared_fixture() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!("../../../../../🧰️framework/🛍️products/💻️os/🔨️modules/🚪️io/🧪️tests/🧫️fixtures/🌳️most-general-dialect/🔣️.json")).expect("shared most-general-dialect fixture");
    let cases = fixture["cases"].as_array().expect("fixture cases");
    assert!(cases.len() >= 10, "the shared fixture keeps its cases");
    for case in cases {
        let name = case["name"].as_str().expect("case name");
        let candidates = case["candidates"].as_array().expect("candidates").iter().enumerate().map(|(index, coordinate)| (index, semio_framework::ArtifactDialect::parse_coordinate(coordinate.as_str().expect("coordinate")).expect("canonical coordinate"))).collect::<Vec<_>>();
        let expected = match &case["mostGeneral"] {
            serde_json::Value::Number(index) => MostGeneralDialect::One(usize::try_from(index.as_u64().expect("index")).expect("index")),
            serde_json::Value::String(answer) if answer == "ambiguous" => MostGeneralDialect::Ambiguous,
            serde_json::Value::String(answer) if answer == "none" => MostGeneralDialect::Empty,
            other => panic!("{name}: unknown answer {other}"),
        };
        let answer = |candidates: Vec<(usize, semio_framework::ArtifactDialect)>| match most_general_dialect(candidates, |(_, dialect)| dialect) {
            MostGeneralDialect::One((index, _)) => MostGeneralDialect::One(index),
            MostGeneralDialect::Ambiguous => MostGeneralDialect::Ambiguous,
            MostGeneralDialect::Empty => MostGeneralDialect::Empty,
        };
        assert_eq!(answer(candidates.clone()), expected, "{name}");
        assert_eq!(answer(candidates.into_iter().rev().collect()), expected, "{name} (reversed)");
    }
}

/// 🏠️ LAW: a kind a package only HOSTS (a stdio family hosting `stdio`'s kinds) is created by the host's MOST GENERAL editor
/// and executed under the HOST's own identity — the owner's linked native codec when the hub links one, the HOST's component
/// for genesis and every guest call (the family ships the app; the owner's component need not) — and its document opens
/// without a requested surface in that same whole-standard editor, while a requested subset surface still opens exactly.
/// Unlinked, the hosted row is a verification row of the HOST's component. Live defect (ticket 26/09/23 H14, 2026-09-29):
/// every multi-subset kind stayed uncreatable, and a hosted creation resolved no codec for the host's identity.
#[tokio::test]
async fn a_hosted_multi_subset_kind_is_created_and_executed_by_its_hosts_most_general_editor() {
    for linked in [true, false] {
    let mut fixture = prepared_fixture();
    let schema = fixture.schema.clone();
    let codecs = fixture.bundle["packages"][0]["nativeCodecs"].take();
    fixture.bundle["packages"][0]["nativeCodecs"] = serde_json::json!([]);
    fixture.bundle["packages"][1]["nativeCodecs"] = codecs;
    let mut strict = fixture.bundle["packages"][0]["openTargets"][0].clone();
    strict["surfaceId"] = "s.fixture.document@1/strict#editor".into();
    strict["appId"] = "s.fixture.document@1/strict#editor".into();
    strict["parentDialect"]["subset"] = "strict".into();
    fixture.bundle["packages"][0]["openTargets"].as_array_mut().expect("host targets").insert(0, strict.clone());
    let mut selected = fixture.bundle["profiles"][0]["openTargets"][0].clone();
    selected["target"] = strict;
    fixture.bundle["profiles"][0]["openTargets"].as_array_mut().expect("profile targets").insert(0, selected);
    fixture.rewrite_descriptor(1, Some(&schema), None);
    fixture.replace_descriptor(0, hosting_descriptor_bytes(&schema));
    let host = |plugin_id: &str| plugin_id == "fixture-editor";
    let descriptor = DocumentDescriptor {
        space_id: "space".into(),
        document_id: "document".into(),
        artifact_kind: "s.fixture.document".into(),
        artifact_schema: schema.clone(),
        owner: directory::os_directory::DocumentOwner { plugin_id: "fixture-editor".into(), package_id: "semio:fixture-editor".into(), version: "1.2.3".into(), package_hash: component_sha256.clone() },
        pack_schema_hash: "11".repeat(32),
        bootstrap_version: 1,
        bootstrap_frontier: directory::os_directory::DocumentFrontier { head_seq: 0, commit_seq: 0, epoch: 0 },
        bootstrap_snapshot_hash: "33".repeat(32),
    };
        let bindings = if linked { vec![NativeCodecBinding::new("fixture-base", "semio:fixture-base", "s.fixture.document", None, fixture_codec(&schema, [0x11; 32]))] } else { Vec::new() };
        let catalog = load_fixture(&fixture, &bindings, &TestControl::new().context()).await.expect("hosting catalog loads");
        let selection = catalog.artifact_creation_selection("s.fixture.document").expect("the hosted multi-subset kind is creatable");
        assert!(host(&selection.package.plugin_id), "the host creates: {:?}", selection.package);
        assert_eq!(selection.surface.surface_id, "s.fixture.document@1/*#editor", "the most general editor creates");
        let identity = TrustedArtifactIdentity {
            plugin_id: selection.package.plugin_id.clone(),
            package_id: selection.package.package_id.clone(),
            version: selection.package.version.clone(),
            package_hash: selection.package.component_sha256.clone(),
            artifact_kind: selection.artifact.kind.clone(),
            artifact_schema: selection.artifact.schema.clone(),
            pack_schema_hash: selection.artifact.pack_schema_hash.clone(),
        };
        assert_eq!(identity, TrustedArtifactIdentity::from_descriptor(&descriptor), "a created document names its host as owner");
        let codec = catalog.resolve(&identity).await.expect("the host's identity resolves a codec");
        assert_eq!(codec.guest.component.package.package.0, "semio:fixture-editor", "genesis and guest calls go to the host's component");
        assert_eq!(codec.codec.is_some(), linked, "the owner's linked native codec executes the hosted identity");
        let declarations=directory::io::artifact_catalog_bindings().unwrap().into_iter().filter(|row|row.artifact.schema==schema).collect::<Vec<_>>();
        assert_eq!(declarations.len(),catalog.open_targets.len()+1);
        for declaration in &declarations{assert_eq!(declaration.owner.plugin_id,"fixture-base");assert_eq!(declaration.owner.package_id,"semio:fixture-base");assert_eq!(matches!(declaration.capability,ArtifactCatalogCapability::Linked{..}),linked);if let ArtifactCatalogCapability::Linked{factory,..}=&declaration.capability{assert!(factory.is_none());}if let Some(target)=&declaration.target{assert!(host(&declaration.contributor.plugin_id));let original=catalog.open_targets.iter().find(|selection|selection.package==declaration.contributor&&selection.artifact==declaration.artifact&&selection.surface==target.surface&&selection.parent_dialect==target.parent_dialect).expect("exact immutable selected catalog target");assert_eq!(original.grant,target.grant);assert_eq!(original.browser_actor,target.browser_actor);}}
        assert_eq!(codec.owner_declaration.owner.plugin_id,"fixture-base");assert_eq!(codec.owner_declaration.contributor.plugin_id,"fixture-base");assert_eq!(serde_json::to_value(codec.owner_declaration.owner.plugin_id.as_str()).unwrap(),serde_json::json!("fixture-base"));
        println!("[DEBUG] Original verified hosted catalog linked={linked} declarations={} exactOwnerPackage=true noGuessedFactory=true exactSelectedSurfaces=true independentSerde=true",declarations.len());
        let owner = TrustedArtifactIdentity { plugin_id: "fixture-base".into(), package_id: "semio:fixture-base".into(), version: "1.0.0".into(), ..identity.clone() };
        assert_eq!(catalog.resolve(&owner).await.expect("the owner's row stays its own").guest.component.package.package.0, "semio:fixture-base");
        assert_eq!(catalog.resolve_document_open(&descriptor, None, true).expect("default editor").surface.surface_id, "s.fixture.document@1/*#editor");
        assert_eq!(catalog.resolve_document_open(&descriptor, Some("s.fixture.document@1/strict#editor"), true).expect("requested subset editor").surface.surface_id, "s.fixture.document@1/strict#editor");
        let progress = catalog.load_progress();
        let hosting = progress.packages.iter().find(|package| host(&package.plugin_id)).expect("host progress");
        assert_eq!((hosting.rows, hosting.rows_pinned), (1, u64::from(linked)), "the hosted identity is a row of the host, pinned only when linked");
    }
}
