//! 📚️ Immutable creation facts bind one intent to one private pair and one public triple.

use super::ArtifactCreationActorV1;
use semio_hub_directory_contract::error::{DirectoryError, DirectoryResult};
use directory::os_directory::schema::space_artifact_creation::{SpaceArtifactCreateV1, SpaceArtifactCreationDialectV1, SpaceArtifactCreationPhaseV1, SpaceArtifactCreationReadyV1, SpaceArtifactCreationStatusV1};
use directory::os_directory::{ArtifactCheckpoint, ArtifactHash, DocumentDescriptor, DocumentOwner, DocumentScope};
use semio_framework_artifact_reference::ArtifactDialect;
use directory::{FromValue, ToValue};

//#region 🔖️ScopeSchemaExports
use semio_framework_schema_registry::{register_scope_schema_exports, FacetLeaves, SchemaExport, ScopeSchemaExports};

/// 🧬️ The scope id every export of this module resolves under.
pub const SCHEMA_SCOPE: &str = "hub.artifact-authority.creation";

/// 🏷️ The leaves of an export that is only ever validated, never transported by a Rust decoder —
/// exactly the set its `"x-semio-formats"` annotation declares (contract §B).
const VALIDATED_ONLY: FacetLeaves = FacetLeaves { rust: "", typescript: "", graphql: "", json_schema: include_str!("🔣️.json"), proto: "" };

/// 📚️ The module document the annotation is read from, so the law never restates it.
#[cfg(test)]
const MODULE_JSON: &str = include_str!("🔣️.json");

/// 🏷️ `$defs` of `🔣️.json`, in declaration order.
const EXPORTS: [SchemaExport; 4] = [
    SchemaExport { id: "ArtifactCreationPhaseV1", leaves: VALIDATED_ONLY },
    SchemaExport { id: "ArtifactCreationFactKindV1", leaves: VALIDATED_ONLY },
    SchemaExport { id: "ArtifactCreationHttpLimitsV1", leaves: VALIDATED_ONLY },
    SchemaExport { id: "ArtifactCreationHttpResponseV1", leaves: VALIDATED_ONLY },
];

/// 📌️ Registers `hub.artifact-authority.creation`'s named exports into the process-wide export catalog.
/// See `📋️execution-contract.md` §C and `semio_framework_schema_registry::resolve_schema_export`.
// 🚫️async: pure registration helper (no I/O)
pub fn register_scope_exports() {
    register_scope_schema_exports(ScopeSchemaExports { scope: SCHEMA_SCOPE, exports: &EXPORTS }).expect("hub.artifact-authority.creation scope schema exports");
}
/// 🔬 Proves the registration at runtime rather than by inspection: it registers, resolves every
/// export in exactly the formats its `"x-semio-formats"` annotation names and in no other, and
/// asserts the scope is visible in the process-wide catalog.
#[cfg(test)]
#[path = "🧪️tests/🔬️scope-schema-export-law-standalone/🦀️.rs"]
mod scope_schema_export_law;
//#endregion 🔖️ScopeSchemaExports

/// ⏱️ How long an ABANDONED creation key stays uncommitted before recovery closes it. It is a
/// calendar bound and it is the right one here: it answers "nobody is executing this any more"
/// (the hub that accepted it restarted, or its task died), and the recovery sweep asks it only of
/// keys no live execution owns — `ArtifactCreationHttpTaskOwnerV1::owns_live_execution`
/// (`🌎️hub/🏗️bootstrap/🦀️.rs`) is consulted first. It is NOT the bound on the work: a creation that
/// is running is bounded by [`ARTIFACT_CREATION_STALL_BOUND_MS`].
pub const ARTIFACT_CREATION_DEADLINE_MS: u64 = 30_000;

/// 🧗️ How long a RUNNING creation may reach no checkpoint before it is refused as wedged
/// (`OperationContext::stall_bounded`, ticket 26/09/18 slice HT16). Creation runs on a detached
/// task no socket waits on, so nothing about it owes an answer by an instant — and under the
/// absolute bound it used to carry, the biggest staged component could not be created at all: hub
/// 7671 failed every creation in 32.0 s at machine loads 120, 33 and 21 alike while the hub process
/// burned 130–145 % CPU throughout (slice HC1, `🗑️generated/hc1-create-sampled-1.txt`). The guest
/// codec call feeds this bound its own fuel progress, so an interpreter that keeps stepping keeps
/// the creation alive and one that stops stepping is named within this span.
pub const ARTIFACT_CREATION_STALL_BOUND_MS: u64 = 180_000;
pub const ARTIFACT_CREATION_PAIR_MAX_BYTES: usize = 1024 * 1024;
pub const ARTIFACT_CREATION_FACTS_MAX: usize = 3;

/// 🪢️ A durable accepted intent captures server-selected identity before invoking any factory.
#[derive(Clone, Debug, PartialEq, Eq, ToValue, FromValue)]
#[value(crate = "::directory", rename_all = "camelCase", deny_unknown_fields)]
pub struct ArtifactCreationIntentV1 {
    pub actor: ArtifactCreationActorV1,
    pub scope: DocumentScope,
    pub request: SpaceArtifactCreateV1,
    pub catalog_generation: String,
    pub owner: DocumentOwner,
    pub artifact_schema: String,
    pub pack_schema_hash: String,
    pub parent_dialect: ArtifactDialect,
    pub command_sha256: String,
    pub accepted_at_ms: u64,
    pub deadline_ms: u64,
}

/// 🪺️ Prepared bytes are retained durably; recovery never invokes the initial factory again.
#[derive(Clone, Debug, PartialEq, Eq, ToValue, FromValue)]
#[value(crate = "::directory", rename_all = "camelCase", deny_unknown_fields)]
pub struct ArtifactCreationPreparedV1 {
    pub descriptor: DocumentDescriptor,
    pub checkpoint: ArtifactCheckpoint,
    pub pack: Vec<u8>,
    pub spr: Vec<u8>,
}

/// 🧾️ Completion is inseparable from the three dense public events and exact private checkpoint.
#[derive(Clone, Debug, PartialEq, Eq, ToValue, FromValue)]
#[value(crate = "::directory", rename_all = "camelCase", deny_unknown_fields)]
pub struct ArtifactCreationReceiptV1 {
    pub ready: SpaceArtifactCreationReadyV1,
    pub checkpoint_id: ArtifactHash,
    pub descriptor_digest_v1: ArtifactHash,
    pub event_seq_first: u64,
    pub event_seq_last: u64,
    pub event_ids: Vec<String>,
}

/// 📜️ Terminal facts never reopen a creation key or replace its captured initial bytes.
#[derive(Clone, Debug, PartialEq, Eq, ToValue, FromValue)]
#[value(crate = "::directory", tag = "kind", rename_all = "lowercase", rename_all_fields = "camelCase", deny_unknown_fields)]
pub enum ArtifactCreationFactBodyV1 {
    Accepted { intent: ArtifactCreationIntentV1 },
    Prepared { candidate: ArtifactCreationPreparedV1 },
    Committed { receipt: ArtifactCreationReceiptV1 },
    Cancelled,
    Failed,
}

/// 🔢️ A request-local immutable revision is appended under the backend writer transaction.
#[derive(Clone, Debug, PartialEq, Eq, ToValue, FromValue)]
#[value(crate = "::directory", rename_all = "camelCase", deny_unknown_fields)]
pub struct ArtifactCreationFactV1 {
    pub actor_user_id: String,
    pub request_id: String,
    pub revision: u64,
    pub recorded_at_ms: u64,
    pub body: ArtifactCreationFactBodyV1,
}

/// 🚦️ Read-side state is derived exclusively from validated durable facts.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ArtifactCreationOperationV1 {
    pub intent: ArtifactCreationIntentV1,
    pub prepared: Option<ArtifactCreationPreparedV1>,
    pub receipt: Option<ArtifactCreationReceiptV1>,
    pub phase: SpaceArtifactCreationPhaseV1,
    pub revision: u64,
}

/// 📨️ Only a newly inserted accepted fact grants this process one execution attempt.
pub struct ArtifactCreationAcceptanceV1 {
    pub status: SpaceArtifactCreationStatusV1,
    pub execution: Option<ArtifactCreationExecutionV1>,
}

/// 🎟️ A non-cloneable execution grant exists only for the newly committed accepted fact.
pub struct ArtifactCreationExecutionV1 {
    pub intent: ArtifactCreationIntentV1,
}

impl ArtifactCreationExecutionV1 {
    /// 🔎️ Inspection cannot construct, clone or renew the factory execution grant.
    pub fn intent(&self) -> &ArtifactCreationIntentV1 {
        &self.intent
    }
}

/// 🆕️ Only the transaction that inserts revision one owns factory execution.
pub enum ArtifactCreationClaimV1 {
    Accepted(ArtifactCreationOperationV1),
    Existing(ArtifactCreationOperationV1),
}

/// ✍️ A private transition must match the complete accepted key and expected revision.
pub struct ArtifactCreationFactAppendV1 {
    pub actor: ArtifactCreationActorV1,
    pub space_id: String,
    pub request_id: String,
    pub command_sha256: String,
    pub expected_revision: u64,
    pub recorded_at_ms: u64,
    pub body: ArtifactCreationFactBodyV1,
}

/// ⚛️ One reserved genesis publishes exactly three events and its private completion together.
pub struct DocumentGenesisAppendV1 {
    pub intent: ArtifactCreationIntentV1,
    pub events: [semio_hub_directory_contract::NewDirectoryEvent; 3],
    pub checkpoint: ArtifactCheckpoint,
    pub reservation: semio_hub_artifact_authority::chunk_cas::ArtifactCasReservation,
    pub now_ms: u64,
}

/// 📣️ Reconciliation returns the original receipt without rebroadcasting historical events.
pub enum DocumentGenesisCommitV1 {
    Committed { events: Vec<directory::os_directory::DirectoryEvent>, operation: ArtifactCreationOperationV1 },
    Existing(ArtifactCreationOperationV1),
    Indeterminate,
}

/// 🛂️ Immutable facts whose physical commitments were admitted before semantic decisions.
pub struct AdmittedArtifactCreationFactsV1<'a> {
    facts: &'a [ArtifactCreationFactV1],
}

impl<'a> AdmittedArtifactCreationFactsV1<'a> {
    /// 🔒️ The physical owner constructs the witness while its source remains immutably borrowed.
    pub(super) fn new(facts: &'a [ArtifactCreationFactV1]) -> Self { Self { facts } }
}

/// 🪢️ An admitted append remains borrowed together with the exact accepted intent it binds.
pub struct AdmittedArtifactCreationAppendV1<'a> {
    append: &'a ArtifactCreationFactAppendV1,
    intent: &'a ArtifactCreationIntentV1,
}

impl<'a> AdmittedArtifactCreationAppendV1<'a> {
    /// 🔐️ Construction is confined to the creation owner after physical preparation admission.
    pub(super) fn new(append: &'a ArtifactCreationFactAppendV1, intent: &'a ArtifactCreationIntentV1) -> Self { Self { append, intent } }
}

/// 🔀️ A transition appends at most one immutable fact; retries never erase or reopen prior facts.
pub(super) fn decide_admitted_artifact_creation_fact_append_v1(admitted: &AdmittedArtifactCreationFactsV1<'_>, admitted_append: &AdmittedArtifactCreationAppendV1<'_>, observed_now_ms: u64) -> DirectoryResult<Option<ArtifactCreationFactV1>> {
    let facts = admitted.facts;
    let append = admitted_append.append;
    let operation = ArtifactCreationOperationV1::fold(admitted)?;
    if !std::ptr::eq(admitted_append.intent, match &facts[0].body { ArtifactCreationFactBodyV1::Accepted { intent } => intent, _ => return Err(rejected("artifact creation append admission has no intent")) }) {
        return Err(rejected("artifact creation append admission belongs to another intent"));
    }
    if append.actor.user_id != operation.intent.actor.user_id || append.space_id != operation.intent.scope.space_id || append.request_id != operation.intent.request.request_id || append.command_sha256 != operation.intent.command_sha256 {
        return Err(rejected("artifact creation transition belongs to another intent"));
    }
    let cancellation = matches!(append.body, ArtifactCreationFactBodyV1::Cancelled);
    if append.recorded_at_ms > observed_now_ms || cancellation && (append.expected_revision == 0 || append.expected_revision > operation.revision) {
        return Err(rejected("artifact creation transition clock or observed revision is invalid"));
    }
    match &append.body {
        ArtifactCreationFactBodyV1::Accepted { .. } | ArtifactCreationFactBodyV1::Committed { .. } => return Err(rejected("artifact creation transition requires its dedicated transaction")),
        ArtifactCreationFactBodyV1::Prepared { candidate } => {
            if append.actor != operation.intent.actor {
                return Err(rejected("artifact creation preparation session differs"));
            }
            candidate.validate_fields(&operation.intent)?;
            if let Some(previous) = operation.prepared.as_ref() {
                return if previous == candidate { Ok(None) } else { Err(rejected("artifact creation prepared bytes cannot be replaced")) };
            }
        }
        ArtifactCreationFactBodyV1::Failed if append.actor != operation.intent.actor => return Err(rejected("artifact creation failure owner differs")),
        _ => {}
    }
    if matches!(operation.phase, SpaceArtifactCreationPhaseV1::Ready | SpaceArtifactCreationPhaseV1::Cancelled | SpaceArtifactCreationPhaseV1::Failed) {
        return Ok(None);
    }
    if !cancellation && append.expected_revision != operation.revision {
        return Err(rejected("artifact creation transition revision changed"));
    }
    let next = ArtifactCreationFactV1 { actor_user_id: append.actor.user_id.clone(), request_id: append.request_id.clone(), revision: operation.revision + 1, recorded_at_ms: observed_now_ms, body: append.body.clone() };
    let mut proposed = facts.to_vec();
    proposed.push(next.clone());
    ArtifactCreationOperationV1::fold_checked(&proposed)?;
    Ok(Some(next))
}

pub(super) fn rejected(message: &'static str) -> DirectoryError {
    DirectoryError::Conflict(message.into())
}

pub(super) fn text(value: &str) -> bool {
    !value.is_empty() && value.len() <= 256 && !value.chars().any(char::is_control)
}

fn hash(value: &str) -> bool {
    value.len() == 64 && value.bytes().all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte)) && value.bytes().any(|byte| byte != b'0')
}

/// 🔏️ Scope is length-prefixed before the canonical client intent; no route alias can collide.

impl ArtifactCreationIntentV1 {
    /// 🚪️ Coordinates are derived from the accepted catalog binding, not supplied as a ready reply.
    pub fn ready(&self) -> SpaceArtifactCreationReadyV1 {
        SpaceArtifactCreationReadyV1 {
            artifact_id: self.scope.document_id.clone(),
            kind_id: self.request.kind_id.clone(),
            artifact_schema: self.artifact_schema.clone(),
            parent_dialect: SpaceArtifactCreationDialectV1 { artifact_kind: self.parent_dialect.artifact_kind.clone(), standard: self.parent_dialect.standard.clone(), subset: self.parent_dialect.subset.clone() },
        }
    }

    /// 🛡️ A stored intent is bounded, exact, and names one server-minted artifact.
    pub fn validate_fields(&self) -> DirectoryResult<()> {
        let descriptor = DocumentDescriptor {
            space_id: self.scope.space_id.clone(),
            document_id: self.scope.document_id.clone(),
            artifact_kind: self.request.kind_id.clone(),
            artifact_schema: self.artifact_schema.clone(),
            owner: self.owner.clone(),
            pack_schema_hash: self.pack_schema_hash.clone(),
            bootstrap_version: 1,
            bootstrap_frontier: directory::os_directory::DocumentFrontier { head_seq: 0, commit_seq: 0, epoch: 0 },
            bootstrap_snapshot_hash: "01".repeat(32),
        };
        if !self.request.validate()
            || !hash(&self.command_sha256)
            || !text(&self.actor.user_id)
            || !text(&self.actor.session_id)
            || self.actor.authorization_generation == 0
            || self.actor.authorization_generation > directory::os_directory::schema::DOCUMENT_OPEN_MAX_SAFE_INTEGER
            || !(SpaceArtifactCreationStatusV1 {
                schema: "semio.hub.space-artifact-creation-status/v1".into(),
                request_id: self.request.request_id.clone(),
                space_id: self.scope.space_id.clone(),
                catalog_generation_id: self.catalog_generation.clone(),
                phase: SpaceArtifactCreationPhaseV1::Accepted,
                ready: None,
                progress: None,
            })
            .validate()
            || !self.ready().validate()
            || !hash(&self.catalog_generation)
            || self.request.expected_catalog_generation_id != self.catalog_generation
            || self.accepted_at_ms.checked_add(ARTIFACT_CREATION_DEADLINE_MS) != Some(self.deadline_ms)
            || self.deadline_ms > directory::os_directory::schema::DOCUMENT_OPEN_MAX_SAFE_INTEGER
            || directory::os_directory::validate_document_descriptor_v1(&descriptor).is_err()
        {
            return Err(rejected("artifact creation accepted identity is invalid"));
        }
        Ok(())
    }
}

impl ArtifactCreationPreparedV1 {
    /// 🧬️ The private pair, descriptor and exact zero checkpoint remain bound to their accepted
    /// intent. Every clause here is an IDENTITY clause — the checkpoint belongs to this intent's
    /// scope, owner, schema, pair bytes and digests. The one clause that was not
    /// (`published_at_ms >= intent.deadline_ms`, i.e. "this took too long") is gone: it refused a
    /// genesis the guest had already completed, which is a decision about a bound and not about
    /// identity, and it belongs to the live operation's stall bound (ticket 26/09/18 slice HC1).
    /// `published_at_ms < accepted_at_ms` stays, because a checkpoint cannot predate its own intent.
    pub fn validate_fields(&self, intent: &ArtifactCreationIntentV1) -> DirectoryResult<()> {
        intent.validate_fields()?;
        let d = &self.descriptor;
        let c = &self.checkpoint;
        if self.pack.is_empty()
            || self.spr.is_empty()
            || self.pack.len().checked_add(self.spr.len()).is_none_or(|length| length > ARTIFACT_CREATION_PAIR_MAX_BYTES)
            || d.space_id != intent.scope.space_id
            || d.document_id != intent.scope.document_id
            || d.artifact_kind != intent.request.kind_id
            || d.artifact_schema != intent.artifact_schema
            || d.owner != intent.owner
            || d.pack_schema_hash != intent.pack_schema_hash
            || d.bootstrap_version != 1
            || d.bootstrap_frontier != (directory::os_directory::DocumentFrontier { head_seq: 0, commit_seq: 0, epoch: 0 })
            || c.scope != intent.scope
            || !c.baseline_frontier.is_genesis_for(&intent.scope)
            || c.parent_checkpoint_id.is_some()
            || c.published_at_ms < intent.accepted_at_ms
            || c.pack.byte_length != self.pack.len() as u64
            || c.spr.byte_length != self.spr.len() as u64
        {
            return Err(rejected("artifact creation prepared pair differs from its accepted intent"));
        }
        Ok(())
    }
}

impl ArtifactCreationOperationV1 {
    /// 📖️ Validates a complete bounded history; neither an orphan completion nor a terminal retry opens a key.
    ///
    /// ⏱️ Order, not the calendar: a fact cannot be recorded before the checkpoint it
    /// carries. A Prepared fact recorded past `intent.deadline_ms` used to be refused
    /// here as "expired", which made the durable history enforce a third copy of the
    /// absolute bound the live path no longer carries — and turned an honest 180 s
    /// genesis on the biggest staged component into a permanent, unrecoverable refusal
    /// (ticket 26/09/18 slice HC1, measured on hub 7681). Nothing is lost: this arm
    /// only accepts Prepared on a key still in `Accepted`, and a key the recovery
    /// sweep closed is already terminal, so a late preparation on an abandoned key is
    /// refused by the transition itself.
    pub fn fold(admitted: &AdmittedArtifactCreationFactsV1<'_>) -> DirectoryResult<Self> {
        Self::fold_checked(admitted.facts)
    }

    fn fold_checked(facts: &[ArtifactCreationFactV1]) -> DirectoryResult<Self> {
        if facts.is_empty() || facts.len() > ARTIFACT_CREATION_FACTS_MAX {
            return Err(rejected("artifact creation fact count is invalid"));
        }
        let ArtifactCreationFactBodyV1::Accepted { intent } = &facts[0].body else {
            return Err(rejected("artifact creation history has no accepted intent"));
        };
        intent.validate_fields()?;
        let mut result = Self { intent: intent.clone(), prepared: None, receipt: None, phase: SpaceArtifactCreationPhaseV1::Accepted, revision: 0 };
        let mut timestamp = intent.accepted_at_ms;
        for (index, fact) in facts.iter().enumerate() {
            if fact.actor_user_id != intent.actor.user_id
                || fact.request_id != intent.request.request_id
                || fact.revision != index as u64 + 1
                || fact.recorded_at_ms < timestamp
                || fact.recorded_at_ms > directory::os_directory::schema::DOCUMENT_OPEN_MAX_SAFE_INTEGER
            {
                return Err(rejected("artifact creation fact identity or order differs"));
            }
            match (&fact.body, result.phase, index) {
                (ArtifactCreationFactBodyV1::Accepted { .. }, _, 0) if fact.recorded_at_ms == intent.accepted_at_ms => {}
                (ArtifactCreationFactBodyV1::Prepared { candidate }, SpaceArtifactCreationPhaseV1::Accepted, _) => {
                    candidate.validate_fields(intent)?;
                    if fact.recorded_at_ms < candidate.checkpoint.published_at_ms {
                        return Err(rejected("artifact creation preparation predates its checkpoint"));
                    }
                    result.prepared = Some(candidate.clone());
                    result.phase = SpaceArtifactCreationPhaseV1::Preparing;
                }
                (ArtifactCreationFactBodyV1::Committed { receipt }, SpaceArtifactCreationPhaseV1::Preparing, _) => {
                    let candidate = result.prepared.as_ref().ok_or_else(|| rejected("artifact creation completion is unprepared"))?;
                    if receipt.ready != intent.ready()
                        || receipt.checkpoint_id != candidate.checkpoint.checkpoint_id
                        || receipt.descriptor_digest_v1 != candidate.checkpoint.descriptor_digest_v1
                        || receipt.event_seq_first == 0
                        || receipt.event_seq_first.checked_add(2) != Some(receipt.event_seq_last)
                        || receipt.event_seq_last > directory::os_directory::schema::DOCUMENT_OPEN_MAX_SAFE_INTEGER
                        || receipt.event_ids.len() != 3
                        || receipt.event_ids.iter().any(|id| !text(id) || !id.is_ascii())
                        || receipt.event_ids.iter().collect::<std::collections::BTreeSet<_>>().len() != 3
                    {
                        return Err(rejected("artifact creation completion differs from its prepared triple"));
                    }
                    result.receipt = Some(receipt.clone());
                    result.phase = SpaceArtifactCreationPhaseV1::Ready;
                }
                (ArtifactCreationFactBodyV1::Cancelled, SpaceArtifactCreationPhaseV1::Accepted | SpaceArtifactCreationPhaseV1::Preparing, _) => result.phase = SpaceArtifactCreationPhaseV1::Cancelled,
                (ArtifactCreationFactBodyV1::Failed, SpaceArtifactCreationPhaseV1::Accepted | SpaceArtifactCreationPhaseV1::Preparing, _) => result.phase = SpaceArtifactCreationPhaseV1::Failed,
                _ => return Err(rejected("artifact creation fact transition is invalid")),
            }
            result.revision = fact.revision;
            timestamp = fact.recorded_at_ms;
        }
        Ok(result)
    }

    /// 📬️ Private bytes and authority identities never appear in a creation status response.
    pub fn status(&self) -> SpaceArtifactCreationStatusV1 {
        SpaceArtifactCreationStatusV1 {
            schema: "semio.hub.space-artifact-creation-status/v1".into(),
            request_id: self.intent.request.request_id.clone(),
            space_id: self.intent.scope.space_id.clone(),
            catalog_generation_id: self.intent.catalog_generation.clone(),
            phase: self.phase,
            ready: self.receipt.as_ref().map(|receipt| receipt.ready.clone()),
            progress: None,
        }
    }
}

#[cfg(test)]
#[path = "🧪️tests/🔬️unit/🦀️.rs"]
mod tests;
