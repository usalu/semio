//! 🧬️ schema leaf

use schema::ArtifactSchema;
use std::collections::BTreeMap;

#[derive(Clone, Debug, PartialEq, value_derive::ToValue, value_derive::FromValue, ArtifactSchema)]
#[value(rename_all = "camelCase")]
#[artifact_schema(id = "hub.compositions.space.engine.space.config")]
pub struct SpaceConfig {
    #[state(config)]
    pub camera: BTreeMap<String, SpaceWindowCamera>,
    #[state(config)]
    pub collapsed_node_ids: Vec<String>,
    #[state(config)]
    pub preview_off_node_ids: Vec<String>,
    #[state(config)]
    pub active_node_id: Option<String>,
    #[state(config)]
    pub focused_node_id: Option<String>,
    #[state(config)]
    pub clipboard_node_ids: Vec<String>,
    #[state(config)]
    pub workflow_engagement_input: String,
    #[state(config)]
    pub compiled_dag_engagement_input: String,
    #[state(config)]
    pub pending_import_node_id: Option<String>,
    #[state(config)]
    pub pending_import_format: Option<String>,
    #[state(config)]
    pub active_panel_tab: String,
    #[state(config)]
    pub space_id: Option<String>,
}

//region 📎 App-schema descriptor
/// 📎 The `s.space.space` app-schema descriptor (config + presence facets) — returned, not
/// self-registered; `ArtifactApp::app_schema` (ticket 26/08/12/ARTIFACTS-ONLY-PLUGIN-ARCHITECTURE
/// W1c) hands it to `register_document_app` for registration, mirroring the `🗒️note` pattern.
pub async fn app_schema_descriptor() -> ::semio_framework_schema_registry::AppSchemaDescriptor {
    ::semio_framework_schema_registry::AppSchemaDescriptor {
        id: "s.space.space",
        config: ::semio_framework_schema_registry::FacetLeaves {
            rust: include_str!("🦀️.rs"),
            typescript: include_str!("🟦️.ts"),
            graphql: include_str!("🔗️.graphql"),
            json_schema: include_str!("🔣️.json"),
            proto: include_str!("🛰️.proto"),
        },
        presence: ::semio_framework_schema_registry::FacetLeaves {
            rust: include_str!("../../👥️presence/🧬️schema/🦀️.rs"),
            typescript: include_str!("../../👥️presence/🧬️schema/🟦️.ts"),
            graphql: include_str!("../../👥️presence/🧬️schema/🔗️.graphql"),
            json_schema: include_str!("../../👥️presence/🧬️schema/🔣️.json"),
            proto: include_str!("../../👥️presence/🧬️schema/🛰️.proto"),
        },
    }
}
//endregion 📎 App-schema descriptor

//#region 🔁️Re-exports
/// 🔁️ Entities this module's schema exports and its crate declares elsewhere.
pub use super::SpaceWindowCamera;
//#endregion 🔁️Re-exports
