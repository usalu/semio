

use semio_hub_space_app::SpaceCommand;
use semio_hub_space_app::unit_tests::context::studio_emit;
use semio_framework_os::empty_workflow_snapshot;
use semio_framework_plugin::{ArtifactView, ConfigView, Effect, Emit};
use semio_hub_space_commands_media::set_active_example::SetActiveExample;
use semio_hub_space_foundation::config::{SpaceConfig, SpaceConfigMutation};
use semio_framework_os::{WorkflowMutation, WorkflowSnapshot};

#[semio_framework_async_macros::async_test]
async fn space_command_op_text_round_trips_every_variant() {
    store::os_store::test_support::assert_op_line_round_trip(&SpaceCommand::SetActiveExample(SetActiveExample { example_id: "demo".into() }));
    store::os_store::test_support::assert_op_line_round_trip(&SpaceCommand::ExportStudioPack(semio_hub_space_commands_media::export_studio_pack::ExportStudioPack {}));
    store::os_store::test_support::assert_op_line_round_trip(&SpaceCommand::ExportStudioDsl(semio_hub_space_commands_media::export_studio_dsl::ExportStudioDsl {}));
    store::os_store::test_support::assert_op_line_round_trip(&SpaceCommand::ImportSpacePack(semio_hub_space_commands_media::import_space_pack::ImportSpacePack {}));
    store::os_store::test_support::assert_op_line_round_trip(&SpaceCommand::ImportSpacePackPayload(semio_hub_space_commands_media::import_space_pack_payload::ImportSpacePackPayload { payload: "data:...".into() }));
    store::os_store::test_support::assert_op_line_round_trip(&SpaceCommand::OpenSpace(semio_hub_space_commands_media::open_space::OpenSpace { space_id: "demo".into() }));
}

#[semio_framework_async_macros::async_test]
async fn open_studio_loads_created_empty_catalog_studio() {
    use semio_framework_artifact_space_space::{SpaceKind, SpaceRole, SpaceUser, SpaceVisibility};
    use semio_framework_os::{MemoryBackbonePort, OsBackbonePorts, create_os_space};
    use std::sync::Arc;
    let port = Arc::new(OsBackbonePorts::Store(store::os_store::backbone::BackbonePorts::Memory(MemoryBackbonePort::default())));
    let owner = SpaceUser { id: "tester".into(), name: "Tester".into(), avatar: None, role: SpaceRole::Author };
    let entry = create_os_space("Opened Empty", SpaceKind::Atelier, SpaceVisibility::Private, owner, &port).expect("create");
    crate::register_studio_port_for_test(&entry.id, port).await;
    let empty = empty_workflow_snapshot().await;
    let config = SpaceConfig::default();
    let emit = studio_emit(&empty, &config, &SpaceCommand::OpenSpace(semio_hub_space_commands_media::open_space::OpenSpace { space_id: entry.id.clone() })).await.expect("handle");
    assert!(emit.config_mutations.contains(&SpaceConfigMutation::SetSpaceId(SpaceIdSetting { space_id: Some(entry.id) })));
    assert!(emit.config_mutations.contains(&SpaceConfigMutation::SetActiveNode(ActiveNodeSetting { node_id: None })));
    assert!(emit.effects.iter().any(|effect| matches!(effect, Effect::LoadDocument { .. })));
    assert!(!emit.effects.iter().any(|effect| matches!(effect, Effect::Navigate { .. })));
}

#[semio_framework_async_macros::async_test]
async fn open_studio_unknown_id_returns_not_found() {
    let empty = empty_workflow_snapshot().await;
    let config = SpaceConfig::default();
    let err = studio_emit(&empty, &config, &SpaceCommand::OpenSpace(semio_hub_space_commands_media::open_space::OpenSpace { space_id: "unknown-studio-id".into() })).await.err().expect("not found");
    assert_eq!(err.code.0, "s.space.not-found");
}

async fn load_document_snapshot(emit: &Emit<WorkflowMutation, SpaceConfigMutation>) -> (WorkflowSnapshot, String) {
    let (pack, spr) = emit
        .effects
        .iter()
        .find_map(|effect| match effect {
            Effect::LoadDocument { pack, spr } => Some((pack.as_slice(), spr.as_slice())),
            _ => None,
        })
        .expect("load document");
    let parsed: store::os_store::text_format::ParsedDocumentText<WorkflowSnapshot, WorkflowMutation> = store::os_store::text_format::parse_document_pack(pack, spr).await.expect("parse document pack");
    let id = parsed.envelope.id.clone();
    (parsed.into_snapshot(), id)
}

#[semio_framework_async_macros::async_test]
async fn open_studio_demo_explicit_loads_demo_fixture() {
    let empty = empty_workflow_snapshot().await;
    let config = SpaceConfig::default();
    let emit = studio_emit(&empty, &config, &SpaceCommand::OpenSpace(semio_hub_space_commands_media::open_space::OpenSpace { space_id: "demo".into() })).await.expect("handle");
    let (projection, id) = load_document_snapshot(&emit).await;
    assert!(id.contains("demo-studio"));
    assert!(!projection.graph.nodes.is_empty());
}

#[semio_framework_async_macros::async_test]
async fn open_studio_loads_ephemeral_created_studio() {
    let mut authoring_observer = |_: semio_framework_value::native_encoding::NativeEncodeProgress| true;
    let mut authoring = store::os_vcs::io::binary::entity_identity::control::EntityIdentityAuthority::new(44, &mut authoring_observer).expect("finite studio fixture admission");
    use semio_s_artifact_space_home::editor::home::commands::create_studio;
    use semio_framework_plugin::{ArtifactEditor, ArtifactView, ConfigView, HistoryView};
    let _home = semio_s_artifact_space_home::editor::home::HomeApp;
    let home_projection = semio_s_artifact_space_home::editor::home::HomeApp::initial_snapshot();
    let history = HistoryView::empty();
    let doc = ArtifactView::new(&home_projection, &history);
    let home_config = semio_s_artifact_space_home::editor::home::config::HomeConfig::default();
    let home_cfg = ConfigView { snapshot: &home_config, window: None };
    // 🪪️ Minting a studio needs the host session identity that owns it — `create_studio::handle` is
    // the identity-less entry point and now always refuses (`s.home.session-identity-required`).
    let identity = semio_framework_plugin::ViewSessionIdentity { user_id: "u1".into(), display_name: "Ada".into() };
    let create = create_studio::handle_with_identity(&create_studio::CreateStudio { name: "Ephemeral Open".into(), kind: "catalog".into(), folder_path: None }, &doc, &home_cfg, &identity, &mut authoring).expect("handle");
    let space_id = create
        .effects
        .iter()
        .find_map(|effect| match effect {
            Effect::Navigate { uri } => Some(uri.trim_start_matches("/spaces/").to_string()),
            _ => None,
        })
        .expect("navigate");
    let empty = empty_workflow_snapshot().await;
    let config = SpaceConfig::default();
    let emit = studio_emit(&empty, &config, &SpaceCommand::OpenSpace(semio_hub_space_commands_media::open_space::OpenSpace { space_id: space_id.clone() })).await.expect("handle");
    let (projection, id) = load_document_snapshot(&emit).await;
    assert_eq!(id, space_id);
    assert!(projection.graph.nodes.is_empty());
}

/// 🌉️ Exercises BOTH apps together (Home's `createStudio` followed by Space's `openSpace`).
#[semio_framework_async_macros::async_test]
async fn create_space_navigates_without_download_and_opens_empty() {
    let mut authoring_observer = |_: semio_framework_value::native_encoding::NativeEncodeProgress| true;
    let mut authoring = store::os_vcs::io::binary::entity_identity::control::EntityIdentityAuthority::new(44, &mut authoring_observer).expect("finite studio fixture admission");
    use semio_s_artifact_space_home::editor::home::commands::create_studio;
    use semio_framework_plugin::{ArtifactEditor, ArtifactView, ConfigView, HistoryView};
    let _home = semio_s_artifact_space_home::editor::home::HomeApp;
    let home_projection = semio_s_artifact_space_home::editor::home::HomeApp::initial_snapshot();
    let history = HistoryView::empty();
    let doc = ArtifactView::new(&home_projection, &history);
    let home_config = semio_s_artifact_space_home::editor::home::config::HomeConfig::default();
    let home_cfg = ConfigView { snapshot: &home_config, window: None };
    // 🪪️ See `open_studio_loads_ephemeral_created_studio`: the identity-less entry point refuses.
    let identity = semio_framework_plugin::ViewSessionIdentity { user_id: "u1".into(), display_name: "Ada".into() };
    let emit = create_studio::handle_with_identity(&create_studio::CreateStudio { name: "Fresh Studio".into(), kind: "catalog".into(), folder_path: None }, &doc, &home_cfg, &identity, &mut authoring).expect("handle");
    assert!(!emit.effects.iter().any(|effect| matches!(effect, Effect::DownloadMediaExport { .. })), "create must not download a file");
    let uri = emit
        .effects
        .iter()
        .find_map(|effect| match effect {
            Effect::Navigate { uri } => Some(uri.as_str()),
            _ => None,
        })
        .expect("navigate");
    assert!(uri.starts_with("/spaces/"), "uri={uri}");
    assert!(!uri.ends_with("/demo") && !uri.ends_with("/default"), "uri={uri}");
    let space_id = uri.trim_start_matches("/spaces/");
    let document = crate::resolve_studio_document(space_id).await.expect("created studio");
    assert_eq!(document.name, "Fresh Studio");
    assert!(document.backbone.is_none(), "ephemeral studio must not attach backbone");
    assert!(document.vcs.genesis.facts().snapshot().collections.is_empty());

    let empty = empty_workflow_snapshot().await;
    let studio_doc = ArtifactView::new(&empty, &history);
    let studio_config = SpaceConfig::default();
    let studio_cfg = ConfigView { snapshot: &studio_config, window: None };
    // 🕹️ `OpenSpace` isn't one of `SpaceApp::handle`'s interaction-aware bypass rows, so it's safe
    // to exercise via `SpaceCommand::dispatch` directly (the `app_commands!`-generated 3-arg path
    // — ticket 26/08/14/FIRST-CLASS-HOVER-AND-SELECTION-MECHANISM) rather than through
    // `SpaceApp::handle`, which now needs a real `InteractionView` only a full `VcsArtifactApp`
    // dispatch can provide.
    let open = SpaceCommand::OpenSpace(semio_hub_space_commands_media::open_space::OpenSpace { space_id: space_id.to_string() }).dispatch(&studio_doc, &studio_cfg).expect("handle");
    assert!(open.effects.iter().any(|effect| matches!(effect, Effect::LoadDocument { .. })), "openSpace must load the created studio");
    assert!(!open.effects.iter().any(|effect| matches!(effect, Effect::Navigate { .. })));
    assert!(!open.effects.iter().any(|effect| matches!(effect, Effect::DownloadMediaExport { .. })));
}
