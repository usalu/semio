//! 📜️ The append-only directory event log and projection rebuild.

use super::*;

impl PostgresDirectory {
    //#region EventLog
    pub(super) async fn append_decided_events(&self, events: &[NewDirectoryEvent]) -> DirectoryResult<DirectoryAppendOutcomeV1> {
        if events.iter().any(|event| matches!(&event.body, DirectoryEventBody::ArtifactCheckpointPublished { .. } | DirectoryEventBody::InviteRedeemed { .. })) {
            return Err(DirectoryError::Conflict("event requires its verified authority append seam".into()));
        }
        let mut tx = self.pool.begin().await.map_err(backend)?;
        let mut persisted = Vec::with_capacity(events.len());
        for event in events {
            let id = time_ordered_id();
            let recorded_at_ms = now_ms();
            let payload_value = serde_json::Value::from(&event.body.to_value());
            let kind = payload_value.get("kind").and_then(|value| value.as_str()).unwrap_or_default().to_string();
            let row: (i64,) = sqlx_core::query_as::query_as("UPDATE hub_directory_event_head SET seq = seq + 1 WHERE singleton RETURNING seq").fetch_one(&mut *tx).await.map_err(backend)?;
            if let Some(reason) = self.projection_rejection(&mut tx, &event.body).await? {
                tx.rollback().await.map_err(backend)?;
                return Ok(DirectoryAppendOutcomeV1::RejectedBeforeCommit(reason));
            }

            let full =
                DirectoryEvent { seq: u64::try_from(row.0).map_err(backend)?, id: id.clone(), hlc: event.hlc, actor: event.actor.clone(), space_id: event.space_id.clone(), user_id: event.user_id.clone(), body: event.body.clone(), recorded_at_ms };
            validate_directory_event_page_event(&full).map_err(|_| DirectoryError::Conflict("directory event violates the bounded event-page contract".into()))?;
            sqlx_core::query::query(
                "INSERT INTO hub_directory_event (seq, id, hlc_physical, hlc_logical, actor_kind, actor_id, space_id, user_id, kind, payload, recorded_at)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)",
            )
            .bind(row.0)
            .bind(&id)
            .bind(event.hlc.physical_ms)
            .bind(event.hlc.logical as i64)
            .bind(actor_kind_to_str(event.actor.kind))
            .bind(&event.actor.id)
            .bind(&event.space_id)
            .bind(&event.user_id)
            .bind(&kind)
            .bind(&payload_value)
            .bind(recorded_at_ms)
            .execute(&mut *tx)
            .await
            .map_err(backend)?;
            self.project(&mut tx, &full).await?;
            let release = match &full.body {
                DirectoryEventBody::ArtifactRetentionAdvanced { retention } => Some(("retention", retention.scope.space_id.as_str(), Some(retention.scope.document_id.as_str()), Some(retention.retained_checkpoint_id))),
                DirectoryEventBody::SpaceDeleted { space_id } => Some(("space-delete", space_id.as_str(), None, None)),
                _ => None,
            };
            if let Some((operation, space_id, document_id, checkpoint_id)) = release {
                let generation = cas_generation(&mut tx).await?;
                sqlx_core::query::query("INSERT INTO hub_artifact_cas_ledger_journal(generation, operation, space_id, document_id, checkpoint_id, event_seq) VALUES ($1,$2,$3,$4,$5,$6)")
                    .bind(generation)
                    .bind(operation)
                    .bind(space_id)
                    .bind(document_id)
                    .bind(checkpoint_id.map(|value| value.0.to_vec()))
                    .bind(row.0)
                    .execute(&mut *tx)
                    .await
                    .map_err(backend)?;
                cas_project_release(&mut tx, operation, space_id, document_id, checkpoint_id).await?;
            }
            persisted.push(full);
        }
        tx.commit().await.map_err(backend)?;
        Ok(DirectoryAppendOutcomeV1::Appended(persisted))
    }

    pub(super) async fn append_decided_events_with_admin_effect(&self, events: &[NewDirectoryEvent], effect: &NewAdminOperationEffectReceiptV1) -> AdminEffectCommitV1<Vec<DirectoryEvent>> {
        if events.is_empty() || events.iter().any(|event| matches!(&event.body, DirectoryEventBody::ArtifactCheckpointPublished { .. } | DirectoryEventBody::InviteRedeemed { .. })) {
            return AdminEffectCommitV1::RejectedBeforeCommit;
        }
        let mut tx = match self.pool.begin().await {
            Ok(tx) => tx,
            Err(_) => return AdminEffectCommitV1::Indeterminate,
        };
        let persisted_result: DirectoryResult<Vec<DirectoryEvent>> = async {
            let mut persisted = Vec::with_capacity(events.len());
            for event in events {
                let id = time_ordered_id();
                let recorded_at_ms = now_ms();
                let payload_value = serde_json::Value::from(&event.body.to_value());
                let kind = payload_value.get("kind").and_then(|value| value.as_str()).unwrap_or_default().to_string();
                let row: (i64,) = sqlx_core::query_as::query_as("UPDATE hub_directory_event_head SET seq = seq + 1 WHERE singleton RETURNING seq").fetch_one(&mut *tx).await.map_err(backend)?;
                if self.projection_rejection(&mut tx, &event.body).await?.is_some() {
                    return Err(DirectoryError::Conflict("administrator event projection was rejected".into()));
                }
                let full = DirectoryEvent {
                    seq: u64::try_from(row.0).map_err(backend)?,
                    id: id.clone(),
                    hlc: event.hlc,
                    actor: event.actor.clone(),
                    space_id: event.space_id.clone(),
                    user_id: event.user_id.clone(),
                    body: event.body.clone(),
                    recorded_at_ms,
                };
                validate_directory_event_page_event(&full).map_err(|_| DirectoryError::Conflict("directory event violates the bounded event-page contract".into()))?;
                sqlx_core::query::query("INSERT INTO hub_directory_event (seq, id, hlc_physical, hlc_logical, actor_kind, actor_id, space_id, user_id, kind, payload, recorded_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)")
                    .bind(row.0)
                    .bind(&id)
                    .bind(event.hlc.physical_ms)
                    .bind(i64::from(event.hlc.logical))
                    .bind(actor_kind_to_str(event.actor.kind))
                    .bind(&event.actor.id)
                    .bind(&event.space_id)
                    .bind(&event.user_id)
                    .bind(kind)
                    .bind(payload_value)
                    .bind(recorded_at_ms)
                    .execute(&mut *tx)
                    .await
                    .map_err(backend)?;
                self.project(&mut tx, &full).await?;
                let release = match &full.body {
                    DirectoryEventBody::ArtifactRetentionAdvanced { retention } => Some(("retention", retention.scope.space_id.as_str(), Some(retention.scope.document_id.as_str()), Some(retention.retained_checkpoint_id))),
                    DirectoryEventBody::SpaceDeleted { space_id } => Some(("space-delete", space_id.as_str(), None, None)),
                    _ => None,
                };
                if let Some((operation, space_id, document_id, checkpoint_id)) = release {
                    let generation = cas_generation(&mut tx).await?;
                    sqlx_core::query::query("INSERT INTO hub_artifact_cas_ledger_journal(generation, operation, space_id, document_id, checkpoint_id, event_seq) VALUES ($1,$2,$3,$4,$5,$6)")
                        .bind(generation)
                        .bind(operation)
                        .bind(space_id)
                        .bind(document_id)
                        .bind(checkpoint_id.map(|value| value.0.to_vec()))
                        .bind(row.0)
                        .execute(&mut *tx)
                        .await
                        .map_err(backend)?;
                    cas_project_release(&mut tx, operation, space_id, document_id, checkpoint_id).await?;
                }
                persisted.push(full);
            }
            insert_admin_operation_effect_receipt(&mut tx, &admin_operation_effect_receipt_v1(effect, &persisted)?).await?;
            Ok(persisted)
        }
        .await;
        let persisted = match persisted_result {
            Ok(persisted) => persisted,
            Err(_) => return admin_effect_rollback(tx).await,
        };
        match tx.commit().await {
            Ok(()) => AdminEffectCommitV1::Applied(persisted),
            Err(_) => AdminEffectCommitV1::Indeterminate,
        }
    }

    pub(super) async fn events_since(&self, since_seq: u64, limit: usize) -> DirectoryResult<Vec<DirectoryEvent>> {
        let (since_seq, limit) = bounded_event_read(since_seq, limit)?;
        let rows: Vec<(i64, String, i64, i64, String, String, Option<String>, Option<String>, serde_json::Value, i64)> = sqlx_core::query_as::query_as(
            "SELECT seq, id, hlc_physical, hlc_logical, actor_kind, actor_id, space_id, user_id, payload, recorded_at
             FROM hub_directory_event WHERE seq > $1 ORDER BY seq LIMIT $2",
        )
        .bind(since_seq)
        .bind(limit)
        .fetch_all(&self.pool)
        .await
        .map_err(backend)?;
        rows.into_iter().map(event_from_row).collect()
    }

    pub(super) async fn head_seq(&self) -> DirectoryResult<u64> {
        let row: (Option<i64>,) = sqlx_core::query_as::query_as("SELECT MAX(seq) FROM hub_directory_event").fetch_one(&self.pool).await.map_err(backend)?;
        u64::try_from(row.0.unwrap_or(0)).map_err(backend)
    }

    pub(super) async fn rebuild_projections(&self) -> DirectoryResult<u64> {
        self.rebuild_projections_controlled(&UNCONTROLLED_PROJECTION_REBUILD).await
    }

    pub(super) async fn rebuild_projections_controlled(&self, control: &dyn ProjectionRebuildControl) -> DirectoryResult<u64> {
        let mut tx = self.pool.begin().await.map_err(backend)?;
        let _: (i64,) = sqlx_core::query_as::query_as("SELECT seq FROM hub_directory_event_head WHERE singleton FOR UPDATE").fetch_one(&mut *tx).await.map_err(backend)?;
        let (event_count,): (i64,) = sqlx_core::query_as::query_as("SELECT COUNT(*) FROM hub_directory_event").fetch_one(&mut *tx).await.map_err(backend)?;
        let total = u64::try_from(event_count).map_err(backend)?;
        checkpoint_projection_rebuild(control, 0, total)?;
        sqlx_core::query::query(
            "CREATE TEMP TABLE hub_rebuild_space_invite ON COMMIT DROP AS SELECT id, selector, secret_digest, space_id, role, created_at, expires_at, revoked_at, revoked_reason, accepted_at, accepted_event_id FROM hub_space_invite",
        )
        .execute(&mut *tx)
        .await
        .map_err(backend)?;
        sqlx_core::query::query("CREATE TEMP TABLE hub_rebuild_user ON COMMIT DROP AS SELECT id, email, display_name, password_hash, sso_subject, sso_provider, created_at FROM hub_user").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query(
            "CREATE TEMP TABLE hub_rebuild_auth_session ON COMMIT DROP AS SELECT id, selector, secret_digest, user_id, identity_provider, identity_subject_digest, issued_at, expires_at, revoked_at, revoked_reason, authorization_generation, device_instance_id, session_kind FROM hub_auth_session",
        )
        .execute(&mut *tx)
        .await
        .map_err(backend)?;
        sqlx_core::query::query("CREATE TEMP TABLE hub_rebuild_sync_binding ON COMMIT DROP AS SELECT id, auth_session_id, user_id FROM hub_sync_session").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_artifact_cas_reservation").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_artifact_cas_reference").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_artifact_retention").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_artifact_checkpoint_private").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_artifact_checkpoint").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_document_index").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_document_descriptor").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_space_membership").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_space").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query("DELETE FROM hub_user").execute(&mut *tx).await.map_err(backend)?;
        sqlx_core::query::query(
            "INSERT INTO hub_user (id, email, display_name, password_hash, sso_subject, sso_provider, created_at)
             SELECT id, email, display_name, password_hash, sso_subject, sso_provider, created_at FROM hub_rebuild_user",
        )
        .execute(&mut *tx)
        .await
        .map_err(|error| DirectoryError::Backend(format!("PostgreSQL projection rebuild identity restore: {error}")))?;
        let mut replayed = 0u64;
        let mut cursor = 0i64;
        while replayed < total {
            let rows: Vec<(i64, String, i64, i64, String, String, Option<String>, Option<String>, serde_json::Value, i64)> =
                sqlx_core::query_as::query_as("SELECT seq, id, hlc_physical, hlc_logical, actor_kind, actor_id, space_id, user_id, payload, recorded_at FROM hub_directory_event WHERE seq > $1 ORDER BY seq LIMIT 512")
                    .bind(cursor)
                    .fetch_all(&mut *tx)
                    .await
                    .map_err(backend)?;
            if rows.is_empty() {
                return Err(DirectoryError::Backend("directory event replay ended before its counted head".into()));
            }
            for row in rows {
                cursor = row.0;
                let event = event_from_row(row)?;
                if let Err(error) = self.project(&mut tx, &event).await {
                    tx.rollback().await.map_err(backend)?;
                    return Err(DirectoryError::Backend(format!("PostgreSQL projection rebuild event {}: {error}", event.seq)));
                }
                if matches!(&event.body, DirectoryEventBody::ArtifactCheckpointPublished { .. }) {
                    let private: Option<(serde_json::Value,)> = sqlx_core::query_as::query_as("SELECT payload FROM hub_artifact_authority_journal WHERE event_seq = $1").bind(cursor).fetch_optional(&mut *tx).await.map_err(backend)?;
                    let checkpoint =
                        private.ok_or_else(|| DirectoryError::Backend(format!("missing private authority journal for checkpoint event {}", event.seq))).and_then(|(value,)| ArtifactCheckpoint::from_value(DslValue::from(value)).map_err(backend))?;
                    self.project_verified_checkpoint(&mut tx, &event, &checkpoint).await?;
                }
                replayed += 1;
                checkpoint_projection_rebuild(control, replayed, total)?;
            }
        }
        sqlx_core::query::query(
            "INSERT INTO hub_space_invite (id, selector, secret_digest, space_id, role, created_at, expires_at, revoked_at, revoked_reason, accepted_at, accepted_event_id)
             SELECT id, selector, secret_digest, space_id, role, created_at, expires_at, revoked_at, revoked_reason, accepted_at, accepted_event_id FROM hub_rebuild_space_invite",
        )
        .execute(&mut *tx)
        .await
        .map_err(backend)?;
        sqlx_core::query::query(
            "INSERT INTO hub_auth_session (id, selector, secret_digest, user_id, identity_provider, identity_subject_digest, issued_at, expires_at, revoked_at, revoked_reason, authorization_generation, device_instance_id, session_kind)
             SELECT id, selector, secret_digest, user_id, identity_provider, identity_subject_digest, issued_at, expires_at, revoked_at, revoked_reason, authorization_generation, device_instance_id, session_kind FROM hub_rebuild_auth_session",
        )
        .execute(&mut *tx)
        .await
        .map_err(|error| DirectoryError::Backend(format!("PostgreSQL projection rebuild session restore: {error}")))?;
        sqlx_core::query::query(
            "UPDATE hub_sync_session SET auth_session_id = binding.auth_session_id, user_id = binding.user_id
             FROM hub_rebuild_sync_binding AS binding WHERE hub_sync_session.id = binding.id",
        )
        .execute(&mut *tx)
        .await
        .map_err(|error| DirectoryError::Backend(format!("PostgreSQL projection rebuild sync binding restore: {error}")))?;
        type CasLedgerRow = (i64, String, String, Option<String>, Option<Vec<u8>>, Option<i64>, Option<i64>, Option<Vec<u8>>);
        let ledger_rows: Vec<CasLedgerRow> =
            sqlx_core::query_as::query_as("SELECT generation, operation, space_id, document_id, checkpoint_id, write_epoch, expires_at_ms, plan FROM hub_artifact_cas_ledger_journal ORDER BY generation").fetch_all(&mut *tx).await.map_err(backend)?;
        for (generation, operation, space_id, document_id, checkpoint_id, write_epoch, expires_at_ms, plan) in ledger_rows {
            match operation.as_str() {
                "reserve" => {
                    let reservation = ArtifactCasReservation::unfenced(
                        decode_artifact_cas_ownership_v1(plan.as_deref().ok_or_else(|| DirectoryError::Backend("artifact CAS reserve journal plan missing".into()))?).map_err(|error| DirectoryError::Backend(error.to_string()))?,
                        u64::try_from(generation).map_err(backend)?,
                        u64::try_from(write_epoch.ok_or_else(|| DirectoryError::Backend("artifact CAS reserve journal epoch missing".into()))?).map_err(backend)?,
                        u64::try_from(expires_at_ms.ok_or_else(|| DirectoryError::Backend("artifact CAS reserve journal expiry missing".into()))?).map_err(backend)?,
                    );
                    cas_project_reserve(&mut tx, &reservation).await?;
                }
                "publish" => {
                    let reservation = ArtifactCasReservation::unfenced(
                        decode_artifact_cas_ownership_v1(plan.as_deref().ok_or_else(|| DirectoryError::Backend("artifact CAS publish journal plan missing".into()))?).map_err(|error| DirectoryError::Backend(error.to_string()))?,
                        u64::try_from(generation).map_err(backend)?,
                        u64::try_from(write_epoch.ok_or_else(|| DirectoryError::Backend("artifact CAS publish journal epoch missing".into()))?).map_err(backend)?,
                        u64::try_from(expires_at_ms.ok_or_else(|| DirectoryError::Backend("artifact CAS publish journal expiry missing".into()))?).map_err(backend)?,
                    );
                    cas_project_publish(&mut tx, &reservation, generation).await?;
                }
                "retention" | "space-delete" => {
                    let checkpoint_id = checkpoint_id.map(|bytes| array32(bytes, "artifact CAS release checkpoint").map(ArtifactHash)).transpose()?;
                    cas_project_release(&mut tx, &operation, &space_id, document_id.as_deref(), checkpoint_id).await?;
                }
                _ => return Err(DirectoryError::Backend("artifact CAS ledger operation is invalid".into())),
            }
        }
        tx.commit().await.map_err(backend)?;
        Ok(replayed)
    }
    //#endregion
}
