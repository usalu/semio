//! 🔌️ Plugin root contract — typestate `Plugin::builder` registration for this owner.

extern crate semio_framework_os_kernel as protocol;
extern crate semio_framework_os_kernel as store;

use semio_framework_plugin::__semio_dispatch_PluginApp;
use semio_s_dev_trinity_jack::SemioJackComposition;
use semio_framework_plugin::kernel::{ActivationEvent, CapabilityId, CapabilityRequest};
use semio_framework_plugin::plugin_app_close_prelude::*;
use semio_framework_plugin::{ExecutionMode, Plugin, PluginApp};
use semio_framework_plugin::PluginBuilder;

//#region 🗃️Apps
semio_framework_dispatch_macros::dyn_enum_close! {
    /// 🗃️ Closed runtime app fleet for both Trinity artifact surfaces.
    pub enum TrinityApps: PluginApp {
        JackEditor(VcsArtifactApp<EditorApp<semio_s_artifact_trinity_jack::editor::jack::TrinityJackPlayApp<SemioJackComposition>>, semio_s_artifact_stdio_semio::SemioMembers>),
        JackViewer(VcsArtifactApp<ViewerApp<semio_s_artifact_trinity_jack::viewer::jack::TrinityJackViewer<SemioJackComposition>>, semio_s_artifact_stdio_semio::SemioMembers>),
        RewritingEditor(VcsArtifactApp<EditorApp<semio_s_artifact_trinity_rewriting::editor::rewriting::TrinityRewritingPlayApp>, semio_s_artifact_stdio_semio::SemioMembers>),
        RewritingViewer(VcsArtifactApp<ViewerApp<semio_s_artifact_trinity_rewriting::viewer::rewriting::TrinityRewritingViewer>, semio_s_artifact_stdio_semio::SemioMembers>),
    }
}
//#endregion 🗃️Apps

/// 🔌️ Builds the plugin surface for host registration. Atomic cutover (ticket
/// 26/08/17/CLEAN-ARTIFACT-STANDARD-SUBSET-MECHANISM, fleet-trinity-recipe): `.declare_artifact(…)`
/// (new declaration tree) replaces `.artifact(declaration())`/`.editor::<>()`/`.viewer::<>()` for
/// BOTH owned artifacts outright — the old channel is NOT kept alongside it (a second parallel
/// registration channel is the compatibility layer this ticket forbids), same cutover `🗒️note`/
/// `🖍️draw` already made. `.editor_mutation_roster()`/`.viewer_mutation_roster()` stay: they are an
/// orthogonal, still-supported opt-in (`contributor.list-artifact-mutations`) the new declaration
/// tree's `SurfaceDeclaration.mutation_roster` does not yet wire live — not a second registration of
/// the artifact/schema/io itself. `.activation(…)`/`.execution(…)`/`.requests(…)` (ticket
/// 26/08/17/MICROKERNEL-POOLED-ACTOR-PLUGIN-RUNTIME M6-remaining, `📓️design-abi.md` §3/§6) are this
/// crate's migration proof: one `OnArtifactKind` event per owned kind, read live from each artifact's
/// own `artifact_kind().id`, `Isolated` execution, one `artifacts.write` ask covering both editors.
pub fn plugin() -> Result<Plugin<TrinityApps>, PluginAssemblyError> {
    PluginBuilder::<_, TrinityApps>::new("trinity")
        .label("Trinity")
        .version("0.1.0")
        .package_id("semio:trinity")
        .declare_artifact(semio_s_dev_trinity_jack::artifact::<TrinityApps>())
        .declare_artifact(semio_s_artifact_trinity_rewriting::artifact::<TrinityApps>())
        .editor_mutation_roster::<semio_s_artifact_trinity_jack::editor::jack::TrinityJackPlayApp<SemioJackComposition>>()
        .viewer_mutation_roster::<semio_s_artifact_trinity_jack::viewer::jack::TrinityJackViewer<SemioJackComposition>>()
        .editor_mutation_roster::<semio_s_artifact_trinity_rewriting::editor::rewriting::TrinityRewritingPlayApp>()
        .viewer_mutation_roster::<semio_s_artifact_trinity_rewriting::viewer::rewriting::TrinityRewritingViewer>()
        .activation(ActivationEvent::OnArtifactKind { kind: semio_s_artifact_trinity_jack::artifact_kind().id })
        .activation(ActivationEvent::OnArtifactKind { kind: semio_s_artifact_trinity_rewriting::artifact_kind().id })
        .execution(ExecutionMode::Isolated)
        .requests(CapabilityRequest { id: CapabilityId("artifacts.write".into()), scope: "plugin".into(), reason: "persist trinity jack/rewriting edits to the open document".into(), optional: false })
        .try_build()
}

//#region 🧪️SurfaceTests
#[cfg(test)]
#[path = "🧪️tests/🔬️surface/🦀️.rs"]
mod surface_tests;
//#endregion 🧪️SurfaceTests

