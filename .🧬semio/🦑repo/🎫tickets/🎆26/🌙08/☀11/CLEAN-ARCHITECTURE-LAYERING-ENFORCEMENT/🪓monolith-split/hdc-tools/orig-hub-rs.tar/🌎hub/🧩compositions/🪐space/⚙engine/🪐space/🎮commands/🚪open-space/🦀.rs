//! 💾️ 💾️ S Studio app command — `open-space`.

use semio_hub_space_foundation::config::{SpaceConfig, SpaceConfigMutation, ActiveNodeSetting, ClipboardSetting, FocusedNodeSetting, SpaceIdSetting};

use semio_framework_artifact_space_space::{empty_space_snapshot, SpaceKind, SpaceVisibility, S_SPACE_SCHEMA};
use semio_framework_os::{create_backbone_document, WorkflowMutation, WorkflowSnapshot};
use semio_framework_plugin::{ArtifactView, ConfigView, Effect, Emit, Fault, FaultCode, FaultOrigin};

#[derive(Clone, Debug, PartialEq, value_derive::ToValue, value_derive::FromValue, semio_framework_dsl_record_derive::DslRecord, semio_framework_value::RetireOwned)]
#[dsl(keyword = "open-space")]
pub struct OpenSpace {
    pub space_id: String,
}

pub fn handle(payload: &OpenSpace, _doc: &ArtifactView<'_, WorkflowSnapshot>, _cfg: &ConfigView<'_, SpaceConfig>) -> Result<Emit<WorkflowMutation, SpaceConfigMutation>, Fault> {
    use semio_hub_space_operations::resolve_future;
    let space_id = &payload.space_id;
    // 🚧️ `parse_demo_space_document()` yields a `workflow::WorkflowSnapshot`, not a
    // `space::SpaceSnapshot`-backed catalog entry — the "demo" id fallback below synthesizes a
    // minimal ephemeral space manifest with the same id/name instead, so `"demo"` still resolves to
    // *something* openable.
    let document = resolve_future(crate::resolve_studio_document(space_id)).or_else(|| {
        if space_id == "demo" {
            let name = {
                let demo = resolve_future(crate::parse_demo_space_document());
                if demo.name.trim().is_empty() {
                    "Demo Studio".into()
                } else {
                    demo.name
                }
            };
            let projection = empty_space_snapshot(&name, SpaceKind::Atelier, SpaceVisibility::Private);
            Some(create_backbone_document(S_SPACE_SCHEMA, "demo", &name, projection))
        } else {
            None
        }
    });
    let Some(document) = document else {
        return Err(Fault::new(FaultOrigin::App, FaultCode::new("s.space.not-found"), format!("studio `{space_id}` not found")));
    };
    let mut config_mutations = vec![SpaceConfigMutation::SetSpaceId(SpaceIdSetting { space_id: Some(space_id.clone()) }), SpaceConfigMutation::SetFocusedNode(FocusedNodeSetting { node_id: None }), SpaceConfigMutation::SetClipboard(ClipboardSetting { node_ids: Vec::new() })];
    // 🕸️ `document` is a `space::SpaceSnapshot`-backed manifest — it carries no workflow graph of
    // its own anymore; the graph lives on a separate `s.workflow` artifact document within one of
    // the space's collections. Resolve, in order: (1) a real workflow artifact already registered
    // in one of `document`'s collections, (2) the bundled demo fixture's real content for the demo
    // space, (3) a freshly-minted, valid, empty `WorkflowSnapshot` for any other space that has none
    // yet — never the space manifest's own bytes.
    let is_demo_space = space_id == "demo" || document.name == crate::DEMO_STUDIO_NAME;
    let workflow_snapshot = resolve_future(semio_s_artifact_space_space::index::resolve_workflow_artifact_document(space_id, &document)).or_else(|| is_demo_space.then(|| resolve_future(crate::parse_demo_space_document()))).unwrap_or_else(|| resolve_future(crate::empty_workflow_artifact_document(space_id, &document.name)));
    let active_node_id = workflow_snapshot.vcs.genesis.facts().snapshot().graph.nodes.first().map(|node| node.id.clone());
    config_mutations.push(SpaceConfigMutation::SetActiveNode(ActiveNodeSetting { node_id: active_node_id }));
    match resolve_future(crate::workflow_artifact_envelope_pack(&workflow_snapshot)) {
        Some(files) => {
            eprintln!("[TRACE] openSpace id={} workflow_id={} nodes={} collections={}", space_id, workflow_snapshot.id, workflow_snapshot.vcs.genesis.facts().snapshot().graph.nodes.len(), document.vcs.genesis.facts().snapshot().collections.len());
            Ok(Emit { config_mutations, effects: vec![Effect::LoadDocument { pack: files.pack, spr: files.spr }], ..Default::default() })
        }
        None => {
            eprintln!("[TRACE] openSpace workflow pack export failed id={space_id}");
            Ok(Emit::config(config_mutations))
        }
    }
}
