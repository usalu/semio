//! 🐘️ `HubDirectory` over PostgreSQL — direct `sqlx-postgres`/`sqlx-core` (not the `sqlx` facade),
//! avoiding the facade's optional SQLite resolver edge. The scale-out backend for multi-node
//! self-hosted deployments. `#[cfg(feature = "postgres")]`-gated as a whole by the parent
//! `directory` module (see `📇️directory/🦀️.rs`'s `//#region 🔖️Backends`).
//!
//! 🌳️ `SCHEMA` is inlined as a `const` string rather than `include_str!`-ed from a sibling
//! `.sql` file: Shape V2 tree purity allows only `component.<ext>` files, `📦️packages`, and plain
//! component folders below an owner root, so a standalone `🗄️.sql` asset has no home in this
//! tree (it is neither example/fixture/generated data for `rootDataDirNames` nor packaging code)
//! — folding it into a string literal is a zero-behavior-change mechanical transform (see
//! `📋️TEMPLATE-FAMILY.md`'s "non-source assets" section for the general rule this establishes).

use semio_hub_artifact_creation::io::decide_artifact_creation_fact_append_v1;
use directory::os_directory::io::text::validate_directory_event_page_event;
use semio_hub_artifact_authority::chunk_cas::{ArtifactCasDeleteFence, ArtifactCasObjectKey, ArtifactCasOwnershipPlanV1, ArtifactCasReservation, decode_artifact_cas_ownership_v1, encode_artifact_cas_ownership_v1, validate_artifact_cas_publication_v1};
use semio_hub_artifact_creation::{ArtifactCreationActorV1, ArtifactCreationClaimV1, ArtifactCreationFactAppendV1, ArtifactCreationFactBodyV1, ArtifactCreationFactV1, ArtifactCreationIntentV1, ArtifactCreationOperationV1, DocumentGenesisAppendV1, DocumentGenesisCommitV1};
use semio_hub_directory_contract::error::{DirectoryError, DirectoryResult};
use semio_hub_directory_contract::{AdminEffectPreflightFailure, actor_kind_from_str, actor_kind_to_str, admin_effect_preflight, backend, now_ms};
use semio_hub_directory_contract::{DIRECTORY_FORMAT_SCHEMA, DIRECTORY_FORMAT_VERSION, DirectoryFormatAdmission, admit_directory_format, ADMIN_PAGE_MAX, ARTIFACT_CAS_RESERVATION_MAX_TTL_MS, ARTIFACT_CAS_SWEEP_PAGE_MAX, ARTIFACT_CHECKPOINT_LINEAGE_MAX, AUTH_AUDIT_PAGE_MAX, AUTH_TEXT_MAX_BYTES, HubClock, InviteCapability, InviteRedemptionPreflight, InviteRedemptionScopeHintV1, InviteRedemptionSpaceStateV1, NewDirectoryEvent, SessionCapability, ShareCapability, active_capability, admin_operation_effect_receipt_v1, auth_audit, directory_command_result_kind_from_str, directory_command_result_kind_str, invite_redemption_preflight, kind_to_str, prepare_auth_session, prepare_invite, prepare_share_token, role_from_wire, role_to_wire, same_admin_operation_request, validate_admin_operation_audit, validate_admin_operation_effect_receipt, validate_bounded_auth_text, validate_checkpoint_publication_claim, validate_checkpoint_publication_completion, validate_directory_command_claim, verify_invite_redemption_event, verify_invite_redemption_scope_hint, visibility_to_str};
use semio_hub_directory::{ArtifactCasSweepCandidatePage, DirectoryAppendOutcomeV1, DirectoryProjectionRejectionV1, HubDirectory, ProjectionRebuildControl, UNCONTROLLED_PROJECTION_REBUILD, bounded_event_read, checkpoint_projection_rebuild, directory_projection_rejection_v1, directory_projection_space_v1, document_genesis_completion_v1, validate_document_genesis_append_v1, validate_verified_checkpoint_append};
use directory::os_directory::{
    ArtifactCheckpoint, ArtifactHash, ArtifactRetention, DirectoryActor, DirectoryActorKind, DirectoryEvent, DirectoryEventBody, DirectorySpaceKind, DirectorySpaceRole, DirectorySpaceVisibility, DocumentDescriptor, Hlc, PublishedArtifactCheckpoint,
    };
use directory::os_identity::time_ordered_id;
use directory::{DslValue, FromValue, ToValue};
use semio_framework_hash::Sha256;
use sqlx_postgres::{PgPool, PgPoolOptions};
use semio_hub_directory_contract::model::{AdminDirectoryOverviewCounts, AdminEffectCommitV1, AdminOperationAuditRecord, AdminOperationEffectReceiptV1, AdminSpaceSummaryRecord, AuthAuditRecord, AuthSessionIssue, AuthSessionKind, AuthSessionRecord, CheckpointPublicationClaimV1, CheckpointPublicationCompletionV1, CheckpointPublicationDispositionV1, CheckpointPublicationReceiptRecordV1, CredentialAuditFactV1, DirectoryCommandClaimV1, DirectoryCommandDispositionV1, DirectoryCommandReceiptCompletion, DirectoryCommandReceiptRecord, InviteRecord, InviteRedemptionCommit, IssuedAuthSession, IssuedInvite, IssuedShareToken, NewAdminOperationAuditRecord, NewAdminOperationEffectReceiptV1, NewCheckpointPublicationClaimV1, NewDirectoryCommandReceipt, RevokedAuthSession, ShareTokenRecord, SocketSessionBindingStatus, SocketShareBindingStatus, SpaceAdministrationInviteRow, SpaceAdministrationMemberRow, SpaceRecord, SpaceRole, SyncSessionRecord, UserRecord};
use directory::os_directory::DocumentScope;

macro_rules! admin_effect_try {
    ($tx:ident, $result:expr) => {
        match $result {
            Ok(value) => value,
            Err(_) => return admin_effect_rollback($tx).await,
        }
    };
}

#[path = "🗃️table-schema/🦀️.rs"]
mod schema;
pub(crate) use schema::*;

#[path = "🔌️connection/🦀️.rs"]
mod connection;
pub use connection::*;

#[path = "🧱️rows/🦀️.rs"]
mod rows;
pub(crate) use rows::*;

#[path = "📽️projections/🦀️.rs"]
mod projections;

#[path = "🏭️artifact-creation/🦀️.rs"]
mod artifact_creation;

#[path = "🎟️capabilities/🦀️.rs"]
mod capabilities;

#[path = "👤️accounts/🦀️.rs"]
mod accounts;
pub(crate) use accounts::*;

#[path = "🏘️spaces/🦀️.rs"]
mod spaces;

#[path = "🛡️administration/🦀️.rs"]
mod administration;
pub(crate) use administration::*;

#[path = "🔄️sync-sessions/🦀️.rs"]
mod sync_sessions;

#[path = "🧺️artifact-cas/🦀️.rs"]
mod artifact_cas;
pub(crate) use artifact_cas::*;

#[path = "📜️event-log/🦀️.rs"]
mod event_log;

/// 🚪️ The port adapter: every method forwards to the section module that owns it, an inherent `pub(super)` method of the same name, so the one `HubDirectory` impl stays a single block while its bodies live in cohesive children. See [`HubDirectory`].
impl HubDirectory for PostgresDirectory {
    async fn claim_artifact_creation(&self, intent: &ArtifactCreationIntentV1) -> DirectoryResult<ArtifactCreationClaimV1> {
        self.claim_artifact_creation(intent).await
    }
    async fn read_artifact_creation(&self, actor_user_id: &str, request_id: &str) -> DirectoryResult<Vec<ArtifactCreationFactV1>> {
        self.read_artifact_creation(actor_user_id, request_id).await
    }
    async fn append_artifact_creation_fact(&self, append: &ArtifactCreationFactAppendV1) -> DirectoryResult<ArtifactCreationOperationV1> {
        self.append_artifact_creation_fact(append).await
    }
    async fn artifact_creation_terminate_uncommitted(&self, intent: &ArtifactCreationIntentV1, current_now_ms: u64) -> DirectoryResult<ArtifactCreationOperationV1> {
        self.artifact_creation_terminate_uncommitted(intent, current_now_ms).await
    }
    async fn artifact_creation_recovery_candidates(&self, current_now_ms: u64, limit: usize) -> DirectoryResult<Vec<ArtifactCreationIntentV1>> {
        self.artifact_creation_recovery_candidates(current_now_ms, limit).await
    }
    async fn append_document_genesis(&self, append: &DocumentGenesisAppendV1) -> DirectoryResult<DocumentGenesisCommitV1> {
        self.append_document_genesis(append).await
    }
    async fn issue_share_token_as(&self, scope: &DocumentScope, ttl_secs: i64, actor_user_id: Option<&str>, correlation_id: &str) -> DirectoryResult<IssuedShareToken> {
        self.issue_share_token_as(scope, ttl_secs, actor_user_id, correlation_id).await
    }
    async fn issue_share_token_as_with_admin_effect(&self, scope: &DocumentScope, ttl_secs: i64, actor_user_id: Option<&str>, correlation_id: &str, effect: &NewAdminOperationEffectReceiptV1) -> AdminEffectCommitV1<IssuedShareToken> {
        self.issue_share_token_as_with_admin_effect(scope, ttl_secs, actor_user_id, correlation_id, effect).await
    }
    async fn revoke_share_token_as(&self, scope: &DocumentScope, share_id: &str, reason: &str, actor_user_id: Option<&str>, correlation_id: &str) -> DirectoryResult<()> {
        self.revoke_share_token_as(scope, share_id, reason, actor_user_id, correlation_id).await
    }
    async fn revoke_share_token_as_with_admin_effect(&self, scope: &DocumentScope, share_id: &str, reason: &str, actor_user_id: Option<&str>, correlation_id: &str, effect: &NewAdminOperationEffectReceiptV1) -> AdminEffectCommitV1<()> {
        self.revoke_share_token_as_with_admin_effect(scope, share_id, reason, actor_user_id, correlation_id, effect).await
    }
    async fn authenticate_share(&self, scope: &DocumentScope, capability: &ShareCapability) -> DirectoryResult<bool> {
        self.authenticate_share(scope, capability).await
    }
    async fn authenticate_share_binding(&self, scope: &DocumentScope, capability: &ShareCapability) -> DirectoryResult<Option<ShareTokenRecord>> {
        self.authenticate_share_binding(scope, capability).await
    }
    async fn socket_share_binding(&self, share_id: &str, selector: &str, scope: &DocumentScope, now_ms: i64) -> DirectoryResult<SocketShareBindingStatus> {
        self.socket_share_binding(share_id, selector, scope, now_ms).await
    }
    async fn create_user(&self, email: &str, display_name: &str, password_hash: Option<&str>, sso_subject: Option<&str>, sso_provider: Option<&str>) -> DirectoryResult<UserRecord> {
        self.create_user(email, display_name, password_hash, sso_subject, sso_provider).await
    }
    async fn get_user(&self, user_id: &str) -> DirectoryResult<Option<UserRecord>> {
        self.get_user(user_id).await
    }
    async fn get_user_by_email(&self, email: &str) -> DirectoryResult<Option<UserRecord>> {
        self.get_user_by_email(email).await
    }
    async fn get_user_by_sso_subject(&self, provider: &str, subject: &str) -> DirectoryResult<Option<UserRecord>> {
        self.get_user_by_sso_subject(provider, subject).await
    }
    async fn list_users(&self, limit: i64, offset: i64) -> DirectoryResult<Vec<UserRecord>> {
        self.list_users(limit, offset).await
    }
    async fn admin_overview_counts(&self) -> DirectoryResult<AdminDirectoryOverviewCounts> {
        self.admin_overview_counts().await
    }
    async fn get_space(&self, space_id: &str) -> DirectoryResult<Option<SpaceRecord>> {
        self.get_space(space_id).await
    }
    async fn list_spaces_for_user(&self, user_id: &str) -> DirectoryResult<Vec<(SpaceRecord, SpaceRole)>> {
        self.list_spaces_for_user(user_id).await
    }
    async fn list_spaces(&self, limit: i64, offset: i64) -> DirectoryResult<Vec<SpaceRecord>> {
        self.list_spaces(limit, offset).await
    }
    async fn list_admin_space_summaries_page(&self, space_id: Option<&str>, offset: usize, limit: usize) -> DirectoryResult<Vec<AdminSpaceSummaryRecord>> {
        self.list_admin_space_summaries_page(space_id, offset, limit).await
    }
    async fn list_visible_space_summaries(&self, user_id: Option<&str>) -> DirectoryResult<Vec<(AdminSpaceSummaryRecord, Option<SpaceRole>)>> {
        self.list_visible_space_summaries(user_id).await
    }
    async fn list_admin_space_members_page(&self, space_id: &str, offset: usize, limit: usize) -> DirectoryResult<Vec<(UserRecord, SpaceRole)>> {
        self.list_admin_space_members_page(space_id, offset, limit).await
    }
    async fn list_members(&self, space_id: &str) -> DirectoryResult<Vec<(UserRecord, SpaceRole)>> {
        self.list_members(space_id).await
    }
    async fn get_role(&self, space_id: &str, user_id: &str) -> DirectoryResult<Option<SpaceRole>> {
        self.get_role(space_id, user_id).await
    }
    async fn list_space_administration_members_page(&self, space_id: &str, after_user_id: Option<&str>, limit: usize) -> DirectoryResult<Vec<SpaceAdministrationMemberRow>> {
        self.list_space_administration_members_page(space_id, after_user_id, limit).await
    }
    async fn get_document_descriptor(&self, scope: &DocumentScope) -> DirectoryResult<Option<DocumentDescriptor>> {
        self.get_document_descriptor(scope).await
    }
    async fn list_document_descriptors(&self, space_id: &str) -> DirectoryResult<Vec<DocumentDescriptor>> {
        self.list_document_descriptors(space_id).await
    }
    async fn list_document_descriptors_page(&self, space_id: Option<&str>, offset: usize, limit: usize) -> DirectoryResult<Vec<DocumentDescriptor>> {
        self.list_document_descriptors_page(space_id, offset, limit).await
    }
    async fn get_artifact_checkpoint(&self, scope: &DocumentScope, checkpoint_id: ArtifactHash) -> DirectoryResult<Option<PublishedArtifactCheckpoint>> {
        self.get_artifact_checkpoint(scope, checkpoint_id).await
    }
    async fn get_verified_artifact_checkpoint(&self, scope: &DocumentScope, checkpoint_id: ArtifactHash) -> DirectoryResult<Option<ArtifactCheckpoint>> {
        self.get_verified_artifact_checkpoint(scope, checkpoint_id).await
    }
    async fn get_active_artifact_checkpoint(&self, scope: &DocumentScope) -> DirectoryResult<Option<PublishedArtifactCheckpoint>> {
        self.get_active_artifact_checkpoint(scope).await
    }
    async fn get_artifact_retention(&self, scope: &DocumentScope) -> DirectoryResult<Option<ArtifactRetention>> {
        self.get_artifact_retention(scope).await
    }
    async fn artifact_checkpoint_count(&self, scope: &DocumentScope) -> DirectoryResult<u64> {
        self.artifact_checkpoint_count(scope).await
    }
    async fn list_artifact_checkpoint_lineage(&self, scope: &DocumentScope, limit: usize) -> DirectoryResult<Vec<PublishedArtifactCheckpoint>> {
        self.list_artifact_checkpoint_lineage(scope, limit).await
    }
    async fn issue_auth_session(&self, issue: &AuthSessionIssue) -> DirectoryResult<IssuedAuthSession> {
        self.issue_auth_session(issue).await
    }
    async fn authenticate_session(&self, capability: &SessionCapability) -> DirectoryResult<Option<AuthSessionRecord>> {
        self.authenticate_session(capability).await
    }
    async fn socket_session_binding(&self, session_id: &str, user_id: &str, authorization_generation: u64, space_id: Option<&str>, now_ms: i64) -> DirectoryResult<SocketSessionBindingStatus> {
        self.socket_session_binding(session_id, user_id, authorization_generation, space_id, now_ms).await
    }
    async fn revoke_auth_session(&self, id: &str, reason: &str, actor_user_id: Option<&str>, correlation_id: &str) -> DirectoryResult<Option<RevokedAuthSession>> {
        self.revoke_auth_session(id, reason, actor_user_id, correlation_id).await
    }
    async fn revoke_auth_sessions_for_user(&self, user_id: &str, reason: &str, actor_user_id: Option<&str>, correlation_id: &str) -> DirectoryResult<Vec<RevokedAuthSession>> {
        self.revoke_auth_sessions_for_user(user_id, reason, actor_user_id, correlation_id).await
    }
    async fn revoke_auth_sessions_for_user_with_admin_effect(&self, user_id: &str, reason: &str, actor_user_id: Option<&str>, correlation_id: &str, effect: &NewAdminOperationEffectReceiptV1) -> AdminEffectCommitV1<Vec<RevokedAuthSession>> {
        self.revoke_auth_sessions_for_user_with_admin_effect(user_id, reason, actor_user_id, correlation_id, effect).await
    }
    async fn revoke_auth_sessions_for_identity(&self, provider: &str, subject_digest: [u8; 32], reason: &str, actor_user_id: Option<&str>, correlation_id: &str) -> DirectoryResult<Vec<RevokedAuthSession>> {
        self.revoke_auth_sessions_for_identity(provider, subject_digest, reason, actor_user_id, correlation_id).await
    }
    async fn list_auth_audit(&self, limit: usize, offset: usize) -> DirectoryResult<Vec<AuthAuditRecord>> {
        self.list_auth_audit(limit, offset).await
    }
    async fn append_credential_audit(&self, fact: &CredentialAuditFactV1) -> DirectoryResult<AuthAuditRecord> {
        self.append_credential_audit(fact).await
    }
    async fn set_password_credential(&self, user_id: &str, encoded_credential: &str, actor_user_id: Option<&str>, correlation_id: &str) -> DirectoryResult<()> {
        self.set_password_credential(user_id, encoded_credential, actor_user_id, correlation_id).await
    }
    async fn claim_or_read_directory_command_receipt(&self, claim: &NewDirectoryCommandReceipt) -> DirectoryResult<DirectoryCommandClaimV1> {
        self.claim_or_read_directory_command_receipt(claim).await
    }
    async fn complete_directory_command_receipt(&self, completion: &DirectoryCommandReceiptCompletion) -> DirectoryResult<DirectoryCommandReceiptRecord> {
        self.complete_directory_command_receipt(completion).await
    }
    async fn release_directory_command_receipt(&self, actor_user_id: &str, request_id: &str, command_sha256: &str) -> DirectoryResult<()> {
        self.release_directory_command_receipt(actor_user_id, request_id, command_sha256).await
    }
    async fn claim_or_read_checkpoint_publication(&self, claim: &NewCheckpointPublicationClaimV1) -> DirectoryResult<CheckpointPublicationClaimV1> {
        self.claim_or_read_checkpoint_publication(claim).await
    }
    async fn release_checkpoint_publication(&self, actor_user_id: &str, correlation_id: &str, command_sha256: &str) -> DirectoryResult<()> {
        self.release_checkpoint_publication(actor_user_id, correlation_id, command_sha256).await
    }
    async fn append_admin_operation_audit(&self, fact: &NewAdminOperationAuditRecord) -> DirectoryResult<AdminOperationAuditRecord> {
        self.append_admin_operation_audit(fact).await
    }
    async fn admin_operation_audit_for_request(&self, request_id: &str) -> DirectoryResult<Vec<AdminOperationAuditRecord>> {
        self.admin_operation_audit_for_request(request_id).await
    }
    async fn admin_operation_audit_for_operation(&self, operation_id: &str) -> DirectoryResult<Vec<AdminOperationAuditRecord>> {
        self.admin_operation_audit_for_operation(operation_id).await
    }
    async fn admin_operation_effect_receipt(&self, operation_id: &str, intent_digest: &str) -> DirectoryResult<Option<AdminOperationEffectReceiptV1>> {
        self.admin_operation_effect_receipt(operation_id, intent_digest).await
    }
    async fn list_admin_operation_audit(&self, after_sequence: u64, limit: usize) -> DirectoryResult<Vec<AdminOperationAuditRecord>> {
        self.list_admin_operation_audit(after_sequence, limit).await
    }
    async fn issue_invite_as(&self, space_id: &str, role: SpaceRole, ttl_secs: i64, actor_user_id: Option<&str>, correlation_id: &str) -> DirectoryResult<IssuedInvite> {
        self.issue_invite_as(space_id, role, ttl_secs, actor_user_id, correlation_id).await
    }
    async fn issue_invite_as_with_admin_effect(&self, space_id: &str, role: SpaceRole, ttl_secs: i64, actor_user_id: Option<&str>, correlation_id: &str, effect: &NewAdminOperationEffectReceiptV1) -> AdminEffectCommitV1<IssuedInvite> {
        self.issue_invite_as_with_admin_effect(space_id, role, ttl_secs, actor_user_id, correlation_id, effect).await
    }
    async fn invite_redemption_scope_hint(&self, capability: &InviteCapability, actor: &DirectoryActor, user_id: &str) -> DirectoryResult<InviteRedemptionScopeHintV1> {
        self.invite_redemption_scope_hint(capability, actor, user_id).await
    }
    async fn redeem_invite_atomic(&self, capability: &InviteCapability, actor: &DirectoryActor, user_id: &str, hlc: Hlc) -> DirectoryResult<InviteRedemptionCommit> {
        self.redeem_invite_atomic(capability, actor, user_id, hlc).await
    }
    async fn revoke_invite_as(&self, space_id: &str, invite_id: &str, reason: &str, actor_user_id: Option<&str>, correlation_id: &str) -> DirectoryResult<()> {
        self.revoke_invite_as(space_id, invite_id, reason, actor_user_id, correlation_id).await
    }
    async fn revoke_invite_as_with_admin_effect(&self, space_id: &str, invite_id: &str, reason: &str, actor_user_id: Option<&str>, correlation_id: &str, effect: &NewAdminOperationEffectReceiptV1) -> AdminEffectCommitV1<()> {
        self.revoke_invite_as_with_admin_effect(space_id, invite_id, reason, actor_user_id, correlation_id, effect).await
    }
    async fn list_invites(&self, space_id: &str) -> DirectoryResult<Vec<InviteRecord>> {
        self.list_invites(space_id).await
    }
    async fn list_space_administration_invites_page(&self, space_id: &str, after: Option<(i64, &str)>, limit: usize) -> DirectoryResult<Vec<SpaceAdministrationInviteRow>> {
        self.list_space_administration_invites_page(space_id, after, limit).await
    }
    async fn record_sync_session_open(
        &self,
        auth_session_id: Option<&str>,
        authorization_generation: u64,
        actor_id: &str,
        space_id: &str,
        document_id: &str,
        surface: &str,
        user_id: Option<&str>,
        authenticated_email: Option<&str>,
        space_role: Option<SpaceRole>,
        client_label: &str,
    ) -> DirectoryResult<SyncSessionRecord> {
        self.record_sync_session_open(auth_session_id, authorization_generation, actor_id, space_id, document_id, surface, user_id, authenticated_email, space_role, client_label).await
    }
    async fn record_sync_session_close(&self, sync_session_id: &str) -> DirectoryResult<()> {
        self.record_sync_session_close(sync_session_id).await
    }
    async fn list_sync_sessions_for_document(&self, document_id: &str) -> DirectoryResult<Vec<SyncSessionRecord>> {
        self.list_sync_sessions_for_document(document_id).await
    }
    async fn list_active_sync_sessions_page(&self, space_id: Option<&str>, offset: usize, limit: usize) -> DirectoryResult<Vec<SyncSessionRecord>> {
        self.list_active_sync_sessions_page(space_id, offset, limit).await
    }
    async fn close_all_sync_sessions(&self) -> DirectoryResult<()> {
        self.close_all_sync_sessions().await
    }
    async fn reserve_artifact_cas(&self, plan: &ArtifactCasOwnershipPlanV1, expires_at_ms: u64, now_ms: u64) -> DirectoryResult<ArtifactCasReservation> {
        self.reserve_artifact_cas(plan, expires_at_ms, now_ms).await
    }
    async fn append_reserved_artifact_checkpoint(
        &self,
        event: Option<&NewDirectoryEvent>,
        checkpoint: &ArtifactCheckpoint,
        reservation: &ArtifactCasReservation,
        completion: Option<&CheckpointPublicationCompletionV1>,
        current_now_ms: u64,
    ) -> DirectoryResult<Vec<DirectoryEvent>> {
        self.append_reserved_artifact_checkpoint(event, checkpoint, reservation, completion, current_now_ms).await
    }
    async fn artifact_cas_ledger_generation(&self) -> DirectoryResult<u64> {
        self.artifact_cas_ledger_generation().await
    }
    async fn artifact_cas_coordinator_id(&self) -> DirectoryResult<[u8; 32]> {
        self.artifact_cas_coordinator_id().await
    }
    async fn artifact_cas_sweep_candidates(&self, after_generation: u64, through_generation: u64, limit: usize) -> DirectoryResult<ArtifactCasSweepCandidatePage> {
        self.artifact_cas_sweep_candidates(after_generation, through_generation, limit).await
    }
    async fn artifact_cas_delete_preview_protected(&self, key: &ArtifactCasObjectKey, observed_generation: u64, now_ms: u64) -> DirectoryResult<bool> {
        self.artifact_cas_delete_preview_protected(key, observed_generation, now_ms).await
    }
    async fn acquire_artifact_cas_delete_fence(&self, key: &ArtifactCasObjectKey, observed_generation: u64, lease_token: [u8; 32], now_ms: u64, expires_at_ms: u64) -> DirectoryResult<Option<ArtifactCasDeleteFence>> {
        self.acquire_artifact_cas_delete_fence(key, observed_generation, lease_token, now_ms, expires_at_ms).await
    }
    async fn validate_artifact_cas_delete_fence(&self, fence: &ArtifactCasDeleteFence, now_ms: u64) -> DirectoryResult<bool> {
        self.validate_artifact_cas_delete_fence(fence, now_ms).await
    }
    async fn renew_artifact_cas_delete_fence(&self, fence: &ArtifactCasDeleteFence, now_ms: u64, expires_at_ms: u64) -> DirectoryResult<()> {
        self.renew_artifact_cas_delete_fence(fence, now_ms, expires_at_ms).await
    }
    async fn release_artifact_cas_delete_fence(&self, fence: ArtifactCasDeleteFence) -> DirectoryResult<()> {
        self.release_artifact_cas_delete_fence(fence).await
    }
    async fn append_decided_events(&self, events: &[NewDirectoryEvent]) -> DirectoryResult<DirectoryAppendOutcomeV1> {
        self.append_decided_events(events).await
    }
    async fn append_decided_events_with_admin_effect(&self, events: &[NewDirectoryEvent], effect: &NewAdminOperationEffectReceiptV1) -> AdminEffectCommitV1<Vec<DirectoryEvent>> {
        self.append_decided_events_with_admin_effect(events, effect).await
    }
    async fn events_since(&self, since_seq: u64, limit: usize) -> DirectoryResult<Vec<DirectoryEvent>> {
        self.events_since(since_seq, limit).await
    }
    async fn head_seq(&self) -> DirectoryResult<u64> {
        self.head_seq().await
    }
    async fn rebuild_projections(&self) -> DirectoryResult<u64> {
        self.rebuild_projections().await
    }
    async fn rebuild_projections_controlled(&self, control: &dyn ProjectionRebuildControl) -> DirectoryResult<u64> {
        self.rebuild_projections_controlled(control).await
    }
}

#[cfg(any(test, feature = "testkit"))]
#[path = "🧪️tests/🧰️testkit/🦀️.rs"]
pub mod testkit;
