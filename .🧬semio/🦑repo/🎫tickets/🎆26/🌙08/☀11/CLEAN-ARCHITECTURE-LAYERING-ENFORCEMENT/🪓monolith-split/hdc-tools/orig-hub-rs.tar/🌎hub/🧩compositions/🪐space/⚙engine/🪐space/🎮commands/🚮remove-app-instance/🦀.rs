//! 🧩️ 🧩️ S Studio app command — `remove-app-instance`.

use semio_hub_space_foundation::config::{SpaceConfig, SpaceConfigMutation, ActiveNodeSetting, FocusedNodeSetting};
use semio_framework_os::workflow::RemoveNode;
use semio_framework_os::{WorkflowMutation, WorkflowSnapshot};
use semio_framework_plugin::{app::InteractionView, ArtifactView, ConfigView, Emit, Fault};

#[derive(Clone, Debug, PartialEq, value_derive::ToValue, value_derive::FromValue, semio_framework_dsl_record_derive::DslRecord, semio_framework_value::RetireOwned)]
#[dsl(keyword = "remove-app-instance")]
pub struct RemoveAppInstance {
    pub node_id: Option<String>,
}

pub async fn remove_with_selection(payload: &RemoveAppInstance, config: &SpaceConfig, selected: &[String]) -> Emit<WorkflowMutation, SpaceConfigMutation> {
    let resolved_node_id = match payload.node_id.clone() {
        Some(node_id) => Some(node_id),
        None => semio_hub_space_operations::primary_selected_node_id(selected, config).await,
    };
    match resolved_node_id {
        Some(node_id) => {
            let mut config_mutations = Vec::new();
            if config.active_node_id.as_deref() == Some(node_id.as_str()) {
                config_mutations.push(SpaceConfigMutation::SetActiveNode(ActiveNodeSetting { node_id: None }));
            }
            if config.focused_node_id.as_deref() == Some(node_id.as_str()) {
                config_mutations.push(SpaceConfigMutation::SetFocusedNode(FocusedNodeSetting { node_id: None }));
            }
            Emit { artifact_mutations: vec![WorkflowMutation::RemoveNode(RemoveNode { node_id })], config_mutations, ..Default::default() }
        }
        None => Emit::default(),
    }
}

/// 🕹️ `app_commands!`'s generated `dispatch(doc, cfg)` is framework-fixed at this exact 3-arg shape
/// (no `interaction` slot — ticket 26/08/14/FIRST-CLASS-HOVER-AND-SELECTION-MECHANISM) — reachable
/// only through that macro-generated path (`SpaceApp::handle` always routes this command through
/// `apply` below instead); `payload.node_id` (when set) is unaffected, and the fallback still honors
/// `config.active_node_id` — only the "fall back to the live selection" step degrades to empty.
pub fn handle(payload: &RemoveAppInstance, _doc: &ArtifactView<'_, WorkflowSnapshot>, cfg: &ConfigView<'_, SpaceConfig>) -> Result<Emit<WorkflowMutation, SpaceConfigMutation>, Fault> {
    Ok(semio_hub_space_operations::resolve_future(remove_with_selection(payload, cfg.snapshot, &[])))
}

pub async fn apply(payload: &RemoveAppInstance, _doc: &ArtifactView<'_, WorkflowSnapshot>, cfg: &ConfigView<'_, SpaceConfig>, interaction: &InteractionView<'_>) -> Result<Emit<WorkflowMutation, SpaceConfigMutation>, Fault> {
    Ok(remove_with_selection(payload, cfg.snapshot, &interaction.selection("graph").ids).await)
}
