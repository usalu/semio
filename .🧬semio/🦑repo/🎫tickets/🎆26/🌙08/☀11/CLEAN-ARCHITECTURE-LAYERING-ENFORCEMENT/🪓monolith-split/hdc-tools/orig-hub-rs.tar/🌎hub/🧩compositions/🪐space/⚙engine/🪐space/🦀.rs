//! 🎛️ S Studio app — `ArtifactApp` impl, command dispatch, manifest (constitutional: ui + general,
//! merged at app level).
//!
//! 🕳️ Deviation from the usual "general"/"ui" split: the Studio app has no document type of its own —
//! its `ArtifactApp::Snapshot`/`Mutation` are `semio_framework_os::{WorkflowSnapshot, WorkflowMutation}`,
//! owned entirely by `framework/product/os/core/rs` (outside this plugin). There is therefore no
//! `🗿️artifacts/🪐️space` node anywhere in this crate — this file carries what would otherwise be the
//! artifact facade's constants (manifest/panel identifiers shared by `engine` config defaults and this
//! file's manifest/render dispatch), plus every DocumentHelpers used by 2+ command modules (a helper
//! that takes `&SpaceConfig` stays app-level no matter how many consumers it has, per the per-app
//! recipe's DocumentHelpers placement rule — artifacts must never depend on apps, and there is no
//! artifact here regardless).
//!
//! WIRING + DISPATCH ONLY beyond that: every command's real body lives in its own
//! `🎮️commands/<group>/🦀️.rs` payload module (see `app_commands!` below).

#![allow(async_fn_in_trait)]
extern crate semio_framework_os_kernel as dsl;
extern crate semio_framework_os_kernel as protocol;
extern crate semio_framework_os_kernel as store;
extern crate semio_framework_schema as schema;
extern crate semio_framework_value_derive as value_derive;
use semio_s_space_core::*;

use semio_hub_space_commands_authoring::node_graph_edit;
use semio_hub_space_commands_authoring::node_graph_viewport;
use semio_hub_space_commands_media::presence_heartbeat;
use semio_hub_space_commands_authoring::{add_parameter, bind_parameter_field, patch_parameter, remove_parameter, unbind_parameter_field};
use semio_hub_space_commands_authoring::{close_focused_instance, open_instance};
use semio_hub_space_commands_media::{compiled_dag_engagement_input, compiled_dag_engagement_submit, workflow_engagement_input, workflow_engagement_submit};
use semio_hub_space_commands_media::{connect_media_ports, disconnect_media_edge};
use semio_hub_space_commands_authoring::{copy_app_instance, delete_selection, duplicate_app_instance, move_media_node, paste_app_instance, patch_app_instances, remove_app_instance, rename_app_instance, reorganize_workflow, spawn_app};
use semio_hub_space_commands_media::patch_media_nodes;
use semio_hub_space_commands_media::{export_media, import_media, import_media_payload};
use semio_hub_space_commands_media::{export_studio_dsl, export_studio_pack, import_space_pack, import_space_pack_payload, open_space, set_active_example};
use semio_hub_space_commands_media::{go_home, navigate_virtual_file_system_node, set_active_panel_tab, set_app_registrations};
use semio_hub_space_foundation::config::{SpaceConfig, SpaceConfigMutation, ClipboardSetting};
use semio_hub_space_foundation::presence::{SpacePresence, SpacePresenceMutation};
use semio_hub_space_foundation::terminology::SStudioLabels;
use crate::parse_demo_space_document;
use semio_framework::{DslValue, ToolExecutionContract, ToolFactoryKey, ToolJobFactoryError};
use semio_framework_os::workflow::ConnectPorts;
use semio_framework_os::{create_os_id, empty_workflow_snapshot, MediaContract, WorkflowEdge, WorkflowMutation, WorkflowSnapshot, S_WORKFLOW_SCHEMA};
use semio_framework_plugin::retained_command::{ArtifactRetainedCommandJob, ArtifactRetainedCommandPayload, BoundedArtifactCommandWork};
use semio_framework_plugin::{
    app::InteractionView, app_commands, create_default_layout, ActionArgDef, ActionArgOption, ActionDefinition, ActionDescriptor, ActionKind, App, AppOperationContext, ArtifactApp, ArtifactOwnedToolJobRequest, ArtifactToolFactoryRegistry,
    ArtifactView, CommandDefinition, ConfigView, DomainTopology, DraftView, Effect, Emit, Fault, FaultCode, FaultOrigin, GranularityDefinition, HierarchyProvider, HoverSpec, InteractionDefinition, InteractionRef, InteractionTarget,
    InteractionTopology, InteractiveJobClassification, MergeMode, NoDraft, NoDraftMutation, SelectionMethod, SelectionMode, SelectionSpec, TopologyNode, WindowLayout, CLEAR_SELECTION_ACTION_ID,
    INTERACTION_SELECT_ACTION_ID, SELECT_ALL_ACTION_ID,
};
use semio_framework_ui_locale::{Label, LocalizedLabel};
use std::collections::HashMap;
use semio_framework_2d::compute::EngineHandles;
use semio_hub_space_foundation::{S_PLAY_APP_ID, S_PLAY_CATALOGUE_BODY_KEY, S_PLAY_CONTROLLER_ID, S_PLAY_INSPECTOR_BODY_KEY, S_PLAY_INTERACTION_DOMAIN, S_PLAY_PARAMETERS_BODY_KEY, S_STUDIO_EXAMPLES};

//#region 🔖️DocumentHelpers
pub(crate) fn s_play_action(action: &str, args: Option<semio_framework_plugin::UiValue>) -> semio_framework_plugin::UiAssemblyResult<(semio_framework_plugin::ActionId, Option<semio_framework_plugin::UiValue>)> {
    semio_framework_plugin::ActionFactory::new(S_PLAY_CONTROLLER_ID).action(action, args)
}

/// 🧱️ Admits one fixed UI text action value without JSON staging.
pub fn ui_value_text(value: impl AsRef<str>) -> semio_framework_plugin::UiAssemblyResult<semio_framework_plugin::UiValue> {
    semio_framework_plugin::UiText::try_from_str(value.as_ref()).map(semio_framework_plugin::UiValue::Text).ok_or_else(|| semio_framework_plugin::PluginAssemblyError::new("ui.fixed-capacity", "fixed UI text admission failed"))
}

/// 🔘️ Admits one boolean UI action value.
pub fn ui_value_bool(value: bool) -> semio_framework_plugin::UiValue {
    semio_framework_plugin::UiValue::Bool(value)
}

/// 🔢️ Admits one numeric UI action value.
pub fn ui_value_number(value: impl Into<f64>) -> semio_framework_plugin::UiValue {
    semio_framework_plugin::UiValue::Number(value.into())
}

/// 📚️ Admits one fixed UI list action value without dynamic staging.
pub fn ui_value_list(values: impl IntoIterator<Item = semio_framework_plugin::UiValue>) -> semio_framework_plugin::UiAssemblyResult<semio_framework_plugin::UiValue> {
    let mut builder = semio_framework_plugin::UiListBuilder::try_new().ok_or_else(|| semio_framework_plugin::PluginAssemblyError::new("ui.fixed-capacity", "fixed UI list admission failed"))?;
    for value in values {
        builder.push(value).map_err(|_| semio_framework_plugin::PluginAssemblyError::new("ui.fixed-capacity", "fixed UI list item admission failed"))?;
    }
    Ok(semio_framework_plugin::UiValue::List(builder.finish()))
}

/// 🗺️ Admits one ordered fixed UI map action value without JSON staging.
pub fn ui_value_map(values: impl IntoIterator<Item = (&'static str, semio_framework_plugin::UiValue)>) -> semio_framework_plugin::UiAssemblyResult<semio_framework_plugin::UiValue> {
    let mut builder = semio_framework_plugin::UiMapBuilder::try_new().ok_or_else(|| semio_framework_plugin::PluginAssemblyError::new("ui.fixed-capacity", "fixed UI map admission failed"))?;
    for (key, value) in values {
        builder.push(key.to_owned(), value).map_err(|_| semio_framework_plugin::PluginAssemblyError::new("ui.fixed-capacity", "fixed UI map entry admission failed"))?;
    }
    Ok(semio_framework_plugin::UiValue::Map(builder.finish()))
}

/// 🕹️ ticket 26/08/14/FIRST-CLASS-HOVER-AND-SELECTION-MECHANISM: builds a framework `interactionSelect`
/// action targeting one `(granularity, id)` pair in the `graph` domain — replaces the deleted
/// `selectInstance`/`nodeGraphSelect`/`setMediaNodeSelection`/`setAppInstanceSelection` action builders
/// every measure/document row used to construct by hand.
pub(crate) async fn space_interaction_select(granularity: &str, id: &str) -> ActionDescriptor {
    let targets = semio_framework_pack_json::to_json_string(&vec![InteractionTarget { granularity: granularity.into(), id: id.into() }]);
    ActionDescriptor {
        controller_id: S_PLAY_CONTROLLER_ID.into(),
        action: INTERACTION_SELECT_ACTION_ID.into(),
        args: Some(DslValue::object(vec![
            ("domainId".to_string(), DslValue::String(S_PLAY_INTERACTION_DOMAIN.into())),
            ("targets".to_string(), DslValue::String(targets)),
            ("merge".to_string(), DslValue::String("replace".into())),
            ("method".to_string(), DslValue::String("pick".into())),
        ])),
    }
}

/// 🔧️ Small pure fold applying a batch of `SpaceConfigMutation`s onto a snapshot — used where a
/// command handler needs the POST-command config (not the pre-command `cfg.snapshot`) to build a
/// derived side value (the presence broadcast) in the very same call, without reaching back into a
/// store this pure function doesn't own.
#[cfg(any(test, feature = "testkit"))]
pub(crate) async fn apply_config_mutations(config: &SpaceConfig, operations: &[SpaceConfigMutation]) -> SpaceConfig {
    use protocol::Mutation;
    operations.iter().fold(config.clone(), |acc, operation| operation.diff(&acc).diff().clone())
}

/// 🫀️ Remote presence is host-owned. Until `ArtifactHost` threads the typed `PresenceView` into render,
/// Space shows no remote peers instead of retaining cross-instance state in a process-global registry.
pub(crate) async fn presence_peers_json(_app: &SpaceApp, _config: &SpaceConfig) -> String {
    "[]".into()
}

/// 🖱️ On-demand space workflow context menu from hit-test and selection snapshot.
async fn space_workflow_context_menu_items(
    registry: &semio_framework_plugin::AppActionRegistry,
    labels: &SStudioLabels,
    axes: &semio_framework_plugin::ViewModel,
    surface: Option<&semio_framework_plugin::ContextMenuSurfaceTarget>,
    selected_node_ids: &[String],
) -> Vec<semio_framework_plugin::ContextMenuItemSpec> {
    use semio_framework_plugin::{selection_count_phrase, selection_domains_from_surface, ContextMenuItemSpec, Menu};

    let hits: &[semio_framework_plugin::ContextMenuHit] = surface.map_or(&[], |target| target.hits.as_slice());
    let (nodes, _) = selection_domains_from_surface(surface, selected_node_ids, &[]);
    let hit_node = hits.iter().find(|hit| hit.domain == "node").map(|hit| hit.id.as_str());
    let mut menu = Menu::of(registry, axes);
    if hits.is_empty() {
        // 🗂️ Empty-canvas menu: paste/select-all stay top-level (the two most frequent verbs here),
        // reorganize is a rarer layout action so it moves into its own taxonomy group.
        menu = menu
            .item(ContextMenuItemSpec { id: "paste-instance".into(), label: Some(labels.context_paste.into()), icon: Some("clipboard".into()), action: Some("pasteAppInstance".into()), ..Default::default() })
            
            .item(ContextMenuItemSpec { id: "select-all".into(), label: Some(labels.context_select_all.into()), icon: Some("maximize-2".into()), action: Some(SELECT_ALL_ACTION_ID.into()), ..Default::default() })
            
            .group("transform", |m| m.item(ContextMenuItemSpec { id: "reorganize".into(), label: Some(labels.context_reorganize.into()), icon: Some("layout-grid".into()), action: Some("reorganizeWorkflow".into()), ..Default::default() }))
            ;
    }
    if hit_node.is_some() || !nodes.is_empty() {
        // 🗂️ Node menu: open/duplicate stay top-level (the two most frequent verbs); copy moves into
        // "transfer" (clipboard), rename into "settings" (identity/label editing), remove stays a
        // trailing destructive leaf — `organize_context_menu` (run automatically at the
        // `VcsArtifactApp::context_menu` funnel) inserts the pre-destructive separator itself.
        menu = menu
            .item(ContextMenuItemSpec { id: "open-instance".into(), label: Some(labels.context_open_instance.into()), icon: Some("external-link".into()), action: Some("openInstance".into()), ..Default::default() })
            
            .item(ContextMenuItemSpec { id: "duplicate-instance".into(), label: Some(labels.context_duplicate.into()), icon: Some("copy".into()), action: Some("duplicateAppInstance".into()), ..Default::default() })
            
            .group("transfer", |m| m.item(ContextMenuItemSpec { id: "copy-instance".into(), label: Some(labels.context_copy.into()), icon: Some("clipboard-copy".into()), action: Some("copyAppInstance".into()), ..Default::default() }))
            
            .group("settings", |m| m.item(ContextMenuItemSpec { id: "rename-instance".into(), label: Some(labels.context_rename_label.into()), icon: Some("edit-3".into()), action: Some("renameAppInstance".into()), ..Default::default() }))
            ;
        if !nodes.is_empty() {
            menu = menu
                .group("selection", |m| {
                    m.item(ContextMenuItemSpec { id: "clear-selection".into(), label: Some(labels.context_clear_selection.into()), icon: Some("square-dashed".into()), action: Some(CLEAR_SELECTION_ACTION_ID.into()), ..Default::default() })
                })
                ;
        }
        let phrase = selection_count_phrase(axes.locale, &[(nodes.len().max(if hit_node.is_some() && nodes.is_empty() { 1 } else { 0 }), semio_framework_plugin::SelectionKind::Node)]);
        let remove_label = phrase.map_or_else(|| labels.context_remove.as_str().to_string(), |phrase| format!("{} ({phrase})", labels.context_remove.as_str()));
        // 🎯️ Destructive tail always comes last — kept unconditionally after the "selection" group so
        // remove-instance is the final row regardless of whether clear-selection was appended above.
        let args = hit_node.map(|node_id| DslValue::object([("nodeId".to_string(), DslValue::String(node_id.into()))]));
        menu = menu.item(ContextMenuItemSpec { id: "remove-instance".into(), label: Some(remove_label), icon: Some("trash".into()), action: Some("removeAppInstance".into()), args, destructive: Some(true), ..Default::default() });
    }
    menu.build()
}
//#endregion 🔖️DocumentHelpers

//#region 🔖️SpaceCommand
app_commands! {
    /// 🎯️ `SpaceApp::Command` — the SOLE dispatch surface for the studio app's own behavior, one
    /// variant per action declared in `create_space_app`'s manifest.
    pub enum SpaceCommand for WorkflowSnapshot, WorkflowMutation, SpaceConfig, SpaceConfigMutation {
        // 🔧️ Document-mutating — dispatched as VCS operations with a true inverse.
        "patchParameter" as "patch-parameter" => semio_hub_space_commands_authoring::patch_parameter::PatchParameter,
        "addParameter" as "add-parameter" => semio_hub_space_commands_authoring::add_parameter::AddParameter,
        "removeParameter" as "remove-parameter" => semio_hub_space_commands_authoring::remove_parameter::RemoveParameter,
        "spawnApp" as "spawn-app" => semio_hub_space_commands_authoring::spawn_app::SpawnApp,
        "moveMediaNode" as "move-media-node" => semio_hub_space_commands_authoring::move_media_node::MoveMediaNode,
        "connectMediaPorts" as "connect-media-ports" => semio_hub_space_commands_media::connect_media_ports::ConnectMediaPorts,
        "disconnectMediaEdge" as "disconnect-media-edge" => semio_hub_space_commands_media::disconnect_media_edge::DisconnectMediaEdge,
        "removeAppInstance" as "remove-app-instance" => semio_hub_space_commands_authoring::remove_app_instance::RemoveAppInstance,
        "deleteSelection" as "delete-selection" => semio_hub_space_commands_authoring::delete_selection::DeleteSelection,
        "copyAppInstance" as "copy-app-instance" => semio_hub_space_commands_authoring::copy_app_instance::CopyAppInstance,
        "duplicateAppInstance" as "duplicate-app-instance" => semio_hub_space_commands_authoring::duplicate_app_instance::DuplicateAppInstance,
        "pasteAppInstance" as "paste-app-instance" => semio_hub_space_commands_authoring::paste_app_instance::PasteAppInstance,
        "renameAppInstance" as "rename-app-instance" => semio_hub_space_commands_authoring::rename_app_instance::RenameAppInstance,
        "patchMediaNodes" as "patch-media-nodes" => semio_hub_space_commands_media::patch_media_nodes::PatchMediaNodes,
        "patchAppInstances" as "patch-app-instances" => semio_hub_space_commands_authoring::patch_app_instances::PatchAppInstances,
        "bindParameterField" as "bind-parameter-field" => semio_hub_space_commands_authoring::bind_parameter_field::BindParameterField,
        "unbindParameterField" as "unbind-parameter-field" => semio_hub_space_commands_authoring::unbind_parameter_field::UnbindParameterField,
        "reorganizeWorkflow" as "reorganize-workflow" => semio_hub_space_commands_authoring::reorganize_workflow::ReorganizeWorkflow,
        "workflowEngagementSubmit" as "workflow-engagement-submit" => semio_hub_space_commands_media::workflow_engagement_submit::WorkflowEngagementSubmit,
        "compiledDagEngagementSubmit" as "compiled-dag-engagement-submit" => semio_hub_space_commands_media::compiled_dag_engagement_submit::CompiledDagEngagementSubmit,
        "nodeGraphEdit" as "node-graph-edit" => semio_hub_space_commands_authoring::node_graph_edit::NodeGraphEdit,

        // 👁️ Config-only — emit `config_mutations`, never document operations.
        "setActivePanelTab" as "active-panel-tab" => semio_hub_space_commands_media::set_active_panel_tab::SetActivePanelTab,
        "nodeGraphViewport" as "node-graph-viewport" => semio_hub_space_commands_authoring::node_graph_viewport::NodeGraphViewport,
        "presenceHeartbeat" as "presence-heartbeat" => semio_hub_space_commands_media::presence_heartbeat::PresenceHeartbeat,
        "workflowEngagementInput" as "workflow-engagement-input" => semio_hub_space_commands_media::workflow_engagement_input::WorkflowEngagementInput,
        "compiledDagEngagementInput" as "compiled-dag-engagement-input" => semio_hub_space_commands_media::compiled_dag_engagement_input::CompiledDagEngagementInput,

        // 🐚️ Shell effects — export/import round-trips through the host, no operations either way.
        "setActiveExample" as "set-active-example" => semio_hub_space_commands_media::set_active_example::SetActiveExample,
        "exportMedia" as "export-media" => semio_hub_space_commands_media::export_media::ExportMedia,
        "importMedia" as "import-media" => semio_hub_space_commands_media::import_media::ImportMedia,
        "importMediaPayload" as "import-media-payload" => semio_hub_space_commands_media::import_media_payload::ImportMediaPayload,
        "exportStudioPack" as "export-studio-pack" => semio_hub_space_commands_media::export_studio_pack::ExportStudioPack,
        "exportStudioDsl" as "export-studio-dsl" => semio_hub_space_commands_media::export_studio_dsl::ExportStudioDsl,
        "importSpacePack" as "import-space-pack" => semio_hub_space_commands_media::import_space_pack::ImportSpacePack,
        "importSpacePackPayload" as "import-space-pack-payload" => semio_hub_space_commands_media::import_space_pack_payload::ImportSpacePackPayload,
        "openSpace" as "open-space" => semio_hub_space_commands_media::open_space::OpenSpace,
        "openInstance" as "open-instance" => semio_hub_space_commands_authoring::open_instance::OpenInstance,
        "closeFocusedInstance" as "close-focused-instance" => semio_hub_space_commands_authoring::close_focused_instance::CloseFocusedInstance,
        "goHome" as "go-home" => semio_hub_space_commands_media::go_home::GoHome,
        "navigateVirtualFileSystemNode" as "navigate-vfs-node" => semio_hub_space_commands_media::navigate_virtual_file_system_node::NavigateVirtualFileSystemNode,
        "setAppRegistrations" as "set-app-registrations" => semio_hub_space_commands_media::set_app_registrations::SetAppRegistrations,
    }
}
//#endregion 🔖️SpaceCommand

//#region 🔖️SpaceApp
/// 🧪️ Unit app instance — config lives in `SpaceConfig`; remote presence stays unavailable until
/// `ArtifactHost` supplies its typed instance-owned presence view.
#[derive(Default, Clone, Copy)]
pub struct SpaceApp;

//#region 🧵️RetainedCommands
const SPACE_BOUNDED_TOOL_IDS: &[&str] = &[
    "setActivePanelTab",
    "nodeGraphViewport",
    "presenceHeartbeat",
    "workflowEngagementInput",
    "compiledDagEngagementInput",
    "closeFocusedInstance",
    "setActiveExample",
    "importSpacePack",
    "goHome",
    "navigateVirtualFileSystemNode",
    "spawnApp",
    "deleteSelection",
    "openSpace",
    "openInstance",
    "importSpacePackPayload",
    "setAppRegistrations",
    "patchParameter",
    "addParameter",
    "removeParameter",
    "moveMediaNode",
    "connectMediaPorts",
    "disconnectMediaEdge",
    "removeAppInstance",
    "copyAppInstance",
    "duplicateAppInstance",
    "pasteAppInstance",
    "renameAppInstance",
    "patchMediaNodes",
    "patchAppInstances",
    "bindParameterField",
    "unbindParameterField",
    "reorganizeWorkflow",
    "workflowEngagementSubmit",
    "compiledDagEngagementSubmit",
    "nodeGraphEdit",
    "exportMedia",
    "importMedia",
    "importMediaPayload",
    "exportStudioPack",
    "exportStudioDsl",
];
const SPACE_RETAINED_PAYLOAD_SCHEMA: &str = "os.workflow.space.tool-command.v1";
/// 📦️ `setAppRegistrations` carries the whole live catalog as one JSON argument and
/// `importSpacePackPayload` a whole base64 `.pack` data URL, so the studio's wire ceiling is sized for
/// a catalog, not for a click.
const SPACE_BOUNDED_RAW_BYTES: usize = 4 * 1024 * 1024;
const SPACE_BOUNDED_WORK_ITEMS: usize = 1;

/// 🧾️ The single contract this app's factory publishes AND its proof rows carry —
/// `validate_tool_job_rows` joins the two by exact equality, so both sides must read it from here.
const SPACE_BOUNDED_OUTPUT_BYTES: usize = 4 * 1024 * 1024;

fn space_bounded_contract() -> ToolExecutionContract {
    ToolExecutionContract::bounded_first_step(SPACE_BOUNDED_RAW_BYTES, 64, SPACE_BOUNDED_WORK_ITEMS as u64, SPACE_BOUNDED_OUTPUT_BYTES, 7_500)
}

fn space_bounded_extent(command: &SpaceCommand, _snapshot: &WorkflowSnapshot, _interaction: &protocol::InteractionState) -> Option<usize> {
    SPACE_BOUNDED_TOOL_IDS.contains(&command.command_id()).then_some(SPACE_BOUNDED_WORK_ITEMS)
}

#[expect(clippy::too_many_arguments, reason = "BoundedArtifactCommandWork requires the full retained reducer context callback")]
fn space_bounded_reduce(
    command: &SpaceCommand,
    snapshot: &WorkflowSnapshot,
    config: &SpaceConfig,
    history: &semio_framework_plugin::HistoryView,
    interaction: &protocol::InteractionState,
    _hover: &semio_framework_plugin::app::InteractionHoverState,
    context: Option<&semio_framework_plugin::app::ArtifactOwnedToolJobContext<SpaceApp>>,
    operation: &AppOperationContext,
) -> Result<Emit<WorkflowMutation, SpaceConfigMutation, NoDraftMutation>, Fault> {
    if !SPACE_BOUNDED_TOOL_IDS.contains(&command.command_id()) {
        return Err(Fault::new(FaultOrigin::App, FaultCode::new("s.space.retained.route"), "the bounded Space reducer rejects document, registry, payload, and graph routes"));
    }
    let doc = ArtifactView::with_operation(snapshot, history, operation.clone());
    // 🕹️ `openInstance` with no explicit node and `deleteSelection` read the live `graph` selection,
    // which the macro-generated 3-arg `dispatch` cannot see — the retained path reads it off the same
    // `InteractionState` `SpaceApp::handle` passes to their `apply`.
    let selected = || interaction.selection.get(S_PLAY_INTERACTION_DOMAIN).map_or_else(Vec::new, |selection| selection.ids.clone());
    if let SpaceCommand::OpenInstance(payload) = command {
        return Ok(semio_hub_space_operations::resolve_future(semio_hub_space_commands_authoring::open_instance::open_with_selection(payload, &doc, config, &selected())));
    }
    if let SpaceCommand::DeleteSelection(_) = command {
        return Ok(semio_hub_space_operations::resolve_future(semio_hub_space_commands_authoring::delete_selection::delete_selected(config, &selected())));
    }
    match command {
        SpaceCommand::NodeGraphEdit(payload) => return semio_hub_space_operations::resolve_future(semio_hub_space_commands_authoring::node_graph_edit::edit(payload, &doc)),
        SpaceCommand::ReorganizeWorkflow(_) => return Ok(semio_hub_space_operations::resolve_future(semio_hub_space_commands_authoring::reorganize_workflow::reorganize_selected(&doc, &selected()))),
        SpaceCommand::CopyAppInstance(_) => return Ok(Emit::config(vec![SpaceConfigMutation::SetClipboard(ClipboardSetting { node_ids: selected() })])),
        SpaceCommand::DuplicateAppInstance(_) => return Ok(semio_hub_space_operations::resolve_future(semio_hub_space_commands_authoring::duplicate_app_instance::duplicate_nodes(selected(), snapshot))),
        SpaceCommand::RemoveAppInstance(payload) => return Ok(semio_hub_space_operations::resolve_future(semio_hub_space_commands_authoring::remove_app_instance::remove_with_selection(payload, config, &selected()))),
        SpaceCommand::RenameAppInstance(payload) => return Ok(semio_hub_space_operations::resolve_future(semio_hub_space_commands_authoring::rename_app_instance::rename_with_selection(payload, &doc, config, &selected()))),
        _ => {}
    }
    if let SpaceCommand::PresenceHeartbeat(payload) = command {
        let identity = context
            .and_then(|context| context.view_state.as_ref())
            .and_then(crate::home_session_identity)
            .ok_or_else(|| Fault::from("s.space.session-identity-required"))?;
        return semio_hub_space_commands_media::presence_heartbeat::handle_with_identity(payload, identity, &doc, &ConfigView { snapshot: config, window: None });
    }
    command.dispatch(&doc, &ConfigView { snapshot: config, window: None })
}

pub struct SpaceCommandJobFactory {
    keys: Vec<ToolFactoryKey>,
}

impl SpaceCommandJobFactory {
    pub fn new(controller_id: &str) -> Self {
        Self { keys: SPACE_BOUNDED_TOOL_IDS.iter().map(|tool_id| ToolFactoryKey::new(controller_id, *tool_id)).collect() }
    }
}

impl semio_framework::ToolJobFactory for SpaceCommandJobFactory {
    type Payload = ArtifactRetainedCommandPayload<SpaceApp>;
    type Job = ArtifactRetainedCommandJob<SpaceApp>;

    fn keys(&self) -> &[ToolFactoryKey] {
        &self.keys
    }

    fn payload_schema_id(&self) -> &str {
        SPACE_RETAINED_PAYLOAD_SCHEMA
    }

    fn classification(&self) -> InteractiveJobClassification {
        InteractiveJobClassification::Migrated
    }

    fn execution_contract(&self) -> ToolExecutionContract {
        space_bounded_contract()
    }

    fn create_job(&mut self, _operation: semio_framework_job::Operation, payload: Self::Payload) -> Result<Self::Job, ToolJobFactoryError> {
        Ok(ArtifactRetainedCommandJob::new(payload))
    }

    fn create_job_from_wire_pages_with_payload(
        &mut self,
        _operation: semio_framework_job::Operation,
        payload: Self::Payload,
        input: semio_framework::action_bus::RetainedToolWireInput,
        checkpoint: Option<semio_framework::action_bus::RetainedToolWireInput>,
    ) -> Result<Self::Job, (ToolJobFactoryError, semio_framework::action_bus::RetainedToolWireInput, Option<semio_framework::action_bus::RetainedToolWireInput>)> {
        if input.declared_bytes() > SPACE_BOUNDED_RAW_BYTES || checkpoint.is_some() {
            return Err((ToolJobFactoryError::new("bounded Space command rejects oversized wire or checkpoint owner"), input, checkpoint));
        }
        Ok(ArtifactRetainedCommandJob::from_wire(payload, input))
    }
}

impl semio_framework_plugin::ArtifactOwnedToolJobFactory for SpaceCommandJobFactory {
    type Owner = SpaceApp;
    const TOOL_IDS: &'static [&'static str] = SPACE_BOUNDED_TOOL_IDS;
    const DOCUMENT_SCHEMA: &'static str = S_WORKFLOW_SCHEMA;
    const PUBLICATION_CONTRACTS: &'static [semio_framework_plugin::ArtifactToolPublicationContract] = &[
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "setActivePanelTab", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "nodeGraphViewport", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "presenceHeartbeat", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "workflowEngagementInput", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "compiledDagEngagementInput", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "closeFocusedInstance", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "setActiveExample", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "importSpacePack", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "goHome", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "navigateVirtualFileSystemNode", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "spawnApp", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact, semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "deleteSelection", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact, semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "openSpace", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "openInstance", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "importSpacePackPayload", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "setAppRegistrations", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "patchParameter", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "addParameter", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "removeParameter", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "moveMediaNode", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "connectMediaPorts", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "disconnectMediaEdge", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "removeAppInstance", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact, semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "copyAppInstance", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "duplicateAppInstance", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact, semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "pasteAppInstance", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact, semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "renameAppInstance", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "patchMediaNodes", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "patchAppInstances", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "bindParameterField", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "unbindParameterField", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "reorganizeWorkflow", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "workflowEngagementSubmit", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact, semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "compiledDagEngagementSubmit", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "nodeGraphEdit", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Artifact, semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "exportMedia", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "importMedia", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "importMediaPayload", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::Config] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "exportStudioPack", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
        semio_framework_plugin::ArtifactToolPublicationContract { tool_id: "exportStudioDsl", lanes: &[semio_framework_plugin::ArtifactToolPublicationLane::HostOnly] },
    ];
}
//#endregion 🧵️RetainedCommands

//#region 📬️ConfigStorePreparation
/// 📏️ Sized for a real session, not for a single toggle: `openSpace` publishes a space id, a focus
/// reset, a clipboard reset and an active node in one turn, and a studio's clipboard/collapsed sets
/// are node-id lists.
const SPACE_CONFIG_RETAINED_BYTES: usize = 65_536;
//#endregion 📬️ConfigStorePreparation

impl ArtifactApp for SpaceApp {
    const DIALECT: semio_framework_plugin::Dialect = semio_framework_plugin::Dialect { artifact_kind: "s.space.studio", standard: semio_framework_plugin::StandardId("1"), subset: semio_framework_plugin::SubsetId::ANY };
    type Snapshot = WorkflowSnapshot;
    type Mutation = WorkflowMutation;
    type Config = SpaceConfig;
    type ConfigMutation = SpaceConfigMutation;
    type Draft = NoDraft;
    type DraftMutation = NoDraftMutation;
    type Presence = SpacePresence;
    type PresenceMutation = SpacePresenceMutation;
    type Transient = semio_framework_plugin::NoTransient;
    type TransientMutation = semio_framework_plugin::NoTransientMutation;
    type Command = SpaceCommand;

    const APP_ID: &'static str = S_PLAY_APP_ID;
    const DOCUMENT_SCHEMA: &'static str = S_WORKFLOW_SCHEMA;

    semio_framework_plugin::bounded_first_step_tool_proofs! {
        owner: SpaceApp,
        owner_file: "✏️s/🔌️plugins/🪐️space/⚙️engine/🪐️space/🦀️.rs",
        controller: "s.space.studio@1/*#editor",
        artifact_schema: "os.workflow",
        factory: "SpaceCommandJobFactory",
        factory_type: SpaceCommandJobFactory,
        contract: space_bounded_contract(),
        tools: [
            "setActivePanelTab",
            "nodeGraphViewport",
            "presenceHeartbeat",
            "workflowEngagementInput",
            "compiledDagEngagementInput",
            "closeFocusedInstance",
            "setActiveExample",
            "importSpacePack",
            "goHome",
            "navigateVirtualFileSystemNode",
            "spawnApp",
            "deleteSelection",
            "openSpace",
            "openInstance",
            "importSpacePackPayload",
            "setAppRegistrations",
            "patchParameter",
            "addParameter",
            "removeParameter",
            "moveMediaNode",
            "connectMediaPorts",
            "disconnectMediaEdge",
            "removeAppInstance",
            "copyAppInstance",
            "duplicateAppInstance",
            "pasteAppInstance",
            "renameAppInstance",
            "patchMediaNodes",
            "patchAppInstances",
            "bindParameterField",
            "unbindParameterField",
            "reorganizeWorkflow",
            "workflowEngagementSubmit",
            "compiledDagEngagementSubmit",
            "nodeGraphEdit",
            "exportMedia",
            "importMedia",
            "importMediaPayload",
            "exportStudioPack",
            "exportStudioDsl",
        ]
    }

    fn build_artifact_store_one_item_preparation_factory() -> Option<std::sync::Arc<dyn store::os_store::one_item_publication::ArtifactStoreOneItemPreparationFactory<Self::Snapshot, Self::Mutation>>> {
        crate::space_retained_store_preparation::<Self::Snapshot, Self::Mutation>("space-studio-artifact-retained", SPACE_BOUNDED_OUTPUT_BYTES)
    }

    fn register_tool_job_factories(registry: &mut ArtifactToolFactoryRegistry<'_, Self>) -> Result<(), Fault> {
        let controller = registry.controller_id().to_string();
        registry.register(SpaceCommandJobFactory::new(&controller))
    }

    fn build_config_store_one_item_preparation_factory() -> Option<std::sync::Arc<dyn store::os_store::one_item_publication::ArtifactStoreOneItemPreparationFactory<Self::Config, Self::ConfigMutation>>> {
        crate::space_retained_store_preparation::<Self::Config, Self::ConfigMutation>("space-studio-config-retained", SPACE_CONFIG_RETAINED_BYTES)
    }

    fn build_config_store_disposer() -> Option<Box<dyn semio_framework_plugin::ArtifactOwnedDisposer<store::ConfigStore<Self::Config, Self::ConfigMutation>>>> {
        Some(semio_framework_plugin::bounded_config_store_disposer::<Self::Config, Self::ConfigMutation>())
    }

    async fn build_tool_job(request: ArtifactOwnedToolJobRequest<Self>) -> Result<Option<semio_framework::ToolOperationSpec>, Fault> {
        if !SPACE_BOUNDED_TOOL_IDS.contains(&request.tool_id.as_str()) {
            return Ok(None);
        }
        if request.command.command_id() != request.tool_id {
            return Err(Fault::new(FaultOrigin::App, FaultCode::new("s.space.retained.tool-mismatch"), "Space command does not match its exact registered tool"));
        }
        if space_bounded_extent(&request.command, &request.snapshot, &request.interaction_state).is_none() {
            return Err(Fault::new(FaultOrigin::App, FaultCode::new("s.space.retained.extent"), "Space bounded route exceeded its declared work extent"));
        }
        let tool_id = request.command.command_id();
        let work = Box::new(BoundedArtifactCommandWork::new(tool_id, space_bounded_reduce, space_bounded_extent));
        let operation_context = AppOperationContext {
            app_instance_id: request.app_instance_id,
            parent_document_id: request.parent_document_id,
            operation_id: request.operation.operation.0,
            generation: request.operation.generation.0,
            canonical_base_revision: request.canonical_base_revision,
            retained: request.retained,
            authoring_seed: request.authoring_seed.clone(),
        };
        let payload = ArtifactRetainedCommandPayload::new(
            semio_framework_plugin::retained_command::ArtifactRetainedCommandInputs { command: *request.command, snapshot: request.snapshot, config: request.config, history: request.history, interaction_state: request.interaction_state, interaction_hover: request.interaction_hover, context: Some(request.context), operation: operation_context, completion: request.completion },
            SpaceCommand::command_id,
            SPACE_BOUNDED_RAW_BYTES,
            SPACE_BOUNDED_WORK_ITEMS,
            work,
        );
        Ok(Some(semio_framework::ToolOperationSpec::new(request.controller_id, request.tool_id, request.payload_schema_id, payload, request.operation)))
    }

    async fn initial_snapshot() -> WorkflowSnapshot {
        empty_workflow_snapshot().await
    }

    async fn command_id(command: &SpaceCommand) -> &'static str {
        command.command_id()
    }

    /// 🪪️ `s.space.space`'s config+presence schema descriptor (ticket
    /// 26/08/12/ARTIFACTS-ONLY-PLUGIN-ARCHITECTURE W1c) — `register_document_app` registers it the
    /// moment this type is bound to the plugin, completing the app-schema declaration for `🪐️space`.
    async fn app_schema() -> Option<::semio_framework_schema_registry::AppSchemaDescriptor> {
        Some(semio_hub_space_foundation::config::schema::app_schema_descriptor().await)
    }

    /// 🎯️ Bridges shell `{action,args}` JSON onto typed `SpaceCommand` until every call site speaks OpBinary.
    async fn command_from_action(action: &str, args: &mut Option<DslValue>, original_fault: &mut Option<Fault>) -> Result<SpaceCommand, Fault> {
        if let Some(fault)=original_fault.take(){return Err(fault)}
        let args=args.as_ref();
        let str_field = |key: &str| args.and_then(|value| value.get(key)).and_then(DslValue::as_str).map(str::to_string);
        let f64_field = |key: &str| args.and_then(|value| value.get(key)).and_then(DslValue::as_f64);
        let string_vec = |key: &str| args.and_then(|value| value.get(key)).and_then(DslValue::as_array).map(|items| items.iter().filter_map(DslValue::as_str).map(str::to_string).collect::<Vec<_>>()).unwrap_or_default();
        let json_field = |key: &str| args.and_then(|value| value.get(key)).map(|raw| raw.as_str().map_or_else(|| semio_framework_pack_json::to_string(&semio_framework_pack_json::from_dsl_value(raw)), str::to_string));
        let node_id = || str_field("nodeId").or_else(|| str_field("node_id")).or_else(|| str_field("instanceId")).or_else(|| str_field("instance_id"));
        match action {
            "patchParameter" => Ok(SpaceCommand::PatchParameter(semio_hub_space_commands_authoring::patch_parameter::PatchParameter {
                parameter_id: str_field("parameterId").or_else(|| str_field("parameter_id")).unwrap_or_default(),
                field: str_field("field").unwrap_or_default(),
                value: json_field("value").unwrap_or_else(|| "null".into()),
            })),
            "addParameter" => Ok(SpaceCommand::AddParameter(semio_hub_space_commands_authoring::add_parameter::AddParameter { name: str_field("name").unwrap_or_else(|| "Parameter".into()), kind: str_field("kind").or_else(|| str_field("type")).unwrap_or_else(|| "numeric".into()) })),
            "removeParameter" => Ok(SpaceCommand::RemoveParameter(semio_hub_space_commands_authoring::remove_parameter::RemoveParameter { parameter_id: str_field("parameterId").or_else(|| str_field("parameter_id")).unwrap_or_default() })),
            "spawnApp" => Ok(SpaceCommand::SpawnApp(semio_hub_space_commands_authoring::spawn_app::SpawnApp {
                plugin_id: str_field("pluginId").or_else(|| str_field("plugin_id")).unwrap_or_default(),
                app_id: str_field("appId").or_else(|| str_field("app_id")).unwrap_or_default(),
                x: f64_field("x").unwrap_or(0.0),
                y: f64_field("y").unwrap_or(0.0),
            })),
            "moveMediaNode" => Ok(SpaceCommand::MoveMediaNode(semio_hub_space_commands_authoring::move_media_node::MoveMediaNode { node_id: node_id().unwrap_or_default(), x: f64_field("x").unwrap_or(0.0), y: f64_field("y").unwrap_or(0.0) })),
            "connectMediaPorts" => Ok(SpaceCommand::ConnectMediaPorts(semio_hub_space_commands_media::connect_media_ports::ConnectMediaPorts {
                source_node_id: str_field("sourceNodeId").or_else(|| str_field("source_node_id")).unwrap_or_default(),
                source_port_id: str_field("sourcePortId").or_else(|| str_field("source_port_id")).unwrap_or_default(),
                target_node_id: str_field("targetNodeId").or_else(|| str_field("target_node_id")).unwrap_or_default(),
                target_port_id: str_field("targetPortId").or_else(|| str_field("target_port_id")).unwrap_or_default(),
            })),
            "disconnectMediaEdge" => Ok(SpaceCommand::DisconnectMediaEdge(semio_hub_space_commands_media::disconnect_media_edge::DisconnectMediaEdge { edge_id: str_field("edgeId").or_else(|| str_field("edge_id")).unwrap_or_default() })),
            "removeAppInstance" => Ok(SpaceCommand::RemoveAppInstance(semio_hub_space_commands_authoring::remove_app_instance::RemoveAppInstance { node_id: node_id() })),
            "deleteSelection" => Ok(SpaceCommand::DeleteSelection(semio_hub_space_commands_authoring::delete_selection::DeleteSelection {})),
            "copyAppInstance" => Ok(SpaceCommand::CopyAppInstance(semio_hub_space_commands_authoring::copy_app_instance::CopyAppInstance {})),
            "duplicateAppInstance" => Ok(SpaceCommand::DuplicateAppInstance(semio_hub_space_commands_authoring::duplicate_app_instance::DuplicateAppInstance {})),
            "pasteAppInstance" => Ok(SpaceCommand::PasteAppInstance(semio_hub_space_commands_authoring::paste_app_instance::PasteAppInstance {})),
            "renameAppInstance" => Ok(SpaceCommand::RenameAppInstance(semio_hub_space_commands_authoring::rename_app_instance::RenameAppInstance { label: str_field("label").or_else(|| str_field("name")) })),
            "patchMediaNodes" => {
                let ids = string_vec("nodeIds");
                Ok(SpaceCommand::PatchMediaNodes(semio_hub_space_commands_media::patch_media_nodes::PatchMediaNodes {
                    node_ids: if ids.is_empty() { node_id().map(|id| vec![id]).unwrap_or_default() } else { ids },
                    field: str_field("field").unwrap_or_default(),
                    axis: str_field("axis"),
                    value: json_field("value").unwrap_or_else(|| "null".into()),
                }))
            }
            "patchAppInstances" => {
                let ids = string_vec("nodeIds");
                Ok(SpaceCommand::PatchAppInstances(semio_hub_space_commands_authoring::patch_app_instances::PatchAppInstances {
                    node_ids: if ids.is_empty() { node_id().map(|id| vec![id]).unwrap_or_default() } else { ids },
                    field: str_field("field").unwrap_or_default(),
                    value: json_field("value").unwrap_or_else(|| "null".into()),
                }))
            }
            "bindParameterField" => Ok(SpaceCommand::BindParameterField(semio_hub_space_commands_authoring::bind_parameter_field::BindParameterField {
                node_id: node_id().unwrap_or_default(),
                field_path: str_field("fieldPath").or_else(|| str_field("field_path")).unwrap_or_default(),
                parameter_id: str_field("parameterId").or_else(|| str_field("parameter_id")).unwrap_or_default(),
            })),
            "unbindParameterField" => {
                Ok(SpaceCommand::UnbindParameterField(semio_hub_space_commands_authoring::unbind_parameter_field::UnbindParameterField { node_id: node_id().unwrap_or_default(), field_path: str_field("fieldPath").or_else(|| str_field("field_path")).unwrap_or_default() }))
            }
            "reorganizeWorkflow" => Ok(SpaceCommand::ReorganizeWorkflow(semio_hub_space_commands_authoring::reorganize_workflow::ReorganizeWorkflow {})),
            "workflowEngagementSubmit" => Ok(SpaceCommand::WorkflowEngagementSubmit(semio_hub_space_commands_media::workflow_engagement_submit::WorkflowEngagementSubmit { value: str_field("value") })),
            "compiledDagEngagementSubmit" => Ok(SpaceCommand::CompiledDagEngagementSubmit(semio_hub_space_commands_media::compiled_dag_engagement_submit::CompiledDagEngagementSubmit {})),
            "nodeGraphEdit" => Ok(SpaceCommand::NodeGraphEdit(semio_hub_space_commands_authoring::node_graph_edit::NodeGraphEdit { operations_json: json_field("operations").or_else(|| json_field("operationsJson")).unwrap_or_else(|| "[]".into()) })),
            "setActivePanelTab" => Ok(SpaceCommand::SetActivePanelTab(semio_hub_space_commands_media::set_active_panel_tab::SetActivePanelTab { tab_id: str_field("tabId").or_else(|| str_field("tab_id")).unwrap_or_default() })),
            "nodeGraphViewport" => {
                let value = args.and_then(|value| value.get("viewport")).cloned().ok_or_else(|| Fault::from("nodeGraphViewport requires viewport"))?;
                let viewport = <semio_framework_os_kernel::Viewport2d as semio_framework_value::FromValue>::from_value(value).map_err(|error| Fault::from(format!("invalid nodeGraphViewport viewport: {error}")))?;
                Ok(SpaceCommand::NodeGraphViewport(semio_hub_space_commands_authoring::node_graph_viewport::NodeGraphViewport { viewport }))
            }
            "presenceHeartbeat" => Ok(SpaceCommand::PresenceHeartbeat(semio_hub_space_commands_media::presence_heartbeat::PresenceHeartbeat {})),
            "workflowEngagementInput" => Ok(SpaceCommand::WorkflowEngagementInput(semio_hub_space_commands_media::workflow_engagement_input::WorkflowEngagementInput { value: str_field("value").unwrap_or_default() })),
            "compiledDagEngagementInput" => Ok(SpaceCommand::CompiledDagEngagementInput(semio_hub_space_commands_media::compiled_dag_engagement_input::CompiledDagEngagementInput { value: str_field("value").unwrap_or_default() })),
            "setActiveExample" => Ok(SpaceCommand::SetActiveExample(semio_hub_space_commands_media::set_active_example::SetActiveExample { example_id: str_field("exampleId").or_else(|| str_field("example_id")).unwrap_or_default() })),
            "exportMedia" => Ok(SpaceCommand::ExportMedia(semio_hub_space_commands_media::export_media::ExportMedia { node_id: node_id().unwrap_or_default(), format: str_field("format").unwrap_or_default(), document_json: str_field("documentJson").unwrap_or_default() })),
            "importMedia" => Ok(SpaceCommand::ImportMedia(semio_hub_space_commands_media::import_media::ImportMedia { node_id: node_id().unwrap_or_default(), format: str_field("format").unwrap_or_default() })),
            "importMediaPayload" => Ok(SpaceCommand::ImportMediaPayload(semio_hub_space_commands_media::import_media_payload::ImportMediaPayload { payload: str_field("payload").or_else(|| str_field("dsl")).unwrap_or_default() })),
            "exportStudioPack" => Ok(SpaceCommand::ExportStudioPack(semio_hub_space_commands_media::export_studio_pack::ExportStudioPack {})),
            "exportStudioDsl" => Ok(SpaceCommand::ExportStudioDsl(semio_hub_space_commands_media::export_studio_dsl::ExportStudioDsl {})),
            "importSpacePack" => Ok(SpaceCommand::ImportSpacePack(semio_hub_space_commands_media::import_space_pack::ImportSpacePack {})),
            "importSpacePackPayload" => Ok(SpaceCommand::ImportSpacePackPayload(semio_hub_space_commands_media::import_space_pack_payload::ImportSpacePackPayload { payload: str_field("payload").or_else(|| str_field("dsl")).unwrap_or_default() })),
            "openSpace" => Ok(SpaceCommand::OpenSpace(semio_hub_space_commands_media::open_space::OpenSpace { space_id: str_field("spaceId").or_else(|| str_field("space_id")).unwrap_or_default() })),
            "openInstance" => Ok(SpaceCommand::OpenInstance(semio_hub_space_commands_authoring::open_instance::OpenInstance { node_id: node_id() })),
            "closeFocusedInstance" => Ok(SpaceCommand::CloseFocusedInstance(semio_hub_space_commands_authoring::close_focused_instance::CloseFocusedInstance {})),
            "goHome" => Ok(SpaceCommand::GoHome(semio_hub_space_commands_media::go_home::GoHome {})),
            "navigateVirtualFileSystemNode" => Ok(SpaceCommand::NavigateVirtualFileSystemNode(semio_hub_space_commands_media::navigate_virtual_file_system_node::NavigateVirtualFileSystemNode {
                space_id: str_field("spaceId").or_else(|| str_field("space_id")).or_else(|| str_field("nodeId")).or_else(|| str_field("node_id")).unwrap_or_default(),
            })),
            "setAppRegistrations" => Ok(SpaceCommand::SetAppRegistrations(semio_hub_space_commands_media::set_app_registrations::SetAppRegistrations { json: json_field("json").unwrap_or_else(|| "[]".into()) })),
            other => Err(Fault::new(FaultOrigin::App, FaultCode::new("s.space.unhandled-action"), format!("space: unhandled action id {other}"))),
        }
    }

    /// 🕹️ `deleteSelection`/`nodeGraphEdit`/`reorganizeWorkflow`/`copyAppInstance`/
    /// `duplicateAppInstance`/`removeAppInstance`/`renameAppInstance`/`openInstance` read the `graph`
    /// interaction domain directly (bypassing the `app_commands!`-generated `dispatch`, whose per-row
    /// `$module::handle(payload, doc, cfg)` signature is framework-fixed and has no `interaction`
    /// slot) — ticket 26/08/14/FIRST-CLASS-HOVER-AND-SELECTION-MECHANISM.
    async fn handle(
        command: &SpaceCommand,
        doc: &ArtifactView<'_, WorkflowSnapshot>,
        cfg: &ConfigView<'_, SpaceConfig>,
        interaction: &InteractionView<'_>,
        view_state: Option<&semio_framework_plugin::ViewModel>,
        _draft: &DraftView<'_, Self::Draft>,
        _engines: &EngineHandles,
    ) -> Result<Emit<WorkflowMutation, SpaceConfigMutation, Self::DraftMutation>, Fault> {
        match command {
            SpaceCommand::DeleteSelection(payload) => semio_hub_space_commands_authoring::delete_selection::apply(payload, doc, cfg, interaction).await,
            SpaceCommand::NodeGraphEdit(payload) => semio_hub_space_commands_authoring::node_graph_edit::edit(payload, doc).await,
            SpaceCommand::ReorganizeWorkflow(payload) => semio_hub_space_commands_authoring::reorganize_workflow::apply(payload, doc, cfg, interaction).await,
            SpaceCommand::CopyAppInstance(payload) => semio_hub_space_commands_authoring::copy_app_instance::apply(payload, doc, cfg, interaction).await,
            SpaceCommand::DuplicateAppInstance(payload) => semio_hub_space_commands_authoring::duplicate_app_instance::apply(payload, doc, cfg, interaction).await,
            SpaceCommand::RemoveAppInstance(payload) => semio_hub_space_commands_authoring::remove_app_instance::apply(payload, doc, cfg, interaction).await,
            SpaceCommand::RenameAppInstance(payload) => semio_hub_space_commands_authoring::rename_app_instance::apply(payload, doc, cfg, interaction).await,
            SpaceCommand::OpenInstance(payload) => semio_hub_space_commands_authoring::open_instance::apply(payload, doc, cfg, interaction).await,
            SpaceCommand::PresenceHeartbeat(payload) => {
                let identity = view_state
                    .and_then(crate::home_session_identity)
                    .ok_or_else(|| Fault::from("s.space.session-identity-required"))?;
                semio_hub_space_commands_media::presence_heartbeat::handle_with_identity(payload, identity, doc, cfg)
            }
            _ => command.dispatch(doc, cfg),
        }
    }

    /// 🕹️ `graph`'s `HierarchyProvider::Topology` — every workflow node is registered at both the
    /// "instance" and "media-node" granularities (a node IS the app instance now, see the kernel
    /// `🔁️workflow` crate's `🔖️InstanceIdentity` doc) so `selectAll`/range-selection behave correctly
    /// under either granularity; no real parent/child structure exists in the node graph, so every
    /// node is a root.
    async fn interaction_topology(doc: &ArtifactView<'_, WorkflowSnapshot>, _cfg: &ConfigView<'_, SpaceConfig>) -> Result<InteractionTopology, semio_framework_value::ValueError> {
        let mut ordered = Vec::new();
        for node in &doc.snapshot.graph.nodes {
            ordered.push(TopologyNode { id: node.id.clone(), granularity: "instance".into(), parent: None });
            ordered.push(TopologyNode { id: node.id.clone(), granularity: "media-node".into(), parent: None });
        }
        let mut domains = std::collections::BTreeMap::new();
        domains.insert(S_PLAY_INTERACTION_DOMAIN.to_string(), DomainTopology { ordered });
        Ok(InteractionTopology { domains })
    }

    async fn render(body_key: &str, doc: &ArtifactView<'_, WorkflowSnapshot>, cfg: &ConfigView<'_, SpaceConfig>, view_state: &semio_framework_plugin::ViewModel) -> semio_framework_plugin::UiAssemblyResult<semio_framework_plugin::ComponentTree> {
        let projection = doc.snapshot;
        let config = cfg.snapshot;
        let labels = semio_framework_plugin::resolve_labels::<SStudioLabels>(view_state);
        match body_key {
            semio_hub_space_foundation::S_PLAY_BODY_WORKFLOW => {
                crate::modes::main::windows::workflow::render(&SpaceApp, projection, config).await.map(semio_framework_plugin::built_to_component_tree)
            }
            crate::modes::main::windows::media_vfs::S_PLAY_BODY_MEDIA_VFS => crate::modes::main::windows::media_vfs::render(projection, view_state).await.map(semio_framework_plugin::built_to_component_tree),
            crate::modes::main::windows::compiled_dag::S_PLAY_BODY_COMPILED_DAG => crate::modes::main::windows::compiled_dag::render(projection).await.map(semio_framework_plugin::built_to_component_tree),
            S_PLAY_CATALOGUE_BODY_KEY => crate::panels::catalogue::build_catalogue_tree(labels, view_state.locale, &semio_framework_plugin::TreeWindows::for_body(view_state, S_PLAY_CATALOGUE_BODY_KEY))
                .await
                .map(semio_framework_plugin::built_to_component_tree),
            // 🧬️ `parameters`/`inspection` are now ported to the contract `BuiltNode` DSL (SEMANTIC-
            // UI-CONTRACT-AND-RENDERER-FAMILY, 26/08/20) — both `render` fns are U1-sync (the contract
            // builder's own sync-only ruling), so no `.await` here, only the `map` bridge into `ComponentTree`.
            S_PLAY_PARAMETERS_BODY_KEY => crate::panels::parameters::render(projection, labels, &semio_framework_plugin::TreeWindows::for_body(view_state, S_PLAY_PARAMETERS_BODY_KEY)).map(semio_framework_plugin::built_to_component_tree),
            // 🕹️ `render` carries no `InteractionView` (ArtifactApp's breaking pass only added it to
            // `handle`/`copy_fragment`/`cut_operations` — see ticket 26/08/14's w3b-summary.md) — the
            // inspector degrades to its "no selection" default until a future wave threads interaction
            // into render. Flagged as a discovered framework gap, not worked around here.
            S_PLAY_INSPECTOR_BODY_KEY => crate::panels::inspection::render(projection, &[], labels, &semio_framework_plugin::TreeWindows::for_body(view_state, S_PLAY_INSPECTOR_BODY_KEY)).map(semio_framework_plugin::built_to_component_tree),
            _ => semio_framework_plugin::built_text_to_component_tree(Label::data(format!("Unknown body: {body_key}"))),
        }
    }

    async fn window_measures(doc: &ArtifactView<'_, WorkflowSnapshot>, cfg: &ConfigView<'_, SpaceConfig>, view_state: &semio_framework_plugin::ViewModel) -> HashMap<String, Vec<semio_framework_plugin::WindowMeasure>> {
        HashMap::from([(semio_hub_space_foundation::S_PLAY_WINDOW_WORKFLOW.into(), crate::modes::main::windows::workflow::window_measures(cfg.snapshot, &doc.snapshot.graph.nodes, view_state).await)])
    }

    /// 🕹️ `context_menu` carries no `InteractionView` (same gap as `render` — see ticket 26/08/14's
    /// w3b-summary.md), so the selection-dependent rows below always take the "nothing selected"
    /// branch rather than reading a stale/wrong selection.
    async fn context_menu(
        request: &semio_framework_plugin::ContextMenuRequest,
        _doc: &ArtifactView<'_, WorkflowSnapshot>,
        _cfg: &ConfigView<'_, SpaceConfig>,
        view_state: &semio_framework_plugin::ViewModel,
        registry: &semio_framework_plugin::AppActionRegistry,
    ) -> Vec<semio_framework_plugin::ContextMenuItemSpec> {
        let labels = semio_framework_plugin::resolve_labels::<SStudioLabels>(view_state);
        space_workflow_context_menu_items(registry, labels, view_state, request.surface.as_ref(), &[]).await
    }
}
//#endregion 🔖️SpaceApp

//#region 🔖️SpaceManifest
async fn space_play_layout() -> WindowLayout {
    create_default_layout(
        &[
            semio_hub_space_foundation::S_PLAY_WINDOW_WORKFLOW.into(),
            crate::modes::main::windows::media_vfs::S_PLAY_WINDOW_MEDIA_VFS.into(),
            crate::modes::main::windows::compiled_dag::S_PLAY_WINDOW_COMPILED_DAG.into(),
        ],
        "row",
        Some(&[40.0, 30.0, 30.0]),
        Some(&["Workflow".into(), "Media VFS".into(), "Compiled DAG".into()]),
    )
}

pub async fn create_space_app() -> App {
    use crate::modes::main::windows::{compiled_dag, media_vfs, workflow};
    let builder = App::builder(S_PLAY_APP_ID, LocalizedLabel::native("Space", "Space")).await.document(["semio", "s", "studio"])
        .command(CommandDefinition { in_palette: false, ..CommandDefinition::bounded_catalog("setAppRegistrations", LocalizedLabel::native("Set App Registrations", "App-Registrierungen festlegen"), "host", ActionKind::View).with_args([ActionArgDef::text("json", LocalizedLabel::native("App Registrations", "App-Registrierungen"))]) }).await
        .icon_id("s").await
        .mode_def(crate::modes::main::definition().await).await
        .default_mode_id("main").await
        .window_kind_def(workflow::definition().await).await
        .window_kind_def(media_vfs::definition().await).await
        .window_kind_def(compiled_dag::definition().await).await
        .panel_tab_def(crate::panels::catalogue::definition().await).await
        .panel_tab_def(crate::panels::parameters::definition().await).await
        .panel_tab_def(crate::panels::inspection::definition().await).await
        .default_layout(space_play_layout().await).await
        .mutation("patchParameter", LocalizedLabel::native("Patch Parameter", "Parameter aktualisieren")).await
        .mutation("addParameter", LocalizedLabel::native("Add Parameter", "Parameter hinzufügen")).await
        .mutation("removeParameter", LocalizedLabel::native("Remove Parameter", "Parameter entfernen")).await
        .action_destructive("removeParameter").await
        .mutation("spawnApp", LocalizedLabel::native("Spawn App", "App erzeugen")).await
        .mutation("moveMediaNode", LocalizedLabel::native("Move Media Node", "Medienknoten verschieben")).await
        .mutation("connectMediaPorts", LocalizedLabel::native("Connect Media Ports", "Medien-Ports verbinden")).await
        .mutation("disconnectMediaEdge", LocalizedLabel::native("Disconnect Media Edge", "Medienverbindung trennen")).await
        .action_with(ActionDefinition::bounded_catalog("removeAppInstance", LocalizedLabel::native("Remove App Instance", "App-Instanz entfernen"), ActionKind::Mutation).with_category("selection")).await
        .action_destructive("removeAppInstance").await
        .mutation("deleteSelection", LocalizedLabel::native("Delete Selection", "Auswahl löschen")).await
        .action_destructive("deleteSelection").await
        .action_with(ActionDefinition::bounded_catalog("copyAppInstance", LocalizedLabel::native("Copy App Instance", "App-Instanz kopieren"), ActionKind::Mutation).with_category("transfer")).await
        .action_with(ActionDefinition::bounded_catalog("duplicateAppInstance", LocalizedLabel::native("Duplicate App Instance", "App-Instanz duplizieren"), ActionKind::Mutation).with_category("create")).await
        .action_with(ActionDefinition::bounded_catalog("pasteAppInstance", LocalizedLabel::native("Paste App Instance", "App-Instanz einfügen"), ActionKind::Mutation).with_category("transfer")).await
        .action_with(ActionDefinition::bounded_catalog("renameAppInstance", LocalizedLabel::native("Rename App Instance", "App-Instanz umbenennen"), ActionKind::Mutation).with_category("settings")).await
        .mutation("patchMediaNodes", LocalizedLabel::native("Patch Media Nodes", "Medienknoten aktualisieren")).await
        .mutation("patchAppInstances", LocalizedLabel::native("Patch App Instances", "App-Instanzen aktualisieren")).await
        .mutation("bindParameterField", LocalizedLabel::native("Bind Parameter Field", "Parameterfeld verknüpfen")).await
        .mutation("unbindParameterField", LocalizedLabel::native("Unbind Parameter Field", "Parameterfeld lösen")).await
        .action_with(ActionDefinition::bounded_catalog("reorganizeWorkflow", LocalizedLabel::native("Reorganize Workflow", "Workflow neu anordnen"), ActionKind::Mutation).with_category("transform")).await
        .mutation("workflowEngagementSubmit", LocalizedLabel::native("Workflow Engagement Submit", "Workflow-Eingabe bestätigen")).await
        .action_audience("workflowEngagementSubmit", semio_framework_plugin::CapabilityAudience::Input).await
        .mutation("compiledDagEngagementSubmit", LocalizedLabel::native("Compiled DAG Engagement Submit", "Kompilierter-DAG-Eingabe bestätigen")).await
        .action_audience("compiledDagEngagementSubmit", semio_framework_plugin::CapabilityAudience::Input).await
        .mutation("nodeGraphEdit", LocalizedLabel::native("Edit Workflow", "Workflow bearbeiten")).await
        // 🕹️ Selection/hover are the framework's `graph` interaction domain now (`.interaction(...)`
        // below) — the six framework verbs (`interactionSelect`/`interactionHover`/`clearSelection`/
        // `selectAll`/`setSelectionMode`/`setInteractionGranularity`) auto-inject.
        .action_with(ActionDefinition::new("setActivePanelTab", LocalizedLabel::native("Set Active Panel Tab", "Aktiven Panel-Tab festlegen"), ActionKind::View, "panel-left")).await
        .action_with(ActionDefinition::new("nodeGraphViewport", LocalizedLabel::native("Set Graph Viewport", "Graph-Ansichtsfenster festlegen"), ActionKind::View, "camera")).await
        .view_action("presenceHeartbeat", LocalizedLabel::native("Presence Heartbeat", "Anwesenheits-Heartbeat")).await
        .action_with(ActionDefinition::new("workflowEngagementInput", LocalizedLabel::native("Workflow Engagement Input", "Workflow-Eingabe"), ActionKind::View, "hand")).await
        .action_audience("workflowEngagementInput", semio_framework_plugin::CapabilityAudience::Input).await
        .action_with(ActionDefinition::new("compiledDagEngagementInput", LocalizedLabel::native("Compiled DAG Engagement Input", "Kompilierter-DAG-Eingabe"), ActionKind::View, "hand")).await
        .action_audience("compiledDagEngagementInput", semio_framework_plugin::CapabilityAudience::Input).await
        .action_with(ActionDefinition::new("setActiveExample", LocalizedLabel::native("Set Active Example", "Aktives Beispiel festlegen"), ActionKind::Shell, "panel-left")).await
        .action_with(ActionDefinition::new("exportMedia", LocalizedLabel::native("Export Media", "Medien exportieren"), ActionKind::Shell, "download")).await
        .action_with(ActionDefinition::new("importMedia", LocalizedLabel::native("Import Media", "Medien importieren"), ActionKind::Shell, "hard-drive")).await
        .action_with(ActionDefinition { in_palette: false, ..ActionDefinition::bounded_catalog("importMediaPayload", LocalizedLabel::native("Import Media Payload", "Medien-Payload importieren"), ActionKind::Shell) }).await
        .action_with(ActionDefinition::new("exportStudioPack", LocalizedLabel::native("Export Studio Pack", "Studio-Paket exportieren"), ActionKind::Shell, "download")).await
        .action_with(ActionDefinition::new("exportStudioDsl", LocalizedLabel::native("Export Studio DSL", "Studio-DSL exportieren"), ActionKind::Shell, "download")).await
        .action_with(ActionDefinition::new("importSpacePack", LocalizedLabel::native("Import Studio Pack", "Studio-Paket importieren"), ActionKind::Shell, "hard-drive")).await
        .action_with(ActionDefinition { in_palette: false, ..ActionDefinition::bounded_catalog("importSpacePackPayload", LocalizedLabel::native("Import Studio Pack Payload", "Studio-Paket-Payload importieren"), ActionKind::Shell) }).await
        .action_with(ActionDefinition::new("openSpace", LocalizedLabel::native("Open Studio", "Studio öffnen"), ActionKind::Shell, "folder-open")).await
        .action_with(ActionDefinition::new("openInstance", LocalizedLabel::native("Open Instance", "Instanz öffnen"), ActionKind::Shell, "folder-open").with_category("open")).await
        .shell_action("closeFocusedInstance", LocalizedLabel::native("Close Focused Instance", "Fokussierte Instanz schließen")).await
        .action_with(ActionDefinition::new("goHome", LocalizedLabel::native("Go Home", "Zur Startseite"), ActionKind::Shell, "home")).await
        .action_with(ActionDefinition::new("navigateVirtualFileSystemNode", LocalizedLabel::native("Navigate File System Node", "Dateisystemknoten navigieren"), ActionKind::Shell, "folder")).await
        .action_interactive_job("patchParameter", InteractiveJobClassification::Migrated).await
        .action_interactive_job("addParameter", InteractiveJobClassification::Migrated).await
        .action_interactive_job("removeParameter", InteractiveJobClassification::Migrated).await
        .action_interactive_job("spawnApp", InteractiveJobClassification::Migrated).await
        .action_interactive_job("moveMediaNode", InteractiveJobClassification::Migrated).await
        .action_interactive_job("connectMediaPorts", InteractiveJobClassification::Migrated).await
        .action_interactive_job("disconnectMediaEdge", InteractiveJobClassification::Migrated).await
        .action_interactive_job("removeAppInstance", InteractiveJobClassification::Migrated).await
        .action_interactive_job("deleteSelection", InteractiveJobClassification::Migrated).await
        .action_interactive_job("copyAppInstance", InteractiveJobClassification::Migrated).await
        .action_interactive_job("duplicateAppInstance", InteractiveJobClassification::Migrated).await
        .action_interactive_job("pasteAppInstance", InteractiveJobClassification::Migrated).await
        .action_interactive_job("renameAppInstance", InteractiveJobClassification::Migrated).await
        .action_interactive_job("patchMediaNodes", InteractiveJobClassification::Migrated).await
        .action_interactive_job("patchAppInstances", InteractiveJobClassification::Migrated).await
        .action_interactive_job("bindParameterField", InteractiveJobClassification::Migrated).await
        .action_interactive_job("unbindParameterField", InteractiveJobClassification::Migrated).await
        .action_interactive_job("reorganizeWorkflow", InteractiveJobClassification::Migrated).await
        .action_interactive_job("workflowEngagementSubmit", InteractiveJobClassification::Migrated).await
        .action_interactive_job("compiledDagEngagementSubmit", InteractiveJobClassification::Migrated).await
        .action_interactive_job("nodeGraphEdit", InteractiveJobClassification::Migrated).await
        .action_interactive_job("setActivePanelTab", InteractiveJobClassification::Migrated).await
        .action_interactive_job("nodeGraphViewport", InteractiveJobClassification::Migrated).await
        .action_interactive_job("presenceHeartbeat", InteractiveJobClassification::Migrated).await
        .action_interactive_job("workflowEngagementInput", InteractiveJobClassification::Migrated).await
        .action_interactive_job("compiledDagEngagementInput", InteractiveJobClassification::Migrated).await
        .action_interactive_job("setActiveExample", InteractiveJobClassification::Migrated).await
        .action_interactive_job("exportMedia", InteractiveJobClassification::Migrated).await
        .action_destructive("exportMedia").await
        .action_interactive_job("importMedia", InteractiveJobClassification::Migrated).await
        .action_interactive_job("importMediaPayload", InteractiveJobClassification::Migrated).await
        .action_interactive_job("exportStudioPack", InteractiveJobClassification::Migrated).await
        .action_destructive("exportStudioPack").await
        .action_interactive_job("exportStudioDsl", InteractiveJobClassification::Migrated).await
        .action_destructive("exportStudioDsl").await
        .action_interactive_job("importSpacePack", InteractiveJobClassification::Migrated).await
        .action_interactive_job("importSpacePackPayload", InteractiveJobClassification::Migrated).await
        .action_interactive_job("openSpace", InteractiveJobClassification::Migrated).await
        .action_interactive_job("openInstance", InteractiveJobClassification::Migrated).await
        .action_interactive_job("closeFocusedInstance", InteractiveJobClassification::Migrated).await
        .action_interactive_job("goHome", InteractiveJobClassification::Migrated).await
        .action_interactive_job("navigateVirtualFileSystemNode", InteractiveJobClassification::Migrated).await
        .action_interactive_job("setAppRegistrations", InteractiveJobClassification::Migrated).await
        // 📝️ Staged argument form for parameter creation (spawnApp stays context-driven; exportMedia requires an explicit artifact document).
        .action_args("exportMedia", vec![
            ActionArgDef::text("nodeId", LocalizedLabel::native("App Instance", "App-Instanz")),
            ActionArgDef::text("format", LocalizedLabel::native("Format", "Format")),
            ActionArgDef::text("documentJson", LocalizedLabel::native("Artifact Document", "Artefaktdokument")),
        ]).await
        .action_args("addParameter", vec![
            ActionArgDef::text("name", LocalizedLabel::native("Name", "Name")).default_value(&"Parameter"),
            ActionArgDef::select("type", LocalizedLabel::native("Type", "Typ"), vec![
                ActionArgOption::new("numeric", LocalizedLabel::native("Numeric", "Numerisch")),
                ActionArgOption::new("categorical", LocalizedLabel::native("Categorical", "Kategorisch")),
                ActionArgOption::new("toggle", LocalizedLabel::native("Toggle", "Schalter")),
                ActionArgOption::new("text", LocalizedLabel::native("Text", "Text")),
            ]).default_value(&"numeric"),
        ]).await
        // 📇️ Per-window action scoping — the Workflow (NodeGraph) window owns all graph/instance/
        // parameter editing plus the per-instance media import/export; the Media VFS
        // (VirtualFileSystem) window only navigates the media file tree; the read-only Compiled DAG
        // window only drives its own engagement. Navigation, panel-tab, presence, example and generic
        // node-graph view actions stay unscoped orphans and appear on every window.
        .window_kind_action_refs(semio_hub_space_foundation::S_PLAY_WINDOW_WORKFLOW, vec![
            "patchParameter".into(), "addParameter".into(), "removeParameter".into(),
            "spawnApp".into(), "moveMediaNode".into(), "connectMediaPorts".into(), "disconnectMediaEdge".into(),
            "removeAppInstance".into(), "deleteSelection".into(), "copyAppInstance".into(),
            "duplicateAppInstance".into(), "pasteAppInstance".into(), "renameAppInstance".into(),
            "patchMediaNodes".into(), "patchAppInstances".into(), "bindParameterField".into(),
            "unbindParameterField".into(), "reorganizeWorkflow".into(), "workflowEngagementSubmit".into(),
            "workflowEngagementInput".into(), "nodeGraphEdit".into(), "exportMedia".into(),
            "importMedia".into(), "importMediaPayload".into(),
        ]).await
        .window_kind_action_refs(media_vfs::S_PLAY_WINDOW_MEDIA_VFS, vec![
            "navigateVirtualFileSystemNode".into(),
        ]).await
        .window_kind_action_refs(compiled_dag::S_PLAY_WINDOW_COMPILED_DAG, vec![
            "compiledDagEngagementSubmit".into(), "compiledDagEngagementInput".into(),
        ]).await
        // 🕹️ First-class hover/selection (ticket 26/08/14/FIRST-CLASS-HOVER-AND-SELECTION-MECHANISM):
        // one domain over the workflow node graph, "instance"/"media-node" granularities (a node IS
        // the app instance now — see the kernel `🔁️workflow` crate's `🔖️InstanceIdentity` doc),
        // `HierarchyProvider::Topology` (see `SpaceApp::interaction_topology` above) — the node graph
        // itself is flat (no parent/child structure), so the topology exists purely so a deleted
        // node's id auto-prunes out of `graph`'s selection.
        .interaction(InteractionDefinition {
            id: S_PLAY_INTERACTION_DOMAIN.into(),
            label: LocalizedLabel::native("Graph", "Graph"),
            granularities: vec![
                GranularityDefinition { id: "instance".into(), label: LocalizedLabel::native("Instance", "Instanz"), icon_id: "box".into() },
                GranularityDefinition { id: "media-node".into(), label: LocalizedLabel::native("Media Node", "Medienknoten"), icon_id: "circle".into() },
            ],
            hierarchy: HierarchyProvider::Topology,
            hover: HoverSpec::default(),
            selection: SelectionSpec {
                modes: vec![SelectionMode::Multiple, SelectionMode::Single],
                methods: vec![SelectionMethod::Pick],
                merges: vec![MergeMode::Replace],
                transitive: false,
                broadcast: true,
            },
        }).await
        .window_kind_interactions(semio_hub_space_foundation::S_PLAY_WINDOW_WORKFLOW, vec![InteractionRef::new(S_PLAY_INTERACTION_DOMAIN)]).await
        .keybinding("mod+z", "undo").await
        .keybinding("mod+shift+z", "redo").await
        .action_describe("patchParameter", LocalizedLabel::native("Sets one field (such as name, value or range) of one studio parameter by id; the value may be JSON or plain text.", "Setzt ein Feld (etwa Name, Wert oder Bereich) eines Studioparameters anhand seiner Id; der Wert darf JSON oder Klartext sein.")).await
        .action_describe("addParameter", LocalizedLabel::native("Adds a studio parameter with the given name and type (numeric, categorical, toggle or text) that app fields can be bound to.", "Fügt einen Studioparameter mit dem angegebenen Namen und Typ (Zahl, Auswahl, Schalter oder Text) hinzu, an den App-Felder gebunden werden können.")).await
        .action_describe("removeParameter", LocalizedLabel::native("Removes one studio parameter by id together with its field bindings.", "Entfernt einen Studioparameter anhand seiner Id samt seiner Feldbindungen.")).await
        .action_describe("spawnApp", LocalizedLabel::native("Adds an instance of a plugin app (plugin id and app id) to the studio workflow at x, y and makes it the active instance.", "Fügt dem Studio-Workflow an x, y eine Instanz einer Plugin-App (Plugin-Id und App-Id) hinzu und macht sie zur aktiven Instanz.")).await
        .action_describe("moveMediaNode", LocalizedLabel::native("Moves one app instance to the workflow canvas position x, y.", "Verschiebt eine App-Instanz an die Position x, y der Workflow-Fläche.")).await
        .action_describe("connectMediaPorts", LocalizedLabel::native("Connects a media output port of one app instance to a media input port of another, so its output flows into the second.", "Verbindet einen Medienausgang einer App-Instanz mit einem Medieneingang einer anderen, sodass deren Ausgabe in die zweite fließt.")).await
        .action_describe("disconnectMediaEdge", LocalizedLabel::native("Removes one media connection between two app instances by id.", "Entfernt eine Medienverbindung zwischen zwei App-Instanzen anhand ihrer Id.")).await
        .action_describe("removeAppInstance", LocalizedLabel::native("Removes one app instance (the given one, or the selected one) from the workflow with its connections.", "Entfernt eine App-Instanz (die angegebene oder die ausgewählte) samt ihrer Verbindungen aus dem Workflow.")).await
        .action_describe("deleteSelection", LocalizedLabel::native("Removes every selected app instance and connection from the studio workflow.", "Entfernt alle ausgewählten App-Instanzen und Verbindungen aus dem Studio-Workflow.")).await
        .action_describe("copyAppInstance", LocalizedLabel::native("Copies the selected app instances to the studio clipboard for a later paste; the workflow is not changed.", "Kopiert die ausgewählten App-Instanzen für ein späteres Einfügen in die Studio-Zwischenablage; der Workflow ändert sich nicht.")).await
        .action_describe("duplicateAppInstance", LocalizedLabel::native("Adds a copy of each selected app instance next to it, labelled with Copy.", "Fügt neben jeder ausgewählten App-Instanz eine mit Kopie beschriftete Kopie hinzu.")).await
        .action_describe("pasteAppInstance", LocalizedLabel::native("Adds a copy of every app instance on the studio clipboard to the workflow, offset from the original.", "Fügt dem Workflow eine versetzte Kopie jeder App-Instanz aus der Studio-Zwischenablage hinzu.")).await
        .action_describe("renameAppInstance", LocalizedLabel::native("Renames one app instance of the workflow.", "Benennt eine App-Instanz des Workflows um.")).await
        .action_describe("patchMediaNodes", LocalizedLabel::native("Sets one field (such as the position along an axis) on several app instances at once.", "Setzt ein Feld (etwa die Position entlang einer Achse) auf mehreren App-Instanzen zugleich.")).await
        .action_describe("patchAppInstances", LocalizedLabel::native("Sets the label of several app instances at once.", "Setzt die Beschriftung mehrerer App-Instanzen zugleich.")).await
        .action_describe("bindParameterField", LocalizedLabel::native("Binds one field of an app instance (by field path) to a studio parameter, so the parameter's value drives it; an empty parameter unbinds it.", "Bindet ein Feld einer App-Instanz (per Feldpfad) an einen Studioparameter, sodass dessen Wert es steuert; ein leerer Parameter löst die Bindung.")).await
        .action_describe("unbindParameterField", LocalizedLabel::native("Removes the parameter binding from one field of an app instance, so the field keeps its own value again.", "Entfernt die Parameterbindung von einem Feld einer App-Instanz, sodass das Feld wieder seinen eigenen Wert behält.")).await
        .action_describe("reorganizeWorkflow", LocalizedLabel::native("Lays out every app instance of the workflow automatically, overwriting their manual positions.", "Ordnet alle App-Instanzen des Workflows automatisch an und überschreibt ihre manuellen Positionen.")).await
        .action_describe("exportMedia", LocalizedLabel::native("Writes the media one app instance produces in the chosen format to a downloaded file on the user's machine.", "Schreibt die Medien, die eine App-Instanz erzeugt, im gewählten Format in eine heruntergeladene Datei auf dem Rechner des Nutzers.")).await
        .action_describe("importMedia", LocalizedLabel::native("Opens the host's file picker for a file of the given format; the chosen file is then imported into the given app instance.", "Öffnet die Dateiauswahl des Hosts für eine Datei des angegebenen Formats; die gewählte Datei wird dann in die angegebene App-Instanz importiert.")).await
        .action_describe("importMediaPayload", LocalizedLabel::native("Imports a picked file's content (data URL) into the app instance that Import Media was started for.", "Importiert den Inhalt einer gewählten Datei (Data-URL) in die App-Instanz, für die Medien importieren gestartet wurde.")).await
        .action_describe("setActivePanelTab", LocalizedLabel::native("Switches the studio's side panel to the given tab; only the view changes.", "Schaltet das Seitenpanel des Studios auf den angegebenen Reiter um; nur die Ansicht ändert sich.")).await
        .action_describe("setActiveExample", LocalizedLabel::native("Opens one of the bundled example studios by navigating the shell to it; the current studio is not changed.", "Öffnet eines der mitgelieferten Beispielstudios, indem die Shell dorthin navigiert; das aktuelle Studio ändert sich nicht.")).await
        .action_describe("exportStudioPack", LocalizedLabel::native("Writes the whole studio as a .pack file and an .ops event log to two downloaded files on the user's machine.", "Schreibt das gesamte Studio als .pack-Datei und .ops-Ereignisprotokoll in zwei heruntergeladene Dateien auf dem Rechner des Nutzers.")).await
        .action_describe("exportStudioDsl", LocalizedLabel::native("Writes the whole studio as DSL text to a downloaded file on the user's machine.", "Schreibt das gesamte Studio als DSL-Text in eine heruntergeladene Datei auf dem Rechner des Nutzers.")).await
        .action_describe("importSpacePack", LocalizedLabel::native("Opens the host's file picker for a studio .pack file; the chosen file is then imported.", "Öffnet die Dateiauswahl des Hosts für eine Studio-.pack-Datei; die gewählte Datei wird dann importiert.")).await
        .action_describe("importSpacePackPayload", LocalizedLabel::native("Imports a studio from the content (data URL) of a picked .pack file.", "Importiert ein Studio aus dem Inhalt (Data-URL) einer gewählten .pack-Datei.")).await
        .action_describe("openInstance", LocalizedLabel::native("Opens the given or selected app instance in its own window so its artifact can be viewed or edited.", "Öffnet die angegebene oder ausgewählte App-Instanz in einem eigenen Fenster, damit ihr Artefakt angesehen oder bearbeitet werden kann.")).await
        .action_describe("closeFocusedInstance", LocalizedLabel::native("Closes the app instance window that is currently focused; the workflow is not changed.", "Schließt das gerade fokussierte App-Instanz-Fenster; der Workflow ändert sich nicht.")).await
        .action_describe("openSpace", LocalizedLabel::native("Opens the studio with the given id, navigating the shell to it.", "Öffnet das Studio mit der angegebenen Id und navigiert die Shell dorthin.")).await
        .action_describe("navigateVirtualFileSystemNode", LocalizedLabel::native("Navigates the shell to the space with the given id.", "Navigiert die Shell zum Space mit der angegebenen Id.")).await
        .action_describe("goHome", LocalizedLabel::native("Navigates the shell back to the Home launcher.", "Navigiert die Shell zurück zum Home-Starter.")).await
        .action_audience("nodeGraphEdit", semio_framework_plugin::CapabilityAudience::Input).await
        .action_audience("nodeGraphViewport", semio_framework_plugin::CapabilityAudience::Chrome).await
        .action_audience("presenceHeartbeat", semio_framework_plugin::CapabilityAudience::Chrome).await
        .action_destructive("reorganizeWorkflow").await
        .keybinding("mod+s", "commitCheckpoint").await;
    let definition = builder.build_definition();
    let app = App { definition, examples: Vec::new() };
    let mut app = app.workflow("s", "S Studio", "studio").await;
    for (id, label) in S_STUDIO_EXAMPLES {
        // 🚧️ `OsWorkflowArtifactDocument` (= `BackboneDocument<WorkflowSnapshot, WorkflowMutation>`)
        // is deeply framework-owned (`ArtifactVcs`/`ArtifactCursor`/`Edit`/`Conflict`/...) and still
        // only derives `Serialize`, not `ToValue` — bridging the whole envelope is out of this
        // ticket's plugin-slice scope (tracked with the in-flight `BackboneDocument: ToValue`
        // framework work). The example payload only ever needed the bare `WorkflowSnapshot` anyway
        // (`parse_demo_space_document`'s own doc: "the fixture holds only the `WorkflowSnapshot`
        // payload"), which already derives `ToValue` — read the immutable genesis snapshot.
        let document = parse_demo_space_document().await;
        let document_value = semio_framework_value::ToValue::to_value(document.vcs.genesis.facts().snapshot());
        let json = semio_framework_pack_json::to_string_pretty(&semio_framework_pack_json::from_dsl_value(&document_value));
        // 📊️ `label` is sourced from `S_STUDIO_EXAMPLES` — no per-locale split is available at the
        // source, so it is genuine runtime data here, not compile-checked native copy.
        app = app.example(*id, LocalizedLabel::data(*label), json, "file-text").await;
    }
    app
}
//#endregion 🔖️SpaceManifest

//#region 🧪️UnitTests
/// 🧪️ Shared test harness — every command-group test file needs this, added here first per the
/// per-app recipe so other nodes don't each re-derive it.
#[cfg(any(test, feature = "testkit"))]
#[path = "🧪️tests/🔬️unit/🦀️.rs"]
pub mod unit_tests;
//#endregion 🧪️UnitTests

//#region 🪢️TaxonomyMounts
#[path = "📚️examples/🎬️demo-session/🦀️.rs"]
pub mod demo_session;
#[cfg(test)]
#[path = "📚️examples/🎬️demo-session/🧪️tests/🧩️example/🦀️.rs"]
mod example;
//#endregion 🪢️TaxonomyMounts

//#region 🔖️Windows
#[path = "."]
pub mod modes {
    #[path = "."]
    pub mod main {
        #[path = "🎭️modes/🌐️main/🦀️.rs"]
        mod component;
        pub use component::*;

        #[path = "."]
        pub mod windows {
            #[path = "."]
            pub mod workflow {
                #[path = "🎭️modes/🌐️main/🪟️windows/🔄️workflow/🦀️.rs"]
                mod component;
                pub use component::*;

                #[path = "."]
                pub mod options {
                    #[path = "🎭️modes/🌐️main/🪟️windows/🔄️workflow/☑️options/🎯️active-instance/🦀️.rs"]
                    pub mod active_instance;
                }
            }

            #[path = "."]
            pub mod media_vfs {
                #[path = "🎭️modes/🌐️main/🪟️windows/🗂️media-vfs/🦀️.rs"]
                mod component;
                pub use component::*;
            }

            #[path = "."]
            pub mod compiled_dag {
                #[path = "🎭️modes/🌐️main/🪟️windows/🕸️compiled-dag/🦀️.rs"]
                mod component;
                pub use component::*;
            }
        }
    }
}

#[path = "."]
pub mod panels {
    #[path = "📌️panels/🛍️catalogue/🦀️.rs"]
    pub mod catalogue;
    #[path = "📌️panels/🔍️inspection/🦀️.rs"]
    pub mod inspection;
    #[path = "📌️panels/🔢️parameters/🦀️.rs"]
    pub mod parameters;
}
//#endregion 🔖️Windows
