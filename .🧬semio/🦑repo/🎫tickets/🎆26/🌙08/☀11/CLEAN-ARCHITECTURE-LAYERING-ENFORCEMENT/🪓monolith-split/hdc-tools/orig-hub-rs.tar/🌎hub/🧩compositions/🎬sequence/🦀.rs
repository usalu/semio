//! 🔌️ Plugin root contract — typestate `Plugin::builder` registration for this owner.

use semio_framework_plugin::__semio_dispatch_PluginApp;
use semio_framework_plugin::kernel::{ActivationEvent, CapabilityId, CapabilityRequest};
use semio_framework_plugin::plugin_app_close_prelude::*;
use semio_framework_plugin::{ExecutionMode, Plugin, PluginApp};
use semio_framework_plugin::PluginBuilder;

//#region 🗃️Apps
semio_framework_dispatch_macros::dyn_enum_close! {
    /// 🗃️ Closed runtime app fleet for the declaration-owned sequence surfaces.
    pub enum SequenceApps: PluginApp {
        Editor(VcsArtifactApp<EditorApp<crate::editor::sequence::SequencePlayApp>, semio_s_artifact_stdio_semio::SemioMembers>),
        Viewer(VcsArtifactApp<ViewerApp<crate::viewer::sequence::SequenceViewer>, semio_s_artifact_stdio_semio::SemioMembers>),
    }
}
//#endregion 🗃️Apps

/// 🔌️ Builds the plugin surface for host registration. Atomic cutover (ticket
/// 26/08/17/CLEAN-ARTIFACT-STANDARD-SUBSET-MECHANISM): `.declare_artifact(...)` (new declaration
/// tree) replaces `.artifact(...)`/`.editor::<>()`/`.viewer::<>()` outright — the old channel is
/// NOT kept alongside it (a second parallel registration channel is the compatibility layer this
/// ticket forbids). `.editor_mutation_roster()`/`.viewer_mutation_roster()` stay: they are an
/// orthogonal, still-supported opt-in (`contributor.list-artifact-mutations`) the new declaration
/// tree's `SurfaceDeclaration.mutation_roster` field does not yet wire live (`📓️w1-c-report.md`
/// openQuestion 3) — not a second registration of the artifact/schema/io itself. `.activation(…)`/
/// `.execution(…)`/`.requests(…)` (ticket 26/08/17/MICROKERNEL-POOLED-ACTOR-PLUGIN-RUNTIME
/// M6-remaining, `📓️design-abi.md` §3/§6) are this crate's migration proof, mirroring `🗒️note`'s
/// shape.
pub fn plugin() -> Result<Plugin<SequenceApps>, PluginAssemblyError> {
    PluginBuilder::<_, SequenceApps>::new("sequence")
        .label("Sequence")
        .version("0.1.0")
        .package_id("semio:sequence")
        .declare_artifact(crate::artifacts::sequence::artifact())
        .editor_mutation_roster::<crate::editor::sequence::SequencePlayApp>()
        .viewer_mutation_roster::<crate::viewer::sequence::SequenceViewer>()
        .activation(ActivationEvent::OnArtifactKind { kind: crate::artifacts::sequence::artifact_kind().id })
        .execution(ExecutionMode::Isolated)
        .requests(CapabilityRequest { id: CapabilityId("artifacts.write".into()), scope: "plugin".into(), reason: "persist sequence edits to the open document".into(), optional: false })
        .canvas_runtime_assets()
        .try_build()
}

//#region 🧪️SurfaceTests
/// 🧪️ Contract §2.5's canonical surface test context — landed by the ticket's W0-F SDK-gap-closure lane
/// (`📓️w0-f-report.md`), used directly rather than a local stand-in.
#[cfg(test)]
#[path = "🧪️tests/🔬️surface/🦀️.rs"]
mod surface_tests;
//#endregion 🧪️SurfaceTests
