//! 🧪️ Every public norm editor/viewer wrapper renders its declared language-neutral surface inventory.

use semio_framework_plugin::artifact_app_laws::{close_registered_fixture_app, project_and_retire_fixture_tree};
use semio_framework_plugin::{AppDefinition, Locale, PanelTabDefinition, PluginApp, Terminology, ViewModel};
use std::collections::BTreeSet;

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Fixture {
    contract_id: String,
    rows: Vec<Surface>,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Surface {
    variant: String,
    role: String,
    app_id: String,
    body_keys: Vec<String>,
}

fn panel_bodies(panels: &[PanelTabDefinition], keys: &mut BTreeSet<String>) {
    for panel in panels {
        if let Some(body) = &panel.body_key {
            keys.insert(body.clone());
        }
        panel_bodies(&panel.children, keys);
    }
}

async fn check_surface<A: PluginApp>(app: &mut A, definition: &AppDefinition, fixture: &Surface) -> Result<usize, String> {
    if app.app_id().await != fixture.app_id {
        return Err(format!("{} factory returned the wrong app identity", fixture.app_id));
    }
    let artifact_schema = app.artifact_schema().await;
    if artifact_schema != format!("semio.norm.{}/v1", fixture.variant) || definition.io.artifact_schema != artifact_schema {
        return Err(format!("{} factory returned the wrong document schema", fixture.app_id));
    }
    let mut keys: BTreeSet<String> = definition.window_kinds.iter().map(|window| window.body_key.clone()).collect();
    panel_bodies(&definition.panel_tabs, &mut keys);
    if keys != fixture.body_keys.iter().cloned().collect() {
        return Err(format!("{} manifest returned the wrong surface inventory", fixture.app_id));
    }
    let view = ViewModel { locale: Locale::En, terminology: Terminology::Native, ..ViewModel::new(semio_framework_ui_locale::Locale::En, semio_framework_ui_locale::Terminology::Native) };
    for key in &fixture.body_keys {
        let tree = app.render(key, None, &view).await.map_err(|error| format!("{} {key}: {error:?}", fixture.app_id))?;
        let projection = project_and_retire_fixture_tree(tree).map_err(|error| format!("{} {key} observation and retirement: {error}", fixture.app_id))?;
        if projection.contains("Unknown body") {
            return Err(format!("{} {key} resolved to the unknown-body fallback", fixture.app_id));
        }
    }
    let unknown = app.render("unregistered.norm.surface", None, &view).await.map_err(|error| format!("{} unknown fallback: {error:?}", fixture.app_id))?;
    let unknown_projection = project_and_retire_fixture_tree(unknown).map_err(|error| format!("{} unknown fallback observation and retirement: {error}", fixture.app_id))?;
    if !unknown_projection.contains("Unknown body") {
        return Err(format!("{} did not render its unknown-body fallback", fixture.app_id));
    }
    if app.render(&"x".repeat(70_000), None, &view).await.is_ok() {
        return Err(format!("{} accepted an oversized surface identity", fixture.app_id));
    }
    Ok(fixture.body_keys.len())
}

#[semio_framework_async_macros::async_test]
async fn norm_public_surfaces_render_all_declared_bodies() {
    let fixture: Fixture = serde_json::from_str(include_str!("../🧫️fixtures/🔣️.json")).unwrap();
    assert_eq!(fixture.contract_id, "semio.norm.surface-render/v1");
    assert_eq!(fixture.rows.len(), 30);
    let plugin = semio_hub_norm::plugin().expect("the real norm plugin must assemble its complete surface registry");
    assert_eq!(plugin.manifest.apps.iter().map(|app| app.id.clone()).collect::<BTreeSet<_>>(), fixture.rows.iter().map(|row| row.app_id.clone()).collect());
    assert_eq!(plugin.artifact_definitions().definitions().map(|definition| definition.identity().as_str().to_owned()).collect::<BTreeSet<_>>(), fixture.rows.iter().map(|row| format!("s.norm.{}", row.variant)).collect());
    let mut visited = BTreeSet::new();
    let mut rendered = 0;
    for row in &fixture.rows {
        assert!(visited.insert(row.app_id.clone()));
        let definition = plugin.manifest.apps.iter().find(|app| app.id == row.app_id).unwrap();
        assert_eq!(definition.id, row.app_id);
        assert_eq!(definition.role.as_str(), row.role);
        assert_eq!(definition.dialect.artifact_kind, format!("s.norm.{}", row.variant));
        let mut app = plugin.create_app(&row.app_id, semio_framework_os_kernel::ActorId(semio_framework_os_kernel::os_spr::LOCAL_ACTOR_ID.into())).expect("each manifest app must have a registered factory");
        let result = check_surface(&mut app, definition, row).await;
        close_registered_fixture_app(&mut app);
        rendered += result.unwrap_or_else(|error| panic!("{error}"));
    }
    assert_eq!(visited.len(), 30);
    assert_eq!(rendered, 120);
    assert!(plugin.create_app("s.norm.unknown@1/*#editor", semio_framework_os_kernel::ActorId(semio_framework_os_kernel::os_spr::LOCAL_ACTOR_ID.into())).is_none());
}

//#region 🧵️RetainedCohort
#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct RetainedFactoryRow {
    payload_schema: String,
    maximum_raw_bytes: usize,
    shared: bool,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct RetainedContractRow {
    tool_id: String,
    lanes: Vec<String>,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct RetainedRouteRow {
    id: String,
    publication_lanes: Vec<String>,
    admission: String,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct RetainedAppRow {
    variant: String,
    controller: String,
    artifact_schema: String,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct RetainedExpected {
    apps: usize,
    routes_per_app: usize,
    identities: usize,
    retained: usize,
    batch_only_pending_rewrite: usize,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct RetainedFixture {
    factory: RetainedFactoryRow,
    publication_contracts: Vec<RetainedContractRow>,
    routes: Vec<RetainedRouteRow>,
    apps: Vec<RetainedAppRow>,
    expected: RetainedExpected,
}

macro_rules! assert_norm_pair {
    ($($artifact:path => ($editor:path, $viewer:path)),+ $(,)?) => {
        $(
            semio_framework_plugin::artifact_app_laws::assert_editor_and_viewer_share_dialect::<$editor, $viewer>().await;
            semio_framework_plugin::artifact_app_laws::assert_viewer_never_mutates::<$viewer>().await;
        )+
    };
}

/// 🧵️ The language-neutral cohort law: all fifteen norm editors classify their three actions
/// `Migrated` and build against the one shared owned bounded factory. `create_app` is the real gate —
/// it runs the framework's proof↔factory join (`interactive-job.catalog-authority`) and the
/// publication-lane availability check, both of which fail closed on a mechanical classification flip.
#[semio_framework_async_macros::async_test]
async fn every_norm_editor_action_is_migrated_onto_the_shared_owned_factory() {
    let fixture: RetainedFixture = serde_json::from_str(include_str!("../../../../../../✏️s/🔌️plugins/📕️norm/📇️registry/🧬️contract/🧪️tests/🧫️fixtures/🧫️retained-command-dispositions/🔣️.json")).unwrap();
    assert!(fixture.factory.shared);
    assert_eq!(fixture.factory.payload_schema, semio_s_plugin_norm_app_surface::NORM_RETAINED_PAYLOAD_SCHEMA);
    assert_eq!(fixture.factory.maximum_raw_bytes, semio_s_plugin_norm_app_surface::NORM_RETAINED_RAW_BYTES);
    assert_eq!(fixture.apps.len(), fixture.expected.apps);
    assert_eq!(fixture.routes.len(), fixture.expected.routes_per_app);
    assert_eq!(fixture.expected.identities, fixture.expected.apps * fixture.expected.routes_per_app);
    assert_eq!(fixture.expected.retained, fixture.expected.identities);
    assert_eq!(fixture.expected.batch_only_pending_rewrite, 0);
    assert_eq!(fixture.routes.iter().map(|route| route.id.as_str()).collect::<Vec<_>>(), semio_s_plugin_norm_app_surface::NORM_RETAINED_TOOL_IDS.to_vec());
    assert_eq!(fixture.publication_contracts.len(), semio_s_plugin_norm_app_surface::NORM_PUBLICATION_CONTRACTS.len());
    for (row, declared) in fixture.publication_contracts.iter().zip(semio_s_plugin_norm_app_surface::NORM_PUBLICATION_CONTRACTS) {
        assert_eq!(row.tool_id, declared.tool_id);
        assert_eq!(row.lanes, declared.lanes.iter().copied().map(semio_s_plugin_norm_app_surface::publication_lane_id).collect::<Vec<_>>());
    }
    for (route, contract) in fixture.routes.iter().zip(&fixture.publication_contracts) {
        assert_eq!(route.admission, "migrated");
        assert_eq!(route.publication_lanes, contract.lanes);
    }

    let plugin = semio_hub_norm::plugin().expect("the real norm plugin must assemble its complete surface registry");
    let mut identities = 0usize;
    for app in &fixture.apps {
        let definition = plugin.manifest.apps.iter().find(|entry| entry.id == app.controller).unwrap_or_else(|| panic!("{} is not a registered norm editor", app.controller));
        assert_eq!(definition.io.artifact_schema, app.artifact_schema);
        assert_eq!(definition.dialect.artifact_kind, format!("s.norm.{}", app.variant));
        for window in definition.window_kinds.iter() {
            let presented = semio_framework_plugin::window_kind_actions(definition, window);
            for route in &fixture.routes {
                let action = presented.iter().find(|action| action.id == route.id).unwrap_or_else(|| panic!("{} window {} does not present {}", app.controller, window.id, route.id));
                assert_eq!(action.semantics.execution.interactive_job, semio_framework_plugin::InteractiveJobClassification::Migrated, "{} {} must dispatch from the UI", app.controller, route.id);
            }
        }
        let mut runtime = plugin.create_app(&app.controller, semio_framework_os_kernel::ActorId(semio_framework_os_kernel::os_spr::LOCAL_ACTOR_ID.into())).unwrap_or_else(|| panic!("{} must build with its owned bounded factory registered", app.controller));
        close_registered_fixture_app(&mut runtime);
        identities += fixture.routes.len();
    }
    assert_eq!(identities, fixture.expected.identities);
    assert_norm_pair! {
        semio_s_artifact_norm_din4108 => (semio_s_artifact_norm_din4108_editor::Din4108PlayApp, semio_s_artifact_norm_din4108_viewer::Din4108Viewer),
        semio_s_artifact_norm_din16798 => (semio_s_artifact_norm_din16798_editor::Din16798PlayApp, semio_s_artifact_norm_din16798_viewer::Din16798Viewer),
        semio_s_artifact_norm_din18599 => (semio_s_artifact_norm_din18599_editor::Din18599PlayApp, semio_s_artifact_norm_din18599_viewer::Din18599Viewer),
        semio_s_artifact_norm_en1990 => (semio_s_artifact_norm_en1990_editor::En1990PlayApp, semio_s_artifact_norm_en1990_viewer::En1990Viewer),
        semio_s_artifact_norm_en1991 => (semio_s_artifact_norm_en1991_editor::En1991PlayApp, semio_s_artifact_norm_en1991_viewer::En1991Viewer),
        semio_s_artifact_norm_en1992 => (semio_s_artifact_norm_en1992_editor::En1992PlayApp, semio_s_artifact_norm_en1992_viewer::En1992Viewer),
        semio_s_artifact_norm_en1993 => (semio_s_artifact_norm_en1993_editor::En1993PlayApp, semio_s_artifact_norm_en1993_viewer::En1993Viewer),
        semio_s_artifact_norm_en1994 => (semio_s_artifact_norm_en1994_editor::En1994PlayApp, semio_s_artifact_norm_en1994_viewer::En1994Viewer),
        semio_s_artifact_norm_en1995 => (semio_s_artifact_norm_en1995_editor::En1995PlayApp, semio_s_artifact_norm_en1995_viewer::En1995Viewer),
        semio_s_artifact_norm_en1996 => (semio_s_artifact_norm_en1996_editor::En1996PlayApp, semio_s_artifact_norm_en1996_viewer::En1996Viewer),
        semio_s_artifact_norm_en1997 => (semio_s_artifact_norm_en1997_editor::En1997PlayApp, semio_s_artifact_norm_en1997_viewer::En1997Viewer),
        semio_s_artifact_norm_en1998 => (semio_s_artifact_norm_en1998_editor::En1998PlayApp, semio_s_artifact_norm_en1998_viewer::En1998Viewer),
        semio_s_artifact_norm_en1999 => (semio_s_artifact_norm_en1999_editor::En1999PlayApp, semio_s_artifact_norm_en1999_viewer::En1999Viewer),
        semio_s_artifact_norm_iso16757 => (semio_s_artifact_norm_iso16757_editor::Iso16757PlayApp, semio_s_artifact_norm_iso16757_viewer::Iso16757Viewer),
        semio_s_artifact_norm_vdi3805 => (semio_s_artifact_norm_vdi3805_editor::Vdi3805PlayApp, semio_s_artifact_norm_vdi3805_viewer::Vdi3805Viewer),
    }
}
//#endregion 🧵️RetainedCohort
