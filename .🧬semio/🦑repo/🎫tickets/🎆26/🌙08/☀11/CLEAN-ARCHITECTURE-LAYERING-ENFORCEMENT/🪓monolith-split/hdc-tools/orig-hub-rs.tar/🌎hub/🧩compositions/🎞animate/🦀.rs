//! 🔌️ Plugin root contract — typestate `Plugin::builder` registration for this owner.

use semio_framework_plugin::__semio_dispatch_PluginApp;
use semio_framework_plugin::kernel::{ActivationEvent, CapabilityId, CapabilityRequest, MEDIA_VIDEO_RENDER_CAPABILITY};
use semio_framework_plugin::plugin_app_close_prelude::*;
use semio_framework_plugin::{EditorApp, ExecutionMode, Plugin, PluginApp, PluginAssemblyError, VcsArtifactApp, ViewerApp};
use semio_framework_plugin::PluginBuilder;

//#region 🗃️Apps
// 🗃️ Closed runtime app fleet for the declaration-owned animate surfaces.
semio_framework_dispatch_macros::dyn_enum_close! {
    pub enum AnimateApps: PluginApp {
        PresentationEditor(VcsArtifactApp<EditorApp<crate::editor::animate::AnimatePresentationPlayApp>, semio_s_artifact_stdio_semio::SemioMembers>),
        PresentationViewer(VcsArtifactApp<ViewerApp<crate::viewer::animate::AnimatePresentationViewer>, semio_s_artifact_stdio_semio::SemioMembers>),
    }
}
//#endregion 🗃️Apps

/// 🔌️ Builds the plugin surface for host registration. `.activation(…)`/`.execution(…)`/
/// `.requests(…)` (ticket 26/08/17/MICROKERNEL-POOLED-ACTOR-PLUGIN-RUNTIME M6-remaining,
/// `📓️design-abi.md` §3/§6) are this crate's migration proof, mirroring `🗒️note`'s shape.
pub fn plugin() -> Result<Plugin<AnimateApps>, PluginAssemblyError> {
    PluginBuilder::<_, AnimateApps>::new("animate")
        .label("Animate")
        .version("0.1.0")
        .package_id("semio:animate")
        .declare_artifact(crate::artifacts::presentation::artifact::<AnimateApps>())
        .editor_mutation_roster::<crate::editor::animate::AnimatePresentationPlayApp>()
        .viewer_mutation_roster::<crate::viewer::animate::AnimatePresentationViewer>()
        .activation(ActivationEvent::OnArtifactKind { kind: crate::artifacts::presentation::artifact_kind().id })
        .execution(ExecutionMode::Isolated)
        .requests(CapabilityRequest { id: CapabilityId("artifacts.write".into()), scope: "plugin".into(), reason: "persist animate presentation edits to the open document".into(), optional: false })
        .requests(CapabilityRequest { id: CapabilityId(MEDIA_VIDEO_RENDER_CAPABILITY.into()), scope: "plugin".into(), reason: "render the presentation deck to an MP4 video on this device".into(), optional: false })
        .try_build()
}

//#region 🧪️SurfaceTests
#[cfg(test)]
#[path = "🧪️tests/🔬️surface/🦀️.rs"]
mod surface_tests;
//#endregion 🧪️SurfaceTests
