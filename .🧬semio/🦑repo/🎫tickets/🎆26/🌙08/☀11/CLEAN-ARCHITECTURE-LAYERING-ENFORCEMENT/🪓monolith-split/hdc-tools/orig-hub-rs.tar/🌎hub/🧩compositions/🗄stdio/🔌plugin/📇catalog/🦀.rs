//! 📇 Component-level composition and validation for selected artifact packages: the feature-free full stdio catalog
//! that the stdio component, the native hub and every composition validating stdio contributions link.

#![allow(async_fn_in_trait)]
#![allow(long_running_const_eval)]

extern crate semio_framework_value_derive as value_derive;

#[path = "../../🛂️manifest/🦀️.rs"]
pub mod manifest;

use semio_framework_plugin::io::FormatDescriptor;
use semio_framework_plugin::{ArtifactDefinition, ArtifactDefinitionError, PluginAssemblyError};
use semio_s_artifact_stdio_contract::registry::ContributionRegistry;
use semio_s_artifact_stdio_contract::{native_codec_hash, ArtifactContribution, NativeCodecFactory};
pub use semio_s_artifact_stdio_contract::{ArtifactAssembly, CapabilityCounts, CapabilityLedger, NativeCodecFactoryReceipt};
use std::collections::{BTreeMap, BTreeSet};

/// 📚️ Schema exports authored by this concrete deployment owner.
pub const CATALOG_SCHEMA_DOCUMENTS: semio_framework_schema_registry::ScopeSchemaExports = semio_framework_schema_registry::ScopeSchemaExports {
    scope: "hub.compositions.stdio.catalog",
    exports: &[semio_framework_schema_registry::SchemaExport { id: "schema", leaves: semio_framework_schema_registry::FacetLeaves { rust: "", typescript: "", graphql: "", json_schema: include_str!("../../📇️catalog/🧬️schema/🔣️.json"), proto: "" } }],
};

/// 📦 Reads the guest's canonical component identity from its Cargo component contract.
pub fn component_package_id() -> Result<&'static str, PluginAssemblyError> {
    let manifest = include_str!("../../🧩️component/📦️packages/🦀️rust/Cargo.toml");
    if manifest.len() > 64 * 1024 {
        return Err(PluginAssemblyError::new("plugin-assembly.package-id", "component Cargo contract exceeds 64 KiB"));
    }
    let mut component = false;
    let mut component_seen = false;
    let mut package_id = None;
    for raw in manifest.lines() {
        let line = raw.trim();
        if line.starts_with('[') {
            component = line == "[package.metadata.component]";
            if component && std::mem::replace(&mut component_seen, true) {
                return Err(PluginAssemblyError::new("plugin-assembly.package-id", "component Cargo contract repeats its component section"));
            }
        } else if component {
            let Some((key, raw_value)) = line.split_once('=') else { continue };
            if key.trim() != "package" {
                continue;
            }
            if package_id.is_some() {
                return Err(PluginAssemblyError::new("plugin-assembly.package-id", "component Cargo contract repeats its package key"));
            }
            package_id = raw_value.trim().strip_prefix('"').and_then(|value| value.strip_suffix('"'));
        }
    }
    let package_id = package_id.ok_or_else(|| PluginAssemblyError::new("plugin-assembly.package-id", "component package identity is missing"))?;
    let suffix = package_id.strip_prefix("semio:").ok_or_else(|| PluginAssemblyError::new("plugin-assembly.package-id", "component package identity must use the semio namespace"))?;
    if suffix.is_empty() || suffix.starts_with('-') || suffix.ends_with('-') || suffix.contains("--") || !suffix.bytes().all(|byte| byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'-') {
        return Err(PluginAssemblyError::new("plugin-assembly.package-id", "component package identity is not canonical semio:<lowercase-alnum-hyphen>"));
    }
    Ok(package_id)
}

#[cfg(test)]
#[path = "🧪️tests/🔬️component-package-id/🦀️.rs"]
mod component_package_id_tests;

#[derive(Clone, value_derive::FromValue, value_derive::ToValue)]
#[value(deny_unknown_fields)]
struct NativeOpenableProviderSourceV1 {
    schema: String,
    provider_id: String,
    plugin_id: String,
    package_id: String,
    receipts: Vec<NativeOpenableReceiptSourceV1>,
}

#[derive(Clone, value_derive::FromValue, value_derive::ToValue)]
#[value(deny_unknown_fields)]
struct NativeOpenableReceiptSourceV1 {
    artifact: String,
    factory_id: String,
    descriptor_codec_id: String,
    runtime_capability_id: String,
    artifact_kind: String,
    artifact_schema: String,
    extension: String,
    pack_schema_hash: String,
    protocol_source_sha256: String,
    protocol_path: String,
    definition_path: String,
}

fn failure(message: impl Into<String>) -> PluginAssemblyError {
    PluginAssemblyError::new("stdio.definition", message)
}

include!("../../🤖️generated/🧩️composition/🦀️.rs");

pub fn selected_registry() -> Result<ContributionRegistry, PluginAssemblyError> {
    let registry = ContributionRegistry::new(selected_contributions())?;
    if let Some(contribution) = registry.contributions().iter().find(|contribution| contribution.identity == "txt") {
        let formats = (contribution.formats)().map_err(PluginAssemblyError::definition)?;
        if !formats.iter().any(|format| format.mimes.iter().any(|mime| mime == "text/plain")) {
            return Err(failure("TXT must own text/plain"));
        }
    }
    Ok(registry)
}

/// 📊 Returns the selected artifact schemas' validated ledger.
pub fn capability_ledger() -> Result<CapabilityLedger, PluginAssemblyError> {
    selected_registry()?.capability_ledger()
}

/// 🧾 Builds every selected artifact definition in authored order.
pub fn artifact_definitions() -> Result<Vec<ArtifactDefinition>, PluginAssemblyError> {
    selected_registry()?.artifact_definitions()
}

/// 🧭 Assembles every selected artifact package in authored order.
pub fn artifact_assemblies() -> Result<Vec<ArtifactAssembly>, PluginAssemblyError> {
    selected_registry()?.artifact_assemblies()
}

/// 🗂 Derives one selected artifact's formats from its own schema.
pub fn format_descriptors_for(artifact: &str) -> Result<Vec<FormatDescriptor>, ArtifactDefinitionError> {
    selected_registry().map_err(|error| ArtifactDefinitionError::new("stdio.format", error.to_string()))?.format_descriptors_for(artifact)
}

/// 🛂 Derives the selected runtime formats from artifact-owned schemas.
pub fn format_descriptors() -> Result<Vec<FormatDescriptor>, PluginAssemblyError> {
    selected_registry()?.format_descriptors()
}

fn native_codec_factories() -> Vec<NativeCodecFactory> {
    selected_contributions().into_iter().flat_map(|contribution| (contribution.native_codecs)()).collect()
}

/// 🧬 Lists only selected native runtime roots; definition-only artifacts are absent.
pub fn native_codec_artifact_kinds() -> Vec<semio_framework_plugin::ArtifactKindSpec> {
    let mut kinds = Vec::new();
    for factory in native_codec_factories() {
        let kind = (factory.kind)();
        if !kinds.contains(&kind) { kinds.push(kind); }
    }
    kinds
}

fn validate_native_openable_projection(receipts: &[NativeCodecFactoryReceipt], factories: &[NativeCodecFactory]) -> Result<(), PluginAssemblyError> {
    let provider: NativeOpenableProviderSourceV1 = semio_framework_pack_json::from_json_str(include_str!("📜️native-codec-factories.json"), semio_framework_pack_json::JsonMemberPolicy::Reject).map_err(|error| failure(format!("cannot parse native codec receipt projection: {error}")))?;
    if provider.schema != "semio.stdio.native-openable-catalog-provider/v1" || provider.provider_id != "stdio/native-codecs/v1" || provider.plugin_id != "stdio" || provider.package_id != "semio:stdio" {
        return Err(failure("native codec receipt projection identity or closure is invalid"));
    }
    let projected_ids = provider.receipts.iter().map(|receipt| receipt.factory_id.as_str()).collect::<BTreeSet<_>>();
    if projected_ids.len() != provider.receipts.len() {
        return Err(failure("native codec receipt projection repeats a factory identity"));
    }
    let authored = native_codec_factories().into_iter().map(|factory| factory.id).collect::<BTreeSet<_>>();
    if projected_ids != authored {
        return Err(failure("native codec receipt projection differs from its authored composition roster"));
    }
    for receipt in receipts {
        let projected = provider.receipts.iter().find(|projected| projected.factory_id == receipt.factory_id).ok_or_else(|| failure("native codec projection omits a selected factory"))?;
        let factory = factories.iter().find(|factory| factory.id == receipt.factory_id).ok_or_else(|| failure("native codec projection has no exact verified private factory"))?;
        let artifact = factory.artifact;
        if projected.artifact != artifact
            || projected.factory_id != receipt.factory_id
            || projected.descriptor_codec_id != receipt.descriptor_codec_id
            || projected.runtime_capability_id != receipt.runtime_capability_id
            || projected.artifact_kind != receipt.artifact_kind
            || projected.artifact_schema != receipt.schema
            || projected.extension != receipt.extension
            || native_codec_hash(&projected.pack_schema_hash)? != receipt.pack_schema_hash
            || native_codec_hash(&projected.protocol_source_sha256).is_err()
            || !projected.definition_path.starts_with("✏️s/🔌️plugins/🗄️stdio/🗿️artifacts/")
            || !projected.definition_path.ends_with("/📜️artifact-definition.json")
            || !projected.protocol_path.starts_with("✏️s/🔌️plugins/🗄️stdio/🗿️artifacts/")
            || !projected.protocol_path.ends_with("📡️.protocol.semio")
        {
            return Err(failure(format!("native codec receipt projection differs from artifact-owned authority for {}", receipt.factory_id)));
        }
    }
    Ok(())
}

const NATIVE_ARTIFACT_CATALOG_TOPIC: &str = "stdio.artifact-catalog.v1";

#[derive(Clone, Debug, PartialEq, Eq, value_derive::FromValue, value_derive::ToValue)]
#[value(rename_all = "camelCase", deny_unknown_fields)]
struct NativeArtifactCatalogV1 {
    schema: String,
    plugin_id: String,
    package_id: String,
    package_version: String,
    definitions: Vec<NativeCatalogDefinitionV1>,
    codecs: Vec<NativeCatalogCodecV1>,
}

#[derive(Clone, Debug, PartialEq, Eq, value_derive::FromValue, value_derive::ToValue)]
#[value(rename_all = "camelCase", deny_unknown_fields)]
struct NativeCatalogDefinitionV1 {
    identity: String,
    capabilities: Vec<NativeCatalogCapabilityV1>,
}

#[derive(Clone, Debug, PartialEq, Eq, value_derive::FromValue, value_derive::ToValue)]
#[value(rename_all = "camelCase", deny_unknown_fields)]
struct NativeCatalogCapabilityV1 {
    identity: String,
    kind: String,
    descriptor_sha256: String,
    executable: bool,
    claims: Vec<NativeCatalogClaimV1>,
    localizations: Vec<NativeCatalogLocalizationV1>,
}

#[derive(Clone, Debug, PartialEq, Eq, value_derive::FromValue, value_derive::ToValue)]
#[value(deny_unknown_fields)]
struct NativeCatalogClaimV1 {
    namespace: String,
    value: String,
}

#[derive(Clone, Debug, PartialEq, Eq, value_derive::FromValue, value_derive::ToValue)]
#[value(deny_unknown_fields)]
struct NativeCatalogLocalizationV1 {
    locale: String,
    text: String,
}

#[derive(Clone, Debug, PartialEq, Eq, value_derive::FromValue, value_derive::ToValue)]
#[value(rename_all = "camelCase", deny_unknown_fields)]
struct NativeCatalogCodecV1 {
    factory_id: String,
    definition_identity: String,
    descriptor_codec_id: String,
    runtime_capability_id: String,
    artifact_kind: String,
    schema: String,
    extension: String,
    pack_schema_hash: String,
}

fn catalog_hex(bytes: &[u8; 32]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

struct NativeCatalogProjectionBudget {
    projection: usize,
    descriptors: usize,
}

impl NativeCatalogProjectionBudget {
    fn new() -> Self {
        Self { projection: 0, descriptors: 0 }
    }

    fn charge(&mut self, bytes: usize) -> Result<(), PluginAssemblyError> {
        self.projection = self.projection.checked_add(bytes).filter(|value| *value <= 2 * 1024 * 1024).ok_or_else(|| failure("native catalog semantic commitment exceeds 2 MiB"))?;
        Ok(())
    }

    fn descriptor(&mut self, bytes: usize) -> Result<(), PluginAssemblyError> {
        self.descriptors = self.descriptors.checked_add(bytes).filter(|value| *value <= 16 * 1024 * 1024).ok_or_else(|| failure("native catalog descriptor hashing exceeds 16 MiB"))?;
        Ok(())
    }

    fn object(&mut self, fields: &[&str]) -> Result<(), PluginAssemblyError> {
        self.charge(2 + fields.len().saturating_sub(1))?;
        for field in fields {
            self.string(&[field], 64)?;
            self.charge(1)?;
        }
        Ok(())
    }

    fn array(&mut self, length: usize) -> Result<(), PluginAssemblyError> {
        self.charge(2 + length.saturating_sub(1))
    }

    fn string(&mut self, parts: &[&str], maximum: usize) -> Result<(), PluginAssemblyError> {
        let length = parts.iter().try_fold(0usize, |sum, part| sum.checked_add(part.len())).filter(|length| *length > 0 && *length <= maximum).ok_or_else(|| failure("native catalog string exceeds its owned schema bound"))?;
        let mut encoded = 2 + length;
        for byte in parts.iter().flat_map(|part| part.bytes()) {
            encoded += match byte {
                b'"' | b'\\' | 8 | 9 | 10 | 12 | 13 => 1,
                0..=31 => 5,
                _ => 0,
            };
        }
        self.charge(encoded)
    }
}

fn preflight_native_catalog_projection(assemblies: &[ArtifactAssembly], receipts: &[NativeCodecFactoryReceipt], factories: &[NativeCodecFactory]) -> Result<NativeCatalogProjectionBudget, PluginAssemblyError> {
    if assemblies.len() > 4096 || receipts.len() > 4096 || receipts.len() != factories.len() {
        return Err(failure("native catalog projection exceeds its bounds or lacks exact factory closure"));
    }
    let mut budget = NativeCatalogProjectionBudget::new();
    budget.object(&["schema", "pluginId", "packageId", "packageVersion", "definitions", "codecs"])?;
    for value in ["semio.stdio.artifact-catalog/v1", "stdio", component_package_id()?, env!("CARGO_PKG_VERSION")] {
        budget.string(&[value], 16384)?;
    }
    budget.array(assemblies.len())?;
    for assembly in assemblies {
        let definition = assembly.definition();
        let count = definition.capabilities().count();
        if count == 0 || count > 2048 {
            return Err(failure("native catalog capability count exceeds its owned commitment bounds"));
        }
        budget.object(&["identity", "capabilities"])?;
        budget.string(&[definition.identity().as_str()], 4096)?;
        budget.array(count)?;
        for capability in definition.capabilities() {
            if capability.descriptor_bytes().len() > 2 * 1024 * 1024 || capability.claims().len() > 64 || capability.localizations().len() > 64 {
                return Err(failure("native catalog capability exceeds its owned commitment bounds"));
            }
            budget.descriptor(capability.descriptor_bytes().len())?;
            budget.object(&["identity", "kind", "descriptorSha256", "executable", "claims", "localizations"])?;
            budget.string(&[capability.identity().as_str()], 4096)?;
            budget.string(&[capability.kind().as_str()], 16384)?;
            budget.charge(66 + if capability.executable_identity().is_some() { 4 } else { 5 })?;
            budget.array(capability.claims().len())?;
            for claim in capability.claims() {
                budget.object(&["namespace", "value"])?;
                budget.string(&[claim.namespace().as_str()], 16384)?;
                budget.string(&[claim.value()], 16384)?;
            }
            budget.array(capability.localizations().len())?;
            for localization in capability.localizations() {
                budget.object(&["locale", "text"])?;
                budget.string(&[localization.locale().as_str()], 16384)?;
                budget.string(&[localization.text()], 16384)?;
            }
        }
    }
    budget.array(receipts.len())?;
    for receipt in receipts {
        let factory = factories.iter().find(|factory| factory.id == receipt.factory_id).ok_or_else(|| failure("native catalog codec has no private artifact owner"))?;
        budget.object(&["factoryId", "definitionIdentity", "descriptorCodecId", "runtimeCapabilityId", "artifactKind", "schema", "extension", "packSchemaHash"])?;
        budget.string(&[&receipt.factory_id], 16384)?;
        budget.string(&["s.stdio.", factory.artifact], 4096)?;
        budget.string(&[&receipt.descriptor_codec_id], 4096)?;
        budget.string(&[&receipt.runtime_capability_id], 4096)?;
        budget.string(&[&receipt.artifact_kind], 4096)?;
        budget.string(&[&receipt.schema], 16384)?;
        budget.string(&[&receipt.extension], 16384)?;
        budget.charge(66)?;
    }
    Ok(budget)
}

#[cfg(test)]
#[path = "🧪️tests/🔬️catalog-projection-budget/🦀️.rs"]
mod catalog_projection_budget_tests;

fn native_artifact_catalog(registry: &ContributionRegistry, assemblies: &[ArtifactAssembly]) -> Result<NativeArtifactCatalogV1, PluginAssemblyError> {
    let receipts = native_codec_factory_receipts_for(registry, assemblies)?;
    let factories = registry.native_codec_factories();
    preflight_native_catalog_projection(assemblies, &receipts, &factories)?;
    let mut definitions = Vec::with_capacity(assemblies.len());
    for assembly in assemblies {
        let definition = assembly.definition();
        let mut capabilities = Vec::new();
        for capability in definition.capabilities() {
            if capabilities.len() == 2048 || capability.descriptor_bytes().len() > 2 * 1024 * 1024 || capability.claims().len() > 64 || capability.localizations().len() > 64 {
                return Err(failure("native catalog capability exceeds its owned commitment bounds"));
            }
            capabilities.push(NativeCatalogCapabilityV1 {
                identity: capability.identity().as_str().into(),
                kind: capability.kind().as_str().into(),
                descriptor_sha256: catalog_hex(&semio_framework_hash::Sha256::digest(capability.descriptor_bytes())),
                executable: capability.executable_identity().is_some(),
                claims: capability.claims().iter().map(|claim| NativeCatalogClaimV1 { namespace: claim.namespace().as_str().into(), value: claim.value().into() }).collect(),
                localizations: capability.localizations().iter().map(|localization| NativeCatalogLocalizationV1 { locale: localization.locale().as_str().into(), text: localization.text().into() }).collect(),
            });
        }
        if capabilities.is_empty() {
            return Err(failure("native catalog definition has no semantic capabilities"));
        }
        definitions.push(NativeCatalogDefinitionV1 { identity: definition.identity().as_str().into(), capabilities });
    }
    definitions.sort_by(|left, right| left.identity.cmp(&right.identity));
    let identities = definitions.iter().map(|definition| definition.identity.as_str()).collect::<BTreeSet<_>>();
    if identities.len() != assemblies.len() || receipts.len() != factories.len() {
        return Err(failure("native catalog definition and codec ownership is incomplete"));
    }
    let mut codecs = Vec::with_capacity(receipts.len());
    for receipt in receipts {
        let factory = factories.iter().find(|factory| factory.id == receipt.factory_id).ok_or_else(|| failure("native catalog codec has no private artifact owner"))?;
        let definition_identity = format!("s.stdio.{}", factory.artifact);
        if !identities.contains(definition_identity.as_str()) {
            return Err(failure("native catalog codec omits its declared definition owner"));
        }
        codecs.push(NativeCatalogCodecV1 {
            factory_id: receipt.factory_id,
            definition_identity,
            descriptor_codec_id: receipt.descriptor_codec_id,
            runtime_capability_id: receipt.runtime_capability_id,
            artifact_kind: receipt.artifact_kind,
            schema: receipt.schema,
            extension: receipt.extension,
            pack_schema_hash: catalog_hex(&receipt.pack_schema_hash),
        });
    }
    codecs.sort_by(|left, right| left.factory_id.cmp(&right.factory_id));
    Ok(NativeArtifactCatalogV1 { schema: "semio.stdio.artifact-catalog/v1".into(), plugin_id: "stdio".into(), package_id: component_package_id()?.into(), package_version: env!("CARGO_PKG_VERSION").into(), definitions, codecs })
}

/// 📇️ Commits the exact definitions consumed by this guest assembly, without executable addresses.
pub fn artifact_catalog_contribution(assemblies: &[ArtifactAssembly]) -> Result<semio_framework::TopicContribution, PluginAssemblyError> {
    artifact_catalog_contribution_for(&selected_registry()?, assemblies)
}

/// 🧩 Commits the exact authored selection and verifies its native receipt closure.
pub fn artifact_catalog_contribution_for(registry: &ContributionRegistry, assemblies: &[ArtifactAssembly]) -> Result<semio_framework::TopicContribution, PluginAssemblyError> {
    let selected = registry.contributions().iter().map(|contribution| format!("s.stdio.{}", contribution.identity)).collect::<BTreeSet<_>>();
    let actual = assemblies.iter().map(|assembly| assembly.definition().identity().as_str()).collect::<BTreeSet<_>>();
    if actual.len() != assemblies.len() || selected.len() != actual.len() || !actual.iter().all(|identity| selected.contains(*identity)) {
        return Err(failure("native catalog assemblies differ from the exact selected roster"));
    }
    let payload = semio_framework_value::ToValue::to_value(&native_artifact_catalog(registry, assemblies)?);
    if semio_framework_pack_json::to_string(&semio_framework_pack_json::from_dsl_value(&payload)).len() > 2 * 1024 * 1024 {
        return Err(failure("native catalog semantic commitment exceeds 2 MiB"));
    }
    Ok(semio_framework::TopicContribution::new(NATIVE_ARTIFACT_CATALOG_TOPIC, payload))
}

/// 🔗️ Binds consumers to the exact version of their statically linked Stdio catalog.
pub fn native_artifact_catalog_dependency() -> Result<semio_framework::PluginDependency, PluginAssemblyError> {
    Ok(semio_framework::PluginDependency::new("stdio", semio_framework::tree_pin!()))
}

/// 🪢️ Requires the consumer's sole dependency to equal its compiled catalog owner.
pub fn validate_native_artifact_catalog_dependency(dependencies: &[semio_framework::PluginDependency]) -> Result<(), PluginAssemblyError> {
    if dependencies != [native_artifact_catalog_dependency()?].as_slice() {
        return Err(failure("decoded consumer dependencies differ from the exact compiled Stdio catalog"));
    }
    Ok(())
}

/// 🧮️ Recomputes the complete headless projection from the same artifact-owned assemblies.
pub fn native_artifact_catalog_contribution() -> Result<semio_framework::TopicContribution, PluginAssemblyError> {
    artifact_catalog_contribution(&artifact_assemblies()?)
}

fn catalog_value_matches(expected: &semio_framework::DslValue, actual: &semio_framework::DslValue) -> bool {
    use semio_framework::DslValue;
    match (expected, actual) {
        (DslValue::String(left), DslValue::String(right)) => left == right,
        (DslValue::Bool(left), DslValue::Bool(right)) => left == right,
        (DslValue::Array(left), DslValue::Array(right)) => left.len() == right.len() && left.iter().zip(right).all(|(a, b)| catalog_value_matches(a, b)),
        (DslValue::Object(left), DslValue::Object(right)) => {
            left.len() == right.len()
                && left.iter().all(|(key, value)| {
                    let mut matches = right.iter().filter(|(candidate, _)| candidate == key);
                    let Some((_, candidate)) = matches.next() else { return false };
                    matches.next().is_none() && catalog_value_matches(value, candidate)
                })
        }
        _ => false,
    }
}

struct CompiledNativeCatalogExpectation {
    payload: semio_framework::DslValue,
    catalog: NativeArtifactCatalogV1,
}

fn compiled_native_catalog_expectation() -> Result<&'static CompiledNativeCatalogExpectation, PluginAssemblyError> {
    static EXPECTED: std::sync::OnceLock<Result<CompiledNativeCatalogExpectation, PluginAssemblyError>> = std::sync::OnceLock::new();
    EXPECTED
        .get_or_init(|| {
            let contribution = native_artifact_catalog_contribution()?;
            let catalog = contribution.decode().map_err(|error| failure(format!("native catalog owner is not its closed schema: {error}")))?;
            Ok(CompiledNativeCatalogExpectation { payload: contribution.payload, catalog })
        })
        .as_ref()
        .map_err(Clone::clone)
}

/// 🔐️ Admits only the exact guest-committed selected semantic projection.
pub fn validate_native_artifact_catalog_contributions(contributions: &[semio_framework::TopicContribution]) -> Result<(), PluginAssemblyError> {
    if contributions.len() > 256 {
        return Err(failure("native catalog contribution inventory exceeds 256 topics"));
    }
    let mut matches = contributions.iter().filter(|contribution| contribution.topic == "stdio.artifact-catalog" || contribution.topic.starts_with("stdio.artifact-catalog."));
    let actual = matches.next().ok_or_else(|| failure("decoded Stdio descriptor omits its semantic catalog commitment"))?;
    if matches.next().is_some() || actual.topic != NATIVE_ARTIFACT_CATALOG_TOPIC {
        return Err(failure("decoded Stdio descriptor repeats or replaces its semantic catalog topic"));
    }
    let expected = compiled_native_catalog_expectation()?;
    if !catalog_value_matches(&expected.payload, &actual.payload) {
        return Err(failure("decoded Stdio descriptor differs from native artifact semantics"));
    }
    let decoded: NativeArtifactCatalogV1 = actual.decode().map_err(|error| failure(format!("native catalog commitment is not its closed schema: {error}")))?;
    if decoded != expected.catalog {
        return Err(failure("decoded Stdio descriptor differs from its exact native commitment"));
    }
    Ok(())
}

/// 🔎️ Requires every decoded kind to equal the complete artifact-owned native catalog.
pub fn validate_native_codec_artifact_kinds(kinds: &[semio_framework_plugin::ArtifactKindSpec]) -> Result<(), PluginAssemblyError> {
    let expected = native_codec_artifact_kinds();
    if kinds.len() != expected.len() {
        return Err(failure("decoded descriptor omits or adds native artifact kinds"));
    }
    let actual = kinds.iter().map(|kind| (kind.id.as_str(), kind)).collect::<BTreeMap<_, _>>();
    let identities = expected.iter().map(|kind| kind.id.as_str()).collect::<BTreeSet<_>>();
    if actual.len() != kinds.len() || identities.len() != expected.len() || expected.iter().any(|kind| actual.get(kind.id.as_str()).copied() != Some(kind)) {
        return Err(failure("decoded descriptor differs from the complete native artifact catalog"));
    }
    Ok(())
}

/// 🧷 Emits receipts only when schema data explicitly authorizes the exact native factory.
pub fn native_codec_factory_receipts() -> Result<Vec<NativeCodecFactoryReceipt>, PluginAssemblyError> {
    native_codec_factory_receipts_for(&selected_registry()?, &artifact_assemblies()?)
}

/// 🧷 The same receipts, derived from assemblies the caller ALREADY owns.
///
/// The only thing the assemblies are read for here is which artifacts carry a runtime declaration,
/// and `native_artifact_catalog` is handed the complete 36-assembly slice by `plugin()`. Building a
/// second, identical set just to answer that question re-parsed, re-validated and re-BUILT every
/// definition a second time — the single largest avoidable cost of the guest's `describe()`.
fn native_codec_factory_receipts_for(registry: &ContributionRegistry, assemblies: &[ArtifactAssembly]) -> Result<Vec<NativeCodecFactoryReceipt>, PluginAssemblyError> {
    let receipts = registry.native_codec_factory_receipts("stdio", component_package_id()?, env!("CARGO_PKG_VERSION"))?;
    let runtime_artifacts = assemblies
        .iter()
        .filter_map(|assembly| match assembly {
            ArtifactAssembly::Runtime(declaration) => declaration.definition().identity().as_str().strip_prefix("s.stdio."),
            ArtifactAssembly::Definition(_) => None,
        })
        .collect::<BTreeSet<_>>();
    let factories = registry.native_codec_factories();
    let mut factory_ids = BTreeSet::new();
    let mut descriptor_ids = BTreeSet::new();
    let mut receipt_keys = BTreeSet::new();
    for receipt in &receipts {
        let factory = factories.iter().find(|factory| factory.id == receipt.factory_id).ok_or_else(|| failure(format!("receipt {} has no selected artifact factory", receipt.factory_id)))?;
        if !runtime_artifacts.contains(factory.artifact)
            || !factory_ids.insert(receipt.factory_id.as_str())
            || !descriptor_ids.insert(receipt.descriptor_codec_id.as_str())
            || !receipt_keys.insert((receipt.artifact_kind.as_str(), receipt.schema.as_str()))
        {
            return Err(failure(format!("receipt {} is not bijective with one selected runtime artifact", receipt.factory_id)));
        }
    }
    if [receipts.len(), factories.len(), factory_ids.len(), descriptor_ids.len(), receipt_keys.len()].iter().any(|count| *count != factories.len()) {
        return Err(failure("native codec receipts and selected artifact factories are not a complete bijection"));
    }
    validate_native_openable_projection(&receipts, &factories)?;
    Ok(receipts)
}

/// 🧬️ The live receipts the committed `📜️native-codec-factories.json` projection is GENERATED from — the same
/// bijection as [`native_codec_factory_receipts`], but before that projection is compared against them, so the
/// `native-codec-projection` verb can regenerate a projection a schema-hash change made stale.
pub fn live_native_codec_factory_receipts() -> Result<Vec<NativeCodecFactoryReceipt>, PluginAssemblyError> {
    selected_registry()?.native_codec_factory_receipts("stdio", component_package_id()?, env!("CARGO_PKG_VERSION"))
}
//#endregion NativeCodecFactoryReceipts

#[cfg(test)]
#[path = "🧪️tests/🔬️unit/🦀️.rs"]
mod tests;
