//! 📏️ Layout plugin — blueprint/preview document editor bundled as a hot-swappable WASM component.
//!
//! WIRING ONLY. Every `mod` below points at exactly one taxonomy component file with a `#[path]` that is
//! written in full, relative to THIS file's directory (`📦️packages/🦀️rust/`, two levels deeper than the
//! owner root under Shape V2 — hence every leaf path below is prefixed `../../` to reach back out). The
//! grouping modules carry `#[path = "."]` so their own names are not spliced into that base directory —
//! without it, Rust resolves an inline module's children under `<file dir>/<inline mod name>/…` and every
//! leaf path dangles. Do not inline any component file back into this one: the taxonomy validator and the
//! `TaxonomyLibShape` policy lint both fail on it (see master ticket
//! `26/08/05/CRATE-CONSOLIDATION-AND-PLUGIN-TAXONOMY-RESTRUCTURE`, Single-File-Repo hazard ruling).

#[allow(clippy::result_large_err)]
//#region 🗿️Artifacts
mod artifacts {
    pub use semio_s_artifact_layout_layout as layout;
}
//#endregion 🗿️Artifacts

//#region ✏️Editor
mod editor {
    pub use semio_s_artifact_layout_layout_editor::*;
    pub use semio_s_artifact_layout_layout_editor_commands::*;
    pub use semio_s_artifact_layout_layout_editor_panels::document::*;
    pub use semio_s_artifact_layout_layout_editor_commands::modes::edit::windows::blueprint::*;
    pub use semio_s_artifact_layout_layout_editor_panels::catalogue::*;
    pub use semio_s_artifact_layout_layout_editor_panels::inspection::*;
    pub use semio_s_artifact_layout_layout_editor_panels::preflight::*;
    pub use semio_s_artifact_layout_layout_editor_commands::modes::edit::windows::preview::*;
    pub use semio_s_artifact_layout_layout_editor_panels::terminology::*;
    pub use semio_s_artifact_layout_layout_editor_commands::modes::edit::windows::blueprint::config::*;
    pub use semio_s_artifact_layout_layout_editor_commands::modes::edit::windows::blueprint::transient::*;
    pub use semio_s_artifact_layout_layout_editor_commands::modes::edit::windows::*;
    pub use semio_s_artifact_layout_layout_editor_panels::*;
    pub use semio_s_artifact_layout_layout_editor_commands::modes::*;
}
//#endregion ✏️Editor

//#region 👁️Viewer
mod viewer {
    pub use semio_s_artifact_layout_layout_viewer::*;
}
//#endregion 👁️Viewer

//#region 🕸️Wasm
// 🌉️ The wasm-bindgen `LayoutSession` bridge that used to be re-exported here was deleted along
// with `editor::layout::wasm`'s content — nothing ever built it for `wasm32-unknown-unknown`.
//#endregion 🕸️Wasm

//#region 🔖️Plugin
#[path = "../../🦀️.rs"]
pub mod plugin;
pub use plugin::LayoutApps;

//#endregion 🔖️Plugin
