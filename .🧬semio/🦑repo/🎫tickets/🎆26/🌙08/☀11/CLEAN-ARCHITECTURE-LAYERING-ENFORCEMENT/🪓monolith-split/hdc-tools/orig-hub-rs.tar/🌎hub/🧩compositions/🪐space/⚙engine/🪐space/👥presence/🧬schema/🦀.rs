//! 🧬️ schema leaf

use schema::ArtifactSchema;
use std::collections::BTreeMap;

#[derive(Clone, Debug, Default, PartialEq, value_derive::ToValue, value_derive::FromValue, ArtifactSchema)]
#[value(rename_all = "camelCase", default)]
#[artifact_schema(id = "hub.compositions.space.engine.space.presence")]
pub struct SpacePresence {
    #[state(presence)]
    pub camera: BTreeMap<String, SpaceWindowCamera>,
    #[state(presence)]
    pub active_node_id: Option<String>,
    #[state(presence)]
    pub focused_node_id: Option<String>,
    #[state(presence)]
    pub collapsed_node_ids: Vec<String>,
    #[state(presence)]
    pub preview_off_node_ids: Vec<String>,
}

//#region 🔁️Re-exports
/// 🔁️ Entities this module's schema exports and its crate declares elsewhere.
pub use crate::config::SpaceWindowCamera;
//#endregion 🔁️Re-exports
