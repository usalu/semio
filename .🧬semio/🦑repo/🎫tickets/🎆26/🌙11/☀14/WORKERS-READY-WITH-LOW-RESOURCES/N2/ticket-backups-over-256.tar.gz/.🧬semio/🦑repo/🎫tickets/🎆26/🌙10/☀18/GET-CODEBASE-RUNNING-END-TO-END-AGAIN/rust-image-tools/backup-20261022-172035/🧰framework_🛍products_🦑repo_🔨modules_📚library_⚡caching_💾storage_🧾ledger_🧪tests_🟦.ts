import {expect,test} from "bun:test";
import Ajv from "ajv";
import {validateJsonSchemaSubset} from "../../../../../../../../🔨️modules/🧬️schema/✅️validator/📦️packages/🟦️typescript/🟦️.ts";
import budgetPolicy from "../../🔒️enforcement/📦️budget/🔣️policy.json" with {type:"json"};
import schema from "../🧬️schema/🔣️.json" with {type:"json"};
import policy from "../🔣️policy.json" with {type:"json"};
import texts from "../📖️texts/🔣️.json" with {type:"json"};
import fixtures from "./🧫️fixtures/🔣️.json" with {type:"json"};
import {cacheAreaBudgetBytesV1,cacheAreaDirectoryV1,cacheLedgerV1,cacheTextV1,classifyCachePathV1,formatCacheBytesV1,formatCacheReportV1,planCacheCollectionV1,readCacheLedgerV1,requireDeclaredCacheSegmentsV1,type CacheLanguageV1,type CacheReportV1,type CacheTargetV1} from "../🟦️.ts";
import {resolveLanguageV1} from "../../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🗣️language/🟦️.ts";
import {CATALOG_LANGUAGES_V1} from "../../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🗣️language/📖️catalog/🟦️.ts";

const clone=<T>(value:T):T=>JSON.parse(JSON.stringify(value));
const ledger=readCacheLedgerV1(policy);

test("the authored ledger is closed, disjoint and within every budget, and Ajv agrees with the schema validator",()=>{
 expect(cacheLedgerV1()).toEqual(ledger);
 const ajv=new Ajv({strict:true,allowUnionTypes:true}),validate=ajv.compile(schema);
 expect(validate(policy)).toBe(true);
 expect(validateJsonSchemaSubset(schema,policy)).toEqual([]);
 const probes:Array<(document:any)=>void>=[
  document=>{delete document.roots;},
  document=>{document.version=2;},
  document=>{document.areas[0].extra=1;},
  document=>{document.areas[0].kind="folder";},
  document=>{document.areas[0].id="Bad Id";},
  document=>{document.areas[0].writers=[];},
  document=>{document.areas.find((area:any)=>area.id==="go").collect.quietMs=-1;},
  document=>{document.areas.find((area:any)=>area.id==="go").budget={bytes:1.5};},
  document=>{document.areas.find((area:any)=>area.id==="go").budget={bytes:1,basisPoints:1};},
  document=>{document.areas.find((area:any)=>area.id==="go").directory="a\\b";},
  document=>{document.areas.find((area:any)=>area.id==="go").purpose={en:"x"};},
  document=>{document.retirements[0].reason={en:"x",de:""};},
  document=>{document.roots.repository.ignored=[".DS_Store",".DS_Store"];}
 ];
 for(const probe of probes){const document=clone(policy);probe(document);expect(validate(document)).toBe(false);expect(validateJsonSchemaSubset(schema,document).length>0).toBe(true);}
});

test("the semantic closure refuses what the schema cannot see",()=>{
 const refused:Array<[string,(document:any)=>void]>=[
  ["duplicate id",document=>{document.areas[1].id=document.areas[0].id;}],
  ["overlapping retirement",document=>{document.retirements.push({root:"repository",directory:"go/00",quietMs:0,reason:{en:"x",de:"y"}});}],
  ["pattern matching a declared home",document=>{document.areas.find((area:any)=>area.id==="query-index").pattern="^go$";}],
  ["nested budgets beyond the partition",document=>{document.areas.find((area:any)=>area.id==="nx-artifacts").budget={bytes:2**40};}],
  ["root budget exceeded",document=>{document.areas.find((area:any)=>area.id==="go").budget={bytes:30*(1<<30)};}],
  ["partition directory differs from the authored budget",document=>{document.areas.find((area:any)=>area.id==="tools").directory="b/x";}],
  ["tree with both collect and managed",document=>{document.areas.find((area:any)=>area.id==="go").managed={owner:"nx"};}],
  ["tree without a budget",document=>{delete document.areas.find((area:any)=>area.id==="go").budget;}],
  ["lease custody without a resource",document=>{document.areas.find((area:any)=>area.id==="go").collect.custody="lease";}],
  ["resource without lease custody",document=>{document.areas.find((area:any)=>area.id==="go").collect.lease="r";}],
  ["parent segment",document=>{document.areas.find((area:any)=>area.id==="go").directory="a/../b";}],
  ["nested area in an unknown partition",document=>{document.areas.find((area:any)=>area.id==="nx-artifacts").partition="nowhere";}],
  ["two remainders",document=>{const second=clone(document.areas.find((area:any)=>area.id==="cargo-store"));second.id="other";document.areas.push(second);}],
  ["nested overlap",document=>{const second=clone(document.areas.find((area:any)=>area.id==="nx-artifacts"));second.id="other";second.directory="nx/artifacts/deep";document.areas.push(second);}],
  ["share budget on a tree",document=>{document.areas.find((area:any)=>area.id==="go").budget={basisPoints:10};}],
  ["directory and pattern together",document=>{document.areas.find((area:any)=>area.id==="query-index").directory="q";}],
  ["case-folded overlap",document=>{document.retirements.push({root:"repository",directory:"GO",quietMs:0,reason:{en:"x",de:"y"}});}]
 ];
 for(const[name,mutate]of refused){const document=clone(policy);mutate(document);expect(()=>readCacheLedgerV1(document),name).toThrow("Closed cache ledger required");}
});

test("budgets resolve exactly: explicit bytes, a share of the partition, and the remainder with its siblings",()=>{
 const bytes=(id:string)=>cacheAreaBudgetBytesV1(ledger,ledger.areas.find(area=>area.id===id)!);
 expect(bytes("nx-artifacts")).toBe(3*1024**3);
 expect(bytes("bazel-actions")).toBe(Math.floor(budgetPolicy.partitions.products.maximumLogicalBytes*4000/10000));
 expect(bytes("cargo-home")).toBe(3*1024**3);expect(bytes("unit-cache")).toBe(24*1024**3);expect(bytes("cargo-store")).toBe(budgetPolicy.partitions.rust.maximumLogicalBytes-30*1024**3);
 expect(bytes("rust")).toBe(Math.min(budgetPolicy.partitions.rust.capacityBytes,budgetPolicy.partitions.rust.maximumLogicalBytes));
 expect(bytes("control")).toBeNull();
 const loose=ledger.areas.filter(area=>area.root==="repository"&&area.kind==="tree").reduce((sum,area)=>sum+(bytes(area.id)??0),0);
 expect(loose).toBeLessThanOrEqual(ledger.roots.repository.maximumBytes);
 expect(ledger.areas.filter(area=>area.kind==="partition").map(area=>area.partition).sort()).toEqual(Object.keys(budgetPolicy.partitions).sort());
 expect(cacheAreaDirectoryV1("/w",ledger,ledger.areas.find(area=>area.id==="nx-artifacts")!)).toBe("/w/"+budgetPolicy.partitions.rust.directory+"/m/nx/artifacts");
 expect(cacheAreaDirectoryV1("/w",ledger,ledger.areas.find(area=>area.id==="cargo-store")!)).toBe("/w/"+budgetPolicy.partitions.rust.directory+"/m");
 expect(cacheAreaDirectoryV1("/w",ledger,ledger.areas.find(area=>area.id==="query-index")!)).toBeNull();
 expect(()=>cacheAreaDirectoryV1("relative",ledger,ledger.areas[0]!)).toThrow("Canonical workspace required");
});

test("the plans of the hand-written cases are exactly what the rules say",()=>{
 for(const row of fixtures.plans){
  const[plan]=planCacheCollectionV1([row.target as CacheTargetV1],fixtures.now);
  expect(plan!.removals.map(removal=>[removal.name,removal.reason]),row.name).toEqual(row.removals);
  expect(plan!.kept.map(kept=>[kept.name,kept.reason]),row.name).toEqual(row.kept);
  expect(plan!.retainedBytes,row.name).toBe(row.retained);
  expect(plan!.overBudgetBytes,row.name).toBe(row.over);
  expect(plan!.removals.reduce((sum,removal)=>sum+removal.bytes,0)+plan!.retainedBytes,row.name).toBe(plan!.totalBytes);
 }
});

test("planning is pure and never removes a held or quiet unit",()=>{
 const target:CacheTargetV1={id:"p",kind:"retired",budgetBytes:0,unusedAgeMs:0,quietMs:60000,units:[{name:"a",bytes:5,recencyMs:1,held:"pid:1"},{name:"b",bytes:5,recencyMs:fixtures.now-1},{name:"c",bytes:5,recencyMs:1}]},frozen=JSON.stringify(target),first=planCacheCollectionV1([target],fixtures.now),second=planCacheCollectionV1([target],fixtures.now);
 expect(JSON.stringify(target)).toBe(frozen);
 expect(first).toEqual(second);
 expect(first[0]!.removals.map(row=>row.name)).toEqual(["c"]);
 expect(first[0]!.kept.map(row=>[row.name,row.reason])).toEqual([["a","held"],["b","quiet"]]);
});

test("every path is classified as an area, a container, a retired root, an ignored file or nobody's",()=>{
 for(const row of fixtures.classification){
  const actual=classifyCachePathV1(ledger,row.root as "repository"|"native",row.path);
  expect(actual.kind,row.root+":"+row.path).toBe(row.kind as typeof actual.kind);
  if("id" in row)expect(actual.id,row.root+":"+row.path).toBe(row.id);
 }
});

test("the runtime door accepts only declared homes and says so in both languages",()=>{
 for(const parts of fixtures.segments.accepted)expect(()=>requireDeclaredCacheSegmentsV1(parts,ledger),JSON.stringify(parts)).not.toThrow();
 for(const parts of fixtures.segments.refused)expect(()=>requireDeclaredCacheSegmentsV1(parts,ledger),JSON.stringify(parts)).toThrow("Declared cache area required");
 try{requireDeclaredCacheSegmentsV1(["e1"],ledger);}catch(error){expect((error as Error).message).toBe(cacheTextV1("en","error.undeclared",{segment:"e1"})+"\n"+cacheTextV1("de","error.undeclared",{segment:"e1"}));}
});

test("every message exists in English and German with the same placeholders, and English comes first",()=>{
 expect(texts.languages).toEqual(["en","de"]);
 const names=(text:string)=>[...text.matchAll(/\{([a-z]+)\}/gu)].map(match=>match[1]!).sort();
 for(const[key,row]of Object.entries(texts.messages)){expect(names(row.en),key).toEqual(names(row.de));expect(typeof row.en).toBe("string");expect(typeof row.de).toBe("string");}
 for(const key of Object.keys(texts.messages).filter(key=>!key.startsWith("gc.mode.")))expect((texts.messages as any)[key].en.length>0&&(texts.messages as any)[key].de.length>0,key).toBe(true);
 expect(()=>cacheTextV1("en","nothing.here")).toThrow("Declared cache message required");
 expect(()=>cacheTextV1("en","gc.scan",{id:"x"})).toThrow("Cache message variable missing");
 const used=new Set<string>();for(const area of ledger.areas){expect(area.purpose.en.length>0&&area.purpose.de.length>0).toBe(true);used.add(area.id);}
 expect(used.size).toBe(ledger.areas.length);
});

test("the language is the flag, then the environment, and nothing is assumed",()=>{
 const pick=(args:string[],environment:Record<string,string>)=>resolveLanguageV1(CATALOG_LANGUAGES_V1,args,environment,()=>[]).language;
 expect(pick(["--lang","de"],{LANG:"en_US.UTF-8"})).toBe("de");
 expect(pick([],{SEMIO_LANGUAGE:"de",LANG:"en_US.UTF-8"})).toBe("de");
 expect(pick([],{LC_ALL:"de_DE.UTF-8"})).toBe("de");
 expect(pick([],{LANG:"en_GB.UTF-8"})).toBe("en");
 expect(()=>pick([],{LANG:"fr_FR.UTF-8"})).toThrow("--lang=en|de");
 expect(()=>pick([],{})).toThrow("SEMIO_LANGUAGE=en|de");
 expect(()=>pick(["--lang","fr"],{})).toThrow("Unknown language: fr (en|de)");
});

test("the status report renders the same in both languages from the same data",()=>{
 const report=fixtures.report as unknown as CacheReportV1;
 for(const language of["en","de"] as CacheLanguageV1[])expect(formatCacheReportV1(language,report,ledger),language).toEqual(fixtures.reportLines[language]);
 expect(formatCacheBytesV1(0)).toBe("0 B");
 expect(formatCacheBytesV1(1023)).toBe("1023 B");
 expect(formatCacheBytesV1(1024)).toBe("1.00 KiB");
 expect(formatCacheBytesV1(1536*1024)).toBe("1.50 MiB");
 expect(formatCacheBytesV1(1024**4*3)).toBe("3.00 TiB");
 const clean:CacheReportV1={...report,retired:[],undeclared:[]};
 expect(formatCacheReportV1("en",clean,ledger).at(-1)).toBe("Nothing retired or undeclared remains.");
 expect(formatCacheReportV1("de",clean,ledger).at(-1)).toBe("Es bleibt nichts Stillgelegtes oder Nicht-Deklariertes übrig.");
});
