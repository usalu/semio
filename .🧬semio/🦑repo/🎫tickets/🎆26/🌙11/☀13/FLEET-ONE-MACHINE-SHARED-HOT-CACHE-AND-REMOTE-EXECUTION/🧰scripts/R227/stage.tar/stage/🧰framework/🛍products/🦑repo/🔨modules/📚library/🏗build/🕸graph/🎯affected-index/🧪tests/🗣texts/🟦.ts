/** 🗣️ Contract: the English and German texts of the affected question are the schema's table, have the same keys and the same placeholders, and every key renders in both languages. */
import {expect,test} from "bun:test";
import schema from "../../🧬️schema/🔣️.json" with {type:"json"};
import {AFFECTED_MESSAGES_V1,renderAffectedMessageV1} from "../../🟨️.mjs";

test("both languages equal the schema table and share their placeholders",()=>{
 const table=schema.definitions.Messages.const,fields=(text:string)=>[...text.matchAll(/\{(\w+)\}/gu)].map(match=>match[1]).sort();
 expect(AFFECTED_MESSAGES_V1).toEqual(table);expect(Object.keys(table.de).sort()).toEqual(Object.keys(table.en).sort());
 for(const key of Object.keys(table.en) as (keyof typeof table.en)[]){
  expect(fields(table.de[key])).toEqual(fields(table.en[key]));
  const values=Object.fromEntries(fields(table.en[key]).map(name=>[name,"v"]));
  for(const language of["en","de"] as const)expect(renderAffectedMessageV1(key,values,language)).not.toMatch(/\{/u);
 }
 expect(()=>renderAffectedMessageV1("answered",{},"en")).toThrow();
});
