"""🧠️ Independent Python oracle of the early memory check (standard library only; the lock is read with `tomllib` when the interpreter has it, else with a block regex; neither is the parser of the implementation): reads the corpus and the texts of the policy file and prints the plans, peaks, closures and lines as one JSON document."""
import json, math, re, sys

try:
    import tomllib
except ModuleNotFoundError:
    tomllib = None

corpus = json.load(open(sys.argv[1], encoding="utf-8"))
policy = json.load(open(sys.argv[2], encoding="utf-8"))["definitions"]["Policy"]["const"]
MEBI = 1048576

def holdable(host):
    return math.floor(max(0, host["totalMegabytes"] - host["floorMegabytes"] - host["interactiveReserveMegabytes"]) * host["budgetBasisPoints"] / 10000)

def growth(need, grant, local, fleet):
    if need <= grant:
        return {"kind": "fits"}
    mine = holdable(local)
    extra = need - grant
    if need <= mine:
        room = max(0, local.get("availableMegabytes", math.inf) - local["floorMegabytes"] - local["interactiveReserveMegabytes"])
        return {"kind": "grow" if extra <= room else "wait"}
    best = (mine, local["origin"])
    for host in fleet or []:
        if host["origin"] != local["origin"] and holdable(host) > best[0]:
            best = (holdable(host), host["origin"])
    if fleet is None or best[0] >= need:
        return {"kind": "beyond-host", "largest": best[0], "origin": best[1]}
    return {"kind": "refused", "largest": best[0], "origin": best[1]}

def plan(case, pol):
    cls = pol["classes"][pol["workerClass"]]
    rows = []
    for peak in case["peaks"]:
        if case["scope"] is not None and peak["crate"] not in case["scope"]:
            continue
        budget = cls["finalMegabytes"] if peak["kind"] == "final" else cls["libraryMegabytes"]
        if peak["peakMegabytes"] <= budget:
            continue
        verdict = growth(peak["peakMegabytes"], budget, case["local"], case["fleet"])
        if verdict["kind"] == "fits":
            continue
        name = {"beyond-host": "beyond-host", "refused": "unbuildable"}.get(verdict["kind"]) or ("serial-backend" if peak["kind"] == "final" else "constrained-threads")
        row = {"unit": peak["crate"] + "|" + peak["target"], "kind": peak["kind"], "peakMegabytes": peak["peakMegabytes"], "budgetMegabytes": budget, "source": peak["source"], "listed": any(c["crate"] == peak["crate"] and c["target"] == peak["target"] for c in pol["carving"]), "plan": name, "waits": verdict["kind"] == "wait", "holdableMegabytes": holdable(case["local"])}
        if "largest" in verdict:
            row["largestMegabytes"] = verdict["largest"]
            row["largestOrigin"] = verdict["origin"]
        rows.append(row)
    rows.sort(key=lambda r: (-r["peakMegabytes"], r["unit"]))
    return rows

def kind_of(types):
    return "final" if any(t in ("cdylib", "bin", "dylib", "staticlib") for t in types.split(",")) else "library"

def telemetry(rows, mode):
    best = {}
    for row in rows:
        parts = row["key"].split("|")
        head, target, profile, types = (parts + ["", "", "", ""])[:4]
        if "@" not in head:
            continue
        crate = head.split("@", 1)[1]
        value = row["peakRssBytes"]
        if not crate or not target or value is None or value <= 0:
            continue
        if mode is not None and profile not in (mode, "-"):
            continue
        peak = math.ceil(value / MEBI)
        unit = crate + "|" + target
        if unit not in best or best[unit]["peakMegabytes"] < peak:
            best[unit] = {"crate": crate, "target": target, "kind": kind_of(types), "peakMegabytes": peak, "source": "telemetry"}
    return sorted(best.values(), key=lambda p: (p["crate"], p["target"]))

def warden(states, now):
    best = {}
    for state in states:
        alarms = state.get("lastAlarms") if isinstance(state, dict) else None
        if not isinstance(alarms, list):
            continue
        for alarm in alarms:
            ceiling = alarm.get("ceiling") or {}
            unit, peak, at = ceiling.get("unit"), alarm.get("megabytes"), alarm.get("atMs")
            if alarm.get("reason") != policy["alarmReason"] or not isinstance(unit, str) or not isinstance(peak, (int, float)) or peak <= 0 or not isinstance(at, (int, float)) or now - at > policy["maximumAlarmAgeMilliseconds"]:
                continue
            cut = unit.rfind("|")
            if cut < 1 or cut == len(unit) - 1:
                continue
            value = math.ceil(peak)
            if unit not in best or best[unit]["peakMegabytes"] < value:
                best[unit] = {"crate": unit[:cut], "target": unit[cut + 1:], "kind": "final" if ceiling.get("kind") == "final" else "library", "peakMegabytes": value, "source": "warden"}
    return sorted(best.values(), key=lambda p: (p["crate"], p["target"]))

def merge(lists):
    best, measured = {}, {}
    for peaks in lists:
        for p in peaks:
            unit = p["crate"] + "|" + p["target"]
            if p["source"] != "carving" and (unit not in measured or p["kind"] == "final"):
                measured[unit] = p["kind"]
            if unit not in best or best[unit]["peakMegabytes"] < p["peakMegabytes"]:
                best[unit] = p
    return sorted(({**p, "kind": measured.get(unit, p["kind"])} for unit, p in best.items()), key=lambda p: (p["crate"], p["target"]))

def closure(lock, roots):
    if tomllib is not None:
        packages = tomllib.loads(lock)["package"]
    else:
        packages = []
        for block in re.split(r"(?m)^\[\[package\]\]\n", lock)[1:]:
            name = re.search(r'(?m)^name = "([^"]+)"', block).group(1)
            listed = re.search(r"(?ms)^dependencies = \[(.*?)\]", block)
            packages.append({"name": name, "dependencies": re.findall(r'"([^"]+)"', listed.group(1)) if listed else []})
    graph = {}
    for package in packages:
        graph.setdefault(package["name"], set()).update(dep.split(" ")[0] for dep in package.get("dependencies", []))
    if any(root not in graph for root in roots):
        return None
    seen, pending = set(), list(roots)
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        pending.extend(graph[name] - seen)
    return sorted(name.replace("-", "_") for name in seen)

def fill(template, values):
    out = template
    for key, value in values.items():
        out = out.replace("{" + key + "}", str(value))
    return out

def lines(rows, language, host):
    if not rows:
        return []
    texts = policy["texts"][language]
    shown = rows[:policy["maximumRows"]]
    out = [fill(texts["header"], {"count": len(rows), "total": host["totalMegabytes"], "holdable": host["holdableMegabytes"]})]
    for row in shown:
        out.append(fill(texts[row["plan"]], {"unit": row["unit"], "peak": row["peakMegabytes"], "budget": row["budgetMegabytes"], "source": row["source"], "largest": row.get("largestMegabytes", 0), "origin": row.get("largestOrigin", "-")}))
    if len(rows) > len(shown):
        out.append(fill(texts["more"], {"more": len(rows) - len(shown)}))
    if any(row["waits"] for row in rows):
        out.append(texts["waits"])
    return out

plans = {case["name"]: plan(case, corpus["policy"]) for case in corpus["plans"]}
many = [{"unit": "u%02d|host" % index, "kind": "library", "peakMegabytes": 2000 + index, "budgetMegabytes": 1536, "source": "telemetry", "listed": False, "plan": "constrained-threads", "waits": False, "holdableMegabytes": 9216} for index in range(corpus["lines"]["many"]["count"])]
many.sort(key=lambda r: (-r["peakMegabytes"], r["unit"]))
host = corpus["lines"]["host"]
rendered = {language: {name: lines(plans[name], language, host) for name in corpus["lines"]["cases"]} for language in ("en", "de")}
for language in ("en", "de"):
    rendered[language]["many"] = lines(many, language, host)
print(json.dumps({
    "plans": plans,
    "telemetry": [telemetry(corpus["telemetry"]["rows"], mode) for mode in corpus["telemetry"]["modes"]],
    "warden": warden(corpus["warden"]["states"], corpus["warden"]["nowMs"]),
    "merge": merge(corpus["merge"]["lists"]),
    "closure": [closure(corpus["closure"]["lock"], roots) for roots in corpus["closure"]["cases"]],
    "lines": rendered,
}, ensure_ascii=False))
