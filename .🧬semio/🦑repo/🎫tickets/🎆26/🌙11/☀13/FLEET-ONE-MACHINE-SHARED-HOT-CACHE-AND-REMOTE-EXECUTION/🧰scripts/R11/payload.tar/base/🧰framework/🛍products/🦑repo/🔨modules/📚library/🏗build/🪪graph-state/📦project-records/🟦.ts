import{createHash,randomBytes}from"node:crypto";
import{existsSync,readFileSync,statSync,writeFileSync}from"node:fs";
import{hostname}from"node:os";
import schema from"./🧬️schema/🔣️.json"with{type:"json"};
import{graphPlatformV1,type GraphStateV1}from"../🟦️.ts";
import{recordPlatformV1}from"../🌍️platform-class/🟦️.ts";
import{dependencyGenerationV1,localRowsV1,portableRowsV1,type ObservationRowV1}from"./🧳️portable/🟦️.ts";
import{decideGraphEntryV1,expandRootV1,graphEntryKeyV1,graphFleetClientV1,neutralizeRootV1,publishGraphEntryV1,type GraphFleetClientV1,type GraphHoldV1}from"../🛰️exchange/🟦️.ts";
import{graphFleetSettingsV1}from"../🧶️nx/🟦️.ts";
import{remoteCacheFetchV1}from"../../🌐️remote-cache/🛰️fleet/🟦️.ts";

type Environment=Readonly<Record<string,string|undefined>>;
/** 📦️ What the inference seam hands over for one project: where its record lives, which project it is, the key text it was computed under, and how to read and write the record locally. */
export type ProjectRecordInfoV1=Readonly<{cachePath:string;fleet:string;keyText:string;exportRecord():unknown;import(portable:unknown):Promise<boolean>}>;
/** 🚪️ The answer of the gate: whether the record was taken from the fleet, and how to store the computed one or give the claim back. */
export type ProjectGateV1=Readonly<{seeded:boolean;publish():void;abandon():Promise<void>}>;
export type ProjectFleetPortV1=Readonly<{gate(info:ProjectRecordInfoV1):Promise<ProjectGateV1>;offer(info:ProjectRecordInfoV1):Promise<void>;flush():Promise<string>;stats():Readonly<Record<"seeded"|"published"|"offered"|"waited"|"computed",number>>}>;

/** 🚩️ Where the fleet marker of a stored project record lives: beside the record, named after it; the closure proof of the graph store knows this name. */
export const projectRecordMarkerPathV1=(cachePath:string)=>cachePath+".fleet";
const ZERO="0".repeat(64),sha=(text:string)=>createHash("sha256").update(text).digest("hex"),MAXIMUM_OFFERS=64;

/** 🧮️ The state a project record is stored under: the digest of the record key (inference revision and the project's own identity) with the root replaced by the token, the platform class (`posix-shared` for macOS and Linux, the exact platform for Windows and for a project whose key names a host-bound declaration), and one slot per project so that a newer record of a project supersedes only its own older ones. It names nothing of the machine, the generation or the module-load state of the producer: the record carries every observation it consumed, and a taker checks them against its own tree before it uses the record, so a record is reusable by every machine whose project inputs equal the producer's. A record that does not hold in the taker's tree is replaced by the taker's own. */
export function projectRecordStateV1(input:Readonly<{root:string;fleet:string;keyText:string;platform:string}>):GraphStateV1{
 const neutral=(text:string)=>Buffer.from(neutralizeRootV1(Buffer.from(text),input.root)).toString("utf8"),platform=recordPlatformV1(input.keyText,input.platform),digest=sha(JSON.stringify(["project-inference",neutral(input.keyText),platform,neutral(input.fleet)]));
 return Object.freeze({version:1,frame:Object.freeze({kind:"project-inference" as const,tooling:sha(neutral(input.fleet)),implementation:ZERO,platform,extra:Object.freeze({})}),names:ZERO,content:ZERO,files:0,contentFiles:0,digest});
}

/** 🌐️ The port of one process: it takes a missing project record from the fleet cache, claims the computation of a record nobody has (so eight machines split the projects), stores finished records and offers the records that were computed earlier. Every fault ends in "compute locally". `undefined` when no fleet cache is configured. */
export function createProjectFleetPortV1(input:Readonly<{root:string;environment:Environment;client?:GraphFleetClientV1;owner?:string;platform?:string;say?(line:string):void}>):ProjectFleetPortV1|undefined{
 const settings=input.client===undefined?graphFleetSettingsV1(input.root,input.environment):undefined;
 if(input.client===undefined&&settings===undefined)return undefined;
 const client=input.client??graphFleetClientV1(settings!,{fetch:remoteCacheFetchV1(input.environment,{root:input.root})}),platform=input.platform??graphPlatformV1(),owner=input.owner??`${hostname()}:${process.pid}:${randomBytes(3).toString("hex")}`,pending=new Set<Promise<unknown>>(),counts={seeded:0,published:0,offered:0,waited:0,computed:0};
 const say=input.say??((line:string)=>{try{process.stderr.write(line+"\n");}catch{}}),language=(input.environment.SEMIO_LANGUAGE==="de"?"de":"en") as "en"|"de";
 const decided=()=>{if((counts.seeded+counts.computed)%50===0)say(schema.definitions.Texts.const[language].progress.replace(/\{(\w+)\}/gu,(_all,name:string)=>String((counts as Record<string,number>)[name]??0)));};
 const stateOf=(info:ProjectRecordInfoV1)=>projectRecordStateV1({root:input.root,fleet:info.fleet,keyText:info.keyText,platform});
 const track=<T>(work:Promise<T>):Promise<T>=>{pending.add(work);void work.finally(()=>pending.delete(work)).catch(()=>undefined);return work;};
 const documentsOf=(info:ProjectRecordInfoV1)=>{const portable=info.exportRecord() as {observations:readonly ObservationRowV1[]}|undefined;if(portable===undefined)return undefined;return[{name:"record",bytes:neutralizeRootV1(Buffer.from(JSON.stringify({...portable,observations:portableRowsV1(portable.observations,input.root)})),input.root)}];};
 const marker=(info:ProjectRecordInfoV1)=>projectRecordMarkerPathV1(info.cachePath);
 const versionOf=(info:ProjectRecordInfoV1,state:GraphStateV1)=>{try{const status=statSync(info.cachePath);return`${state.digest}:${status.size}:${Math.floor(status.mtimeMs)}`;}catch{return state.digest;}};
 const mark=(info:ProjectRecordInfoV1,state:GraphStateV1)=>{try{writeFileSync(marker(info),versionOf(info,state));}catch{}};
 const publisher=(info:ProjectRecordInfoV1,state:GraphStateV1,hold:GraphHoldV1|undefined)=>{let done=false;return{
  publish(){if(done)return;done=true;void track((async()=>{const documents=documentsOf(info);if(documents===undefined){await hold?.release().catch(()=>undefined);return false;}const stored=await publishGraphEntryV1({client,state,owner,documents,...(hold===undefined?{}:{hold})});if(stored){counts.published++;mark(info,state);}return stored;})());},
  async abandon(){if(done)return;done=true;await hold?.release().catch(()=>undefined);}};};
 return Object.freeze({
  async gate(info){
   const state=stateOf(info),decision=await decideGraphEntryV1({client,state,owner});
   if(decision.outcome==="hit"){
    const document=decision.documents.find(row=>row.name==="record");
    try{
     if(document!==undefined){const shared=JSON.parse(Buffer.from(expandRootV1(document.bytes,input.root)).toString("utf8")) as {observations:readonly ObservationRowV1[]},ok=await info.import({...shared,observations:localRowsV1(shared.observations,dependencyGenerationV1(input.root))});if(ok){counts.seeded++;decided();if(decision.via==="wait")counts.waited++;mark(info,state);return{seeded:true,...publisher(info,state,undefined)};}}
    }catch{}
    return{seeded:false,...publisher(info,state,undefined)};
   }
   counts.computed++;decided();
   return{seeded:false,...publisher(info,state,decision.hold)};
  },
  async offer(info){
   if(!client.settings.upload||!client.usable())return;
   while(pending.size>=MAXIMUM_OFFERS)await Promise.race([...pending].map(work=>work.catch(()=>undefined)));
   const state=stateOf(info);
   try{if(existsSync(marker(info))&&readFileSync(marker(info),"utf8")===versionOf(info,state))return;}catch{}
   void track((async()=>{
    const documents=documentsOf(info);if(documents===undefined)return false;
    const stored=await publishGraphEntryV1({client,state,owner,documents});if(stored){counts.offered++;mark(info,state);}return stored;
   })().catch(()=>false));
  },
  async flush(){await Promise.allSettled([...pending]);const texts=schema.definitions.Texts.const;return(["en","de"] as const).map(language=>texts[language].summary.replace(/\{(\w+)\}/gu,(_all,name:string)=>String((counts as Record<string,number>)[name]??0))).join(" | ");},
  stats:()=>Object.freeze({...counts}),
 });
}
