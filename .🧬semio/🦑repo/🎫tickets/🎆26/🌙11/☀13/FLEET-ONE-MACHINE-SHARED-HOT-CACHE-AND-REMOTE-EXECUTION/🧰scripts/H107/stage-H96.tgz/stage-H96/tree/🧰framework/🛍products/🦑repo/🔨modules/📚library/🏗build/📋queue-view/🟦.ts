import {createHash} from "node:crypto";
import {progressDurationTextV1,progressMedianV1,progressRateTextV1,type ProgressRateEstimateV1} from "../📈️progress-rate/🟦️.ts";
import schema from "./🧬️schema/🔣️.json" with {type:"json"};

export type QueueViewLanguageV1="en"|"de";
export type QueueViewPolicyV1=Readonly<typeof schema.definitions.Policy.const>;
export type QueueViewSourceV1="progress"|"history"|"class"|"fallback";
export type QueueViewRowV1=Readonly<{key:string;class:string;agents:readonly string[];tickets:number;reserveMegabytes:number;runMs?:number;progress?:Readonly<{done:number;total?:number}>;estimate?:ProgressRateEstimateV1}>;
export type QueueViewSnapshotV1=Readonly<{atMs:number;hostBudgetMegabytes:number;running:readonly QueueViewRowV1[];queued:readonly QueueViewRowV1[]}>;
export type QueueViewHistoryV1=Readonly<{keys:Readonly<Record<string,readonly number[]>>;classes:Readonly<Record<string,readonly number[]>>}>;
export type QueueViewJobV1=Readonly<{key:string;class:string;agents:readonly string[];watchers:number;merged:number;reserveMegabytes:number;position?:number;startsInMs:number|null;endsInMs:number|null;source:QueueViewSourceV1;stalled:boolean;progress?:Readonly<{done:number;total?:number;rate:number|null}>}>;
export type QueueViewV1=Readonly<{version:1;atMs:number;budgetMegabytes:number;reservedMegabytes:number;running:readonly QueueViewJobV1[];queued:readonly QueueViewJobV1[];drainsInMs:number|null;merged:number}>;
export type QueueAdmissionV1=Readonly<{action:"attach"|"enqueue";key:string;position?:number;running?:boolean;startsInMs:number|null;endsInMs:number|null;watchers:number}>;
export type QueueRequestV1=Readonly<{key:string;class:string;agent:string;reserveMegabytes:number}>;

/** 📋️ The declared numbers: fallback duration, horizon, backfill, history bound and the presentation flags that never make two requests different; the schema file is the single source.
 * @see ./🧬️schema/🔣️.json */
export const QUEUE_VIEW_POLICY_V1:QueueViewPolicyV1=Object.freeze({...schema.definitions.Policy.const});
const texts=schema.definitions.Texts.const as Readonly<Record<string,Readonly<Record<QueueViewLanguageV1,string>>>>;

/** 🔑️ The identity of a request: SHA-256 of the canonical JSON of the command and its arguments with the presentation flags (`--json`, `--lang`, `--agent`, `--progress`, …, with their values) removed, so a text and a JSON invocation of the same build, or two agents with different languages, are one request. Argument order is kept: two orders are never merged. After `--` nothing is removed. */
export function queueRequestKeyV1(command:string,args:readonly string[],policy:QueueViewPolicyV1=QUEUE_VIEW_POLICY_V1):string{
 const kept:string[]=[];let rest=false;
 for(let at=0;at<args.length;at++){
  const token=args[at]!;
  if(rest||!token.startsWith("--")||token==="--"){if(token==="--")rest=true;kept.push(token);continue;}
  const name=token.split("=")[0]!;
  if(!policy.presentationFlags.includes(name)){kept.push(token);continue;}
  if(!token.includes("=")&&policy.valueFlags.includes(name)&&at+1<args.length&&!args[at+1]!.startsWith("--"))at++;
 }
 return createHash("sha256").update(JSON.stringify({command,args:kept})).digest("hex");
}

const durationOf=(row:QueueViewRowV1,running:boolean,history:QueueViewHistoryV1,policy:QueueViewPolicyV1):Readonly<{ms:number;source:QueueViewSourceV1}>=>{
 const estimate=row.estimate,runMs=row.runMs??0;
 if(running&&estimate!==undefined&&!estimate.stalled&&estimate.etaMs!==null&&estimate.source==="plan")return{ms:estimate.etaMs,source:"progress"};
 const own=history.keys[row.key]?.slice(-policy.historyKeep),kind=history.classes[row.class]?.slice(-policy.historyKeep);
 if(own!==undefined&&own.length>0){const median=progressMedianV1(own);return{ms:running?Math.max(0,median-runMs):median,source:"history"};}
 if(kind!==undefined&&kind.length>0){const median=progressMedianV1(kind);return{ms:running?Math.max(0,median-runMs):median,source:"class"};}
 return{ms:running?Math.max(0,policy.fallbackMs-runMs):policy.fallbackMs,source:"fallback"};
};

type Interval={start:number;end:number;reserve:number};

const placeJob=(intervals:readonly Interval[],budget:number,duration:number,reserve:number,notBefore:number):number=>{
 const usage=(at:number)=>intervals.reduce((sum,item)=>item.start<=at&&at<item.end?sum+item.reserve:sum,0),need=Math.min(reserve,budget);
 const candidates=[...new Set([notBefore,...intervals.map(item=>item.end).filter(end=>end>=notBefore)])].sort((a,b)=>a-b);
 for(const start of candidates){
  const points=[start,...intervals.map(item=>item.start).filter(point=>point>start&&point<start+duration)];
  if(points.every(point=>usage(point)+need<=budget))return start;
 }
 return candidates[candidates.length-1]!;
};

/** 🧮️ Simulates the queue like the scheduler runs it: running jobs end after their remaining time (measured progress ETA, else the median of earlier runs of the same job, else of its class, else the fallback, minus the time already run), queued jobs take the earliest time at which the host memory budget has room for their reservation for their whole duration (backfill; without it no job starts before the one ahead). Returns the view with start and end offsets, merged duplicate counts (`tickets - 1`) and the drain time (`null` while a running job is stalled). */
export function queueViewV1(snapshot:QueueViewSnapshotV1,history:QueueViewHistoryV1={keys:{},classes:{}},policy:QueueViewPolicyV1=QUEUE_VIEW_POLICY_V1):QueueViewV1{
 const budget=snapshot.hostBudgetMegabytes,intervals:Interval[]=[];
 const progressOf=(row:QueueViewRowV1)=>row.progress===undefined?undefined:{done:row.progress.done,...row.progress.total===undefined?{}:{total:row.progress.total},rate:row.estimate?.rate??null};
 const running=snapshot.running.map(row=>{
  const found=durationOf(row,true,history,policy),stalled=row.estimate?.stalled===true;
  intervals.push({start:0,end:Math.min(found.ms,policy.horizonMs),reserve:row.reserveMegabytes});
  const progress=progressOf(row);
  return{key:row.key,class:row.class,agents:[...row.agents],watchers:Math.max(1,row.tickets),merged:Math.max(0,row.tickets-1),reserveMegabytes:row.reserveMegabytes,startsInMs:0,endsInMs:stalled?null:Math.round(found.ms),source:found.source,stalled,...progress?{progress}:{}} satisfies QueueViewJobV1;
 });
 let previousStart=0;
 const queued=snapshot.queued.map((row,index)=>{
  const found=durationOf(row,false,history,policy),duration=Math.min(Math.round(found.ms),policy.horizonMs);
  const start=placeJob(intervals,budget,duration,row.reserveMegabytes,policy.backfill?0:previousStart);
  intervals.push({start,end:start+duration,reserve:row.reserveMegabytes});previousStart=start;
  return{key:row.key,class:row.class,agents:[...row.agents],watchers:Math.max(1,row.tickets),merged:Math.max(0,row.tickets-1),reserveMegabytes:row.reserveMegabytes,position:index+1,startsInMs:start,endsInMs:start+duration,source:found.source,stalled:false} satisfies QueueViewJobV1;
 });
 const ends=[...running,...queued].map(job=>job.endsInMs),drainsInMs=running.some(job=>job.stalled)?null:ends.length===0?0:Math.max(...ends.map(end=>end??0));
 return{version:1,atMs:Math.round(snapshot.atMs),budgetMegabytes:budget,reservedMegabytes:running.reduce((sum,job)=>sum+job.reserveMegabytes,0),running,queued,drainsInMs,merged:[...running,...queued].reduce((sum,job)=>sum+job.merged,0)};
}

/** 🔗️ What happens to a new request: an identical one (same key) already running or queued makes it a watcher of that job (`attach`, with the job's ETA and the new watcher count), anything else is `enqueue` with the simulated start and end behind the current queue. Identical requests therefore never run twice. */
export function admitQueueRequestV1(snapshot:QueueViewSnapshotV1,request:QueueRequestV1,history:QueueViewHistoryV1={keys:{},classes:{}},policy:QueueViewPolicyV1=QUEUE_VIEW_POLICY_V1):QueueAdmissionV1{
 const view=queueViewV1(snapshot,history,policy),existing=[...view.running,...view.queued].find(job=>job.key===request.key);
 if(existing!==undefined)return{action:"attach",key:request.key,...existing.position===undefined?{running:true}:{position:existing.position},startsInMs:existing.startsInMs,endsInMs:existing.endsInMs,watchers:existing.watchers+(existing.agents.includes(request.agent)?0:1)};
 const hypothetical=queueViewV1({...snapshot,queued:[...snapshot.queued,{key:request.key,class:request.class,agents:[request.agent],tickets:1,reserveMegabytes:request.reserveMegabytes}]},history,policy),added=hypothetical.queued[hypothetical.queued.length-1]!;
 return{action:"enqueue",key:request.key,position:added.position!,startsInMs:added.startsInMs,endsInMs:added.endsInMs,watchers:1};
}

const fill=(template:string,values:Readonly<Record<string,string|number>>)=>template.replace(/\{(\w+)\}/gu,(_,name:string)=>String(values[name]??""));
const text=(language:QueueViewLanguageV1,key:string,values:Readonly<Record<string,string|number>>={})=>fill(texts[key]![language],values);
const span=(language:QueueViewLanguageV1,value:number|null)=>value===null?text(language,"unknown"):progressDurationTextV1(language,value);

const progressText=(language:QueueViewLanguageV1,job:QueueViewJobV1)=>{
 const parts:string[]=[];
 if(job.progress!==undefined){
  parts.push(job.progress.total===undefined?String(job.progress.done):`${job.progress.done}/${job.progress.total}`);
  if(job.progress.rate!==null&&job.progress.rate>0)parts.push(`${progressRateTextV1(language,job.progress.rate)}/s`);
 }
 return(job.stalled?text(language,"stalled"):"")+(parts.length>0?parts.join(" ")+", ":"");
};

/** 🖨️ The queue as text lines in one language: header with reservation and drain time, one line per running job (progress, rate, stalled, ends in, source) and per queued job (position, starts in, ends in, source), merged duplicate counts named. */
export function renderQueueViewV1(language:QueueViewLanguageV1,view:QueueViewV1):string[]{
 if(view.running.length===0&&view.queued.length===0)return[text(language,"idle")];
 const lines=[text(language,"head",{running:view.running.length,queued:view.queued.length,reserved:Math.round(view.reservedMegabytes),budget:Math.round(view.budgetMegabytes),drain:span(language,view.drainsInMs)})];
 const names=(job:QueueViewJobV1)=>({key:job.key,class:job.class,agents:job.agents.join(","),merged:job.merged>0?text(language,"merged",{count:job.merged}):"",source:text(language,"source."+job.source)});
 for(const job of view.running)lines.push(text(language,"running",{...names(job),progress:progressText(language,job),ends:span(language,job.endsInMs)}));
 for(const job of view.queued)lines.push(text(language,"queued",{...names(job),position:job.position!,starts:span(language,job.startsInMs),ends:span(language,job.endsInMs)}));
 return lines;
}

/** 🖨️ The admission answer as one line in one language. */
export function renderQueueAdmissionV1(language:QueueViewLanguageV1,admission:QueueAdmissionV1):string{
 if(admission.action==="attach")return text(language,"attach",{where:admission.running?text(language,"where.running"):text(language,"where.queued",{position:admission.position!}),watchers:admission.watchers,ends:span(language,admission.endsInMs)});
 return text(language,"enqueue",{position:admission.position!,starts:span(language,admission.startsInMs),ends:span(language,admission.endsInMs)});
}
