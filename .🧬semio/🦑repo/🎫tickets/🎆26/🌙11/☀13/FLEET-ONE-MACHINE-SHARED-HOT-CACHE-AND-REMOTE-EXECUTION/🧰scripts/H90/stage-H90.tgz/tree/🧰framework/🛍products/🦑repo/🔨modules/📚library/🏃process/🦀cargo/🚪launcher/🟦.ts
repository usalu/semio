import {nativeImageVolumeUsedBytesSyncV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/💾️storage/🍎️image/⚖️availability/🟦️.ts";
import{profilePhaseV1}from"../../../🏗️build/⏱️profile/🟨️.mjs";
import{retainRemovedLaneV1,withLaneRetentionV1}from"../../../⚡️caching/🦀️cargo/🗃️unit-cache/🧵️lane/📤️retention/🟦️.ts";
import {readNativeCallerAuthorityV1} from "../../../⚡️caching/📦️artifacts/📋️native-orchestration/📥️invocation/🟦️.ts";
import {withRepositoryCompilerRuntimeEntriesV1} from "../../../🏗️build/📥️source/🔏️closure/🚪️command/🔌️runtime/🟦️.ts";
import {prepareRepositoryCargoSchedulerV1} from "../🧰️native-helpers/🟦️.ts";
import {prepareCargoWorkspaceInvocation} from "../../../🗂️workspaces/🦀️cargo/🟦️.ts";
import {prepareGeneratedSourcesV1} from "../🏭️generated-sources/🟦️.ts";
import {repositoryCargoPreparationStorageV1} from "../../../⚡️caching/📦️artifacts/📋️native-orchestration/📥️invocation/🛠️preparation/🟦️.ts";
import{nativeBuildDiagnosticLinesV1}from"../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/📣️diagnostics/🟦️.ts";
import{cargoProfileCompilerConsumptionV1}from"../../../🏗️build/🎚️mode/🦀️profile/🟦️.ts";
import{cargoTimingPolicyV1,cargoTimingEventV1,cargoResourceWaitEventV1,cargoTimingLedgerRowV1,appendCargoTimingLedgerV1}from"../⏱️timing/🟦️.ts";
import{withCompilerWorkspaceSharedWriteV1}from"../../../⚡️caching/💾️storage/🔒️enforcement/🏗️compiler/📏️capacity/🟦️.ts";
import {withSeededLaneV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🛰️fleet/🌱️seed/🛫️lane/🟦️.ts";
import {acquirePooledLaneV1,planPoolAcquireV1,poolBoundsV1,poolOwnerKeyV1,readPoolV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🧵️lane/🏊️pool/🟦️.ts";
import {crateKeyV1,laneFlavourV1,measureLaneBytesV1,removeLaneV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🧵️lane/🟦️.ts";
import {rustImageReclaimRuleV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🧹️gc/♻️auto-reclaim/🟦️.ts";
import {admitImageHeadroomV1,headroomImageMountV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🧹️gc/🏦️headroom/🟦️.ts";
import {compilerLaneQuotaBytesV1,compilerLaneStoreBytesV1} from "../../../⚡️caching/💾️storage/🔒️enforcement/🏗️compiler/🛤️lane/🟦️.ts";
import {agentSessionAddressV1,currentAgentSessionV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🪪️agent-sessions/🟦️.ts";
import {gcOutOfSpaceV1,measureVolumeV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🧹️gc/🟦️.ts";
import {collectAfterOutOfSpaceV1,focusFromCargoArgumentsV1,retryWhenFullV1,laneMessageV1,relieveUnitCachePressureV1,withUnitPressureRecheckV1,reportUnitCacheStillFullV1,unitCacheCapacityBytesV1,unitCacheEnvironmentV1,unitCacheRootV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🚪️launch/🟦️.ts";
import {unitAdmissionMemoV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/📖️admission/🟦️.ts";
import {reportMemoryPreflightForCargoV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🧠️preflight/🟦️.ts";
import {foreignDigestMemoV1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/📖️admission/📚️foreign/🟦️.ts";
import{requireIssuedResourceControlInvocationV1,createRequestedIssuedResourceControlV1,withIssuedResourceOperationV1,withRequestedIssuedResourceControlV1}from"../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧭️routing/🟦️.ts";
import {checkScriptInvocation} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧭️routing/🟦️.ts";
import {scriptInvocationEnvironment,scriptResourceProcessEnvironmentV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧭️routing/🟦️.ts";
import {bindHostCapacityWaitMarkerV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🌡️host-capacity/🟦️.ts";
import {randomBytes} from "node:crypto";
import {withNativeRecheckWindowV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/💾️storage/🍎️image/📡️roster/🟦️.ts";
import {copyFileSync,mkdirSync,readdirSync,rmSync,statfsSync,statSync} from "node:fs";
import {availableParallelism,constants} from "node:os";
import {dirname,join,resolve} from "node:path";
import {checkResourceLeaseControl,acquireResourceLease,retireResourceLeaseV1,type ResourceLease,type ResourceLeaseControl} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🔒️leases/🟦️.ts";
import {captureOwnedCommandResultV1,runOwnedCommand,OwnedCommandFailure,type OwnedCommandCaptureV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🎛️execution/🟦️.ts";
import type {BuildMode} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🎚️mode/🟦️.ts";
import {withCompilerCapacityConsumptionV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🎟️capacity/🪆️scope/🤲️consumption/🟦️.ts";
import {compileUnitsForHostV1,describeCompileUnitsV1,planFleetJobsV1,requireGrantedCompileUnitsV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🎟️capacity/🟦️.ts";
import {cargoArtifactArgumentsV1,cargoConfigurationArgumentsV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/🟦️.ts";
import {acquireCargoBuildLeaseV1,cargoRequestedProfileV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/🔒️lease/🟦️.ts";
import {ADMISSION_POLICY_V1,admissionMemoryBytesV1,admissionMemoryShareV1,admissionReserveBytesV1,localUnitHistoryPathV1,localUnitObservationV1,parentCompilerMemoryAllowanceBytesV1,readUnitHistoryV1,recordUnitHistoryV1,startAdmissionBrokerV1,unitHistoryPathV1,unitOutputBytesV1,type UnitObservationV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/🎟️admission/🟦️.ts";
import {createJobserverV1,defaultJobserverStyleV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/🎰️jobserver/🟦️.ts";
import {memoryCountersV1,startTelemetrySamplerV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/📈️telemetry/🟦️.ts";
import {captureCargoCompilationGraphV1,actualCargoCompilerPlanningPortV1,cargoPlanMemoV1,cargoPlanningOutputBytesV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/🕸️units/📥️capture/🟦️.ts";
import {UNIT_CACHE_POLICY_V1} from "../../../⚡️caching/🦀️cargo/🗃️unit-cache/🔏️key/🟦️.ts";
import {fleetIdleSlotsV1} from "../../../🏗️build/🌐️remote-execution/🚀️offload/🚦️admission/🟦️.ts";
import {admitCargoSourceBoundariesV1,actualCargoSourceAdmissionPortV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/📥️source/🎟️admission/🟦️.ts";
import {readPhysicalCargoSourceV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/📥️source/🎟️admission/📖️read/🟦️.ts";
import {requireNativeStorageReservationV1,readNativeStorageReservationPolicyV1,type NativeStorageReservationV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/💾️storage/🟦️.ts";
import {requireNativeStoragePathV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/📦️artifacts/🏗️native-build/💾️storage/🌐️platform/📋️contract/🟦️.ts";
import {validateJsonSchemaSubset} from "../../../../../../../🔨️modules/🧬️schema/✅️validator/📦️packages/🟦️typescript/🟦️.ts";
import type {ScriptInvocation} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧭️routing/🟦️.ts";
import {withRepositoryCompilerStoreV1,type RepositoryCompilerStoreV1} from "../../../⚡️caching/💾️storage/🔒️enforcement/🏗️compiler/🟦️.ts";
import {repositoryCargoNetworkV1,withRepositoryCargoInputsV1,withRepositoryCargoResolutionV1} from "../📥️dependencies/🟦️.ts";
import {admitWarmCargoRetryGraphV1,cargoDependencyDiagnosticV1,failedCompilerArtifactDriftV1,runCargoPassAttemptsV1} from "../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🧩️component-pass/🔁️failure-churn/🟦️.ts";
import failureChurn from "../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🧩️component-pass/🔁️failure-churn/🔣️.json" with {type:"json"};
import {readPhysicalFileV1} from "../../../../../../../🔨️modules/📁️filesystem/🧾️observation/🟦️.ts";
import schema from "./🧬️schema/🔣️.json" with {type:"json"};
import {ensureRepositoryCargoLockV1} from "../../../🗂️workspaces/🦀️cargo/🔒️lock/🟦️.ts";
import {resolveLanguageV1} from "../../../../../../../📦️packages/🟦️typescript/⚙️runtime/🗣️language/🟦️.ts";
import {CATALOG_LANGUAGES_V1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🗣️language/📖️catalog/🟦️.ts";
import {createCargoOverheadSamplerV1} from "./📈️overhead/🟦️.ts";
const authored=schema.definitions.Configuration.const;

/** 🧾️ One admitted ad-hoc Cargo command: its explicit store, build configuration, core share and closed subcommand class. */
export type RepositoryCargoLaunchV1=Readonly<{version:1;store:"shared"|"isolated";configuration:BuildMode;parallelism:number|"planned";kind:"compile"|"resolve"|"lock";freshLane?:true;cargo:readonly string[]}>;
/** 🧺️ Names one invocation's private target, build and temporary namespaces inside the issued compiler store. */
export type RepositoryCargoIsolatedStoreV1=Readonly<{root:string;target:string;build:string;temporary:string}>;
/** 📐️ The authored launcher policy. */
export type RepositoryCargoLaunchPolicyV1=Readonly<Omit<typeof authored,"isolatedLifetimeMode"|"isolatedSweepMode">&{isolatedLifetimeMode:"shared";isolatedSweepMode:"exclusive"}>;

/** 🛂️ Validates one value against a named launcher schema definition. */
function admit<T>(definition:keyof typeof schema.definitions,value:unknown):T{const errors=validateJsonSchemaSubset(schema.definitions[definition],value,schema);if(errors.length)throw Error(`Invalid repository Cargo launch ${definition}: ${errors.join("; ")}`);return value as T;}

/** 📜️ The schema-admitted launcher policy. */
export const REPOSITORY_CARGO_LAUNCH_POLICY_V1=Object.freeze(admit<RepositoryCargoLaunchPolicyV1>("Policy",authored));
const policy=REPOSITORY_CARGO_LAUNCH_POLICY_V1;

/** 🧭️ Parses `--store=shared|isolated --configuration=prototype|release [--parallelism=<cores>] [--fresh-lane] -- <subcommand> <args…>` without consuming any Cargo argument. `--fresh-lane` (shared store only) runs the call in a lane that is born for it and removed after it: a cold Cargo target with nothing carried over, so a probe measures cold, local-hit and remote-hit honestly; an isolated store is fresh by itself.
 * @see ./🧬️schema/🔣️.json */
export function readRepositoryCargoLaunchV1(argv:readonly string[],environment:Readonly<Record<string,string|undefined>>):RepositoryCargoLaunchV1{
 const delimiter=argv.indexOf(policy.delimiter);if(delimiter<0)throw Error("Repository Cargo launch requires `--` before the Cargo subcommand");
 const all=argv.slice(0,delimiter),flagged=all.filter(argument=>argument===policy.options.freshLane).length,head=all.filter(argument=>argument!==policy.options.freshLane),cargo=argv.slice(delimiter+1),selected=new Map<string,string>(),names=Object.values(policy.options).filter(name=>name!==policy.options.freshLane);
 if(flagged>1)throw Error(`Repeated repository Cargo launch option: ${policy.options.freshLane} / Wiederholte Startoption des Repository-Cargo: ${policy.options.freshLane}`);
 for(let index=0;index<head.length;index++){const argument=head[index]!,name=names.find(option=>argument===option||argument.startsWith(option+"="));if(!name||selected.has(name))throw Error(`Unknown or repeated repository Cargo launch option: ${argument}`);const value=argument===name?head[++index]:argument.slice(name.length+1);if(!value||value.startsWith("-"))throw Error(`Repository Cargo launch option ${name} requires a value`);selected.set(name,value);}
 const store=selected.get(policy.options.store),configuration=selected.get(policy.options.configuration),parallelism=selected.get(policy.options.parallelism);
 if(store===undefined||configuration===undefined)throw Error(`Repository Cargo launch requires explicit ${policy.options.store}=${policy.stores.join("|")} and ${policy.options.configuration}=${policy.configurations.join("|")}`);
 if(environment.SEMIO_BUILD_MODE!==undefined&&environment.SEMIO_BUILD_MODE!==configuration)throw Error("Repository Cargo launch configuration conflicts with SEMIO_BUILD_MODE");
 if(flagged===1&&store!=="shared")throw Error(`${policy.options.freshLane} needs ${policy.options.store}=shared (an isolated store is fresh by itself) / ${policy.options.freshLane} braucht ${policy.options.store}=shared (ein isolierter Speicher ist von sich aus frisch)`);
 if(parallelism!==undefined&&!/^[1-9][0-9]{0,3}$/u.test(parallelism))throw Error("Repository Cargo launch parallelism must be a positive integer");
 const kinds=Object.keys(policy.subcommands) as RepositoryCargoLaunchV1["kind"][],kind=kinds.find(key=>policy.subcommands[key].includes(cargo[0]??""));
 if(!kind)throw Error(`Repository Cargo launch admits only ${kinds.flatMap(key=>policy.subcommands[key]).join(", ")} as its first Cargo argument`);
 if(cargo.length>policy.maximumArguments||cargo.some(argument=>argument.length>policy.maximumArgumentLength||argument.includes("\0")))throw Error("Repository Cargo launch arguments exceed their declared bounds");
 return Object.freeze(admit<RepositoryCargoLaunchV1>("Request",{version:1,store,configuration,parallelism:parallelism===undefined?policy.parallelism:Number(parallelism),kind,...flagged===1?{freshLane:true}:{},cargo:Object.freeze([...cargo])}));
}

/** 🔏️ A live namespace reader excludes maintenance; atomic directory birth admits its unique writer. */
export async function withRepositoryCargoIsolatedStoreV1<T>(options:Readonly<{storage:NativeStorageReservationV1;base:string;control:ResourceLeaseControl}>,body:(store:RepositoryCargoIsolatedStoreV1)=>Promise<T>):Promise<T>{
 requireNativeStorageReservationV1(options.storage,options.control);await options.storage.recheck();
 const directory=requireNativeStoragePathV1(options.storage.backing.root,join(options.base,policy.isolatedDirectory)),pattern=new RegExp(policy.isolatedNoncePattern,"u");mkdirSync(directory,{recursive:true});
 const claim=(nonce:string,mode:"shared"|"exclusive")=>acquireResourceLease({directory,resource:nonce,mode,signal:options.control.signal,control:options.control,timeoutMs:0});
 const retire=async(nonce:string,lease:ResourceLease)=>{let failed=false,failure:unknown;try{rmSync(join(directory,nonce),{recursive:true,force:true});}catch(error){failed=true;failure=error;}try{lease.release();}catch(error){if(!failed){failed=true;failure=error;}}try{await retireResourceLeaseV1(directory,nonce,options.control,0);}catch(error){if(!failed){failed=true;failure=error;}}if(failed)throw failure;};
 for(const nonce of readdirSync(directory).filter(name=>pattern.test(name))){let lease:ResourceLease;try{lease=await claim(nonce,policy.isolatedSweepMode);}catch(error){if(error instanceof Error&&error.message.startsWith("Resource lease timed out: "))continue;throw error;}await retire(nonce,lease);process.stderr.write(`[repo cargo] swept isolated store ${nonce} of a settled owner\n`);}
 const nonce=randomBytes(6).toString("hex"),lease=await claim(nonce,policy.isolatedLifetimeMode),root=join(directory,nonce),store=Object.freeze({root,target:join(root,"target"),build:join(root,"build"),temporary:join(root,"tmp")});let result:T|undefined,failed=false,failure:unknown,born=false;
 try{mkdirSync(root);born=true;for(const path of[store.target,store.build,store.temporary]){requireNativeStoragePathV1(options.storage.backing.root,path);mkdirSync(path,{recursive:true});}result=await body(store);}catch(error){failed=true;failure=error;}try{if(born)await retire(nonce,lease);else lease.release();}catch(error){if(failed&&!Object.is(failure,error))throw new AggregateError([failure,error],"Isolated Cargo body and namespace retirement failed");failed=true;failure=error;}if(failed)throw failure;return result as T;
}

/** 🛤️ One private lane of the pool inside the issued compiler store: a target and build directory held by one process at a time, so no two Cargo processes ever share a build directory and Cargo's unit locks can never form a cycle between processes. The lane of the same crate set is preferred (its incremental state is still warm), a new lane starts empty and fills from the shared content-addressed unit cache, and the idle lanes are trimmed to the pool bounds. */
export type RepositoryCargoAgentLaneV1=Readonly<{target:string;build:string;lane:Readonly<{id:string;root:string}>;cold?:boolean}>;
type AgentLaneOptionsV1=Readonly<{storage:NativeStorageReservationV1;sharedBuild:string;cacheRoot:string;workspace:string;capacityBytes:number;crates:readonly string[];classes?:readonly string[];fresh?:boolean;environment:Readonly<Record<string,string|undefined>>;control:ResourceLeaseControl}>;

/** 💽️ Observes occupied bytes on the admitted image volume. */
function imageUsedBytesV1(root:string):number|null{
 try{
  const volume=process.platform==="darwin"?headroomImageMountV1(root)?.mount:root;
  return volume===undefined?null:nativeImageVolumeUsedBytesSyncV1(volume,statfsSync(volume))??null;
 }catch{return null;}
}

/** 🧮️ Combines lane growth with occupied image growth when the command has exclusive headroom admission throughout both observations. */
export function commandWriteBytesV1(laneGrownBytes:number,usedBeforeBytes:number|null,usedAfterBytes:number|null,exclusive:boolean=true):number{return Math.max(0,laneGrownBytes,!exclusive||usedBeforeBytes===null||usedAfterBytes===null?0:usedAfterBytes-usedBeforeBytes);}

/** 🛌️ Publishes this process's waits to the memory grant it runs under, once: the holder of the grant then sees that its tree only waits at an inner gate (image headroom, lease queue) and lends the reservation instead of idling on it while other runs queue at the door. */
let waitMarkerBound=false;
function bindWaitMarkerOnceV1():void{if(waitMarkerBound)return;waitMarkerBound=true;bindHostCapacityWaitMarkerV1();}

async function withAgentLaneV1<T>(options:AgentLaneOptionsV1,body:(lane:RepositoryCargoAgentLaneV1)=>Promise<T>):Promise<T>{
 requireNativeStorageReservationV1(options.storage,options.control);await options.storage.recheck();bindWaitMarkerOnceV1();
 const root=options.storage.backing.root;requireNativeStoragePathV1(root,options.cacheRoot);mkdirSync(options.cacheRoot,{recursive:true});
 const session=currentAgentSessionV1({environment:options.environment}),language=resolveLanguageV1(CATALOG_LANGUAGES_V1,[],options.environment).language,quotaBytes=await compilerLaneQuotaBytesV1(options.workspace,options.environment,options.capacityBytes),classes=options.classes??["lane"],flavour=laneFlavourV1(options.sharedBuild);
 const commitmentBytes=await compilerLaneStoreBytesV1(options.workspace,options.environment),commitment=commitmentBytes===null?{}:{commitmentBytes},owner={session:agentSessionAddressV1(session),agent:session.agent.id};
 const warm=options.fresh!==true&&planPoolAcquireV1(readPoolV1(options.cacheRoot,Date.now()),{crateKey:crateKeyV1(options.crates),owner:poolOwnerKeyV1(owner),...flavour===undefined?{}:{flavour}},poolBoundsV1(quotaBytes)).kind==="warm";
 const headroom=await admitImageHeadroomV1({root:options.cacheRoot,capacityBytes:options.capacityBytes,classes,temperature:warm?"warm":"cold",label:classes[classes.length-1]!,language,report:line=>{process.stderr.write(line+"\n");},signal:options.control.signal,softReclaim:rustImageReclaimRuleV1});
 let freshId:string|undefined;
 try{
  const lane=await acquirePooledLaneV1(options.cacheRoot,{crates:options.crates,quotaBytes,...commitment,owner,...flavour===undefined?{}:{flavour},...options.fresh===true?{fresh:true}:{}},{signal:options.control.signal,volume:()=>measureVolumeV1(options.cacheRoot,options.capacityBytes),report:(kind,parameters)=>{process.stderr.write(laneMessageV1(kind,parameters,language)+"\n");}});
  if(options.fresh===true)freshId=lane.paths.id;
  return await withLaneRetentionV1({lane,shared:options.sharedBuild,language,report:line=>{process.stderr.write(line+"\n");}},async()=>{let grown:(()=>number)|undefined,completed=false;
  try{
   for(const path of[lane.paths.target,lane.paths.build])requireNativeStoragePathV1(root,path);
   const before=measureLaneBytesV1(options.cacheRoot,lane.paths.id),usedBefore=headroom.imageWriteUncontended()?imageUsedBytesV1(options.cacheRoot):null;
    grown=()=>{
     const laneGrowth=measureLaneBytesV1(options.cacheRoot,lane.paths.id)-before,usedAfter=usedBefore!==null&&headroom.imageWriteUncontended()?imageUsedBytesV1(options.cacheRoot):null;
     return commandWriteBytesV1(laneGrowth,usedBefore,usedAfter,headroom.imageWriteUncontended());
    };
   const result=await body(Object.freeze({target:lane.paths.target,build:lane.paths.build,lane:Object.freeze({id:lane.paths.id,root:lane.paths.base}),cold:lane.choice!=="warm"}));completed=true;return result;
  }finally{const failedGrowth=!completed&&grown?grown():0;await headroom.release(completed?grown:failedGrowth>headroom.reservedBytes?()=>failedGrowth:undefined,lane.choice==="warm"?"warm":"cold");}
  });
 }finally{await headroom.release();if(freshId!==undefined)removeLaneV1(options.cacheRoot,freshId,"lane",Date.now(),paths=>{retainRemovedLaneV1(paths);});}
}

/** 🗂️ The planning port of a repository compile: foreign (registry) crate sources are inventoried through the digest book kept under the store's unit cache, so an unchanged crate directory is stamped, not re-hashed. Shared by `bun repo cargo` and repository tests. */
export function repositoryCargoPlanningPortV1(store:Readonly<{root:string}>){const port=actualCargoCompilerPlanningPortV1({digests:foreignDigestMemoV1(unitCacheRootV1(store.root)),plans:cargoPlanMemoV1(join(unitCacheRootV1(store.root),UNIT_CACHE_POLICY_V1.layout.plans))}),plans=port.plans!;return{...port,plans:{recall:(...row:Parameters<typeof plans.recall>)=>profilePhaseV1("cargo.plan.recall",()=>plans.recall(...row)),remember:(...row:Parameters<typeof plans.remember>)=>profilePhaseV1("cargo.plan.remember",()=>plans.remember(...row))},cfg:(...row:Parameters<typeof port.cfg>)=>profilePhaseV1("cargo.plan.cfg",()=>port.cfg(...row)),sourceInputs:(...row:Parameters<typeof port.sourceInputs>)=>profilePhaseV1("cargo.plan.foreign-inventory",()=>port.sourceInputs(...row)),compiler:(...row:Parameters<typeof port.compiler>)=>profilePhaseV1("cargo.plan.compiler",()=>port.compiler(...row)),capture:(...row:Parameters<typeof port.capture>)=>profilePhaseV1("cargo.plan.capture",()=>port.capture(...row),row[1].slice(0,3).join(" "))};}
/** 📖️ The source admission memo of a repository compile, keyed by the store's toolchain digest and kept under its unit cache, so the second admission of an unchanged unit reads no source byte. Shared by `bun repo cargo` and repository tests. */
export function repositoryCargoSourceMemoV1(store:Readonly<{root:string;toolchain:Readonly<{digest:string}>}>){return unitAdmissionMemoV1(unitCacheRootV1(store.root),store.toolchain.digest);}

/** 🧵️ One Cargo command's lane (see {@link RepositoryCargoAgentLaneV1}). Cleanup of idle lanes and cold cache objects is a niced, single-flight background collector that starts when the image passes its high-water mark (or every ten minutes of use), and a command that finds less free space than one compile needs collects before it starts. */
export async function withRepositoryCargoLaneV1<T>(options:Readonly<{storage:NativeStorageReservationV1;sharedBuild:string;cacheRoot:string;workspace:string;crates:readonly string[];classes?:readonly string[];fresh?:boolean;capacityBytes:number;emergencyBytes:number;environment:Readonly<Record<string,string|undefined>>;temporary:string;control:ResourceLeaseControl}>,body:(store:Readonly<{target:string;build:string;temporary:string;lane:Readonly<{id:string;root:string}>;cold?:boolean}>)=>Promise<T>):Promise<T>{
 const language=resolveLanguageV1(CATALOG_LANGUAGES_V1,[],options.environment).language,report=(line:string)=>{process.stderr.write(line+"\n");},relieve=()=>relieveUnitCachePressureV1({root:options.cacheRoot,capacityBytes:options.capacityBytes,emergencyBytes:options.emergencyBytes,environment:options.environment,language,report});
 try{return await withAgentLaneV1(options,async lane=>{await relieve();return withUnitPressureRecheckV1(relieve,()=>body(Object.freeze({...lane,temporary:options.temporary})));});}
 finally{await relieveUnitCachePressureV1({root:options.cacheRoot,capacityBytes:options.capacityBytes,emergencyBytes:0,environment:options.environment,language,report});}
}

/** 🧱️ Runs one component build driver in a private lane of the pool inside the issued compiler store, the same lane discipline as `repo cargo`: two drivers never wait for each other's build directory, and a fresh lane fills from the unit cache.
 * @see ../../../⚡️caching/🦀️cargo/🗃️unit-cache/🧵️lane/🏊️pool/🟦️.ts */
export function withRepositoryComponentLaneV1<T>(options:Readonly<{storage:NativeStorageReservationV1;root:string;sharedBuild:string;workspace:string;crates?:readonly string[];classes?:readonly string[];environment:Readonly<Record<string,string|undefined>>;control:ResourceLeaseControl;policyControl?:ResourceLeaseControl}>,body:(lane:RepositoryCargoAgentLaneV1)=>Promise<T>):Promise<T>{
 return withAgentLaneV1({storage:options.storage,sharedBuild:options.sharedBuild,cacheRoot:unitCacheRootV1(options.root),workspace:options.workspace,capacityBytes:unitCacheCapacityBytesV1(readNativeStorageReservationPolicyV1(options.storage,options.policyControl??options.control)),crates:options.crates??[],classes:options.classes??componentHeadroomClassesV1(options.crates??[]),environment:options.environment,control:options.control},body);
}

/** 📍️ Selects the manifest Cargo itself would read: `--manifest-path` or the working directory's `Cargo.toml`. */
function cargoManifestV1(args:readonly string[],cwd:string):string{
 const delimiter=args.indexOf("--"),head=delimiter<0?args:args.slice(0,delimiter),index=head.indexOf("--manifest-path"),inline=head.find(argument=>argument.startsWith("--manifest-path=")),manifest=index>=0?head[index+1]:inline?.slice("--manifest-path=".length)??"Cargo.toml";
 if(!manifest)throw Error("Original compiler manifest selection required");return resolve(cwd,manifest);
}

/** 🖼️ The classes the image bytes of a component build are learned under: all component builds, then its crate set (the `component` prefix selects the component prior of the headroom policy). */
export function componentHeadroomClassesV1(crates:readonly string[]):readonly string[]{return Object.freeze(["component",`component/${crateKeyV1(crates)}`]);}

/** 🏷️ The classes the image bytes of a Cargo command are learned under, general to specific: its subcommand, then the compilation target, then the crate set it selects (see `admitImageHeadroomV1`). */
export function cargoHeadroomClassesV1(args:readonly string[]):readonly string[]{
 const subcommand=`cargo/${args[0]??""}`,target=`${subcommand}/${cargoTargetV1(args)}`;
 return Object.freeze([subcommand,target,`${target}/${crateKeyV1(focusFromCargoArgumentsV1(args))}`]);
}

/** 🎯️ The compilation target a broker pass is keyed by: the first `--target`, else the host. */
function cargoTargetV1(args:readonly string[]):string{const delimiter=args.indexOf("--"),head=delimiter<0?args:args.slice(0,delimiter),index=head.indexOf("--target"),inline=head.find(argument=>argument.startsWith("--target="));return(index>=0?head[index+1]:inline?.slice("--target=".length))??"host";}

/** 📸️ Declares finite separated Cargo output, independently of passive stream execution. */
export type RepositoryCargoCapturePolicyV1=Readonly<{maximumBytes:number;maximumLines:number}>;
/** 🪢️ Carries the actual retained compiler store and Original control through result consumption. */
export type RepositoryCargoCaptureContextV1=Readonly<{store:RepositoryCompilerStoreV1;environment:Readonly<Record<string,string|undefined>>;control:ResourceLeaseControl;generated?:Uint8Array}>;
/** 🔐️ Admits the closed Cargo result capture policy before acquiring any store. */
export function readRepositoryCargoCapturePolicyV1(value:unknown):RepositoryCargoCapturePolicyV1{return Object.freeze({...admit<RepositoryCargoCapturePolicyV1>("CapturePolicy",value)});}
/** 🤖️ Bounds one generated output inside issued Rust backing without an external publish path. */
export type RepositoryCargoGeneratedCapturePolicyV1=Readonly<{version:1;maximumBytes:number}>;
/** 🔒️ Admits generated output custody before compiler/store admission. */
export function readRepositoryCargoGeneratedCapturePolicyV1(value:unknown):RepositoryCargoGeneratedCapturePolicyV1{return Object.freeze({...admit<RepositoryCargoGeneratedCapturePolicyV1>("GeneratedCapturePolicy",value)});}
let cargoTimingBytes=0,cargoTimingSequence=0;
type StreamOptions=Readonly<{maximumMilliseconds:number;output:"stream"}>;
type CaptureOptions<T>=Readonly<{maximumMilliseconds:number;output:"capture";limits:RepositoryCargoCapturePolicyV1;generated?:RepositoryCargoGeneratedCapturePolicyV1;consume(result:OwnedCommandCaptureV1,context:RepositoryCargoCaptureContextV1):Promise<T>}>;

/** 🦀️ Runs one admitted Cargo command inside the issued compiler-workspace reservation and returns Cargo's own exit status. Compilers share the machine through
 * the host capacity gate, a jobserver of exactly the admitted cores and the memory-admitting rustc broker sized to the same share of physical memory; a planned compile
 * under a machine admission takes the cores the grant's memory carries at the unit footprint the broker measured, and the broker never holds more than that memory.
 * @see ../../../⚡️caching/💾️storage/🔒️enforcement/🏗️compiler/🚪️ingress/🟦️.ts
 * @see ../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🧩️component-pass/🟦️.ts */
export function launchRepositoryCargoV1(invocation:ScriptInvocation,phaseControl:ResourceLeaseControl,workspace:string,request:RepositoryCargoLaunchV1,cwd:string,environment:Readonly<Record<string,string|undefined>>,options:StreamOptions):Promise<number>;
export function launchRepositoryCargoV1<T>(invocation:ScriptInvocation,phaseControl:ResourceLeaseControl,workspace:string,request:RepositoryCargoLaunchV1,cwd:string,environment:Readonly<Record<string,string|undefined>>,options:CaptureOptions<T>):Promise<T>;
export async function launchRepositoryCargoV1<T>(invocation:ScriptInvocation,phaseControl:ResourceLeaseControl,workspace:string,request:RepositoryCargoLaunchV1,cwd:string,environment:Readonly<Record<string,string|undefined>>,options:StreamOptions|CaptureOptions<T>):Promise<number|T>{
 requireIssuedResourceControlInvocationV1(phaseControl,invocation);return withIssuedResourceOperationV1(phaseControl,()=>withNativeRecheckWindowV1(async()=>{request=Object.freeze({...admit<RepositoryCargoLaunchV1>("Request",request),cargo:Object.freeze([...request.cargo])});environment=Object.freeze({...environment});checkScriptInvocation(invocation);
 if(options.output==="capture"){const limits=readRepositoryCargoCapturePolicyV1(options.limits),consume=options.consume;if(typeof consume!=="function")throw Error("Actual retained Cargo result consumer required");options=Object.freeze({output:"capture",maximumMilliseconds:options.maximumMilliseconds,limits,consume,...(options.generated?{generated:readRepositoryCargoGeneratedCapturePolicyV1(options.generated)}:{})});}else if(options.output==="stream")options=Object.freeze({output:"stream",maximumMilliseconds:options.maximumMilliseconds});else throw Error("Closed Cargo output intent required");
 const generatedPolicy=options.output==="capture"&&options.generated?readRepositoryCargoGeneratedCapturePolicyV1(options.generated):undefined;if(generatedPolicy&&(request.kind!=="compile"||environment.SEMIO_TYPEGEN_OUT!==undefined))throw Error("Generated capture requires compiler execution without an external publication path");
 let launchedMs=Date.now();const args=request.cargo,label="cargo:"+args[0],admission=createRequestedIssuedResourceControlV1(phaseControl,options.maximumMilliseconds);
 const control=admission,network=repositoryCargoNetworkV1(invocation,workspace),configuration=join(workspace,".cargo/config.toml");
 const timing=environment.SEMIO_CARGO_TIMING==="1",scope=timing?++cargoTimingSequence:0,started=timing?performance.now():0;let timingEvents=0,resourceEvents=0;
 const clock=()=>{const now=Math.floor(performance.now());let remaining:number|null;try{const value=control.remainingMilliseconds();remaining=value===null?null:Math.max(0,Math.floor(value));}catch{remaining=0;}return{at:now,elapsed:Math.max(0,Math.floor(now-started)),remaining};};
 const emit=(kind:string,event:object)=>{const line="[cargo-timing] "+JSON.stringify({pid:process.pid,scope,command:label,kind,...event})+"\n",bytes=Buffer.byteLength(line);if(bytes>cargoTimingPolicyV1.maximumRecordBytes||bytes>cargoTimingPolicyV1.maximumLogBytes-cargoTimingBytes)return;cargoTimingBytes+=bytes;process.stderr.write(line);};
 const began=performance.now(),pending:string[]=[];let ledger:string|undefined;const record=(phase:string,point:string)=>{try{const row=cargoTimingLedgerRowV1(process.pid,label,phase,point,Date.now(),Math.floor(performance.now()-began));if(ledger)appendCargoTimingLedgerV1(ledger,row);else pending.push(row);}catch{}};const mark=(phase:string,point:string)=>{record(phase,point);if(!timing||timingEvents>=cargoTimingPolicyV1.maximumPhaseEvents||cargoTimingBytes>=cargoTimingPolicyV1.maximumLogBytes)return;const value=clock();timingEvents++;emit("phase",cargoTimingEventV1(phase,point,value.at,value.elapsed,value.remaining));};
 const reportResource=(progress:Parameters<ResourceLeaseControl["publish"]>[0])=>{if(!timing||resourceEvents>=cargoTimingPolicyV1.maximumResourceEvents||cargoTimingBytes>=cargoTimingPolicyV1.maximumLogBytes)return;const value=clock();resourceEvents++;let event:object;try{event=cargoResourceWaitEventV1(progress.resource,progress.mode,Math.floor(progress.elapsedMs));}catch{event={version:1,status:"unavailable",reason:"unsupported progress data"};}emit("resource",{...event,atMonotonicMilliseconds:value.at,elapsedMilliseconds:value.elapsed,remainingMilliseconds:value.remaining});};mark("store","begin");
 return withRepositoryCompilerRuntimeEntriesV1(readNativeCallerAuthorityV1(invocation.capabilities).codeRoot,invocation,phaseControl,()=>withRepositoryCompilerStoreV1(workspace,request.configuration,control,scriptInvocationEnvironment(invocation,{...environment,SEMIO_BUILD_MODE:request.configuration}),async (store,control)=>{
  const leaseDirectory=readNativeStorageReservationPolicyV1(store.storage,store.control).leaseDirectory;
  ledger=join(store.root,"timing","cargo-phases.jsonl");try{requireNativeStoragePathV1(store.root,ledger);appendCargoTimingLedgerV1(ledger,pending.splice(0).join(""));}catch{ledger=undefined;}mark("store","ready");
  type Execution=(Readonly<{kind:"capture";result:OwnedCommandCaptureV1}>|Readonly<{kind:"stream";status:number}>)&Readonly<{full:boolean;dependencyDiagnostic:boolean}>;
  const execute=async(command:readonly string[],env:Readonly<Record<string,string|undefined>>,control:ResourceLeaseControl):Promise<Execution>=>{
   checkResourceLeaseControl(control);mark("child","begin");
   if(options.output==="capture"){const result=await captureOwnedCommandResultV1("cargo",command,cwd,{control,env:scriptInvocationEnvironment(invocation,{...env,SEMIO_SCRIPT_POLICY:undefined}),output:options.limits});const success=result.status===0&&result.signal===null;mark("child",success?"end":"error");return Object.freeze({kind:"capture",result,full:!success&&gcOutOfSpaceV1(result.stderr+"\n"+result.stdout),dependencyDiagnostic:!success&&result.stderr.split("\n").some(cargoDependencyDiagnosticV1)});}
   let status:number,full=false,dependencyDiagnostic=false;try{await runOwnedCommand("cargo",[...command],cwd,label,0,{deadline:control,env:scriptResourceProcessEnvironmentV1(control,scriptInvocationEnvironment(invocation,{...env,SEMIO_SCRIPT_POLICY:undefined})),signal:control.signal,onProgress:line=>{process.stderr.write(line+"\n");},onLine:line=>{if(!full&&gcOutOfSpaceV1(line))full=true;if(!dependencyDiagnostic&&cargoDependencyDiagnosticV1(line))dependencyDiagnostic=true;}});status=0;}catch(error){mark("child","error");if(!(error instanceof OwnedCommandFailure))throw error;status=error.outcome.status??128+(constants.signals[error.outcome.signal as keyof typeof constants.signals]??0);}if(status===0)mark("child","end");return Object.freeze({kind:"stream",status,full:status!==0&&full,dependencyDiagnostic});
  };
  const space=readNativeStorageReservationPolicyV1(store.storage,store.control),spaceRoot=unitCacheRootV1(store.root),spaceBudget=unitCacheCapacityBytesV1(space),spaceLanguage=resolveLanguageV1(CATALOG_LANGUAGES_V1,[],environment).language,spaceReport=(line:string)=>{process.stderr.write(line+"\n");};
  if(request.kind==="compile")await reportMemoryPreflightForCargoV1({workspace,manifest:cargoManifestV1(args,cwd),args,storeRoot:store.root,mode:request.configuration,environment,language:spaceLanguage},spaceReport);
  const retryingFullImage=<Result extends Execution>(run:()=>Promise<Result>):Promise<Result>=>retryWhenFullV1(run,{collect:()=>collectAfterOutOfSpaceV1({root:spaceRoot,capacityBytes:spaceBudget,language:spaceLanguage,report:spaceReport}),stillFull:()=>reportUnitCacheStillFullV1({root:spaceRoot,capacityBytes:spaceBudget,language:spaceLanguage,report:spaceReport})});
  const consumeExecution=(execution:Execution,env:Readonly<Record<string,string|undefined>>,control:ResourceLeaseControl,beforeConsume:(()=>void)|undefined,generatedFile:string|undefined):Promise<number|T>=>withRequestedIssuedResourceControlV1(control,0,async control=>{
   mark("consume","begin");checkResourceLeaseControl(control);await store.storage.recheck();const success=execution.kind==="capture"?execution.result.status===0&&execution.result.signal===null:execution.status===0;if(success)beforeConsume?.();else (await import("../../../../../../../🔨️modules/🏃️process/🏗️build/🌡️host-capacity/🛡️warden/🔁️loop/🟦️.ts")).requireNoHostWardenCancelBelowV1(process.pid,launchedMs);
   if(execution.kind==="stream"){mark("consume","end");return execution.status;}if(options.output!=="capture")throw Error("Actual captured Cargo consumer required");
   await control.publish({resource:"cargo:consume",mode:"shared",elapsedMs:0});await control.yieldContinuation();const generated=generatedPolicy&&success&&generatedFile?await readPhysicalCargoSourceV1(generatedFile,{expectedBytes:null,version:1,root:store.root,maximumBytes:generatedPolicy.maximumBytes,remainingFiles:1},control):undefined;if(generatedPolicy&&success&&!generated)throw Error("Actual generated Cargo output absent");
   const value=await options.consume(execution.result,Object.freeze({store,environment:Object.freeze({...env}),control,...(generated?{generated}:{})}));checkResourceLeaseControl(control);await store.storage.recheck();checkScriptInvocation(invocation);mark("consume","end");return value;
  });
  const preparation={...repositoryCargoPreparationStorageV1(workspace),directory:requireNativeStoragePathV1(store.root,join(store.buildDirectory,"preparation"))};
  const offline=network.offline||args.includes("--offline")||args.includes("--frozen");
  if(request.kind==="compile")await profilePhaseV1("cargo.body.generated-sources",()=>prepareGeneratedSourcesV1(invocation,workspace,cargoManifestV1(args,cwd),environment));
  await profilePhaseV1("cargo.body.prepare",()=>prepareCargoWorkspaceInvocation(preparation,workspace,args,cwd,{...store.environment,CARGO_NET_OFFLINE:String(offline)},control));
  const preparedScheduler=request.kind==="compile"?await profilePhaseV1("cargo.body.scheduler",()=>prepareRepositoryCargoSchedulerV1(invocation,control,workspace,store)):undefined;
  const admitted=async(compilerArgs:readonly string[],env:Readonly<Record<string,string|undefined>>,selected:RepositoryCargoIsolatedStoreV1|Readonly<{target:string;build:string;lane?:Readonly<{id:string;root:string}>}>,control:ResourceLeaseControl,readmit:(retryControl:ResourceLeaseControl,suffix:string)=>Promise<unknown>,beforeConsume?:()=>void,generatedFile?:string):Promise<number|T>=>{mark("profile","begin");return (async()=>{
   const lease=await acquireCargoBuildLeaseV1({directory:leaseDirectory,buildDirectory:selected.build,targetDirectory:selected.target,args:compilerArgs,signal:control.signal,control});mark("profile","ready");let profileFailed=false,profileFailure:unknown;
   try{
    mark("capacity","begin");
    const historyRoot=join(store.root,"components"),localHistoryPath=localUnitHistoryPathV1(historyRoot);
    const [history,localHistory]=await Promise.all([readUnitHistoryV1(unitHistoryPathV1(historyRoot)),readUnitHistoryV1(localHistoryPath)]);
    const units=request.parallelism==="planned"?await compileUnitsForHostV1({environment:env,signal:control.signal,history}):undefined,waitStart=Date.now(),operation="cargo "+(args[0]??"");if(units)spaceReport(describeCompileUnitsV1(spaceLanguage,"planned",{operation,preferred:units.decision.preferred,minimum:units.decision.minimum,cores:units.host.cores,reason:units.decision.reason}));return await withCompilerWorkspaceSharedWriteV1(store.storage,leaseDirectory,control,writer=>withCompilerCapacityConsumptionV1({directory:leaseDirectory,control:writer,environment:env,request:units?.request??{kind:"exact",parallelism:request.parallelism as number}},async(capacity,cpuControl)=>{mark("capacity","ready");if(units){requireGrantedCompileUnitsV1(units.decision,capacity.parallelism);spaceReport(describeCompileUnitsV1(spaceLanguage,"granted",{operation,granted:capacity.parallelism,cores:units.host.cores,seconds:Math.round((Date.now()-waitStart)/1000)}));}mark("writer","begin");const compiled=await(async()=>{mark("writer","ready");mark("scheduler","begin");
     const scheduler=preparedScheduler!,local=capacity.parallelism,fleet=units?await(async()=>{try{const idle=await fleetIdleSlotsV1(env,{signal:control.signal}),plan=planFleetJobsV1({local,fleetIdle:idle,grantedMegabytes:units.host.grantedMegabytes,availableMegabytes:units.host.availableMegabytes,pressure:units.host.pressure,unitMegabytes:units.host.unitMegabytes});if(plan.remote>0)spaceReport(describeCompileUnitsV1(spaceLanguage,"fleet",{operation,jobs:plan.jobs,local,remote:plan.remote,idle:idle??0,reason:plan.reason}));return plan;}catch{return undefined;}})():undefined,tokens=fleet?.jobs??local;mark("scheduler","ready");
     const jobserverDirectory=join(store.environment.TMPDIR!,policy.jobserverDirectoryPrefix+randomBytes(6).toString("hex")),jobserver=await createJobserverV1({version:1,tokens,style:defaultJobserverStyleV1()},jobserverDirectory);let jobserverFailed=false,jobserverFailure:unknown;
     try{
      const observations:UnitObservationV1[]=[];
      const physical=admissionMemoryBytesV1(),parentMemoryAllowanceBytes=parentCompilerMemoryAllowanceBytesV1(environment);
      const broker=await startAdmissionBrokerV1({physicalBytes:admissionMemoryShareV1(physical,local,availableParallelism()),reserveBytes:admissionReserveBytesV1(physical),parentMemoryAllowanceBytes,growth:(await import("../../../🏗️build/🌡️host-capacity/🟦️.ts")).createGrantGrowthPortV1({environment}),onWaits:(await import("../../../🏗️build/🌡️host-capacity/⏳️unit-waits/🟦️.ts")).createUnitWaitPublisherV1(environment),history,localHistory,log:spaceReport,onVerifiedLocal(unit){
       const row=localUnitObservationV1(unit,artifact=>{
        const directory=dirname(artifact);
        return unitOutputBytesV1(artifact,readdirSync(directory),name=>statSync(join(directory,name)).size);
       });
       if(row)observations.push(row);
      }});let previous:Readonly<{atMs:number;bytes:number}>|undefined,sampler:ReturnType<typeof startTelemetrySamplerV1>|undefined;let executionFailed=false,executionFailure:unknown;
      try{
      const overhead=parentMemoryAllowanceBytes===undefined?undefined:createCargoOverheadSamplerV1();
      broker.observe({nonRustcBytes:overhead?process.memoryUsage.rss():0,swapOutBytesPerSecond:null});
      sampler=startTelemetrySamplerV1(cpuControl,async sampleControl=>{const counters=await memoryCountersV1(sampleControl),atMs=Date.now(),rate=previous&&counters.swappedOutBytes!==null?Math.max(0,(counters.swappedOutBytes-previous.bytes)*1000/Math.max(1,atMs-previous.atMs)):null;if(counters.swappedOutBytes!==null)previous={atMs,bytes:counters.swappedOutBytes};broker.observe({nonRustcBytes:overhead?await overhead(broker.runningSchedulerPids()):0,swapOutBytesPerSecond:rate});},policy.swapSampleMilliseconds);

      broker.registerPass({id:policy.pass,profile:cargoRequestedProfileV1(compilerArgs)!,target:cargoTargetV1(compilerArgs)});for(const line of nativeBuildDiagnosticLinesV1(request.store==="shared"?"repoCargoAdmittedShared":"repoCargoAdmittedIsolated",{tokens:local,cores:availableParallelism(),budget:(broker.stats().budgetBytes/1024**3).toFixed(1)}))process.stderr.write(line+"\n");mark("scheduler","end");await profilePhaseV1("cargo.body.lock-check",()=>ensureRepositoryCargoLockV1({workspaceRoot:workspace,cwd,program:"cargo",prefix:[],args:compilerArgs,environment:env,control:cpuControl,force:false}));const runAttempt=()=>jobserver.withClient(inherited=>execute(compilerArgs,{...env,...inherited,RUSTC_WRAPPER:scheduler,...("lane"in selected&&selected.lane?unitCacheEnvironmentV1({cacheRoot:unitCacheRootV1(store.root),lane:selected.lane.id,laneRoot:selected.lane.root,scheduler,compiler:env.RUSTC??"rustc",toolchain:store.toolchain.digest,focus:focusFromCargoArgumentsV1(compilerArgs),...fleet&&fleet.remote>0?{slots:Number(env.SEMIO_UNIT_CACHE_SLOTS)||local,lightSlots:fleet.remote}:{},features:{buildScripts:true}}):{}),[ADMISSION_POLICY_V1.brokerEnvironment]:broker.endpoint,[ADMISSION_POLICY_V1.passEnvironment]:policy.pass,SEMIO_COMPILER_PARALLELISM:String(local),CARGO_BUILD_JOBS:String(tokens)},cpuControl));
       const compile=async()=>{
        let recoveredStorage=false;
        const result=await retryingFullImage(async()=>{
         const started=broker.units().length;
         const execution=await runAttempt();
         recoveredStorage ||= execution.full;
         return {...execution,units:broker.units().slice(started)};
        });
        const {units,...execution}=result;
        return {execution,units,recoveredStorage};
       };
       const {execution}=await runCargoPassAttemptsV1(compile,async({execution,units,recoveredStorage})=>{
        const code=execution.kind==="stream"?execution.status:execution.result.signal===null?execution.result.status:null;
        if(code!==101||recoveredStorage||execution.full||!execution.dependencyDiagnostic||units.some(unit=>unit.exit>=128))return;
        const failed=units.filter(unit=>unit.exit!==0&&!unit.cache);
        if(failed.length!==1||failed[0]!.exit!==1)return;
        checkResourceLeaseControl(cpuControl);await store.storage.recheck();
        const filenames=failed[0]!.dependencies.flatMap(edge=>edge.artifacts);
        if(filenames.length===0)return;
        const probeDeadline=performance.now()+failureChurn.maximumProbeMilliseconds;
        const read=async(path:string)=>{
         const remainingMs=()=>Math.min(probeDeadline-performance.now(),checkResourceLeaseControl(cpuControl)??Infinity);
         if(remainingMs()<=0)return;
         try{return (await readPhysicalFileV1(path,{maxBytes:failureChurn.maximumReadBytes,chunkBytes:failureChurn.readChunkBytes,maxWork:Math.ceil(failureChurn.maximumReadBytes/failureChurn.readChunkBytes)+5,cancelled:()=>cpuControl.signal.aborted,remainingMs,onProgress:()=>{}})).bytes;}
         catch{checkResourceLeaseControl(cpuControl);return;}
        };
        return failedCompilerArtifactDriftV1({workspace,build:selected.build,target:selected.target,filenames,read});
       },async(drift,suffix)=>{
        await readmit(cpuControl,suffix);
        spaceReport(spaceLanguage==="de"?`[cargo] Wiederholung im gehaltenen Compilerbereich nach Quelltextänderung: ${drift.path}`:`[cargo] Retrying in the held compiler lane after a source change: ${drift.path}`);
       });
       return()=>consumeExecution(execution,env,control,beforeConsume,generatedFile);}
      catch(error){executionFailed=true;executionFailure=error;throw error;}
      finally{const secondary:unknown[]=[];try{await sampler?.stop();}catch(error){if(!executionFailed||error!==executionFailure)secondary.push(error);}try{await broker.close();}catch(error){secondary.push(error);}
       if(observations.length)await recordUnitHistoryV1(localHistoryPath,observations,{leaseDirectory,control:cpuControl}).catch(error=>spaceReport(`[native-build] unit history write failed: ${error instanceof Error?error.message:String(error)}`));
       if(secondary.length)throw executionFailed?new AggregateError([executionFailure,...secondary],"Compiler and telemetry retirement failed"):secondary.length===1?secondary[0]:new AggregateError(secondary,"Compiler telemetry retirement failed");}
     }catch(error){jobserverFailed=true;jobserverFailure=error;throw error;}finally{const secondary:unknown[]=[];try{jobserver.close();}catch(error){secondary.push(error);}try{rmSync(jobserverDirectory,{recursive:true,force:true});}catch(error){secondary.push(error);}if(secondary.length)throw jobserverFailed?new AggregateError([jobserverFailure,...secondary],"Compiler and jobserver retirement failed"):secondary.length===1?secondary[0]:new AggregateError(secondary,"Jobserver retirement failed");}
    })();return compiled;
    }));
   }catch(error){profileFailed=true;profileFailure=error;throw error;}finally{try{lease.release();}catch(secondary){if(profileFailed)throw new AggregateError([profileFailure,secondary],"Compiler consumption and profile retirement failed");throw secondary;}}
  })();};
  const run=async(selected:RepositoryCargoIsolatedStoreV1|Readonly<{target:string;build:string;temporary:string;lane?:Readonly<{id:string;root:string}>;cold?:boolean}>):Promise<number|T>=>{
   const inputs={invocation,consumption:request.kind==="compile"?cargoProfileCompilerConsumptionV1("artifact",args[0]??""):{kind:"resolution" as const},workspace,cwd,manifest:cargoManifestV1(args,cwd),args,network,control,storage:store.storage,environment:{...store.environment,CARGO_TARGET_DIR:selected.target,CARGO_BUILD_BUILD_DIR:selected.build,TMPDIR:selected.temporary,TMP:selected.temporary,TEMP:selected.temporary}};
   const resolution=async(input:import("../📥️dependencies/🟦️.ts").RepositoryCargoInputsViewV1):Promise<number|T>=>{const control=input.control,env=input.environment,command=cargoConfigurationArgumentsV1(input.selections[0]!.arguments,configuration,selected.build);return consumeExecution(await execute(command,env,control),env,control,undefined,undefined);};
   const resolved=async(input:import("../📥️dependencies/🟦️.ts").RepositoryCargoInputsViewV1):Promise<number|T>=>{const control=input.control,lease=await acquireCargoBuildLeaseV1({directory:leaseDirectory,buildDirectory:selected.build,targetDirectory:selected.target,args:cargoConfigurationArgumentsV1(input.selections[0]!.arguments,configuration,selected.build),signal:control.signal,control});try{return await resolution(input);}finally{lease.release();}};
   if(request.kind==="lock")return withRepositoryCargoResolutionV1(inputs,resolution);
   mark("inputs","begin");return withRepositoryCargoInputsV1(inputs,async input=>{const control=input.control,env=input.environment;mark("inputs","ready");
    if(request.kind==="resolve")return resolved(input);
    const generated=env.SEMIO_TYPEGEN_OUT||generatedPolicy?join(store.captureDirectory,"typegen-"+randomBytes(4).toString("hex")+".ts"):undefined,compilerEnvironment={...env,...(generated?{SEMIO_TYPEGEN_OUT:generated}:{})},compilerArgs=cargoArtifactArgumentsV1(input.selections[0]!.arguments,{mode:request.configuration,compilerConfiguration:configuration,buildDirectory:selected.build});
    const plan={workspaceRoot:workspace,cwd,program:"cargo",prefix:[],args:compilerArgs,environment:compilerEnvironment,maximumOutputBytes:cargoPlanningOutputBytesV1};
     mark("graph","begin");const graph=await profilePhaseV1("cargo.plan.graph",()=>captureCargoCompilationGraphV1(plan,control,repositoryCargoPlanningPortV1(store)));mark("graph","end");
     const admitSource=async(selectedGraph:typeof graph,sourceControl:ResourceLeaseControl)=>{
      mark("source","begin");await profilePhaseV1("cargo.plan.source-admission",()=>admitCargoSourceBoundariesV1(selectedGraph,workspace,store.sourceBoundary,sourceControl,actualCargoSourceAdmissionPortV1(compilerEnvironment,cwd,store.storage),repositoryCargoSourceMemoV1(store)));mark("source","end");await store.storage.recheck();
     };
     await admitSource(graph,control);
     const readmit=async(retryControl:ResourceLeaseControl,suffix:string)=>{
      let planned=graph;
      await admitWarmCargoRetryGraphV1({manifest:inputs.manifest,suffix,previous:graph,observe:async()=>planned=await captureCargoCompilationGraphV1(plan,retryControl,actualCargoCompilerPlanningPortV1()),admit:()=>admitSource(planned,retryControl),replacementFits:()=>false});
     };
     const attempt=async()=>(await import("../../../../../../../🔨️modules/🏃️process/🏗️build/🌡️host-capacity/🛡️warden/🔁️loop/🟦️.ts")).retryAfterHostWardenCancelV1((_attempt,startedMs)=>{launchedMs=startedMs;return admitted(compilerArgs,compilerEnvironment,selected,control,readmit,generated&&!generatedPolicy?()=>copyFileSync(generated,env.SEMIO_TYPEGEN_OUT!):undefined,generated);},{report:spaceReport,signal:control.signal});
     try{return await ("lane" in selected&&selected.lane!==undefined?withSeededLaneV1({cacheRoot:unitCacheRootV1(store.root),laneRoot:selected.lane.root,lane:selected.lane.id,graph,environment,language:spaceLanguage,report:spaceReport,signal:control.signal,cold:selected.cold===true},attempt):attempt());}finally{if(generated)rmSync(generated,{force:true});}
   });
  };
  return request.store==="shared"?withRepositoryCargoLaneV1({storage:store.storage,sharedBuild:store.buildDirectory,cacheRoot:unitCacheRootV1(store.root),workspace,crates:focusFromCargoArgumentsV1(request.cargo),classes:cargoHeadroomClassesV1(request.cargo),capacityBytes:spaceBudget,emergencyBytes:space.maximumWorkspaceBytes,...request.freshLane===true?{fresh:true}:{},environment,temporary:store.environment.TMPDIR!,control},run):withRepositoryCargoIsolatedStoreV1({storage:store.storage,base:dirname(store.buildDirectory),control},run);
 }));
 }));
}
