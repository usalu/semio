import {mkdtempSync,rmSync,writeFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {join,resolve} from "node:path";
import {spawnSync} from "node:child_process";
import {fileURLToPath} from "node:url";
import {expect,test} from "bun:test";
import Ajv from "ajv";
import {parse as parseToml} from "@iarna/toml";
import {carvingPeaksV1,collectMemoryPreflightV1,readTelemetryRowsV1,telemetryPathV1,lockClosureV1,memoryPreflightLinesV1,MEMORY_PREFLIGHT_POLICY_V1,mergePreflightPeaksV1,planMemoryPreflightV1,reportMemoryPreflightV1,telemetryPeaksV1,wardenPeaksV1,type PreflightPeakV1,type PreflightRowV1} from "../../🧠️preflight/🟦️.ts";
import schema from "../../🧠️preflight/🧬️schema/🔣️.json";
import {localUnitHistoryPathV1} from "../../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🟦️.ts";
import {UNIT_CEILING_POLICY_V1} from "../../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🏔️ceiling/🟦️.ts";
import corpus from "./🔣️.json";

const here=fileURLToPath(new URL(".",import.meta.url));
const python=(()=>{for(const name of ["python3","python"]){const run=spawnSync(name,["--version"]);if(run.status===0)return name;}return undefined;})();
const planOf=(name:string)=>{const row=corpus.plans.find(item=>item.name===name)!;return planMemoryPreflightV1({peaks:row.peaks as never,policy:corpus.policy as never,local:row.local as never,fleet:(row.fleet??undefined) as never,...row.scope===null?{}:{scope:new Set(row.scope)}});};
const oracle=()=>{const run=spawnSync(python!,[join(here,"🐍️.py"),join(here,"🔣️.json"),resolve(here,"../../🧠️preflight/🧬️schema/🔣️.json")],{encoding:"utf8"});expect(run.status,run.stderr).toBe(0);return JSON.parse(run.stdout) as Record<string,any>;};

test("every plan row of the corpus obeys the row schema and the plans follow the grant-growth law",()=>{
 const validate=new Ajv({strict:true}).compile({...schema.definitions.Row,definitions:schema.definitions});
 for(const row of corpus.plans)for(const entry of planOf(row.name))expect(validate(entry),row.name+": "+JSON.stringify(validate.errors)).toBe(true);
 expect(planOf("below-budget")).toEqual([]);
 expect(planOf("library-grows")[0]).toMatchObject({plan:"constrained-threads",waits:false,budgetMegabytes:1536,holdableMegabytes:9216});
 expect(planOf("library-waits")[0]).toMatchObject({plan:"constrained-threads",waits:true});
 expect(planOf("final-serial")[0]).toMatchObject({plan:"serial-backend",budgetMegabytes:4096});
 expect(planOf("beyond-host-known-fleet")[0]).toMatchObject({plan:"beyond-host",largestOrigin:"big",largestMegabytes:46080});
 expect(planOf("unbuildable")[0]).toMatchObject({plan:"unbuildable",largestOrigin:"local",largestMegabytes:3840});
 expect(planOf("beyond-host-unknown-fleet")[0]).toMatchObject({plan:"beyond-host"});
 expect(planOf("scope-narrows").map(row=>row.unit)).toEqual(["a|host"]);
 expect(planOf("order-and-listed").map(row=>row.unit)).toEqual(["big|host","heavy_lib|host","m|host","z|host"]);
 expect(planOf("order-and-listed")[1]!.listed).toBe(true);
});

test("plans, peaks, closures and bilingual lines of every corpus case equal the independent Python oracle",()=>{
 if(python===undefined)return;
 const expected=oracle(),host=corpus.lines.host;
 expect(Object.fromEntries(corpus.plans.map(row=>[row.name,planOf(row.name)]))).toEqual(expected["plans"]);
 expect(corpus.telemetry.modes.map(mode=>[...telemetryPeaksV1(corpus.telemetry.rows as never,mode??undefined)].sort((a,b)=>a.crate<b.crate?-1:a.crate>b.crate?1:a.target<b.target?-1:1))).toEqual(expected["telemetry"]);
 expect([...wardenPeaksV1(corpus.warden.states,corpus.warden.nowMs)].sort((a,b)=>a.crate<b.crate?-1:1)).toEqual(expected["warden"]);
 expect([...mergePreflightPeaksV1(...(corpus.merge.lists as unknown as PreflightPeakV1[][]))].sort((a,b)=>a.crate<b.crate?-1:1)).toEqual(expected["merge"]);
 expect(corpus.closure.cases.map(roots=>{const set=lockClosureV1(corpus.closure.lock,roots);return set===undefined?null:[...set].sort();})).toEqual(expected["closure"]);
 const many=Array.from({length:corpus.lines.many.count},(_,index)=>({unit:"u"+String(index).padStart(2,"0")+"|host",kind:"library",peakMegabytes:2000+index,budgetMegabytes:1536,source:"telemetry",listed:false,plan:"constrained-threads",waits:false,holdableMegabytes:9216}) as PreflightRowV1).sort((a,b)=>b.peakMegabytes-a.peakMegabytes||(a.unit<b.unit?-1:1));
 for(const language of ["en","de"] as const){
  for(const name of corpus.lines.cases)expect(memoryPreflightLinesV1(planOf(name),language,host)).toEqual(expected["lines"][language][name]);
  expect(memoryPreflightLinesV1(many,language,host)).toEqual(expected["lines"][language]["many"]);
  expect(expected["lines"][language]["many"]).toHaveLength(MEMORY_PREFLIGHT_POLICY_V1.maximumRows+2);
 }
});

test("the dependency closure of a lock equals the one a third-party TOML parser gives",()=>{
 const parsed=parseToml(corpus.closure.lock) as {package:{name:string;dependencies?:string[]}[]},graph=new Map<string,Set<string>>();
 for(const row of parsed.package){const set=graph.get(row.name)??new Set<string>();for(const dependency of row.dependencies??[])set.add(dependency.split(" ")[0]!);graph.set(row.name,set);}
 for(const roots of corpus.closure.cases){
  const expected=roots.some(root=>!graph.has(root))?undefined:(()=>{const seen=new Set<string>(),pending=[...roots];while(pending.length){const next=pending.pop()!;if(seen.has(next))continue;seen.add(next);pending.push(...graph.get(next)!);}return [...seen].map(name=>name.replaceAll("-","_")).sort();})();
  const actual=lockClosureV1(corpus.closure.lock,roots);
  expect(actual===undefined?undefined:[...actual].sort()).toEqual(expected);
 }
});

test("the texts are bilingual with the same placeholders and a text for every plan",()=>{
 const holes=(text:string)=>[...text.matchAll(/\{([a-z]+)\}/gu)].map(match=>match[1]!).sort();
 const english=MEMORY_PREFLIGHT_POLICY_V1.texts.en,german=MEMORY_PREFLIGHT_POLICY_V1.texts.de;
 expect(Object.keys(german).sort()).toEqual(Object.keys(english).sort());
 for(const key of Object.keys(english) as (keyof typeof english)[])expect(holes(german[key]),key).toEqual(holes(english[key]));
 for(const plan of MEMORY_PREFLIGHT_POLICY_V1.plans)expect(english[plan as keyof typeof english]).toBeTruthy();
 expect(english.header).not.toBe(german.header);
});

test("the carving list of the real policy plans without a crash and every row is a listed unit",()=>{
 const local=corpus.plans[1]!.local as never,rows=planMemoryPreflightV1({peaks:carvingPeaksV1(UNIT_CEILING_POLICY_V1),policy:UNIT_CEILING_POLICY_V1,local,fleet:undefined});
 const budget=UNIT_CEILING_POLICY_V1.classes[UNIT_CEILING_POLICY_V1.workerClass]!.libraryMegabytes;
 expect(rows.length).toBe(UNIT_CEILING_POLICY_V1.carving.filter(entry=>entry.measuredMegabytes>budget).length);
 for(const row of rows)expect(row.listed).toBe(true);
});

test("the early check reads its sources, prints the plan, and a failing source never fails the build",async()=>{
 const directory=mkdtempSync(join(tmpdir(),"preflight-")),history=join(directory,"units.jsonl");
 try{
  writeFileSync(history,"{}\n"+JSON.stringify({key:"p@tele|host|prototype|lib|h",peakRssBytes:1800*1048576})+"\nnot json\n"+JSON.stringify({key:"p@torn|host|prototype|lib|h",peakRssBytes:9000*1048576}));
  const local=corpus.plans[1]!.local as never,base={historyPath:history,environment:{},language:"en" as const,nowMs:corpus.warden.nowMs,localHost:()=>local,fleetHosts:()=>undefined,wardenState:()=>({lastAlarms:[{atMs:corpus.warden.nowMs-5,reason:"ceiling",megabytes:1900,ceiling:{unit:"heavy|host",kind:"library"}}]}),policy:corpus.policy as never};
  const lines=await collectMemoryPreflightV1(base);
  expect(lines[0]).toBe("[memory-preflight] 3 unit(s) of this build are known to exceed their memory budget (this machine: 16384 MB, holdable 9216 MB):");
  expect(lines.slice(1)).toEqual(["  heavy|host: peak 1900 MB (budget 1536 MB, warden): compiled with one front-end thread (-Z threads=1).","  tele|host: peak 1800 MB (budget 1536 MB, telemetry): compiled with one front-end thread (-Z threads=1).","  heavy_lib|host: peak 1750 MB (budget 1536 MB, carving): compiled with one front-end thread (-Z threads=1)."]);
  const failing:string[]=[];
  await reportMemoryPreflightV1({...base,localHost:()=>{throw Error("no host facts");}},line=>failing.push(line));
  expect(failing).toEqual(["[memory-preflight] unavailable (no host facts); the build goes on without the early memory check."]);
  const german:string[]=[];
  await reportMemoryPreflightV1({...base,language:"de",localHost:()=>{throw Error("keine Hostdaten");}},line=>german.push(line));
  expect(german).toEqual(["[Speicher-Vorabprüfung] nicht verfügbar (keine Hostdaten); der Build läuft ohne die frühe Speicherprüfung weiter."]);
  const silent=await collectMemoryPreflightV1({...base,historyPath:join(directory,"absent.jsonl"),wardenState:()=>{throw Error("gone");}});
  expect(silent[0]).toContain("1 unit(s)");
 }finally{rmSync(directory,{recursive:true,force:true});}
});

test("the telemetry path equals the admission path and the reader drops torn tails and non-JSON lines",()=>{
 expect(telemetryPathV1("/cache")).toBe(localUnitHistoryPathV1("/cache"));
 expect(telemetryPathV1("/cache","linux","x64")).toBe(localUnitHistoryPathV1("/cache","linux","x64"));
 const directory=mkdtempSync(join(tmpdir(),"preflight-rows-")),path=join(directory,"units.jsonl");
 try{
  writeFileSync(path,JSON.stringify({key:"a@a|host|prototype|lib|h",peakRssBytes:5})+"\nnot json\n"+JSON.stringify({key:7,peakRssBytes:5})+"\n"+JSON.stringify({key:"b@b|host|prototype|lib|h",peakRssBytes:6}));
  expect(readTelemetryRowsV1(path,1024)).toEqual([{key:"a@a|host|prototype|lib|h",peakRssBytes:5}]);
  expect(readTelemetryRowsV1(path,10)).toEqual([]);
  expect(readTelemetryRowsV1(join(directory,"absent"),1024)).toEqual([]);
 }finally{rmSync(directory,{recursive:true,force:true});}
});
