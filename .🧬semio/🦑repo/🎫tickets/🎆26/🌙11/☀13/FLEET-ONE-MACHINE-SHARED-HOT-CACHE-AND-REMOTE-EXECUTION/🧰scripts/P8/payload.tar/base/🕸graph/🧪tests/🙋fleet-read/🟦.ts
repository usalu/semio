import{afterAll,expect,test}from"bun:test";
import{mkdtempSync,rmSync}from"node:fs";
import{tmpdir}from"node:os";
import{join}from"node:path";
import{fleetReadStaleGenerationV1}from"../../🤝️prefetch/🟦️.ts";

/** 🙋️ Contract: a graph read decides fleet-first by its admitted memory (`SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES` reaches the decision): a serving-sized machine and a disabled fleet read stay local and silent, a 16 GB shape with thousands of stale projects and no fleet to ask refuses in plain text with the designed refusal instead of waiting for ever. */
const scratch:string[]=[];
afterAll(()=>{for(const path of scratch)rmSync(path,{recursive:true,force:true});});
const request=(count:number)=>({generation:3,dirty:Array.from({length:count},(_,at)=>`p${String(at).padStart(5,"0")}`),roots:{},structural:false,implementation:"a".repeat(64)});
const invocation={control:{signal:new AbortController().signal}} as never;
async function run(count:number,environment:Record<string,string>){
 const root=mkdtempSync(join(tmpdir(),"fleet-read-"));scratch.push(root);
 const lines:string[]=[],write=process.stderr.write.bind(process.stderr);
 process.stderr.write=((chunk:string|Uint8Array)=>{lines.push(String(chunk));return true;}) as never;
 const before=process.env.SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES;process.env.SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES=environment.SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES;
 try{await fleetReadStaleGenerationV1({root,request:request(count),invocation,language:"en",environment:{PATH:process.env.PATH,HOME:root,...environment}});return{lines,error:undefined};}
 catch(error){return{lines,error:error as {name:string;key:string;code:string}};}
 finally{process.stderr.write=write;if(before===undefined)delete process.env.SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES;else process.env.SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES=before;}
}

test("a disabled fleet read and a serving-sized machine say nothing and read locally",async()=>{
 expect(await run(5000,{SEMIO_GRAPH_FLEET_READ:"off",SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES:"16384"})).toEqual({lines:[],error:undefined});
 expect(await run(5000,{SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES:"32768"})).toEqual({lines:[],error:undefined});
});

test("a 16 GB shape with 5 000 stale projects and no fleet cache refuses at once in plain text with the designed class",async()=>{
 const result=await run(5000,{SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES:"16384"});
 expect(result.error?.name).toBe("RepoError");expect(result.error?.key).toBe("build.graph.wanted-expired");expect(result.error?.code).toBe("unserved");
 expect(result.lines.join("")).toContain("cannot be reached");expect(result.lines.join("")).toContain("5000 stale projects");
});

test("a 16 GB shape with few stale projects stays local and silent",async()=>{
 expect(await run(40,{SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES:"16384"})).toEqual({lines:[],error:undefined});
});
