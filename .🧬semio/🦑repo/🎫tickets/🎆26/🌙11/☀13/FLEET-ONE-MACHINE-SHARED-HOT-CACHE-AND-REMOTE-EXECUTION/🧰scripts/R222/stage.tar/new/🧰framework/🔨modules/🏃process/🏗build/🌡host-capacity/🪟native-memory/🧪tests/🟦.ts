/** 🪟️ Law: a Windows host answers its memory questions through the native calls (`GlobalMemoryStatusEx`, `CreateToolhelp32Snapshot`, `K32GetProcessMemoryInfo`), never through a PowerShell process; the answer is a typed number or a typed unknown with its reason in both languages, an unknown is never read as pressure, every handle is closed, and the structure layouts equal an independent Python `struct` reading of the Win32 definitions. Proven with a Windows-shaped call table; the real kernel calls are not reachable on this machine. */
import {expect,test} from "bun:test";
import {spawnSync} from "node:child_process";
import {readFileSync} from "node:fs";
import {join} from "node:path";
import {testPythonV1} from "../../../../📦️packages/🟦️typescript/🧪️testing/🧰️toolchain/🟦️.ts";
import {createWindowsMemoryPortV1,systemWindowsMemoryPortV1,type NativeWindowsMemoryBindingV1} from "../🟦️.ts";
import {readHostCountersV1,observeTreeMegabytesV1,reduceHostSampleV1,windowsCountersV1} from "../../📡️sampling/🟦️.ts";
import {readHostProcessRowsV1} from "../../🧺️unmanaged/🟦️.ts";
import {readHostCapacityPolicyV1} from "../../🟦️.ts";
import decisionFixture from "../../🧪️tests/🧫️fixtures/🔣️.json";
import fixture from "./🧫️fixtures/🔣️.json";
import schema from "../🧬️schema/🔣️.json";

const here=import.meta.dir,python=testPythonV1(),layout=schema.definitions.Layout.const,policy=readHostCapacityPolicyV1(decisionFixture.policy);
const oracle=(request:object):{sizes:{status:number;entry:number;counters:number};status:string[];entries:string[];counters:string[]}=>{const run=spawnSync(python!,["-I",join(here,"🐍️oracle","🐍️.py")],{input:JSON.stringify(request),encoding:"utf8"});expect(run.status,run.stderr).toBe(0);return JSON.parse(run.stdout);};

type Fault=Readonly<{status?:boolean;snapshot?:boolean;first?:boolean;throws?:boolean;slow?:number}>;
function fake(status:string|undefined,entries:readonly string[],counters:ReadonlyMap<number,string>,pids:readonly number[],fault:Fault={},clock?:{now:number}){
 const open=new Set<bigint>(),calls:string[]=[];let index=-1,error=0;
 const binding:NativeWindowsMemoryBindingV1={
  globalMemoryStatusEx:buffer=>{calls.push("GlobalMemoryStatusEx");if(fault.throws)throw Error("bun:ffi is not available");if(fault.status||buffer.readUInt32LE(0)!==layout.memoryStatus.bytes){error=fault.status?5:87;return 0;}Buffer.from(status!,"hex").copy(buffer);return 1;},
  createToolhelp32Snapshot:(flags)=>{calls.push("CreateToolhelp32Snapshot");if(fault.snapshot||flags!==2){error=5;return BigInt(layout.invalidHandle);}open.add(7n);return 7n;},
  process32First:(snapshot,entry)=>{calls.push("Process32FirstW");if(fault.first||!open.has(snapshot)||entry.readUInt32LE(0)!==layout.processEntry.bytes){error=24;return 0;}index=0;Buffer.from(entries[0]!,"hex").copy(entry);return 1;},
  process32Next:(snapshot,entry)=>{calls.push("Process32NextW");if(clock&&fault.slow)clock.now+=fault.slow;if(entry.readUInt32LE(0)!==layout.processEntry.bytes){error=24;return 0;}index++;if(index>=entries.length){error=18;return 0;}Buffer.from(entries[index]!,"hex").copy(entry);return 1;},
  openProcess:(access,inherit,pid)=>{calls.push("OpenProcess");if(access!==layout.queryLimitedInformation||inherit!==0||!pids.includes(pid)){error=5;return 0n;}const handle=BigInt(1000+pid);open.add(handle);return handle;},
  getProcessMemoryInfo:(handle,buffer,bytes)=>{calls.push("K32GetProcessMemoryInfo");const pid=Number(handle)-1000;if(bytes!==layout.processMemory.bytes||buffer.readUInt32LE(0)!==bytes||!counters.has(pid)){error=87;return 0;}Buffer.from(counters.get(pid)!,"hex").copy(buffer);return 1;},
  closeHandle:handle=>{calls.push("CloseHandle");return open.delete(handle)?1:0;},
  lastError:()=>error,
  close:()=>undefined
 };
 return{binding,open,calls};
}
function machine(){
 const rows=fixture.processes,built=oracle({entries:rows.map(row=>({name:row.name,pid:row.pid,parent:row.parent,threads:row.threads})),counters:rows.filter(row=>!("protected" in row)).map(row=>({peak:(row as any).peak,workingSet:(row as any).workingSet,pagefile:(row as any).pagefile,private:(row as any).private}))});
 const counters=new Map<number,string>(),readable=rows.filter(row=>!("protected" in row));readable.forEach((row,index)=>counters.set(row.pid,built.counters[index]!));
 return{entries:built.entries,counters,pids:readable.map(row=>row.pid)};
}
const tableOf=(m=machine())=>{const f=fake(undefined,m.entries,m.counters,m.pids);return{...f,port:createWindowsMemoryPortV1(f.binding)};};

test("the structure sizes and offsets equal an independent Python struct reading of the Win32 definitions",()=>{
 expect(python,"python is a required test tool").toBeTruthy();
 const built=oracle({});
 expect(built.sizes).toEqual({status:layout.memoryStatus.bytes,entry:layout.processEntry.bytes,counters:layout.processMemory.bytes});
 const machineRows=fixture.machines.map(row=>row.status),made=oracle({status:machineRows,entries:[{name:"x.exe",pid:4242,parent:77,threads:1}],counters:[{peak:9,workingSet:1234,pagefile:5,private:5678}]});
 const status=Buffer.from(made.status[0]!,"hex");
 expect(status.readUInt32LE(0)).toBe(layout.memoryStatus.bytes);expect(status.readUInt32LE(layout.memoryStatus.load)).toBe(machineRows[0]!.load);
 expect(status.readBigUInt64LE(layout.memoryStatus.totalPhysical)).toBe(BigInt(machineRows[0]!.total));expect(status.readBigUInt64LE(layout.memoryStatus.availablePhysical)).toBe(BigInt(machineRows[0]!.available));
 expect(status.readBigUInt64LE(layout.memoryStatus.totalCommit)).toBe(BigInt(machineRows[0]!.commit));expect(status.readBigUInt64LE(layout.memoryStatus.availableCommit)).toBe(BigInt(machineRows[0]!.commitAvailable));
 const entry=Buffer.from(made.entries[0]!,"hex");
 expect(entry.readUInt32LE(layout.processEntry.processId)).toBe(4242);expect(entry.readUInt32LE(layout.processEntry.parentProcessId)).toBe(77);expect(entry.subarray(layout.processEntry.executableName,layout.processEntry.executableName+12).toString("utf16le")).toBe("x.exe\0");
 const counters=Buffer.from(made.counters[0]!,"hex");
 expect(counters.readBigUInt64LE(layout.processMemory.workingSet)).toBe(1234n);expect(counters.readBigUInt64LE(layout.processMemory.privateUsage)).toBe(5678n);
});

test("the machine totals read through GlobalMemoryStatusEx equal the authored machines and become the sampler's counters",async()=>{
 const built=oracle({status:fixture.machines.map(row=>row.status)});
 for(const [index,row] of fixture.machines.entries()){
  const f=fake(built.status[index]!,[],new Map(),[]),port=createWindowsMemoryPortV1(f.binding),facts=port.memory();
  expect(facts,row.name).toMatchObject({known:true,totalBytes:row.expect.totalBytes,availableBytes:row.expect.availableBytes,commitLimitBytes:row.expect.commitLimitBytes,commitAvailableBytes:row.expect.commitAvailableBytes,loadPercent:row.expect.loadPercent});
  expect(f.calls,row.name).toEqual(["GlobalMemoryStatusEx"]);
  const counters=await readHostCountersV1({platform:"win32",run:async()=>{throw Error("no command may run on Windows");},read:async()=>null,windows:port});
  expect(counters,row.name).toEqual({availableBytes:row.expect.countersAvailableBytes,compressedBytes:null,constrainedBytes:null,swapUsedBytes:null,swappedOutBytes:null,pressureLevel:null,stallPercent:null,openFiles:null,openFilesMaximum:null,attachedImages:null});
  expect("partial" in counters).toBe(false);
 }
});

test("a failing or impossible machine answer is a typed unknown with the call, the error and both languages, and never a number",()=>{
 const built=oracle({status:fixture.impossible.map(row=>row.status)});
 for(const [index,row] of fixture.impossible.entries()){const facts=createWindowsMemoryPortV1(fake(built.status[index]!,[],new Map(),[]).binding).memory();expect(facts,row.name).toMatchObject({known:false,reason:"incoherent",call:"GlobalMemoryStatusEx"});if(!facts.known){expect(facts.text.en).toContain("GlobalMemoryStatusEx");expect(facts.text.de).toContain("GlobalMemoryStatusEx");expect(facts.text.en).not.toBe(facts.text.de);}}
 const refused=createWindowsMemoryPortV1(fake(undefined,[],new Map(),[],{status:true}).binding).memory();
 expect(refused).toMatchObject({known:false,reason:"host-call",call:"GlobalMemoryStatusEx",error:5});
 if(!refused.known){expect(refused.text.en).toContain("error 5");expect(refused.text.de).toContain("Fehler 5");}
 const missing=createWindowsMemoryPortV1(fake(undefined,[],new Map(),[],{throws:true}).binding).memory();
 expect(missing).toMatchObject({known:false,reason:"unsupported"});
});

test("the process table lists every process with parent, name and both memory figures, reads unopenable processes as unreadable, and closes every handle",()=>{
 const {port,open,calls}=tableOf(),table=port.processes();
 expect(table.known).toBe(true);if(!table.known)return;
 expect(table.rows.map(row=>[row.pid,row.parent,row.name])).toEqual(fixture.processes.map(row=>[row.pid,row.parent,row.name]));
 const bun=table.rows.find(row=>row.pid===100)!;expect(bun).toMatchObject({workingSetBytes:104857600,privateBytes:52428800});
 expect(table.rows.find(row=>row.pid===4)).toMatchObject({workingSetBytes:null,privateBytes:null});
 expect(table.unreadable).toBe(2);
 expect(open.size,"no handle stays open").toBe(0);
 expect(calls.filter(call=>call==="OpenProcess").length).toBe(fixture.processes.length-1);
 expect(calls.filter(call=>call==="CloseHandle").length,"four opened processes and the snapshot").toBe(5);
});

test("the footprint of a tree is the private commit, the resident set the working set, equal to the authored trees and to the independent shared tree sum",async()=>{
 for(const [root,expected] of Object.entries(fixture.trees)){
  const {port}=tableOf();
  const footprint=await observeTreeMegabytesV1(Number(root),undefined,"win32",undefined,()=>{throw Error("no notice expected");},"footprint",port),resident=await observeTreeMegabytesV1(Number(root),undefined,"win32",undefined,()=>{throw Error("no notice expected");},"resident",port);
  expect(footprint,root).toBe(expected===null?null:expected.footprint);expect(resident,root).toBe(expected===null?null:expected.resident);
 }
});

test("a blind process walk is announced once in every language, observes nothing and learns nothing",async()=>{
 const lines:string[]=[],f=fake(undefined,[],new Map(),[],{snapshot:true}),port=createWindowsMemoryPortV1(f.binding);
 expect(port.processes()).toMatchObject({known:false,reason:"host-call",call:"CreateToolhelp32Snapshot",error:5});
 expect(await observeTreeMegabytesV1(100,undefined,"win32",undefined,line=>lines.push(line),"footprint",port)).toBeNull();
 expect(lines.length).toBe(2);expect(lines[0]).toContain("cannot be observed on win32");expect(lines[0]).toContain("CreateToolhelp32Snapshot");expect(lines[1]).toContain("kann unter win32 nicht beobachtet werden");
 expect(f.open.size).toBe(0);
});

test("a walk that takes too long is the typed budget unknown, and a table of nothing is a failed first call",()=>{
 const m=machine(),clock={now:0},f=fake(undefined,m.entries,m.counters,m.pids,{slow:layout.budgetMilliseconds+1},clock),port=createWindowsMemoryPortV1(f.binding,()=>clock.now);
 const table=port.processes();expect(table).toMatchObject({known:false,reason:"budget"});if(!table.known){expect(table.text.en).toContain("not complete after 4 s");expect(table.text.de).toContain("nach 4 s");}
 expect(f.open.size).toBe(0);
 expect(createWindowsMemoryPortV1(fake(undefined,[],new Map(),[],{first:true}).binding).processes()).toMatchObject({known:false,reason:"host-call",call:"Process32FirstW",error:24});
});

test("a machine that cannot load the native calls answers unknown on both questions and never throws",()=>{
 const port=systemWindowsMemoryPortV1();
 if(process.platform!=="win32"){expect(port.memory()).toMatchObject({known:false,reason:"unsupported"});expect(port.processes()).toMatchObject({known:false,reason:"unsupported"});}
 else expect(port.memory().known||!port.memory().known).toBe(true);
});

test("an unknown memory answer is never pressure: the sample is partial, announced once in both languages, and its pressure follows the free memory alone",async()=>{
 const lines:string[]=[],f=fake(undefined,[],new Map(),[],{status:true}),port=createWindowsMemoryPortV1(f.binding);
 const counters=await readHostCountersV1({platform:"win32",run:async()=>{throw Error("no command may run on Windows");},read:async()=>null,windows:port,notify:line=>lines.push(line)});
 expect(counters.partial).toBe(true);expect(lines.length).toBe(2);expect(lines[0]).toContain("GlobalMemoryStatusEx");expect(lines[0]).toContain("unknown is not pressure");expect(lines[1]).toContain("unbekannt ist kein Druck");
 const facts={platform:"win32" as const,cores:8,totalMegabytes:16384,atMs:5,load:null},sample=reduceHostSampleV1(policy,facts,{...counters,availableBytes:12000*1048576});
 expect(sample.counters).toBe("partial");expect(sample.pressure).toBe("normal");
 expect(reduceHostSampleV1(policy,facts,{...counters,availableBytes:100*1048576}).pressure,"a real shortage is still pressure").not.toBe("normal");
 expect(windowsCountersV1({known:true,totalBytes:1,availableBytes:5,commitLimitBytes:9,commitAvailableBytes:3,loadPercent:1}).availableBytes).toBe(3);
});

test("the unmanaged census reads the native table on Windows, and a blind table is empty",async()=>{
 const {port}=tableOf(),rows=await readHostProcessRowsV1("win32",port);
 expect(rows.find(row=>row.pid===300)).toEqual({pid:300,ppid:100,kilobytes:5120,name:"rustc.exe"});
 const blind=createWindowsMemoryPortV1(fake(undefined,[],new Map(),[],{snapshot:true}).binding);
 expect(await readHostProcessRowsV1("win32",blind)).toEqual([]);
});

test("no production source of the host capacity starts PowerShell for memory any more",()=>{
 const base=join(here,"../..");
 for(const file of ["📡️sampling/🟦️.ts","🧺️unmanaged/🟦️.ts","🪟️native-memory/🟦️.ts"]){const text=readFileSync(join(base,file),"utf8");expect(text,file).not.toMatch(/powershell|Get-CimInstance|Win32_Process|Win32_Perf/iu);}
 expect(readFileSync(join(base,"🧬️schema/🔣️.json"),"utf8")).not.toMatch(/powershell|Get-CimInstance|Win32_Process|Win32_Perf/iu);
});
