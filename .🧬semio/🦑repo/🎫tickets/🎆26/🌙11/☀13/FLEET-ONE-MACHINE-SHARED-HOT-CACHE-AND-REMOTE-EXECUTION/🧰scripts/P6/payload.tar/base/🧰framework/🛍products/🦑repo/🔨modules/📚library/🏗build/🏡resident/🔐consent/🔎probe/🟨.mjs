/** 🔎️ The probe job of the launcher consent: `launcher <this file> <checkout>` lists the checkout with the launcher as responsible process (macOS shows the dialog "repo would like to access files in your Documents folder" now, once) and leaves the marker that the launcher holds the consent; it ends by itself and never serves anything. */
import {readdirSync} from "node:fs";
import {writeLauncherMarkerV1} from "../🟨️.mjs";

const root=process.argv[2];
if(typeof root!=="string"||root.length===0){process.stderr.write("usage: probe <checkout> / Aufruf: probe <Checkout>\n");process.exit(2);}
readdirSync(root);
writeLauncherMarkerV1(root);
