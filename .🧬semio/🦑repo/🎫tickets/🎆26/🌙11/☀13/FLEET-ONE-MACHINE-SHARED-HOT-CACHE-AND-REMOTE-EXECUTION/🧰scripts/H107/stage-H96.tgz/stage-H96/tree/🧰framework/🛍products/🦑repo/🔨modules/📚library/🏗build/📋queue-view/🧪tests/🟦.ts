/** 📋️ Contract: the queue view says per job when it starts and ends (measured progress, then history of the job, then of its class, then a fallback), memory aware with or without backfill, equal to an independent one second grid model; identical requests share one key whatever their presentation flags and a repeated request attaches to the running job instead of running twice; the view satisfies its closed schema under both validators and renders in both languages.
 * @see ../🧬️schema/🔣️.json */
import Ajv from "ajv";
import {expect,test} from "bun:test";
import {dirname,join} from "node:path";
import {fileURLToPath} from "node:url";
import {validateJsonSchemaSubset} from "../../../../../../../🔨️modules/🧬️schema/✅️validator/📦️packages/🟦️typescript/🟦️.ts";
import {testPythonV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧪️testing/🧰️toolchain/🟦️.ts";
import {QUEUE_VIEW_POLICY_V1,admitQueueRequestV1,queueRequestKeyV1,queueViewV1,renderQueueAdmissionV1,renderQueueViewV1,type QueueViewHistoryV1,type QueueViewRowV1,type QueueViewSnapshotV1} from "../🟦️.ts";
import schema from "../🧬️schema/🔣️.json";
import corpus from "./🔣️.json";

const here=dirname(fileURLToPath(import.meta.url)),schemaPath=join(here,"..","🧬️schema","🔣️.json"),python=testPythonV1();
const ajv=new Ajv({strict:false,allowUnionTypes:true}),definitions=schema.definitions,compile=(name:string)=>ajv.compile({$schema:schema.$schema,definitions,$ref:`#/definitions/${name}`});
const inRepo=(name:string,value:unknown)=>validateJsonSchemaSubset({$ref:`#/definitions/${name}`},value,schema as never);
const run=(mode:string)=>JSON.parse(Bun.spawnSync([python!,"-I",join(here,"🐍️.py"),mode,schemaPath,join(here,"🔣️.json")]).stdout.toString()) as never;
type Case=(typeof corpus.simulations)[number];
const rowOf=(row:Record<string,unknown>):QueueViewRowV1=>({key:row.key as string,class:row.class as string,agents:["a1"],tickets:row.tickets as number,reserveMegabytes:row.reserve as number,...row.runMs===undefined?{}:{runMs:row.runMs as number},...row.estimate===undefined?{}:{estimate:row.estimate as never}});
const snapshotOf=(item:Case):QueueViewSnapshotV1=>({atMs:1000,hostBudgetMegabytes:item.budget,running:item.running.map(rowOf),queued:item.queued.map(rowOf)});
const policyOf=(item:Case)=>({...QUEUE_VIEW_POLICY_V1,backfill:item.backfill});

test("every simulated start and end equals the hand computed expectation and the independent grid model, and the view satisfies the schema under both validators",()=>{
 expect(python,"python3 is required for the independent model").toBeTruthy();
 expect(inRepo("Policy",QUEUE_VIEW_POLICY_V1)).toEqual([]);
 const model=run("simulate") as {running:(number|null)[][];queued:number[][];drain:number|null}[],check=compile("View");
 expect(model.length).toBe(corpus.simulations.length);
 corpus.simulations.forEach((item,at)=>{
  const view=queueViewV1(snapshotOf(item),item.history as QueueViewHistoryV1,policyOf(item));
  expect(view.running.map(job=>[job.startsInMs,job.endsInMs]),item.name).toEqual(item.expected.running as never);
  expect(view.queued.map(job=>[job.startsInMs,job.endsInMs]),item.name).toEqual(item.expected.queued as never);
  expect(view.drainsInMs,item.name).toBe(item.expected.drain);
  expect({running:view.running.map(job=>[job.startsInMs,job.endsInMs]),queued:view.queued.map(job=>[job.startsInMs,job.endsInMs]),drain:view.drainsInMs},item.name+" (model)").toEqual(model[at] as never);
  expect(check(view),item.name+JSON.stringify(check.errors)).toBe(true);expect(inRepo("View",view),item.name).toEqual([]);
 });
});

test("sources, stalled jobs, merged duplicates and reservations are reported per job",()=>{
 const [backfill,,progress,classes]=corpus.simulations.map(item=>queueViewV1(snapshotOf(item),item.history as QueueViewHistoryV1,policyOf(item)));
 expect(backfill!.running[0]!.source).toBe("history");
 expect(progress!.running.map(job=>[job.source,job.stalled])).toEqual([["progress",false],["fallback",true]]);
 expect(progress!.running[1]!.merged).toBe(1);expect(progress!.running[1]!.watchers).toBe(2);
 expect(classes!.queued.map(job=>job.source)).toEqual(["class","fallback"]);
 expect(classes!.queued[0]!.merged).toBe(2);expect(classes!.merged).toBe(2);
 expect(classes!.reservedMegabytes).toBe(900);expect(classes!.queued.map(job=>job.position)).toEqual([1,2]);
 const bad:unknown[]=[{...classes!,extra:1},{...classes!,version:2},{...classes!,running:[{...classes!.running[0],source:"guess"}]},{...classes!,queued:[{...classes!.queued[0],position:0}]}];
 for(const value of bad){expect(compile("View")(value)).toBe(false);expect(inRepo("View",value).length).toBeGreaterThan(0);}
});

test("request keys ignore presentation flags and nothing else, and equal the independent model",()=>{
 const model=run("keys") as {same:string[][];different:string[]};
 corpus.requests.same.forEach((group,at)=>{
  const keys=group.map(([command,args])=>queueRequestKeyV1(command as string,args as string[]));
  expect(new Set(keys).size,JSON.stringify(group)).toBe(1);expect(keys).toEqual(model.same[at]!);
 });
 const keys=corpus.requests.different.map(([command,args])=>queueRequestKeyV1(command as string,args as string[]));
 expect(new Set(keys).size).toBe(keys.length);expect(keys).toEqual(model.different);
});

test("a repeated request attaches to the running or queued job with its ETA, a new one is queued with the simulated start, and both render in two languages",()=>{
 const item=corpus.simulations[0]!,snapshot=snapshotOf(item),history=item.history as QueueViewHistoryV1,policy=policyOf(item);
 const running=admitQueueRequestV1(snapshot,{key:"r1",class:"cargo",agent:"a2",reserveMegabytes:600},history,policy);
 expect(running).toEqual({action:"attach",key:"r1",running:true,startsInMs:0,endsInMs:40000,watchers:2});
 const queued=admitQueueRequestV1(snapshot,{key:"q1",class:"cargo",agent:"a1",reserveMegabytes:600},history,policy);
 expect(queued).toEqual({action:"attach",key:"q1",position:1,startsInMs:40000,endsInMs:70000,watchers:1});
 const fresh=admitQueueRequestV1(snapshot,{key:"n",class:"cargo",agent:"a3",reserveMegabytes:600},history,policy);
 expect(fresh).toEqual({action:"enqueue",key:"n",position:3,startsInMs:70000,endsInMs:130000,watchers:1});
 const check=compile("Admission");for(const value of[running,queued,fresh]){expect(check(value),JSON.stringify(check.errors)).toBe(true);expect(inRepo("Admission",value)).toEqual([]);}
 expect(renderQueueAdmissionV1("en",running)).toBe("identical request already running: attaching as watcher #2, ends in 40 s");
 expect(renderQueueAdmissionV1("de",queued)).toBe("gleiche Anfrage eingereiht als #1: als Beobachter #1 angehängt, endet in 1 min 10 s");
 expect(renderQueueAdmissionV1("en",fresh)).toBe("queued as #3: starts in 1 min 10 s, ends in 2 min 10 s");
 expect(renderQueueAdmissionV1("de",fresh)).toBe("eingereiht als #3: startet in 1 min 10 s, endet in 2 min 10 s");
});

test("the view renders running progress, stalled, merged counts, sources and the drain time in both languages",()=>{
 const stalledCase=corpus.simulations[2]!,classCase=corpus.simulations[3]!,first=corpus.simulations[0]!;
 const withProgress=queueViewV1({...snapshotOf(stalledCase),running:snapshotOf(stalledCase).running.map(row=>({...row,progress:{done:5,total:10}}))},stalledCase.history as QueueViewHistoryV1);
 const en=renderQueueViewV1("en",withProgress),de=renderQueueViewV1("de",withProgress);
 expect(en[0]).toBe("queue: 2 running, 0 queued, 1000/2000 MB reserved, drains in unknown");
 expect(de[0]).toBe("Warteschlange: 2 laufen, 0 warten, 1000/2000 MB reserviert, leer in unbekannt");
 expect(en[1]).toBe("running p (run, a1): 5/10 1.0/s, ends in 15 s [progress]");
 expect(en[2]).toBe("running s (run, a1, 1 identical requests merged): stalled, 5/10, ends in unknown [default]");
 expect(de[2]).toBe("läuft s (run, a1, 1 gleiche Anfragen verschmolzen): steht still, 5/10, endet in unbekannt [Standardwert]");
 const view=queueViewV1(snapshotOf(classCase),classCase.history as QueueViewHistoryV1,policyOf(classCase));
 expect(renderQueueViewV1("en",view)).toContain("#1 a (cargo, a1, 2 identical requests merged): starts in 15 s, ends in 35 s [class history]");
 expect(renderQueueViewV1("de",view)).toContain("#2 b (unknown, a1): startet in 35 s, endet in 1 min 35 s [Standardwert]");
 expect(renderQueueViewV1("en",queueViewV1(snapshotOf(corpus.simulations[4]!),first.history as QueueViewHistoryV1))).toEqual(["queue idle"]);
 expect(renderQueueViewV1("de",queueViewV1(snapshotOf(corpus.simulations[4]!))) ).toEqual(["Warteschlange leer"]);
 for(const key of Object.keys(schema.definitions.Texts.const))expect(schema.definitions.Texts.const[key as keyof typeof schema.definitions.Texts.const].de.length>0,key).toBe(true);
});
