/** 📈️ Contract: the rate is the progress over a sliding window, 0 after a quiet window, `stalled` after the declared threshold and then no ETA; the ETA comes from the plan and the measured rate, else from measured history; every estimate satisfies its closed schema under the in-repo validator and Ajv; text and MCP progress render in both languages; an independent Python model replays the same corpus.
 * @see ../🧬️schema/🔣️.json */
import Ajv from "ajv";
import {expect,test} from "bun:test";
import {mkdtempSync,rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {dirname,join} from "node:path";
import {fileURLToPath} from "node:url";
import {validateJsonSchemaSubset} from "../../../../../../../🔨️modules/🧬️schema/✅️validator/📦️packages/🟦️typescript/🟦️.ts";
import {testPythonV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧪️testing/🧰️toolchain/🟦️.ts";
import {PROGRESS_RATE_POLICY_V1,createProgressRateV1,createProgressRatesV1,mcpProgressOfRateV1,progressHistoryOfV1,readProgressHistoryV1,recordProgressHistoryV1,renderProgressRateV1,writeProgressHistoryV1,type ProgressRateEstimateV1} from "../🟦️.ts";
import schema from "../🧬️schema/🔣️.json";
import corpus from "./🔣️.json";

const here=dirname(fileURLToPath(import.meta.url)),schemaPath=join(here,"..","🧬️schema","🔣️.json"),python=testPythonV1();
const ajv=new Ajv({strict:false,allowUnionTypes:true}),definitions=schema.definitions,validator=(name:string)=>ajv.compile({$schema:schema.$schema,definitions,$ref:`#/definitions/${name}`});
const inRepo=(name:string,value:unknown)=>validateJsonSchemaSubset({$ref:`#/definitions/${name}`},value,schema as never);

test("the policy is closed and every replayed estimate equals the independent model and satisfies the schema under both validators",()=>{
 expect(python,"python3 is required for the independent model").toBeTruthy();
 expect(inRepo("Policy",PROGRESS_RATE_POLICY_V1)).toEqual([]);
 expect(validator("Policy")(PROGRESS_RATE_POLICY_V1)).toBe(true);
 const model=JSON.parse(Bun.spawnSync([python!,"-I",join(here,"🐍️.py"),"estimates",schemaPath,join(here,"🔣️.json")]).stdout.toString()) as Record<string,unknown>[][];
 expect(model.length).toBe(corpus.cases.length);
 const check=validator("Estimate");
 corpus.cases.forEach((item,at)=>{
  const tracker=createProgressRateV1({...(item as {history?:{ms:number;items?:number}}).history?{history:(item as {history:{ms:number;items?:number}}).history}:{}});
  item.steps.forEach((step,index)=>{
   const estimate=tracker.observe(step[1]!,step[2],step[0]),expected=model[at]![index]!;
   const label=`${item.name} #${index}`;
   expect({rate:estimate.rate,etaMs:estimate.etaMs,source:estimate.source,stalled:estimate.stalled,stalledForMs:estimate.stalledForMs,elapsedMs:estimate.elapsedMs},label).toEqual(expected as never);
   expect(check(estimate),label+JSON.stringify(check.errors)).toBe(true);
   expect(inRepo("Estimate",estimate),label).toEqual([]);
  });
 });
 for(const mutation of[{},{done:-1,elapsedMs:0,rate:0,etaMs:0,source:"plan",stalled:false,stalledForMs:0},{done:1,elapsedMs:0,rate:0,etaMs:0,source:"guess",stalled:false,stalledForMs:0},{done:1,elapsedMs:0,rate:0,etaMs:0,source:"plan",stalled:false,stalledForMs:0,extra:1}]){
  expect(check(mutation),JSON.stringify(mutation)).toBe(false);
  expect(inRepo("Estimate",mutation).length,JSON.stringify(mutation)).toBeGreaterThan(0);
 }
});

test("a stalled stream has no ETA, a finished one has ETA zero, and the clock can be injected",()=>{
 let clock=0;const tracker=createProgressRateV1({now:()=>clock});
 tracker.observe(0,10);clock=29000;expect(tracker.observe(0,10).stalled).toBe(false);
 clock=30000;const stalled=tracker.observe(0,10);expect(stalled.stalled).toBe(true);expect(stalled.etaMs).toBeNull();
 clock=31000;expect(tracker.observe(10,10).etaMs).toBe(0);
});

test("text and MCP progress render in both languages and the message stays within its bound",()=>{
 const check=validator("McpProgress");
 for(const item of corpus.renders){
  const estimate=item.estimate as ProgressRateEstimateV1;
  expect(renderProgressRateV1("en",item.label,estimate)).toBe(item.en);
  expect(renderProgressRateV1("de",item.label,estimate)).toBe(item.de);
  for(const language of["en","de"] as const){const row=mcpProgressOfRateV1(language,item.label,estimate);expect(check(row),JSON.stringify(check.errors)).toBe(true);expect(inRepo("McpProgress",row)).toEqual([]);expect(row.progress).toBe(estimate.done);}
 }
 expect(mcpProgressOfRateV1("en","x".repeat(400),corpus.renders[0]!.estimate as ProgressRateEstimateV1).message.length).toBe(240);
 expect("total" in mcpProgressOfRateV1("en","u",corpus.renders[2]!.estimate as ProgressRateEstimateV1)).toBe(false);
 for(const key of Object.keys(schema.definitions.Texts.const))expect(schema.definitions.Texts.const[key as keyof typeof schema.definitions.Texts.const].de.length>0,key).toBe(true);
});

test("existing {phase,done,total} rows are decorated per phase with their own window and history",()=>{
 let clock=0;const rated=createProgressRatesV1({now:()=>clock,history:phase=>phase==="verify"?{ms:30000}:undefined});
 const first=rated.decorate({phase:"pin",done:0,total:10},0),second=rated.decorate({phase:"verify",done:0,total:10},0);
 clock=2000;
 expect(rated.decorate({phase:"pin",done:4,total:10}).estimate.rate).toBe(2);
 expect(first.estimate.source).toBe("none");expect(second.estimate.source).toBe("history");
 expect(rated.decorate({phase:"verify",done:0,total:10}).estimate.rate).toBe(0);
});

test("the history keeps the newest runs per key, answers the median, drops the oldest key and survives a corrupt file",()=>{
 let history=readProgressHistoryV1("/nonexistent/h.json");
 expect(history).toEqual({version:1,keys:{}});
 for(const ms of[10,50,20,40,30,60,70,80,90,100])history=recordProgressHistoryV1(history,"a",{ms,items:ms/10});
 expect(history.keys.a!.length).toBe(PROGRESS_RATE_POLICY_V1.historyKeep);
 expect(progressHistoryOfV1(history,"a")).toEqual({ms:60,items:6});
 expect(progressHistoryOfV1(history,"b")).toBeUndefined();
 expect(progressHistoryOfV1(recordProgressHistoryV1({version:1,keys:{}},"c",{ms:5}),"c")).toEqual({ms:5});
 const small={...PROGRESS_RATE_POLICY_V1,historyKeys:2};
 let bounded=recordProgressHistoryV1({version:1,keys:{}},"k1",{ms:1},small);bounded=recordProgressHistoryV1(bounded,"k2",{ms:1},small);bounded=recordProgressHistoryV1(bounded,"k3",{ms:1},small);
 expect(Object.keys(bounded.keys)).toEqual(["k2","k3"]);
 expect(inRepo("History",history)).toEqual([]);expect(validator("History")(history)).toBe(true);
 const directory=mkdtempSync(join(tmpdir(),"h96-rate-"));
 try{const path=join(directory,"nested","history.json");writeProgressHistoryV1(path,history);expect(readProgressHistoryV1(path)).toEqual(history);Bun.write(join(directory,"bad.json"),"{");expect(readProgressHistoryV1(join(directory,"bad.json"))).toEqual({version:1,keys:{}});}finally{rmSync(directory,{recursive:true,force:true});}
});
