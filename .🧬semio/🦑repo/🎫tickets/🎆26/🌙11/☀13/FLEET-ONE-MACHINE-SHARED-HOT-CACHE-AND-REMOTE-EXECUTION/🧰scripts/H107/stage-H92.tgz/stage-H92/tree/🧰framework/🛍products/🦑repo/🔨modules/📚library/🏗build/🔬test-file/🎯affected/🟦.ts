import {existsSync,mkdirSync,readFileSync,readdirSync,renameSync,statSync,writeFileSync} from "node:fs";
import {dirname,isAbsolute,join,posix as unix,relative,resolve,sep} from "node:path";
import {discoverProcessTestFilesV1,expandProcessTestSuiteV1,processTestProtocolV1,type ProcessTestSuiteV1,type ProcessTestTableV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧪️testing/🗂️suites/🟦️.ts";
import {importKeysV1,typecheckCacheDirectoryV1} from "../../🔬️typecheck/🟦️.ts";
import {refuseTestFileV1,testFileTextV1,type TestFileLanguageV1} from "../📖️texts/🟦️.ts";
import type {TestFilePolicyV1} from "../🟦️.ts";

/** 📐️ The closed `affected` section of the test-file policy: where the import graph is read, how deep a change spreads, when a module counts as widely imported and how many tests one call may select.
 * @see ../🧬️schema/🔣️.json */
export type AffectedPolicyV1=TestFilePolicyV1["affected"];
/** 🧭️ How one changed file selected its tests: it is a test itself, a leaf module (its importers and the declared test beside it), a widely imported module (the declared suites that own it), a module without any test in reach (the declared suites as fallback) or a file no suite table covers. */
export type AffectedModeV1="test"|"leaf"|"wide"|"fallback"|"unmapped";
/** 🧾️ One changed file and what it selected. */
export type AffectedRowV1=Readonly<{file:string;mode:AffectedModeV1;importers:number;tests:number;suites:readonly string[]}>;
/** 🎯️ The selection of a call: the test files in checkout-relative POSIX form and one row per changed file. */
export type AffectedSelectionV1=Readonly<{tests:readonly string[];rows:readonly AffectedRowV1[]}>;
/** 🕸️ The reverse import graph: modules by extensionless key, who imports each key and which sources are test files. */
export type AffectedGraphV1=Readonly<{files:ReadonlyMap<string,string>;importers:ReadonlyMap<string,readonly string[]>;tests:ReadonlySet<string>}>;
/** 🔌️ The seams of a selection; tests replace them. */
export type AffectedPortsV1=Readonly<{cacheDirectory?:string;discover?:(root:string)=>readonly string[]}>;

type IndexV1=Record<string,[number,number,string[],boolean]>;
const keyPattern=/(?:\.d\.mts|\.mts|\.mjs|\.tsx|\.ts|\.js|\.jsx|\.cjs|\.cts)$/u;
const runnerPatterns=processTestProtocolV1.importPatterns.map(pattern=>new RegExp(pattern,"u"));

/** 🔑️ The extensionless key under which a source and every spelling of its import meet. */
export const affectedKeyV1=(file:string):string=>file.replace(keyPattern,"");

/** 📍️ Resolves the changed files to checkout-relative POSIX paths: an absolute path as is, a relative one against the directory the caller stands in when it exists there, else against the checkout; the file may be gone (a deletion), it must lie inside the checkout. */
export function affectedChangedFilesV1(root:string,directory:string,files:readonly string[]):readonly string[]{
 const found:string[]=[];
 for(const file of files){
  const candidate=isAbsolute(file)?file:existsSync(resolve(directory,file))?resolve(directory,file):resolve(root,file),inside=relative(resolve(root),resolve(candidate));
  if(inside===""||inside===".."||inside.startsWith(".."+sep)||isAbsolute(inside))throw refuseTestFileV1("invalid","file.outside",{file});
  const posix=inside.split(sep).join("/");
  if(!found.includes(posix))found.push(posix);
 }
 return Object.freeze(found);
}

const isSource=(name:string,rules:AffectedPolicyV1):boolean=>rules.sourceExtensions.some(extension=>name.endsWith(extension));
const walk=(directory:string,rules:AffectedPolicyV1,found:string[]):void=>{
 let entries;try{entries=readdirSync(directory,{withFileTypes:true});}catch{return;}
 for(const entry of entries){
  if(rules.skipDirectories.includes(entry.name))continue;
  const path=join(directory,entry.name);
  if(entry.isDirectory())walk(path,rules,found);else if(entry.isFile()&&isSource(entry.name,rules))found.push(path);
 }
};
const underTests=(file:string,rules:AffectedPolicyV1,extensions:readonly string[]):boolean=>{
 const segments=file.split("/");
 return segments.includes(rules.testDirectory)&&!segments.includes(rules.fixtureDirectory)&&extensions.some(extension=>file.endsWith(extension));
};

/** 🕸️ Reads the reverse import graph of the scan roots: only sources whose size or time changed since the last call are read again (the index lives in the machine cache of the checkout and survives restarts); a test file is a source below a `🧪️tests` folder, outside `🧫️fixtures`, that imports the test runner, exactly the discovery rule of the suite tables. */
export function affectedGraphV1(root:string,rules:AffectedPolicyV1,extensions:readonly string[],cacheDirectory:string=typecheckCacheDirectoryV1(resolve(root))):AffectedGraphV1{
 const indexPath=join(cacheDirectory,rules.indexFile);
 let index:IndexV1={};
 try{index=JSON.parse(readFileSync(indexPath,"utf8")) as IndexV1;}catch{index={};}
 const next:IndexV1={},paths:string[]=[],files=new Map<string,string>(),importers=new Map<string,string[]>(),tests=new Set<string>();
 let changed=false;
 for(const scan of rules.scanRoots){const directory=resolve(root,scan);if(existsSync(directory))walk(directory,rules,paths);}
 for(const path of paths){
  const name=relative(resolve(root),path).split(sep).join("/");
  if(!keyPattern.test(name)&&!name.endsWith(".json"))continue;
  const stat=statSync(path),known=index[name];
  let row=known;
  if(known===undefined||known[0]!==stat.mtimeMs||known[1]!==stat.size){
   const text=readFileSync(path,"utf8");
   row=[stat.mtimeMs,stat.size,name.endsWith(".json")?[]:[...importKeysV1(name,text)],underTests(name,rules,extensions)&&runnerPatterns.some(pattern=>pattern.test(text))];
   changed=true;
  }
  next[name]=row!;
  const key=affectedKeyV1(name);
  if(!files.has(key)||name.endsWith(".ts"))files.set(key,name);
  if(row![3])tests.add(name);
  for(const imported of row![2]){const list=importers.get(imported);if(list)list.push(name);else importers.set(imported,[name]);}
 }
 if(changed||Object.keys(index).length!==Object.keys(next).length)try{
  mkdirSync(cacheDirectory,{recursive:true});
  const temporary=indexPath+"."+process.pid+".tmp";
  writeFileSync(temporary,JSON.stringify(next));renameSync(temporary,indexPath);
 }catch{}
 return Object.freeze({files,importers,tests});
}

/** 🌊️ The importers of a module that lie within `depth` import steps, split into test files and other modules; the walk never continues through a test file. */
export function affectedClosureV1(graph:AffectedGraphV1,file:string,depth:number):Readonly<{modules:readonly string[];tests:readonly string[]}>{
 const start=affectedKeyV1(file),seen=new Set<string>([start]),modules:string[]=[],tests:string[]=[];
 let frontier=[start];
 for(let level=0;level<depth&&frontier.length>0;level++){
  const following:string[]=[];
  for(const key of frontier)for(const importer of graph.importers.get(key)??[]){
   const importerKey=affectedKeyV1(importer);
   if(seen.has(importerKey))continue;
   seen.add(importerKey);
   if(graph.tests.has(importer)){tests.push(importer);continue;}
   modules.push(importer);following.push(importerKey);
  }
  frontier=following;
 }
 return Object.freeze({modules:Object.freeze(modules.sort()),tests:Object.freeze(tests.sort())});
}

const ownerOf=(file:string,rules:TestFilePolicyV1)=>rules.tables.find(row=>file.startsWith(row.root+"/"));

/** 🧪️ The declared test entry beside a module: the `🧪️tests/🟦️.ts` of the nearest folder above it, when it is a test of the graph. */
export function affectedDeclaredTestV1(graph:AffectedGraphV1,file:string,rules:AffectedPolicyV1):string|undefined{
 for(let directory=unix.dirname(file);directory!=="."&&directory!=="/";directory=unix.dirname(directory)){
  const candidate=unix.join(directory,rules.testDirectory,rules.entryName);
  if(graph.tests.has(candidate))return candidate;
 }
 return undefined;
}

/** 🗂️ The suites a module belongs to: those owning the deepest tree above it in the suite table of its area, with the test files each of them declares (helpers excluded). */
export function affectedSuitesV1(root:string,file:string,tables:ReadonlyMap<string,ProcessTestTableV1>,rules:TestFilePolicyV1,discover:(root:string)=>readonly string[]=discoverProcessTestFilesV1):Readonly<{suites:readonly string[];tests:readonly string[]}>{
 const owner=ownerOf(file,rules),table=owner===undefined?undefined:tables.get(owner.id);
 if(owner===undefined||table===undefined)return {suites:[],tests:[]};
 const module=file.slice(owner.root.length+1),depth=(suite:ProcessTestSuiteV1)=>Math.max(-1,...(suite.trees??[]).filter(tree=>module===tree||module.startsWith(tree+"/")).map(tree=>tree.length));
 const best=Math.max(-1,...table.suites.map(depth)),chosen=best<0?[]:table.suites.filter(suite=>depth(suite)===best);
 if(!chosen.length)return {suites:[],tests:[]};
 const discovered=discover(resolve(root,owner.root)),tests=new Set<string>();
 for(const suite of chosen)for(const member of expandProcessTestSuiteV1(suite,discovered,table))if(!table.helpers.includes(member))tests.add(owner.root+"/"+member);
 return {suites:chosen.map(suite=>owner.id+":"+suite.id),tests:[...tests].sort()};
}

/** 🎯️ Selects the test files a set of changed files affects. A test file selects itself. A leaf module selects the tests that import it within `maximumDepth` steps plus the declared test entry beside it. A module with more than `wideImporters` importers in reach selects the declared suites that own it instead, and so does a module with no test in reach; a file no suite table covers selects nothing and says so. The selection never grows to the whole workspace: more than `maximumTests` test files is refused.
 * @see ./🧪️tests/🟦️.ts */
export function selectAffectedTestsV1(root:string,changed:readonly string[],tables:ReadonlyMap<string,ProcessTestTableV1>,policy:TestFilePolicyV1,ports:AffectedPortsV1={}):AffectedSelectionV1{
 const rules=policy.affected,graph=affectedGraphV1(root,rules,[...policy.extensions],ports.cacheDirectory),rows:AffectedRowV1[]=[],selected=new Set<string>();
 for(const file of changed){
  if(graph.tests.has(file)){selected.add(file);rows.push({file,mode:"test",importers:0,tests:1,suites:[]});continue;}
  const closure=affectedClosureV1(graph,file,rules.maximumDepth),beside=affectedDeclaredTestV1(graph,file,rules),own=new Set<string>([...closure.tests,...beside===undefined?[]:[beside]]);
  const wide=closure.modules.length>rules.wideImporters,suited=wide||!own.size?affectedSuitesV1(root,file,tables,policy,ports.discover):{suites:[] as string[],tests:[] as string[]};
  const [mode,tests,suites]:[AffectedModeV1,readonly string[],readonly string[]]=wide&&suited.tests.length?["wide",suited.tests,suited.suites]:own.size?["leaf",[...own].sort(),[]]:suited.tests.length?["fallback",suited.tests,suited.suites]:["unmapped",[],[]];
  for(const test of tests)selected.add(test);
  rows.push({file,mode,importers:closure.modules.length,tests:tests.length,suites});
 }
 if(selected.size>rules.maximumTests)throw refuseTestFileV1("invalid","affected.too-wide",{count:selected.size,maximum:rules.maximumTests});
 return Object.freeze({tests:Object.freeze([...selected].sort()),rows:Object.freeze(rows)});
}

/** 📃️ Renders one row of a selection in the chosen language. */
export function renderAffectedRowV1(row:AffectedRowV1,language:TestFileLanguageV1):string{
 const values=row.mode==="test"||row.mode==="unmapped"?{file:row.file}:row.mode==="leaf"?{file:row.file,importers:row.importers,tests:row.tests}:row.mode==="wide"?{file:row.file,importers:row.importers,tests:row.tests,suites:row.suites.join(", ")}:{file:row.file,tests:row.tests,suites:row.suites.join(", ")};
 const keys={test:"affected.row.test",leaf:"affected.row.leaf",wide:"affected.row.wide",fallback:"affected.row.fallback",unmapped:"affected.row.unmapped"} as const;
 return testFileTextV1(language,keys[row.mode],values as Record<string,string|number>);
}
