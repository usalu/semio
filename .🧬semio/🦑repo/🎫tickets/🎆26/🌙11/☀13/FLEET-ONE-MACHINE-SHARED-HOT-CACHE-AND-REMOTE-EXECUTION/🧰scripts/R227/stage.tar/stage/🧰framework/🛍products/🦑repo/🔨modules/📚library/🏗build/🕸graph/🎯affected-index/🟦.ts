import {join,resolve} from "node:path";
import {withRepositoryCacheStoreV1} from "../../../⚡️caching/💾️storage/🔒️enforcement/📦️budget/📥️opening/🏪️store/🟦️.ts";
import {resolveLanguageV1} from "../../../../../../../📦️packages/🟦️typescript/⚙️runtime/🗣️language/🟦️.ts";
import {CATALOG_LANGUAGES_V1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🗣️language/📖️catalog/🟦️.ts";
import {captureOwnedCommandV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🎛️execution/🟦️.ts";
import {scriptCompilerAdmissionControlV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🎟️capacity/🟦️.ts";
import type {ScriptInvocation} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧭️routing/🟦️.ts";
import type {ResourceLeaseControl} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🔒️leases/🟦️.ts";
import {buildChangedFilesCommandsV1,buildBooleanOptionV1} from "../../🧭️selection/🟦️.ts";
import {buildOptionsV1,literalBuildProjectSelectorsV1} from "../../🧭️selection/📥️options/🟦️.ts";
import {graphDeclarationV1,exactSourceReadPolicyV1} from "../🔐️authority/🟦️.ts";
import {readInventoryRecordLeanV1} from "../../📥️inputs/🪶️lean-inventory/🟨️.mjs";
import {captureSourceInputInventoryV1,captureCargoLockInventoryV1} from "../../📥️inputs/📋️data/📥️load/🟨️.mjs";
import {workspaceClosurePortV1} from "../🕰️generations/🌐️remote-exchange/🟦️.ts";
import {generationFilesV1} from "../🛑️custody/🟦️.ts";
import {createGenerationStoreV1,type GenerationFilePortV1} from "../🕰️generations/🟨️.mjs";
import {generationAgeSecondsV1,generationAgeTextV1} from "../🕰️generations/🔌️load/🟨️.mjs";
import {AFFECTED_INDEX_POLICY_V1 as P,ensureAffectedIndexV1,openAffectedIndexV1,renderAffectedMessageV1,type AffectedMessageKeyV1} from "./🟨️.mjs";

const language=()=>resolveLanguageV1(CATALOG_LANGUAGES_V1,[],process.env).language as "en"|"de",say=(key:AffectedMessageKeyV1,fields:Record<string,string|number>)=>{process.stderr.write(renderAffectedMessageV1(key,fields,language())+"\n");};
const declared=()=>graphDeclarationV1("../🔣️policy.json").namedInputs as Record<string,readonly unknown[]>;

/** 🗄️ The files one closure leaf of this machine lists (undefined when the leaf is not here): the reading `portableInputs` does for the same leaf, without expanding any node.
 * @see ../📁️workspace/🟦️.ts */
export function affectedLeafPortV1(workspace:string):(key:string)=>Promise<readonly string[]|undefined>{
 const port=workspaceClosurePortV1(workspace);
 return async key=>{
  const match=/^SEMIO_(SOURCE_CLOSURE|CARGO_LOCK)_([a-f0-9]{64})$/u.exec(key);if(!port||!match)return undefined;
  const source=match[1]==="SOURCE_CLOSURE";
  try{
   const file=readInventoryRecordLeanV1(port.directory(source?"build-input-closures":"build-lock-closures"),match[2]!,exactSourceReadPolicyV1.maximumClosureBytes);if(file.sha256!==match[2])return undefined;
   return source?captureSourceInputInventoryV1(file.value,workspace).value.files:["Cargo.lock",captureCargoLockInventoryV1(file.value,workspace).value.manifest];
  }catch{return undefined;}
 };
}

/** 🔏️ The hook the generation store calls after it published a generation: derives and stores the reverse index beside it; a failure is never a failure of the build.
 * @see ../🕰️generations/🟨️.mjs */
export function affectedSealHookV1(input:{workspace:string;root:string;fs:GenerationFilePortV1;declared:Readonly<Record<string,readonly unknown[]>>}){
 return async(sealed:{manifest:never;digest:string;readFragment:never;readGlobal:never;signal?:AbortSignal}):Promise<void>=>{
  try{
   const out=await ensureAffectedIndexV1({fs:input.fs,root:input.root,sealed:{manifest:sealed.manifest,digest:sealed.digest},declared:input.declared as never,readFragment:sealed.readFragment,readGlobal:sealed.readGlobal,leafFiles:affectedLeafPortV1(input.workspace),signal:sealed.signal});
   if(out.derived&&out.stats)say("derived",{generation:out.index.generation,read:out.stats.read,owners:out.stats.owners,milliseconds:out.stats.milliseconds,megabytes:(out.stats.bytes/1048576).toFixed(1)});
  }catch{}
 };
}

const VALUE_OPTIONS=["base","head","files"],BOOLEAN_OPTIONS=["uncommitted","untracked","all"];

/** 🚦️ Whether `repo affected` may be answered by the index, and the arguments of the equivalent literal `run-many` once the projects are known: no `--all`, no `--exclude` (which may name tags and patterns), literal bounded targets (the selection rule of a selected read). */
export function affectedFastPlanV1(args:readonly string[]):{head:string[];forwarded:string[];files:string[]|undefined}|undefined{
 if(args[0]!=="affected")return undefined;
 const boundary=args.indexOf("--"),head=args.slice(1,boundary<0?undefined:boundary),forwarded=boundary<0?[]:args.slice(boundary),all=["affected",...head];
 if(buildBooleanOptionV1(all,"all")===true||buildOptionsV1(all,["exclude"]).length||buildOptionsV1(all,["projects","p"]).length)return undefined;
 const targets=[...new Set(buildOptionsV1(all,["targets","target","t"]).flatMap(value=>value.split(",").filter(Boolean)))];
 if(!targets.length||targets.length>64||!targets.every(target=>!/[*?\[\]{}()\\:]/u.test(target)))return undefined;
 const kept:string[]=[];
 for(let at=0;at<head.length;at++){
  const argument=head[at]!,name=argument.replace(/^--?/u,"").split("=")[0]!;
  if(VALUE_OPTIONS.includes(name)){if(!argument.includes("="))at++;continue;}
  if(BOOLEAN_OPTIONS.includes(name)){if(!argument.includes("=")&&["true","false"].includes(head[at+1]??""))at++;continue;}
  kept.push(argument);
 }
 const listed=buildOptionsV1(all,["files"]).flatMap(value=>value.split(",").filter(Boolean));
 return{head:kept,forwarded,files:listed.length?listed:undefined};
}

/** 🎯️ Answers `repo affected` from the reverse index of the sealed generation of this machine: changed files by git (or `--files`), projects by the index in milliseconds, then the same command as a literal `run-many` over exactly those projects, which reads only their owners; `undefined` leaves the question to the whole graph (no sealed generation, a changed manifest of an unknown project, a bound, any fault), always with the reason said. */
export async function answerAffectedV1(input:{root:string;invocation:ScriptInvocation;phaseControl:ResourceLeaseControl;args:readonly string[]}):Promise<{kind:"none"}|{kind:"rewrite";args:string[]}|undefined>{
 const plan=affectedFastPlanV1(input.args);if(!plan)return undefined;
 try{
  const control=scriptCompilerAdmissionControlV1(input.invocation,"build:affected-files",30_000),files=plan.files??[...new Set((await Promise.all(buildChangedFilesCommandsV1(["affected",...plan.head]).map(command=>captureOwnedCommandV1("git",[...command],input.root,{control})))).flatMap(output=>output.split("\0").filter(Boolean)))];
  const started=performance.now();
  const answer=await withRepositoryCacheStoreV1(input.root,"graph",input.invocation,input.phaseControl,async(store)=>{
   const root=join(store.root,"generations"),fs=generationFilesV1(store as never),engine=createGenerationStoreV1({root,fs,holds:async()=>true,resources:{facts:"repository-graph-facts:"+resolve(input.root)},workspaceRoot:input.root}),sealed=await engine.read(input.invocation.control.signal);
   if(!sealed?.manifest){say("noGeneration",{});return undefined;}
   const loaded=await ensureAffectedIndexV1({fs,root,sealed:{manifest:sealed.manifest,digest:sealed.pointer.manifest!},declared:declared() as never,readFragment:row=>engine.readFragment(row),readGlobal:manifest=>engine.readGlobal(manifest),leafFiles:affectedLeafPortV1(input.root),signal:input.invocation.control.signal});
   if(loaded.derived&&loaded.stats)say("derived",{generation:loaded.index.generation,read:loaded.stats.read,owners:loaded.stats.owners,milliseconds:loaded.stats.milliseconds,megabytes:(loaded.stats.bytes/1048576).toFixed(1)});
   const result=openAffectedIndexV1(loaded.index).query(files),age=await generationAgeSecondsV1(fs,root,sealed.pointer.manifest!,Date.now());
   if(result.unknown.length){say("unknownOwner",{path:result.unknown[0]!});return undefined;}
   if(result.projects.length>P.maximumProjects||!literalBuildProjectSelectorsV1(result.projects,[])&&result.projects.length){say("tooMany",{count:result.projects.length,limit:P.maximumProjects});return undefined;}
   say("answered",{count:result.projects.length,files:files.length,generation:loaded.index.generation,owners:Object.keys(sealed.manifest.owners).length,milliseconds:Math.round(performance.now()-started),age:age===undefined?"?":generationAgeTextV1(age)});
   return result.projects;
  });
  if(answer===undefined)return undefined;
  if(!answer.length)return{kind:"none"};
  return{kind:"rewrite",args:["run-many","--projects="+answer.join(","),...plan.head,...plan.forwarded]};
 }catch(error){
  const code=(error as {code?:string}).code;
  if(code==="AFFECTED_TOO_LARGE")say("tooLarge",{reason:String((error as Error).message).slice(0,120)});else if(code==="AFFECTED_LEAF_MISSING")say("leafMissing",{key:String((error as {key?:string}).key??"").slice(0,80)});else if(input.invocation.control.signal.aborted)throw error;else say("failed",{reason:String((error as Error).message).slice(0,160)});
  return undefined;
 }
}
