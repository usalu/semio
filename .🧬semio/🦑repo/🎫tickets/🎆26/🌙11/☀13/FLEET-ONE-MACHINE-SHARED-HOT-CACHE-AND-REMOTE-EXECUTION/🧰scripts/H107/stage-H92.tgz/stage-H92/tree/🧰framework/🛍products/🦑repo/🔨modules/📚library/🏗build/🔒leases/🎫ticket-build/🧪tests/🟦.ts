/** 🎟️ Contract: a ticket runs one heavy build at a time; further heavy builds of the same ticket queue in arrival order and say so in both languages, a nested build passes, a dead holder is taken over, other tickets and light commands are never held back.
 * @see ../🟦️.ts */
import {expect,test} from "bun:test";
import Ajv from "ajv";
import {existsSync,mkdirSync,mkdtempSync,readdirSync,rmSync,writeFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import schema from "../🧬️schema/🔣️.json" with {type:"json"};
import {acquireTicketBuildLeaseV1,ticketBuildHeavyV1,ticketBuildLeaseDirectoryV1,ticketBuildLeaseHeldV1,ticketOfBuildV1,TICKET_BUILD_LEASE_POLICY_V1 as P,validateTicketBuildHolderV1,withTicketBuildLeaseV1} from "../🟦️.ts";

const fast={...P,pollMilliseconds:2,progressMilliseconds:0},wait=(milliseconds:number)=>new Promise<void>(done=>setTimeout(done,milliseconds));
const world=()=>mkdtempSync(join(tmpdir(),"ticket-lease-"));

test("the policy and the holder file satisfy their closed schemas under Ajv and the in-repo validator, and both reject the same mutations",()=>{
 const ajv=new Ajv({strict:false}),policy=ajv.compile({$schema:schema.$schema,definitions:schema.definitions,$ref:"#/definitions/Holder"});
 const holder={version:1,ticket:"26/11/27/X",pid:4,token:"0123456789abcdef0123456789abcdef",operation:"cargo",startedAtMs:5};
 expect(policy(holder),JSON.stringify(policy.errors?.[0])).toBe(true);
 expect(validateTicketBuildHolderV1(holder)).toEqual([]);
 for(const mutate of [(value:any)=>{value.pid=0;},(value:any)=>{value.token="x";},(value:any)=>{value.extra=1;},(value:any)=>{delete value.operation;}]){
  const value=JSON.parse(JSON.stringify(holder));mutate(value);
  expect(policy(value)).toBe(false);expect(validateTicketBuildHolderV1(value).length).toBeGreaterThan(0);
 }
 expect(Object.keys(schema.definitions.Messages.const.messages).every(key=>{const row=(schema.definitions.Messages.const.messages as Record<string,{en:string;de:string}>)[key]!;return row.en.length>10&&row.de.length>10;})).toBe(true);
});

test("a ticket is named by the environment or by the folder the build runs in, with or without the emoji variation selector, and a build outside every ticket has none",()=>{
 const root="/work/repo",folder=(...parts:string[])=>join(root,".🧬semio","🦑️repo","🎫️tickets",...parts);
 expect(ticketOfBuildV1(root,folder("🎆️26","🌙️11","☀️27","SLUG","🗑️generated"),{})).toBe("26/11/27/SLUG");
 expect(ticketOfBuildV1(root,folder("🎆26","🌙11","☀27","SLUG"),{})).toBe("26/11/27/SLUG");
 expect(ticketOfBuildV1(root,root,{})).toBeUndefined();
 expect(ticketOfBuildV1(root,folder("🎆️26","🌙️11"),{})).toBeUndefined();
 expect(ticketOfBuildV1(root,root,{SEMIO_TICKET:"26/11/27/OTHER"})).toBe("26/11/27/OTHER");
 expect(ticketOfBuildV1(root,root,{SEMIO_TICKET:"26/11/OTHER"})).toBeUndefined();
});

test("cargo, run-many and affected are heavy, help, dry runs and every other command are not",()=>{
 const rows:[string[],boolean][]=[[["cargo","build"],true],[["run-many","--targets=test"],true],[["affected","--targets=test"],true],[["run","a:b"],false],[["show","projects"],false],[["cargo","--help"],false],[["run-many","--dry-run"],false],[["affected","--graph=stdout"],false],[["run-many","--","--help"],true],[[],false]];
 for(const [args,heavy] of rows)expect(ticketBuildHeavyV1(args),args.join(" ")).toBe(heavy);
});

test("a second heavy build of the same ticket waits for the first, says so in both languages and then starts; another ticket is not held back",async()=>{
 const root=world();
 try{
  const first=await acquireTicketBuildLeaseV1(root,"26/11/27/A","cargo",{environment:{},policy:fast});
  const other=await acquireTicketBuildLeaseV1(root,"26/11/27/B","run-many",{environment:{},policy:fast});
  expect(ticketBuildLeaseHeldV1(root,"26/11/27/A")).toBe(true);
  const lines:string[]=[];let started=false;
  const second=acquireTicketBuildLeaseV1(root,"26/11/27/A","run-many",{environment:{},policy:fast,notice:line=>lines.push(line)}).then(lease=>{started=true;return lease;});
  await wait(60);
  expect(started).toBe(false);
  expect(lines[0]).toContain("queued at position 1");expect(lines[0]).toContain("steht an Position 1");expect(lines[0]).toContain(" / ");expect(lines[0]).toContain("cargo");
  await first.release();await first.release();
  const lease=await second;
  expect(started).toBe(true);expect(lines.some(line=>line.includes("is yours")&&line.includes("gehört dir"))).toBe(true);
  await lease.release();await other.release();
  expect(ticketBuildLeaseHeldV1(root,"26/11/27/A")).toBe(false);
  expect(existsSync(join(ticketBuildLeaseDirectoryV1(root,"26/11/27/A"),"holder.json"))).toBe(false);
 }finally{rmSync(root,{recursive:true,force:true});}
});

test("builds queue in arrival order",async()=>{
 const root=world();
 try{
  const first=await acquireTicketBuildLeaseV1(root,"26/11/27/Q","cargo",{environment:{},policy:fast}),order:string[]=[];
  const run=(name:string)=>acquireTicketBuildLeaseV1(root,"26/11/27/Q",name,{environment:{},policy:fast}).then(async lease=>{order.push(name);await wait(5);await lease.release();});
  const all=[run("one"),(async()=>{await wait(15);await run("two");})(),(async()=>{await wait(30);await run("three");})()];
  await wait(60);await first.release();
  await Promise.all(all);
  expect(order).toEqual(["one","two","three"]);
 }finally{rmSync(root,{recursive:true,force:true});}
});

test("a build nested in the holder passes through its inherited token, and the token is removed from the environment again",async()=>{
 const root=world(),environment:NodeJS.ProcessEnv={};
 try{
  const outer=await acquireTicketBuildLeaseV1(root,"26/11/27/N","run-many",{environment,policy:fast});
  expect(environment[P.environment.token]).toMatch(/^[0-9a-f]{32}$/u);
  const inner=await acquireTicketBuildLeaseV1(root,"26/11/27/N","cargo",{environment,policy:fast});
  expect(inner.reentrant).toBe(true);await inner.release();
  expect(ticketBuildLeaseHeldV1(root,"26/11/27/N")).toBe(true);
  await outer.release();
  expect(environment[P.environment.token]).toBeUndefined();
  expect(ticketBuildLeaseHeldV1(root,"26/11/27/N")).toBe(false);
 }finally{rmSync(root,{recursive:true,force:true});}
});

test("a lease whose holder is gone, or a half-written one, is taken over; a lease held for longer than the maximum is stale",async()=>{
 const root=world();
 try{
  const directory=ticketBuildLeaseDirectoryV1(root,"26/11/27/D");mkdirSync(directory,{recursive:true});
  const holder={version:1,ticket:"26/11/27/D",pid:99999991,token:"0123456789abcdef0123456789abcdef",operation:"cargo",startedAtMs:Date.now()};
  writeFileSync(join(directory,"holder.json"),JSON.stringify(holder));
  const lines:string[]=[],lease=await acquireTicketBuildLeaseV1(root,"26/11/27/D","run-many",{environment:{},policy:fast,alive:pid=>pid!==99999991,notice:line=>lines.push(line)});
  expect(lines[0]).toContain("is gone");expect(lines[0]).toContain("ist fort");
  await lease.release();
  writeFileSync(join(directory,"holder.json"),JSON.stringify({...holder,pid:process.pid,startedAtMs:0}));
  const stale=await acquireTicketBuildLeaseV1(root,"26/11/27/D","cargo",{environment:{},policy:fast});
  await stale.release();
 }finally{rmSync(root,{recursive:true,force:true});}
});

test("a waiting build ends with a bilingual refusal at the maximum wait and when it is cancelled, and leaves no queue entry behind",async()=>{
 const root=world();
 try{
  const holder=await acquireTicketBuildLeaseV1(root,"26/11/27/T","cargo",{environment:{},policy:fast});
  const short={...fast,maximumWaitMilliseconds:30};
  let error:unknown;try{await acquireTicketBuildLeaseV1(root,"26/11/27/T","run-many",{environment:{},policy:short});}catch(raised){error=raised;}
  expect(String((error as Error).message)).toContain("did not start within");expect(String((error as Error).message)).toContain("startete nicht innerhalb");
  const controller=new AbortController();
  const waiting=acquireTicketBuildLeaseV1(root,"26/11/27/T","run-many",{environment:{},policy:fast,signal:controller.signal});
  await wait(20);controller.abort();
  await expect(waiting).rejects.toThrow("wurde abgebrochen");
  const queue=join(ticketBuildLeaseDirectoryV1(root,"26/11/27/T"),"queue");
  expect(readdirSync(queue)).toEqual([]);
  await holder.release();
 }finally{rmSync(root,{recursive:true,force:true});}
});

test("the wrapper serialises heavy builds of one ticket and lets light commands and builds outside a ticket run at once",async()=>{
 const root=world(),tickets=join(root,".🧬semio","🦑️repo","🎫️tickets","🎆️26","🌙️11","☀️27","SLUG");
 mkdirSync(tickets,{recursive:true});
 try{
  let running=0,peak=0;
  const body=async()=>{running++;peak=Math.max(peak,running);await wait(15);running--;return "done";};
  const options=()=>({cwd:tickets,environment:{} as NodeJS.ProcessEnv,policy:fast});
  const results=await Promise.all([withTicketBuildLeaseV1(root,["cargo","build"],body,options()),withTicketBuildLeaseV1(root,["run-many"],body,options()),withTicketBuildLeaseV1(root,["affected"],body,options())]);
  expect(results).toEqual(["done","done","done"]);expect(peak).toBe(1);
  running=0;peak=0;
  await Promise.all([withTicketBuildLeaseV1(root,["run","a:b"],body,options()),withTicketBuildLeaseV1(root,["run","a:c"],body,options()),withTicketBuildLeaseV1(root,["cargo","x"],body,{...options(),cwd:root}),withTicketBuildLeaseV1(root,["cargo","y"],body,{...options(),cwd:root})]);
  expect(peak).toBe(4);
  await expect(withTicketBuildLeaseV1(root,["cargo"],async()=>{throw Error("boom");},options())).rejects.toThrow("boom");
  expect(ticketBuildLeaseHeldV1(root,"26/11/27/SLUG")).toBe(false);
 }finally{rmSync(root,{recursive:true,force:true});}
});
