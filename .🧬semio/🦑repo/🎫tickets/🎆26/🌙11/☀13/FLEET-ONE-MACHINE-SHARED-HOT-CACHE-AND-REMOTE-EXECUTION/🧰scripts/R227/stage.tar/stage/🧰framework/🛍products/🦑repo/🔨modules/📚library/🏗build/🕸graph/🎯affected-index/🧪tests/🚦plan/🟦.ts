/** 🚦️ Contract: the fast plan of `repo affected` takes only questions the index answers exactly (no `--all`, no `--exclude`, no `--projects`, literal bounded targets), keeps every other option and the arguments after `--`, and drops the changed-file options that only select the files. */
import {expect,test} from "bun:test";
import {affectedFastPlanV1} from "../../🟦️.ts";

test("eligible questions keep their options, drop the file selectors",()=>{
 expect(affectedFastPlanV1(["affected","--targets=build,test","--base=main","--head","HEAD","--parallel=4","--","--flag"])).toEqual({head:["--targets=build,test","--parallel=4"],forwarded:["--","--flag"],files:undefined});
 expect(affectedFastPlanV1(["affected","-t","test","--files=a.ts,b/c.ts","--uncommitted","--untracked=true","--bail","true"])).toEqual({head:["-t","test","--bail","true"],forwarded:[],files:["a.ts","b/c.ts"]});
});

test("questions the index cannot answer exactly stay with the whole graph",()=>{
 for(const args of[["run-many","--targets=build"],["affected","--targets=build","--all"],["affected","--targets=build","--exclude=tag:x"],["affected","--targets=build","--projects=a"],["affected"],["affected","--targets=b*"],["affected","--targets=a:b"],["affected","--targets="+Array.from({length:65},(_,at)=>"t"+at).join(",")]])expect(affectedFastPlanV1(args)).toBeUndefined();
});
