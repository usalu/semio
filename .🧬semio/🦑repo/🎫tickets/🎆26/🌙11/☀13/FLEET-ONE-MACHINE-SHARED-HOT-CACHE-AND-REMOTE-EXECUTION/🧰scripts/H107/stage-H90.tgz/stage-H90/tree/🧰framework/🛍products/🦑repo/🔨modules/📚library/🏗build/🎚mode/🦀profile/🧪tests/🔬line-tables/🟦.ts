import {existsSync,mkdirSync,mkdtempSync,readdirSync,rmSync,writeFileSync} from "node:fs";
import {homedir,tmpdir} from "node:os";
import {join,resolve} from "node:path";
import {spawnSync} from "node:child_process";
import {fileURLToPath} from "node:url";
import {expect,test} from "bun:test";
import {planCargoProfilePolicyV1,renderCargoProfileConfigurationV1} from "../../🟦️.ts";
import schema from "../../🧬️schema/🔣️.json";
import {unitKeyV1} from "../../../../../⚡️caching/🦀️cargo/🗃️unit-cache/🔏️key/🟦️.ts";
import corpus from "./🔣️.json";

const here=fileURLToPath(new URL(".",import.meta.url));
const python=(()=>{for(const name of ["python3","python"]){const run=spawnSync(name,["--version"]);if(run.status===0)return name;}return undefined;})();

test("native prototype builds, tests and checks keep line-level debug information only; every other role keeps its level",()=>{
 for(const row of corpus.cases){
  const plan=planCargoProfilePolicyV1(row.request,{kind:"repository",owner:"Cargo.toml"}),selectors=renderCargoProfileConfigurationV1(row.request,"Cargo.toml","repository").selectors,expected=(schema.definitions.PolicyProtocol.const.settings as Record<string,{debug:unknown}>)[row.settings]!.debug;
  expect<unknown>(plan.target.debug,row.name).toBe(expected);
  expect(selectors.filter(selector=>/^profile\.[a-z]+\.debug=/u.test(selector)),row.name).toEqual(["profile."+row.request.mode+".debug="+JSON.stringify(expected)]);
 }
 expect(planCargoProfilePolicyV1(corpus.cases[0]!.request,{kind:"repository",owner:"Cargo.toml"}).target.debug).toBe("line-tables-only");
 expect(planCargoProfilePolicyV1(corpus.cases[0]!.request,{kind:"repository",owner:"Cargo.toml"}).host.debug).toBe(0);
});

test("the debug level of every case equals the independent Python oracle",()=>{
 if(python===undefined)return;
 const run=spawnSync(python,[join(here,"🐍️.py"),join(here,"🔣️.json"),resolve(here,"../../🧬️schema/🔣️.json")],{encoding:"utf8"});
 expect(run.status,run.stderr).toBe(0);
 expect(JSON.parse(run.stdout)).toEqual(Object.fromEntries(corpus.cases.map(row=>[row.name,planCargoProfilePolicyV1(row.request,{kind:"repository",owner:"Cargo.toml"}).target.debug])));
});

test("the debug level is part of the compiler arguments and so of the unit key: a unit with another level never shares an entry, no output-determinism bump is needed",()=>{
 const keys=corpus.keyArguments.map(normalized=>unitKeyV1({toolchain:"t",normalized,sourceSha256:"a".repeat(64),externs:[],environment:[]}));
 expect(keys[0]).not.toBe(keys[1]);
});

test("the pinned Cargo accepts the level and reports it in the unit graph",()=>{
 const roots=[join(process.env["RUSTUP_HOME"]??join(homedir(),".rustup"),"toolchains")];
 const toolchain=existsSync(roots[0]!)?readdirSync(roots[0]!).find(name=>name.startsWith("nightly-2026-07-20")):undefined;
 if(toolchain===undefined)return;
 const bin=join(roots[0]!,toolchain,"bin");
 if(spawnSync(join(bin,"rustc"),["-vV"]).status!==0)return;
 const directory=mkdtempSync(join(tmpdir(),"line-tables-"));
 try{
  mkdirSync(join(directory,"src"));writeFileSync(join(directory,"Cargo.toml"),'[package]\nname="probe"\nversion="0.0.0"\nedition="2021"\n[workspace]\n');writeFileSync(join(directory,"src","lib.rs"),"pub fn f()->u8{1}\n");
  const selectors=renderCargoProfileConfigurationV1(corpus.cases[0]!.request,"Cargo.toml","repository").selectors,args=selectors.filter(selector=>/^profile\.prototype\.(inherits|debug)=/u.test(selector)).flatMap(selector=>["--config",selector]);
  const run=spawnSync(join(bin,"cargo"),[...args,"build","--unit-graph","-Z","unstable-options","--offline","--profile","prototype"],{cwd:directory,encoding:"utf8",env:{...process.env,PATH:bin+":"+process.env["PATH"],RUSTC:join(bin,"rustc"),RUSTC_WRAPPER:"",RUSTC_WORKSPACE_WRAPPER:"",CARGO_BUILD_RUSTC_WRAPPER:"",RUSTC_BOOTSTRAP:"1"}});
  expect(run.status,run.stderr).toBe(0);
  const graph=JSON.parse(run.stdout) as {units:{target:{name:string};profile:{debuginfo:unknown}}[]};
  expect(graph.units.find(unit=>unit.target.name==="probe")?.profile.debuginfo).toBe("line-tables-only");
 }finally{rmSync(directory,{recursive:true,force:true});}
});
