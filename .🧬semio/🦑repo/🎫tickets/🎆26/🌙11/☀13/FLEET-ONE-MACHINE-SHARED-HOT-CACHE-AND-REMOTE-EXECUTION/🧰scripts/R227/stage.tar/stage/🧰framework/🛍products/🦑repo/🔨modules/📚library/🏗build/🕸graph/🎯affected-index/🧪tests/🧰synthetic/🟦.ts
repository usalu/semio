/** 🧰️ A synthetic workspace for the affected index: projects with roots, target inputs (workspace files, named inputs, filesets, extended globs, closure leaves), dependency edges, and the same world as a portable graph, so the index and the neutral answer are asked the same question. */
import {createHash} from "node:crypto";
import type {BuildGraphV1} from "../../../📋️model/🟦️.ts";
import {canonicalJsonV1} from "../../../🕰️generations/🟨️.mjs";

export const sha=(value:unknown)=>createHash("sha256").update(typeof value==="string"?value:canonicalJsonV1(value)).digest("hex");
export const random=(seed:number)=>()=>{seed|=0;seed=seed+0x6D2B79F5|0;let value=Math.imul(seed^seed>>>15,1|seed);value=value+Math.imul(value^value>>>7,61|value)^value;return((value^value>>>14)>>>0)/4294967296;};

export interface WorldProjectV1{name:string;root:string;targets:Record<string,{inputs?:unknown[]}>;namedInputs?:Record<string,unknown[]>;edges:{source:string;target:string;type:string}[]}
export interface WorldV1{projects:WorldProjectV1[];declared:Record<string,unknown[]>;leaves:Map<string,string[]>;globalEdges:{source:string;target:string;type:string}[];files:string[]}

export const leafKey=(kind:"SOURCE_CLOSURE"|"CARGO_LOCK",seed:string)=>`SEMIO_${kind}_${sha(seed)}`;

export function makeWorld(seed:number,options:{projects?:number;filesPerLeaf?:number;patternsPerProject?:number;edgesPerProject?:number;leafShare?:number;rootProject?:boolean}={}):WorldV1{
 const next=random(seed),pick=<T,>(list:readonly T[])=>list[Math.floor(next()*list.length)]!,count=options.projects??12,roots:string[]=[];
 const groups=["pkg","lib","app","tools"],names:string[]=[];
 const projects:WorldProjectV1[]=[];
 for(let index=0;index<count;index++){
  let root:string;
  do{root=next()<0.3&&roots.length?pick(roots)+"/n"+index:pick(groups)+"/"+(next()<0.5?"g"+Math.floor(next()*3)+"/":"")+"p"+index;}while(roots.includes(root));
  roots.push(root);names.push("@w/p"+index);
 }
 if(options.rootProject){roots.push(".");names.push("@w/root");}
 const files:string[]=["nx.json","README.md","docs/guide.md","schema/a.json","schema/b.json","shared/x.ts","shared/y.ts","Cargo.lock"];
 for(const root of roots)for(const file of["src/a.ts","src/b.ts","📋️project.json","Cargo.toml"])files.push((root==="."?"":root+"/")+file);
 const declared:Record<string,unknown[]>={default:["{projectRoot}/**/*","{workspaceRoot}/nx.json"],shared:["{workspaceRoot}/shared/*.ts"],schemas:["{workspaceRoot}/schema/*.json",{fileset:"{workspaceRoot}/docs/**/*.md"}]};
 const leaves=new Map<string,string[]>(),leafKeys:string[]=[],perLeaf=options.filesPerLeaf??6;
 for(let index=0;index<Math.max(2,Math.floor(count/2));index++){
  const key=leafKey(index%4===3?"CARGO_LOCK":"SOURCE_CLOSURE","leaf"+seed+":"+index);
  leaves.set(key,key.includes("CARGO_LOCK")?["Cargo.lock",pick(roots)+"/Cargo.toml"]:Array.from({length:perLeaf},()=>pick(files)));leafKeys.push(key);
 }
 const direct=["{workspaceRoot}/schema/a.json","{workspaceRoot}/docs/**/*.md","{workspaceRoot}/shared/*.ts","{workspaceRoot}/README.md","{workspaceRoot}/!(a|b).txt","{projectRoot}/**/*","^default","shared","schemas","default","external:foo"];
 for(let index=0;index<count+(options.rootProject?1:0);index++){
  const root=roots[index]!,inputs:unknown[]=[];
  for(let at=0;at<(options.patternsPerProject??3);at++){const value=next();inputs.push(value<0.15&&leafKeys.length?{env:pick(leafKeys)}:value<0.25?{fileset:"{workspaceRoot}/"+pick(files)}:value<0.4?"{workspaceRoot}/"+pick(files):pick(direct));}
  const other:unknown[]=next()<0.3?[pick(direct),{env:"SOME_OTHER"},{runtime:"node"}]:[];
  projects.push({name:names[index]!,root,targets:{build:{inputs},test:{inputs:other}},...(next()<0.3?{namedInputs:{shared:["{workspaceRoot}/shared/x.ts",...(leafKeys.length&&next()<0.5?[{env:pick(leafKeys)}]:[])]}}:{}),edges:[]});
 }
 const edgesPer=options.edgesPerProject??2;
 for(const project of projects)for(let at=0;at<edgesPer;at++){const target=pick(names);if(next()<0.9)project.edges.push({source:project.name,target:next()<0.1?"npm:external":target,type:pick(["static","implicit"])});}
 const globalEdges=next()<0.5?[{source:pick(names),target:pick(names),type:"implicit"}]:[];
 return{projects,declared,leaves,globalEdges,files};
}

const flatten=(inputs:readonly unknown[],leaves:ReadonlyMap<string,readonly string[]>):unknown[]=>inputs.flatMap(input=>{const key=input&&typeof input==="object"&&Object.keys(input).length===1?(input as {env?:unknown}).env:undefined;return typeof key==="string"&&leaves.has(key)?leaves.get(key)!.map(file=>"{workspaceRoot}/"+file):[input];});

export function worldGraph(world:WorldV1):BuildGraphV1{
 return {version:1,namedInputs:world.declared as never,projects:Object.fromEntries(world.projects.map(project=>[project.name,{name:project.name,root:project.root,targets:Object.fromEntries(Object.entries(project.targets).map(([name,target])=>[name,{execution:{kind:"noop"},...(target.inputs?{inputs:flatten(target.inputs,world.leaves)}:{})}])),...(project.namedInputs?{namedInputs:Object.fromEntries(Object.entries(project.namedInputs).map(([name,list])=>[name,flatten(list,world.leaves)]))}:{})}])) as never,dependencies:[...world.projects.flatMap(project=>project.edges),...world.globalEdges]} as BuildGraphV1;
}

export function worldGeneration(world:WorldV1){
 const fragments=new Map<string,{node:unknown;edges:unknown[]}>(),owners:Record<string,unknown>={};
 for(const project of world.projects){
  const fragment={version:1,name:project.name,root:project.root,kind:"project",node:{name:project.name,root:project.root,targets:Object.fromEntries(Object.entries(project.targets).map(([name,target])=>[name,{execution:{kind:"noop"},...(target.inputs?{inputs:target.inputs}:{})}])),...(project.namedInputs?{namedInputs:project.namedInputs}:{})},edges:project.edges},digest=sha(fragment);
  fragments.set(digest,fragment);owners[project.name]={root:project.root,kind:"project",fragment:digest,bytes:1,edgesEnv:sha("env"),targets:Object.keys(project.targets),config:(project.root==="."?"":project.root+"/")+"📋️project.json"};
 }
 const global={version:1,name:"@global",value:{externalNodes:{},edges:world.globalEdges,unavailable:[]}},manifest={generation:1,global:sha(global),owners};
 return{manifest,digest:sha(manifest),fragments,global:global.value};
}

export const portsOf=(world:WorldV1,generation:ReturnType<typeof worldGeneration>,counts?:{fragments:number;leaves:number;globals:number})=>({
 readFragment:async(row:{fragment:string})=>{if(counts)counts.fragments++;return generation.fragments.get(row.fragment) as never;},
 readGlobal:async()=>{if(counts)counts.globals++;return generation.global as never;},
 leafFiles:async(key:string)=>{if(counts)counts.leaves++;return world.leaves.get(key);}
});

export const changeSets=(world:WorldV1,count:number,seed:number):string[][]=>{const next=random(seed*7+1);return Array.from({length:count},()=>{const size=next()<0.2?0:1+Math.floor(next()*3);return Array.from({length:size},()=>next()<0.15?"new/"+Math.floor(next()*5)+"/file.ts":next()<0.1?"nx.json":world.files[Math.floor(next()*world.files.length)]!);});};
