import {runtimeSupportsV1} from "../../../../⚙️runtime/🏷️identity/🟦️.ts";
import {runtimeNativeSystemV1} from "../../../../⚙️runtime/🧲️native/🟦️.ts";
import schema from "./🧬️schema/🔣️.json" with {type:"json"};

const layout=schema.definitions.Layout.const,texts=schema.definitions.Texts.const;

/** 🧵️ The exact Win32 calls the memory questions need, as one replaceable call table (the FFI call-sequence port of the host capacity). */
export type NativeWindowsMemoryBindingV1=Readonly<{
 globalMemoryStatusEx(status:Buffer):number;
 createToolhelp32Snapshot(flags:number,process:number):bigint;
 process32First(snapshot:bigint,entry:Buffer):number;
 process32Next(snapshot:bigint,entry:Buffer):number;
 openProcess(access:number,inherit:number,process:number):bigint;
 getProcessMemoryInfo(handle:bigint,counters:Buffer,bytes:number):number;
 closeHandle(handle:bigint):number;
 lastError():number;
 close():void;
}>;

/** ❔️ Why a Windows memory question has no answer: an unknown, which no consumer reads as pressure. @see ./🧬️schema/🔣️.json */
export type WindowsMemoryUnknownV1=Readonly<{known:false;reason:"unsupported"|"host-call"|"incoherent"|"budget";call:string;error:number;detail:string;text:Readonly<{en:string;de:string}>}>;
/** 🧮️ What the machine holds in bytes: physical memory and the commit (physical plus page files) with what is still free of each. */
export type WindowsMemoryFactsV1=Readonly<{known:true;totalBytes:number;availableBytes:number;commitLimitBytes:number;commitAvailableBytes:number;loadPercent:number}>|WindowsMemoryUnknownV1;
/** 🌳️ One process of the table: its parent, its executable name and, where the process could be opened, the working set and the private commit in bytes. */
export type WindowsProcessRowV1=Readonly<{pid:number;parent:number;name:string;workingSetBytes:number|null;privateBytes:number|null}>;
/** 📋️ The process table of the machine, with the number of processes whose memory could not be read (protected or exited), or an unknown. */
export type WindowsProcessTableV1=Readonly<{known:true;rows:readonly WindowsProcessRowV1[];unreadable:number}>|WindowsMemoryUnknownV1;
/** 🖥️ The semantic memory questions of a Windows host; neither throws. */
export type WindowsMemoryPortV1=Readonly<{memory():WindowsMemoryFactsV1;processes():WindowsProcessTableV1}>;

const fill=(text:string,values:Readonly<Record<string,string|number>>):string=>text.replace(/\{(\w+)\}/gu,(_,name:string)=>String(values[name]??""));
const unknown=(reason:WindowsMemoryUnknownV1["reason"],call:string,error:number,detail:string,seconds:number=0):WindowsMemoryUnknownV1=>{
 const row=texts[reason],values={call,error,detail,seconds};
 return Object.freeze({known:false,reason,call,error,detail,text:Object.freeze({en:fill(row.en,values),de:fill(row.de,values)})});
};
const whole=(value:bigint):number|undefined=>value<=BigInt(Number.MAX_SAFE_INTEGER)?Number(value):undefined;

/** 🧩️ Builds the semantic port over a call table: the machine totals from `GlobalMemoryStatusEx`, the process table from a `CreateToolhelp32Snapshot` walk and the per-process memory from `K32GetProcessMemoryInfo`; every handle is closed, a call that fails or answers an impossible value is a typed unknown, and the walk is bounded in processes and time. */
export function createWindowsMemoryPortV1(binding:NativeWindowsMemoryBindingV1,now:()=>number=Date.now):WindowsMemoryPortV1{
 const memory=():WindowsMemoryFactsV1=>{
  try{
   const status=Buffer.alloc(layout.memoryStatus.bytes);status.writeUInt32LE(layout.memoryStatus.bytes,0);
   if(binding.globalMemoryStatusEx(status)!==1)return unknown("host-call","GlobalMemoryStatusEx",binding.lastError(),"");
   const field=(offset:number)=>whole(status.readBigUInt64LE(offset)),totalBytes=field(layout.memoryStatus.totalPhysical),availableBytes=field(layout.memoryStatus.availablePhysical),commitLimitBytes=field(layout.memoryStatus.totalCommit),commitAvailableBytes=field(layout.memoryStatus.availableCommit),loadPercent=status.readUInt32LE(layout.memoryStatus.load);
   if(totalBytes===undefined||availableBytes===undefined||commitLimitBytes===undefined||commitAvailableBytes===undefined||totalBytes<1||availableBytes>totalBytes||commitAvailableBytes>commitLimitBytes||loadPercent>100)return unknown("incoherent","GlobalMemoryStatusEx",0,`total ${totalBytes}, available ${availableBytes}, commit ${commitLimitBytes}/${commitAvailableBytes}, load ${loadPercent}`);
   return Object.freeze({known:true,totalBytes,availableBytes,commitLimitBytes,commitAvailableBytes,loadPercent});
  }catch(error){return unknown("unsupported","GlobalMemoryStatusEx",0,String((error as Error)?.message??error).split("\n")[0]!.slice(0,160));}
 };
 const processes=():WindowsProcessTableV1=>{
  let snapshot:bigint|undefined;
  try{
   const invalid=BigInt(layout.invalidHandle),started=now();
   snapshot=binding.createToolhelp32Snapshot(layout.snapshotProcesses,0);
   if(snapshot===0n||snapshot===invalid){const error=binding.lastError();snapshot=undefined;return unknown("host-call","CreateToolhelp32Snapshot",error,"");}
   const entry=Buffer.alloc(layout.processEntry.bytes),rows:WindowsProcessRowV1[]=[];let unreadable=0,more=true;
   entry.writeUInt32LE(layout.processEntry.bytes,0);
   if(binding.process32First(snapshot,entry)!==1)return unknown("host-call","Process32FirstW",binding.lastError(),"");
   while(more){
    if(rows.length>=layout.maximumProcesses||now()-started>layout.budgetMilliseconds)return unknown("budget","Process32NextW",0,"",Math.round(layout.budgetMilliseconds/1000));
    const pid=entry.readUInt32LE(layout.processEntry.processId),parent=entry.readUInt32LE(layout.processEntry.parentProcessId),raw=entry.subarray(layout.processEntry.executableName,layout.processEntry.executableName+layout.processEntry.executableCharacters*2).toString("utf16le"),name=raw.split("\0")[0]!;
    let workingSetBytes:number|null=null,privateBytes:number|null=null;
    const handle=pid===0?0n:binding.openProcess(layout.queryLimitedInformation,0,pid);
    if(handle!==0n){
     try{
      const counters=Buffer.alloc(layout.processMemory.bytes);counters.writeUInt32LE(layout.processMemory.bytes,0);
      if(binding.getProcessMemoryInfo(handle,counters,layout.processMemory.bytes)===1){workingSetBytes=whole(counters.readBigUInt64LE(layout.processMemory.workingSet))??null;privateBytes=whole(counters.readBigUInt64LE(layout.processMemory.privateUsage))??null;}
     }finally{binding.closeHandle(handle);}
    }
    if(workingSetBytes===null)unreadable++;
    rows.push(Object.freeze({pid,parent,name,workingSetBytes,privateBytes}));
    entry.writeUInt32LE(layout.processEntry.bytes,0);more=binding.process32Next(snapshot,entry)===1;
   }
   return Object.freeze({known:true,rows:Object.freeze(rows),unreadable});
  }catch(error){return unknown("unsupported","CreateToolhelp32Snapshot",0,String((error as Error)?.message??error).split("\n")[0]!.slice(0,160));}
  finally{if(snapshot!==undefined)try{binding.closeHandle(snapshot);}catch{}}
 };
 return Object.freeze({memory,processes});
}

/** 🔓️ Loads kernel32 through bun:ffi (the psapi call is `K32GetProcessMemoryInfo` of kernel32 itself); anything but Windows under Bun is a refusal that the system port turns into an unknown. */
export function openNativeWindowsMemoryBindingV1():NativeWindowsMemoryBindingV1{
 if(process.platform!=="win32"||!runtimeSupportsV1("ffi"))throw Error("Actual Windows Bun receiver required");
 const{dlopen,FFIType:f}=runtimeNativeSystemV1(),library=dlopen(layout.library,{GlobalMemoryStatusEx:{args:[f.ptr],returns:f.i32},CreateToolhelp32Snapshot:{args:[f.u32,f.u32],returns:f.u64},Process32FirstW:{args:[f.u64,f.ptr],returns:f.i32},Process32NextW:{args:[f.u64,f.ptr],returns:f.i32},OpenProcess:{args:[f.u32,f.i32,f.u32],returns:f.u64},K32GetProcessMemoryInfo:{args:[f.u64,f.ptr,f.u32],returns:f.i32},CloseHandle:{args:[f.u64],returns:f.i32},GetLastError:{args:[],returns:f.u32}});
 const k=library.symbols as unknown as Record<string,(...args:unknown[])=>unknown>;
 return Object.freeze({
  globalMemoryStatusEx:status=>Number(k.GlobalMemoryStatusEx!(status)),
  createToolhelp32Snapshot:(flags,process)=>BigInt(k.CreateToolhelp32Snapshot!(flags,process) as bigint),
  process32First:(snapshot,entry)=>Number(k.Process32FirstW!(snapshot,entry)),
  process32Next:(snapshot,entry)=>Number(k.Process32NextW!(snapshot,entry)),
  openProcess:(access,inherit,process)=>BigInt(k.OpenProcess!(access,inherit,process) as bigint),
  getProcessMemoryInfo:(handle,counters,bytes)=>Number(k.K32GetProcessMemoryInfo!(handle,counters,bytes)),
  closeHandle:handle=>Number(k.CloseHandle!(handle)),
  lastError:()=>Number(k.GetLastError!()),
  close:()=>library.close()
 });
}

let systemPort:WindowsMemoryPortV1|undefined;
/** 💻️ The process-wide memory port over the real kernel, loaded once; a machine that cannot load it answers every question with a typed unknown and never throws. */
export function systemWindowsMemoryPortV1():WindowsMemoryPortV1{
 if(systemPort)return systemPort;
 try{return systemPort=createWindowsMemoryPortV1(openNativeWindowsMemoryBindingV1());}
 catch(error){const refused=unknown("unsupported","LoadLibrary",0,String((error as Error)?.message??error).split("\n")[0]!.slice(0,160));return Object.freeze({memory:()=>refused,processes:()=>refused});}
}
