/** 💾️ Contract: the index of a sealed generation is stored beside it under the manifest digest, read back without reading a fragment, derived from the newest older index when the generation moved (only changed fragments are read), re-derived when the declared named inputs differ or the file is damaged, and superseded files are pruned after the grace window. */
import {expect,test} from "bun:test";
import {mkdtempSync,realpathSync,rmSync,writeFileSync,existsSync,readdirSync,utimesSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {createNodeFilePortV1} from "../../../🕰️generations/🟨️.mjs";
import {AFFECTED_INDEX_POLICY_V1 as P,ensureAffectedIndexV1,openAffectedIndexV1} from "../../🟨️.mjs";
import {makeWorld,portsOf,sha,worldGeneration} from "../🧰️synthetic/🟦️.ts";

const scratch=()=>mkdtempSync(join(realpathSync(tmpdir()),"affected-"));

test("store, reuse, incremental derivation, invalidation and pruning",async()=>{
 const root=scratch(),fs=createNodeFilePortV1();
 try{
  const world=makeWorld(5,{projects:10}),counts={fragments:0,leaves:0,globals:0},first=worldGeneration(world),ports=portsOf(world,first,counts);
  const one=await ensureAffectedIndexV1({fs,root,sealed:{manifest:first.manifest as never,digest:first.digest},declared:world.declared as never,...ports} as never);
  expect(one.derived).toBe(true);expect(counts.fragments).toBe(10);expect(existsSync(join(root,P.directory,first.digest+P.extension))).toBe(true);
  const read={...counts};const two=await ensureAffectedIndexV1({fs,root,sealed:{manifest:first.manifest as never,digest:first.digest},declared:world.declared as never,...ports} as never);
  expect(two.derived).toBe(false);expect(counts).toEqual(read);expect(two.index).toEqual(one.index);
  const name=world.projects[3]!.name,changed={...world,projects:world.projects.map(project=>project.name===name?{...project,edges:[]}:project)},second=worldGeneration(changed),moved={...second.manifest,generation:2},movedDigest=sha(moved);
  const before={...counts},three=await ensureAffectedIndexV1({fs,root,sealed:{manifest:moved as never,digest:movedDigest},declared:world.declared as never,...portsOf(changed,second,counts)} as never);
  expect(three.derived).toBe(true);expect(counts.fragments-before.fragments).toBe(1);expect(counts.leaves).toBe(before.leaves);expect(three.index.generation).toBe(2);
  expect(openAffectedIndexV1(three.index).owners).toBe(10);
  const other=await ensureAffectedIndexV1({fs,root,sealed:{manifest:moved as never,digest:movedDigest},declared:{...world.declared,extra:[]} as never,...portsOf(changed,second,counts)} as never);
  expect(other.derived).toBe(true);
  writeFileSync(join(root,P.directory,movedDigest+P.extension),"damaged");
  expect((await ensureAffectedIndexV1({fs,root,sealed:{manifest:moved as never,digest:movedDigest},declared:world.declared as never,...portsOf(changed,second,counts)} as never)).derived).toBe(true);
  const old=join(root,P.directory,"1".repeat(64)+P.extension);for(const at of[1,2,3,4]){const path=join(root,P.directory,String(at).repeat(64)+P.extension);writeFileSync(path,"x");utimesSync(path,new Date(0),new Date(at*1000));}
  const third={...moved,generation:3},thirdDigest=sha(third);await ensureAffectedIndexV1({fs,root,sealed:{manifest:third as never,digest:thirdDigest},declared:world.declared as never,...portsOf(changed,second,counts)} as never);
  expect(existsSync(old)).toBe(false);expect(readdirSync(join(root,P.directory)).filter(file=>file.endsWith(P.extension)).length).toBeLessThanOrEqual(P.retainIndexes+1);
 }finally{rmSync(root,{recursive:true,force:true});}
},60000);

test("a leaf nobody holds refuses with the typed code and stores nothing",async()=>{
 const root=scratch(),fs=createNodeFilePortV1();
 try{
  const world=makeWorld(2,{projects:8,patternsPerProject:8}),generation=worldGeneration(world),ports={...portsOf(world,generation),leafFiles:async()=>undefined};
  await expect(ensureAffectedIndexV1({fs,root,sealed:{manifest:generation.manifest as never,digest:generation.digest},declared:world.declared as never,...ports} as never)).rejects.toMatchObject({code:"AFFECTED_LEAF_MISSING"});
  expect(existsSync(join(root,P.directory))).toBe(false);
 }finally{rmSync(root,{recursive:true,force:true});}
});
