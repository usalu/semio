#!/usr/bin/env python3
"""🐍️ Independent model of the verdict reuse key (standard library only): `key <schema> <root> <file> <extra.json>` walks the tree, scans imports with its own pattern, builds the inputs document and prints its key and cache address; `canonical <schema> <document>` prints the canonical JSON digest of a document."""
import hashlib, json, os, re, sys

schema = json.load(open(sys.argv[2], encoding="utf-8"))["definitions"]
policy = schema["Policy"]["const"]
sha = lambda b: hashlib.sha256(b).hexdigest()
canon = lambda v: json.dumps(v, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def rel(path, root):
    return os.path.relpath(path, root).replace(os.sep, "/")


def tree(path, root):
    out = []
    if os.path.isfile(path):
        return [{"path": rel(path, root), "digest": sha(open(path, "rb").read())}]
    if not os.path.isdir(path):
        return [{"path": rel(path, root), "digest": "0" * 64}]
    for base, dirs, files in os.walk(path):
        dirs[:] = sorted(d for d in dirs if d not in policy["skipFolders"])
        for name in sorted(files):
            full = os.path.join(base, name)
            out.append({"path": rel(full, root), "digest": sha(open(full, "rb").read())})
    return sorted(out, key=lambda e: e["path"])


PATTERNS = [r"""\b(?:import|export)\s+(?:type\s+)?(?:[^"'`;]*?\sfrom\s*)?["']([^"'\n]+)["']""", r"""\bimport\s*\(\s*["']([^"'\n]+)["']\s*\)""", r"""\brequire\s*\(\s*["']([^"'\n]+)["']\s*\)"""]


def resolve(directory, spec):
    base = os.path.normpath(os.path.join(directory, spec))
    swapped = re.sub(r"\.cjs$", ".cts", re.sub(r"\.mjs$", ".mts", re.sub(r"\.js$", ".ts", base)))
    for cand in (base, swapped):
        for ext in policy["extensions"]:
            if os.path.isfile(cand + ext):
                return cand + ext
    for name in policy["indexNames"]:
        if os.path.isfile(os.path.join(base, name)):
            return os.path.join(base, name)
    return None


def member_of(file):
    parts = file.split(os.sep)
    if policy["testsFolder"] in parts and parts.index(policy["testsFolder"]) > 0:
        return os.sep.join(parts[: parts.index(policy["testsFolder"])])
    return os.path.dirname(file)


if sys.argv[1] == "canonical":
    print(sha(canon(json.load(open(sys.argv[3], encoding="utf-8"))).encode("utf-8")))
else:
    root, file, extra = os.path.realpath(sys.argv[3]), os.path.realpath(sys.argv[4]), json.load(open(sys.argv[5], encoding="utf-8"))
    seen, queue, unresolved, externals = {file}, [file], set(), set()
    for current in queue:
        if not os.path.isfile(current):
            continue
        text = open(current, "rb").read().decode("utf-8")
        specs = set()
        for pattern in PATTERNS:
            specs.update(re.findall(pattern, text))
        for spec in sorted(specs):
            if spec.startswith("."):
                target = resolve(os.path.dirname(current), spec)
                if target is None:
                    unresolved.add(rel(current, root) + " -> " + spec)
                    continue
            elif spec.startswith("node:") or spec.startswith("bun:") or spec == "bun":
                continue
            else:
                externals.add("/".join(spec.split("/")[:2]) if spec.startswith("@") else spec.split("/")[0])
                continue
            if target not in seen:
                seen.add(target)
                queue.append(target)
    seen.discard(file)
    member = tree(member_of(file), root)
    member_paths = {e["path"] for e in member}
    closure = [{"path": rel(p, root), "digest": sha(open(p, "rb").read())} for p in sorted(seen) if rel(p, root) not in member_paths]
    fixtures = sorted([e for f in extra["fixtures"] for e in tree(os.path.join(root, f), root)], key=lambda e: e["path"])
    inputs = {"version": 1, "file": rel(file, root), "fileDigest": sha(open(file, "rb").read()), "closure": closure, "unresolved": sorted(unresolved), "externals": sorted(externals), "member": member, "fixtures": fixtures, "toolchain": extra["toolchain"], "envelope": extra["envelope"]}
    key = sha(canon(inputs).encode("utf-8"))
    print(json.dumps({"key": key, "address": sha((policy["keyPrefix"] + key).encode("utf-8"))}))
