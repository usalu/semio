/** 🧾️ Contract: the verdict that ends test-file, run, cargo and typecheck is schema valid under the in-repo validator and Ajv, never exceeds 4096 bytes whatever the input, keeps its counts exact when rows are omitted, names the first failure per file with file:line (TypeScript, rustc, panic and bun formats; an independent Python model extracts the same), carries the failure class, the offload origin and the cache numbers, and renders in both languages.
 * @see ../🧬️schema/🔣️.json */
import Ajv from "ajv";
import {expect,test} from "bun:test";
import {mkdtempSync,rmSync,writeFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {dirname,join} from "node:path";
import {fileURLToPath} from "node:url";
import {validateJsonSchemaSubset} from "../../../../../../../🔨️modules/🧬️schema/✅️validator/📦️packages/🟦️typescript/🟦️.ts";
import {testPythonV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧪️testing/🧰️toolchain/🟦️.ts";
import {VERDICT_LIMITS_V1,buildVerdictV1,diagnosticFilesOfLinesV1,firstFailureOfLinesV1,renderVerdictV1,testTotalsOfLinesV1,verdictBytesV1,verdictJsonV1,verdictLinesV1,verdictOfCommandV1,verdictOfTestFileResultV1,type VerdictV1} from "../🟦️.ts";
import schema from "../🧬️schema/🔣️.json";
import corpus from "./🔣️.json";

const here=dirname(fileURLToPath(import.meta.url)),schemaPath=join(here,"..","🧬️schema","🔣️.json"),python=testPythonV1();
const ajv=new Ajv({strict:false,allowUnionTypes:true}),definitions=schema.definitions,check=ajv.compile({$schema:schema.$schema,definitions,$ref:"#/definitions/Verdict"});
const valid=(verdict:unknown)=>{const errors=validateJsonSchemaSubset({$ref:"#/definitions/Verdict"},verdict,schema as never);expect(errors,JSON.stringify(errors)).toEqual([]);expect(check(verdict),JSON.stringify(check.errors)).toBe(true);};
const run=(...words:string[])=>JSON.parse(Bun.spawnSync([python!,"-I",join(here,"🐍️.py"),...words]).stdout.toString()) as unknown[];

test("the first failure of every tail equals the hand written expectation and the independent model",()=>{
 expect(python,"python3 is required for the independent model").toBeTruthy();
 const model=run("failures",schemaPath,join(here,"🔣️.json"));
 expect(model.length).toBe(corpus.failures.length);
 corpus.failures.forEach((item,at)=>{
  const found=firstFailureOfLinesV1(verdictLinesV1(item.tail.join("\n")),{...(item as {file?:string}).file?{file:(item as {file:string}).file}:{},root:(item as {root?:string}).root});
  expect(found,item.name).toEqual(item.expected as never);
  expect(model[at],item.name+" (model)").toEqual(item.expected as never);
 });
 const output=verdictLinesV1(corpus.typecheck.output.join("\n")),diagnostics=diagnosticFilesOfLinesV1(output,corpus.typecheck.root);
 expect(diagnostics.files).toEqual(corpus.typecheck.files as never);expect(diagnostics.count).toBe(corpus.typecheck.count);
 expect(testTotalsOfLinesV1(["test result: ok. 4 passed; 0 failed; 0 ignored;","test result: FAILED. 1 passed; 2 failed; 0 ignored;"])).toEqual({passed:5,failed:2});
 expect(testTotalsOfLinesV1([" 7 pass"," 1 fail"])).toEqual({passed:7,failed:1});
 expect(testTotalsOfLinesV1(["nothing"])).toBeUndefined();
});

const sample={status:"failed" as const,seconds:12.345,files:[
 {file:"/repo/src/a.test.ts",status:"passed" as const,seconds:1.234,pass:4,fail:0,ranOn:"g1-m13"},
 {file:"/repo/src/b.test.ts",status:"failed" as const,seconds:3,pass:1,fail:2,tail:"error: expect(received).toBe(expected)\n\nExpected: 2\nReceived: 1\n      at <anonymous> (/repo/src/b.test.ts:12:15)",ranOn:"g1-m15"},
 {file:"/repo/src/c.test.ts",status:"passed" as const,seconds:0.5,pass:2,fail:0,reused:true},
 {file:"/repo/src/d.test.ts",status:"not-run" as const,seconds:0},
]};

test("a test-file result becomes a schema valid verdict with counts, first failure with file:line, class, origin, cache and the log reference",()=>{
 const verdict=verdictOfTestFileResultV1(sample,{root:"/repo",log:{reference:".cache/logs/run-1.log",bytes:51234},cache:{hits:3,misses:1},classify:lines=>lines.some(line=>line.includes("expect("))?{class:"test.assertion"}:undefined});
 valid(verdict);
 expect(verdict.status).toBe("failed");expect(verdict.counts).toEqual({passed:2,failed:1,skipped:0,notRun:1});
 expect(verdict.tests).toEqual({passed:7,failed:2});expect(verdict.failureClass).toBe("test.assertion");
 expect(verdict.files[0]).toEqual({file:"src/b.test.ts",status:"failed",seconds:3,pass:1,fail:2,first:{line:12,column:15,message:"expect(received).toBe(expected); Expected: 2; Received: 1"},class:"test.assertion",ranOn:"g1-m15"});
 expect(verdict.files.map(row=>row.status)).toEqual(["failed","not-run","passed","passed"]);
 expect(verdict.origin).toEqual({local:2,offloaded:2,hosts:["g1-m13","g1-m15"]});
 expect(verdict.cache).toEqual({hits:3,misses:1,reused:1});expect(verdict.log).toEqual({reference:".cache/logs/run-1.log",bytes:51234});
 expect(verdict.seconds).toBe(12.35);
 expect(verdictBytesV1(verdict)).toBe(Buffer.byteLength(verdictJsonV1(verdict)));
 expect(verdict.omitted).toBeUndefined();
 expect(buildVerdictV1({command:"test-file",seconds:1,rows:sample.files.slice(0,1)}).status).toBe("passed");
 expect(buildVerdictV1({command:"test-file",seconds:1,localHost:"g1-m13",rows:sample.files.slice(0,1)}).origin).toEqual({local:1,offloaded:0,hosts:[]});
});

test("the verdict never exceeds 4096 bytes: adversarial inputs shrink in a fixed order, counts stay exact and an independent model re-measures",()=>{
 const long="p".repeat(500),emoji="🧪️".repeat(120);
 const failing=(index:number)=>({file:`/repo/${index%2?long:emoji}/${index}.test.ts`,status:"failed" as const,seconds:index,pass:index,fail:1,ranOn:`g1-machine-with-a-long-name-${index}-${"x".repeat(80)}`,tail:`error: ${"boom ".repeat(100)}\n      at <anonymous> (/repo/${index}/deep.ts:${index+1}:2)`});
 const many=Array.from({length:200},(_,index)=>failing(index)),passing=Array.from({length:60},(_,index)=>({file:`/repo/ok/${index}.test.ts`,status:"passed" as const,seconds:1,pass:3,fail:0}));
 const built:VerdictV1[]=[
  buildVerdictV1({command:"test-file",seconds:99,root:"/repo",rows:[...passing,...many],log:{reference:"r".repeat(1000),bytes:1}}),
  buildVerdictV1({command:"test-file",seconds:99,root:"/repo",rows:many.slice(0,24)}),
  buildVerdictV1({command:"test-file",seconds:1,rows:passing}),
  buildVerdictV1({command:"typecheck",seconds:1,rows:[]}),
 ];
 for(const verdict of built){valid(verdict);expect(verdictBytesV1(verdict)).toBeLessThanOrEqual(VERDICT_LIMITS_V1.maximumBytes);expect(verdict.files.length).toBeLessThanOrEqual(VERDICT_LIMITS_V1.maximumFiles);}
 expect(built[0]!.counts).toEqual({passed:60,failed:200,skipped:0,notRun:0});
 expect(built[0]!.omitted!.files+built[0]!.files.length).toBe(260);
 expect(built[0]!.files.every(row=>row.status==="failed")).toBe(true);
 expect(built[2]!.files.length).toBeLessThanOrEqual(24);expect(built[2]!.omitted?.files??0).toBe(60-built[2]!.files.length);
 const directory=mkdtempSync(join(tmpdir(),"h96-verdict-"));
 try{
  const path=join(directory,"verdicts.json");writeFileSync(path,JSON.stringify(built));
  const model=run("check",schemaPath,path) as {bytes:number;ok:boolean;omitted:number}[];
  built.forEach((verdict,at)=>{expect(model[at]!.ok,String(at)).toBe(true);expect(model[at]!.bytes).toBe(verdictBytesV1(verdict));});
 }finally{rmSync(directory,{recursive:true,force:true});}
});

test("the closed schema rejects the same mutations under both validators",()=>{
 const verdict=verdictOfTestFileResultV1(sample,{root:"/repo"}) as unknown as Record<string,unknown>;
 valid(verdict);
 for(const [name,mutate] of Object.entries({
  "unknown field":(copy:Record<string,unknown>)=>{copy.extra=1;},
  "unknown command":(copy:Record<string,unknown>)=>{copy.command="build";},
  "negative count":(copy:Record<string,unknown>)=>{(copy.counts as Record<string,number>).failed=-1;},
  "too many files":(copy:Record<string,unknown>)=>{copy.files=Array.from({length:25},()=>({file:"a",status:"passed"}));},
  "bad class":(copy:Record<string,unknown>)=>{copy.failureClass="Bad Class";},
  "line zero":(copy:Record<string,unknown>)=>{copy.files=[{file:"a",status:"failed",first:{line:0,message:"m"}}];},
  "missing log":(copy:Record<string,unknown>)=>{delete copy.log;},
 })){
  const copy=JSON.parse(JSON.stringify(verdict)) as Record<string,unknown>;mutate(copy);
  expect(check(copy),name+" Ajv").toBe(false);
  expect(validateJsonSchemaSubset({$ref:"#/definitions/Verdict"},copy,schema as never).length,name+" in-repo").toBeGreaterThan(0);
 }
});

test("typecheck, cargo and run outputs become verdicts: failing files from diagnostics, totals from summary lines, cancelled and refused keep their status",()=>{
 const typecheck=verdictOfCommandV1({command:"typecheck",exit:2,seconds:4.2,output:corpus.typecheck.output.join("\n"),root:"/repo",log:{reference:"t.log",bytes:9}});
 valid(typecheck);
 expect(typecheck.status).toBe("failed");expect(typecheck.diagnostics).toBe(3);expect(typecheck.counts).toEqual({passed:0,failed:2,skipped:0,notRun:0});
 expect(typecheck.files).toEqual([{file:"src/a.ts",status:"failed",first:{line:1,column:1,message:"TS1: first a"}},{file:"src/b.ts",status:"failed",first:{line:3,column:3,message:"TS3: only b"}}]);
 const cargo=verdictOfCommandV1({command:"cargo",exit:101,seconds:60,output:["error[E0308]: mismatched types"," --> src/lib.rs:12:5","test result: FAILED. 3 passed; 1 failed; 0 ignored;"].join("\n"),ranOn:"g1-m02",classify:lines=>lines.some(line=>line.startsWith("error[E"))?{class:"cargo.compile"}:undefined});
 valid(cargo);expect(cargo.tests).toEqual({passed:3,failed:1});expect(cargo.failureClass).toBe("cargo.compile");expect(cargo.origin.hosts).toEqual(["g1-m02"]);
 const bare=verdictOfCommandV1({command:"run",exit:1,seconds:2,output:"starting\nthe build failed badly\n"});
 valid(bare);expect(bare.files).toEqual([{file:"-",status:"failed",first:{message:"the build failed badly"}}]);
 expect(verdictOfCommandV1({command:"run",exit:0,seconds:1,output:""}).status).toBe("passed");
 expect(verdictOfCommandV1({command:"run",exit:null,seconds:1,output:"",cancelled:true}).status).toBe("cancelled");
 const refused=verdictOfCommandV1({command:"cargo",exit:2,seconds:0,output:"refused",refused:true});valid(refused);expect(refused.status).toBe("refused");expect(refused.files).toEqual([]);
});

test("the verdict renders in both languages with file:line, class, host, origin, cache and log reference, and every text has both languages",()=>{
 const verdict=verdictOfTestFileResultV1(sample,{root:"/repo",log:{reference:"x.log",bytes:10},cache:{hits:3,misses:1},classify:()=>({class:"test.assertion"})});
 const en=renderVerdictV1("en",verdict),de=renderVerdictV1("de",verdict);
 expect(en[0]).toBe("failed: test-file, 4 files (1 failed), 12.35 s");
 expect(de[0]).toBe("fehlgeschlagen: test-file, 4 Dateien (1 fehlgeschlagen), 12.35 s");
 expect(en).toContain("FAIL src/b.test.ts:12: expect(received).toBe(expected); Expected: 2; Received: 1 [class test.assertion] (on g1-m15)");
 expect(de).toContain("FEHLER src/b.test.ts:12: expect(received).toBe(expected); Expected: 2; Received: 1 [Klasse test.assertion] (auf g1-m15)");
 expect(en).toContain("origin: 2 local, 2 offloaded to g1-m13, g1-m15");expect(de).toContain("Herkunft: 2 lokal, 2 ausgelagert auf g1-m13, g1-m15");
 expect(en).toContain("cache: 3 hits, 1 misses, 1 reused verdicts");expect(de).toContain("Cache: 3 Treffer, 1 Fehlschläge, 1 wiederverwendete Urteile");
 expect(en.at(-1)).toBe("full log: x.log (10 bytes)");expect(de.at(-1)).toBe("Volllog: x.log (10 Bytes)");
 expect(en.join("\n").length).toBeLessThan(1500);
 for(const [key,value] of Object.entries(schema.definitions.Texts.const))expect(value.en.length>0&&value.de.length>0,key).toBe(true);
});
