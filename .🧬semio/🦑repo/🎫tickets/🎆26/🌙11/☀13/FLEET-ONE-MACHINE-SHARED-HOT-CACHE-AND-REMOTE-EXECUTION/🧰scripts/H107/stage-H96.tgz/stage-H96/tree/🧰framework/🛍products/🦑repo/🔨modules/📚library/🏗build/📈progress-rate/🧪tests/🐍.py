#!/usr/bin/env python3
"""🐍️ Independent model of the progress rate (standard library only): `estimates <schema> <corpus>` replays every case of the corpus and prints the estimate of every step as JSON."""
import json, sys

schema = json.load(open(sys.argv[2], encoding="utf-8"))["definitions"]
policy = schema["Policy"]["const"]


def replay(case):
    samples, started, last_advance, highest, rows = [], None, 0, None, []
    history = case.get("history")
    for step in case["steps"]:
        at, done = step[0], step[1]
        total = step[2] if len(step) > 2 else None
        if started is None:
            started, last_advance = at, at
        if highest is None or done > highest:
            if highest is not None:
                last_advance = at
            highest = done
        samples.append((at, done))
        edge = at - policy["windowMs"]
        older = [index for index, (when, _) in enumerate(samples) if when <= edge]
        if older:
            samples = samples[older[-1]:]
        anchor_at, anchor_done = samples[0]
        span, idle = at - anchor_at, at - last_advance
        finished = total is not None and done >= total
        if finished:
            rate = None
        elif idle >= policy["windowMs"]:
            rate = 0
        elif len(samples) < 2 or span < policy["minimumSpanMs"]:
            rate = None
        else:
            rate = max(0, (done - anchor_done) * 1000 / span)
        stalled_for = idle if (not finished and rate == 0) else 0
        stalled = stalled_for >= policy["stalledMs"]
        elapsed = at - started
        eta, source = None, "none"
        if finished:
            eta, source = 0, "plan"
        elif not stalled:
            if total is not None and rate is not None and rate > 0:
                eta, source = (total - done) * 1000 / rate, "plan"
            elif history and rate is not None and rate > 0 and total is None and "items" in history:
                eta, source = max(0, history["items"] - done) * 1000 / rate, "history"
            elif history:
                eta, source = max(0, history["ms"] - elapsed), "history"
        if eta is not None and eta > policy["maximumEtaMs"]:
            eta, source = None, "none"
        rows.append({"rate": None if rate is None else round(rate, 3), "etaMs": None if eta is None else int(eta + 0.5), "source": source, "stalled": stalled, "stalledForMs": stalled_for, "elapsedMs": elapsed})
    return rows


print(json.dumps([replay(case) for case in json.load(open(sys.argv[3], encoding="utf-8"))["cases"]]))
