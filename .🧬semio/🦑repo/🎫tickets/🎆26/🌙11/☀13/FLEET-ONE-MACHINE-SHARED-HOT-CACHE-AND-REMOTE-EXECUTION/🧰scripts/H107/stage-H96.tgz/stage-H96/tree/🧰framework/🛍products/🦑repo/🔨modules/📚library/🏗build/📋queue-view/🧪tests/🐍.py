#!/usr/bin/env python3
"""🐍️ Independent model of the queue view (standard library only): `simulate <schema> <corpus>` places every job on a one second memory grid and prints start and end of every job, `keys <schema> <corpus>` prints the request key of every request of the corpus."""
import hashlib, json, sys

schema = json.load(open(sys.argv[2], encoding="utf-8"))["definitions"]
policy = schema["Policy"]["const"]
corpus = json.load(open(sys.argv[3], encoding="utf-8"))


def median(values):
    ordered = sorted(values)
    return ordered[(len(ordered) - 1) // 2]


def remaining_or_total(row, running, history):
    est = row.get("estimate")
    if running and est and not est["stalled"] and est["etaMs"] is not None and est["source"] == "plan":
        return est["etaMs"]
    own = history["keys"].get(row["key"], [])[-policy["historyKeep"]:]
    kind = history["classes"].get(row["class"], [])[-policy["historyKeep"]:]
    base = median(own) if own else median(kind) if kind else policy["fallbackMs"]
    return max(0, base - row.get("runMs", 0)) if running else base


def simulate(case):
    grid = [0] * 100000
    budget = case["budget"]
    out = {"running": [], "queued": []}
    for row in case["running"]:
        ms = min(remaining_or_total(row, True, case["history"]), policy["horizonMs"])
        assert ms % 1000 == 0
        for second in range(ms // 1000):
            grid[second] += row["reserve"]
        stalled = bool(row.get("estimate") and row["estimate"]["stalled"])
        out["running"].append([0, None if stalled else ms])
    previous = 0
    for row in case["queued"]:
        ms = min(remaining_or_total(row, False, case["history"]), policy["horizonMs"])
        need = min(row["reserve"], budget)
        seconds = ms // 1000
        second = (0 if case["backfill"] else previous // 1000)
        while True:
            window = grid[second: second + max(seconds, 1)] if seconds > 0 else [grid[second]]
            if max(window) + need <= budget:
                break
            second += 1
        for tick in range(second, second + seconds):
            grid[tick] += row["reserve"]
        previous = second * 1000
        out["queued"].append([second * 1000, second * 1000 + ms])
    ends = [e for _, e in out["running"] + out["queued"]]
    stalled_any = any(e is None for _, e in out["running"])
    out["drain"] = None if stalled_any else (max(ends) if ends else 0)
    return out


def request_key(command, args):
    kept, rest, at = [], False, 0
    while at < len(args):
        token = args[at]
        if rest or not token.startswith("--") or token == "--":
            if token == "--":
                rest = True
            kept.append(token)
        else:
            name = token.split("=")[0]
            if name not in policy["presentationFlags"]:
                kept.append(token)
            elif "=" not in token and name in policy["valueFlags"] and at + 1 < len(args) and not args[at + 1].startswith("--"):
                at += 1
        at += 1
    return hashlib.sha256(json.dumps({"command": command, "args": kept}, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()


if sys.argv[1] == "simulate":
    print(json.dumps([simulate(case) for case in corpus["simulations"]]))
else:
    print(json.dumps({"same": [[request_key(c, a) for c, a in group] for group in corpus["requests"]["same"]], "different": [request_key(c, a) for c, a in corpus["requests"]["different"]]}))
