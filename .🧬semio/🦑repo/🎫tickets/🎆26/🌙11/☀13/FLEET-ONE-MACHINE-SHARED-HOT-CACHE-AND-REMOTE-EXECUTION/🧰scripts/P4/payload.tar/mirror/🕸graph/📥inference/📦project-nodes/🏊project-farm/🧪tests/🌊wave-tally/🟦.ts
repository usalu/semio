/** 🌊️ Contract: a farm tells the wave meter what happened to the projects of its wave when it closes, also when no worker ever started, so a wave row shows whether the parent or the workers inferred the projects. */
import{afterAll,expect,test}from"bun:test";
import{mkdtempSync,readFileSync,realpathSync,rmSync}from"node:fs";
import{tmpdir}from"node:os";
import{join}from"node:path";
import{graphWaveMeterV1}from"../../../../../📈️wave-row/🟨️.mjs";
import{openProjectFarmV1}from"../../🟨️.mjs";

const roots:string[]=[],scratch=()=>{const root=mkdtempSync(join(realpathSync(tmpdir()),"farm-tally-"));roots.push(root);return root;};
afterAll(()=>{for(const root of roots)rmSync(root,{recursive:true,force:true});});

test("a farm that never got a worker reports its wave to the meter as handled by the parent",async()=>{
 graphWaveMeterV1.take({generation:0});
 const root=scratch();
 let grant!:(value:{jobs:number;megabytes:number}|undefined)=>void;
 const farm=openProjectFarmV1({workspaceRoot:root,context:{registry:null},contracts:{},launch:null,projects:566,commandInputs:null,projectsByRoot:new Map(),componentRoots:[],environment:{LANG:"en_US.UTF-8"},processed:()=>24,cores:10,write:()=>undefined,
  spawnProcess:(()=>{throw new Error("no worker must start");}) as never,
  request:(()=>({granted:new Promise<{jobs:number;megabytes:number}|undefined>(done=>{grant=done;}),release:()=>undefined})) as never})!;
 const job={name:"p",root:"p",json:{},native:false,pipeline:false,nativeRoot:"p",selectedInputs:[],head:[],cacheKey:"0".repeat(24)};
 for(let index=0;index<24;index++)await farm.prepare(job);
 grant({jobs:0,megabytes:2048});
 await Bun.sleep(20);
 await farm.close();
 expect(graphWaveMeterV1.take({generation:1}).farm).toEqual({workers:0,projects:566,adopted:0,failed:0,lost:0,declined:0});
});

test("the close of the farm reports before it can return early, with the lost jobs and not the lost processes",()=>{
 const source=readFileSync(new URL("../../🟨️.mjs",import.meta.url),"utf8"),report=source.indexOf("graphWaveMeterV1.farm("),early=source.indexOf("if (pools.length === 0) return;");
 expect(report).toBeGreaterThan(0);expect(report).toBeLessThan(early);
 expect(source.slice(report,early)).toContain("lost: counts.lostJobs");expect(source.slice(report,early)).toContain("adopted: counts.adopted");
});
