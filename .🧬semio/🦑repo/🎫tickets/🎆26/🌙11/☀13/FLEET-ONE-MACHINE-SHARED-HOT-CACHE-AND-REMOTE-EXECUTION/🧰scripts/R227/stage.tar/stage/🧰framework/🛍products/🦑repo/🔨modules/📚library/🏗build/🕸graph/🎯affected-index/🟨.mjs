import{createHash}from"node:crypto";
import{join}from"node:path";
import schema from"./🧬️schema/🔣️.json"with{type:"json"};
import{canonicalJsonV1,compareCodePointsV1,packGenerationDocumentV1}from"../🕰️generations/🟨️.mjs";
import{unpack}from"../🕰️generations/🧱️guards/🟨️.mjs";
import{GlobV1}from"../../../../../../../📦️packages/🟦️typescript/⚙️runtime/🌐️glob/🟦️.ts";

/** 📏️ The declared limits and names of the affected index; the schema file is their single source.
 * @see ./🧬️schema/🔣️.json */
export const AFFECTED_INDEX_POLICY_V1=Object.freeze({...schema.definitions.Policy.const,manifestNames:Object.freeze([...schema.definitions.Policy.const.manifestNames])});
const P=AFFECTED_INDEX_POLICY_V1,LEAF=/^SEMIO_(SOURCE_CLOSURE|CARGO_LOCK)_[a-f0-9]{64}$/u,HEX=/^[a-f0-9]{64}$/u,GLOB=/[*?\[\]{}()!\\]/u,EXTGLOB=/[?*+@!]\(/u;
const bad=(message,code)=>Object.assign(Error(message),{code}),sha=text=>createHash("sha256").update(text).digest("hex"),order=compareCodePointsV1;

/** 🗣️ The bilingual texts of the affected question; the schema file declares the same table and a law keeps both equal. */
export const AFFECTED_MESSAGES_V1=Object.freeze({en:Object.freeze({...schema.definitions.Messages.const.en}),de:Object.freeze({...schema.definitions.Messages.const.de})});
export function renderAffectedMessageV1(key,fields,language){
 const text=AFFECTED_MESSAGES_V1[language]?.[key];if(text===undefined)throw bad("Known affected text and language required: "+key+" "+language,"AFFECTED_TEXT");
 return text.replace(/\{(\w+)\}/gu,(_,name)=>{if(!Object.hasOwn(fields,name))throw bad("Missing field "+name+" for "+key,"AFFECTED_TEXT");return String(fields[name]);});
}

/** 🧮️ The workspace files and globs the target inputs of one project node name (named inputs expanded, project ones over the declared ones) and the closure leaves they reference: the rule of `affectedTouchesV1`, read from the stored node where a leaf token is still unexpanded. */
export function affectedInputsOfNodeV1(node,declared={}){
 const named={...declared,...(node?.namedInputs??{})},patterns=new Set(),leaves=new Set(),prefix=P.workspacePrefix;
 const walk=(inputs,seen)=>{
  for(const input of inputs){
   if(typeof input==="string"){if(Object.hasOwn(named,input)){if(!seen.has(input)&&Array.isArray(named[input]))walk(named[input],new Set(seen).add(input));}else if(input.startsWith(prefix))patterns.add(input.slice(prefix.length));}
   else if(input!==null&&typeof input==="object"){
    if(Object.keys(input).length===1&&typeof input.env==="string"&&LEAF.test(input.env))leaves.add(input.env);
    else if(typeof input.fileset==="string"&&input.fileset.startsWith(prefix))patterns.add(input.fileset.slice(prefix.length));
   }
  }
 };
 for(const target of Object.values(node?.targets??{}))if(Array.isArray(target?.inputs))walk(target.inputs,new Set());
 return{patterns:[...patterns].sort(order),leaves:[...leaves].sort(order)};
}

/** 🔢️ Admits one closed index document: counts, digests and every index into the pattern table within their bounds. */
export function readAffectedIndexV1(value){
 const keys=["version","manifest","generation","global","namedInputs","patterns","owners","leaves","edges"],optional=["configs"];
 if(value===null||typeof value!=="object"||Array.isArray(value)||keys.some(key=>!Object.hasOwn(value,key))||Object.keys(value).some(key=>!keys.includes(key)&&!optional.includes(key)))throw bad("Closed affected index required","AFFECTED_INDEX");
 if(value.version!==1||!Number.isSafeInteger(value.generation)||value.generation<0||!["manifest","global","namedInputs"].every(key=>HEX.test(value[key])))throw bad("Affected index version 1 with digests required","AFFECTED_INDEX");
 const count=value.patterns?.length;
 if(!Array.isArray(value.patterns)||count>P.maximumPatterns||value.patterns.some(pattern=>typeof pattern!=="string")||!Array.isArray(value.owners)||value.owners.length>P.maximumOwners||!Array.isArray(value.edges))throw bad("Bounded affected index required","AFFECTED_INDEX");
 const known=index=>Number.isSafeInteger(index)&&index>=0&&index<count,texts=list=>Array.isArray(list)&&list.every(text=>typeof text==="string");
 for(const row of value.owners){
  const closed=row!==null&&typeof row==="object"&&["n","r","f","p","l","d"].every(key=>Object.hasOwn(row,key))&&Object.keys(row).every(key=>["n","r","f","c","p","l","d","x"].includes(key));
  if(!closed||typeof row.n!=="string"||!row.n||typeof row.r!=="string"||!row.r||!HEX.test(row.f)||!Array.isArray(row.p)||!row.p.every(known)||!texts(row.l)||!row.l.every(key=>LEAF.test(key))||!texts(row.d)||row.x!==undefined&&!(Array.isArray(row.x)&&row.x.every(edge=>Array.isArray(edge)&&edge.length===2&&texts(edge))))throw bad("Closed affected owner row required","AFFECTED_INDEX");
 }
 if(value.leaves===null||typeof value.leaves!=="object"||Array.isArray(value.leaves)||Object.keys(value.leaves).length>P.maximumLeaves||Object.entries(value.leaves).some(([key,list])=>!LEAF.test(key)||!Array.isArray(list)||!list.every(known)))throw bad("Closed affected leaves required","AFFECTED_INDEX");
 if(!value.edges.every(edge=>Array.isArray(edge)&&edge.length===2&&texts(edge))||value.configs!==undefined&&!texts(value.configs))throw bad("Closed affected edges required","AFFECTED_INDEX");
 return value;
}

/** 🔓️ The rows and leaves of a stored index as texts again, so an unchanged owner and a known leaf are carried into the next index without being read. */
export function decodeAffectedIndexV1(index){
 const rows=new Map(index.owners.map(row=>[row.n,{n:row.n,r:row.r,f:row.f,...(row.c===undefined?{}:{c:row.c}),patterns:row.p.map(at=>index.patterns[at]),l:row.l,d:row.d,...(row.x===undefined?{}:{x:row.x})}])),leaves=new Map(Object.entries(index.leaves).map(([key,list])=>[key,list.map(at=>index.patterns[at])]));
 return{rows,leaves,edges:index.edges};
}

const pool=async(items,limit,visit,signal)=>{const out=new Array(items.length);let next=0;await Promise.all(Array.from({length:Math.min(limit,items.length)},async()=>{while(next<items.length){signal?.throwIfAborted();const at=next++;out[at]=await visit(items[at],at);}}));return out;};

/** 🏗️ Derives the reverse index of one sealed generation from its manifest, the fragments of the owners that changed since `previous` and the leaves not yet known, and nothing else: no inference, no tree read, no node assembly.
 * @see ./🧬️schema/🔣️.json */
export async function deriveAffectedIndexV1({manifest,digest,previous,declared,readFragment,readGlobal,leafFiles,signal,concurrency=P.readConcurrency}){
 const namedInputs=sha(canonicalJsonV1(declared??{})),projects=Object.entries(manifest.owners).filter(([,row])=>row.kind==="project").sort(([a],[b])=>order(a,b));
 if(projects.length>P.maximumOwners)throw bad("owners: "+projects.length,"AFFECTED_TOO_LARGE");
 const before=previous&&previous.namedInputs===namedInputs?decodeAffectedIndexV1(previous):{rows:new Map(),leaves:new Map(),edges:undefined},stats={read:0,owners:projects.length};
 const rows=await pool(projects,concurrency,async([name,row])=>{
  const held=before.rows.get(name);if(held&&held.f===row.fragment&&held.r===row.root)return held;
  const fragment=await readFragment(row);if(!fragment)throw bad("Fragment of "+name+" is missing","GENERATION_INCOMPLETE");stats.read++;
  const{patterns,leaves}=affectedInputsOfNodeV1(fragment.node,declared),targets=new Set(),others=[];
  for(const edge of fragment.edges)if(edge.source===name){if(edge.target!==name)targets.add(edge.target);}else others.push([edge.source,edge.target]);
  return{n:name,r:row.root,f:row.fragment,...(row.config?{c:row.config}:{}),patterns,l:leaves,d:[...targets].sort(order),...(others.length?{x:others}:{})};
 },signal);
 const keys=[...new Set(rows.flatMap(row=>row.l))].sort(order),files=new Map();
 if(keys.length>P.maximumLeaves)throw bad("leaves: "+keys.length,"AFFECTED_TOO_LARGE");
 await pool(keys,concurrency,async key=>{const known=before.leaves.get(key)??await leafFiles(key);if(!known)throw Object.assign(bad("Closure leaf missing: "+key,"AFFECTED_LEAF_MISSING"),{key});files.set(key,known);},signal);
 const global=previous&&previous.global===manifest.global?previous.edges:((await readGlobal(manifest)).edges??[]).map(edge=>[edge.source,edge.target]);
 const table=[...new Set([...rows.flatMap(row=>row.patterns),...[...files.values()].flat()])].sort(order);
 if(table.length>P.maximumPatterns)throw bad("patterns: "+table.length,"AFFECTED_TOO_LARGE");
 const at=new Map(table.map((pattern,index)=>[pattern,index])),ints=list=>list.map(pattern=>at.get(pattern)).sort((a,b)=>a-b);
 const configs=[...new Set(Object.values(manifest.owners).map(row=>row.config).filter(Boolean))].sort(order);
 const index={version:1,manifest:digest,generation:manifest.generation,global:manifest.global,namedInputs,patterns:table,owners:rows.map(row=>({n:row.n,r:row.r,f:row.f,...(row.c===undefined?{}:{c:row.c}),p:ints(row.patterns),l:row.l,d:row.d,...(row.x===undefined?{}:{x:row.x})})),leaves:Object.fromEntries(keys.map(key=>[key,ints(files.get(key))])),edges:global,configs};
 return{index:readAffectedIndexV1(index),stats};
}

/** 🔎️ Opens an index for questions: file to owner by one walk up the path, input patterns by hash (literal) or on first use compiled globs, dependents as adjacency lists. Answers exactly what `affectedBuildProjectsV1` answers on the graph the index was derived from.
 * @see ../../🧭️selection/🟦️.ts */
export function openAffectedIndexV1(index,{glob=pattern=>{const compiled=new GlobV1(pattern);return file=>compiled.match(file);}}={}){
 const names=index.owners.map(row=>row.n),at=new Map(names.map((name,position)=>[name,position])),byRoot=new Map(),dots=[],better=(left,right)=>names[left]<names[right]?left:right;
 index.owners.forEach((row,position)=>{if(row.r===P.rootProject)dots.push(position);else{const held=byRoot.get(row.r);byRoot.set(row.r,held===undefined?position:better(held,position));}});
 const dot=dots.length?dots.reduce(better):undefined,owner=file=>{
  let deepest;for(let cut=file.lastIndexOf("/");cut>0;cut=file.lastIndexOf("/",cut-1)){const held=byRoot.get(file.slice(0,cut));if(held!==undefined){deepest={position:held,length:cut};break;}}
  if(deepest===undefined)return dot;if(dot===undefined||deepest.length>1)return deepest.position;return names[deepest.position]<names[dot]?deepest.position:dot;
 };
 const direct=[],leafOwners=new Map(),viaLeaf=[],literal=new Map(),wild=[],always=[],dependents=names.map(()=>[]);
 index.owners.forEach((row,position)=>{
  for(const pattern of row.p)(direct[pattern]??=[]).push(position);
  for(const key of row.l){let list=leafOwners.get(key);if(!list)leafOwners.set(key,list=[]);list.push(position);}
  for(const[source,target]of[...row.d.map(target=>[row.n,target]),...(row.x??[])]){const from=at.get(source),to=at.get(target);if(from!==undefined&&to!==undefined&&from!==to)dependents[to].push(from);}
 });
 for(const[source,target]of index.edges){const from=at.get(source),to=at.get(target);if(from!==undefined&&to!==undefined&&from!==to)dependents[to].push(from);}
 for(const[key,list]of Object.entries(index.leaves))for(const pattern of list)(viaLeaf[pattern]??=[]).push(key);
 index.patterns.forEach((pattern,id)=>{if(direct[id]===undefined&&viaLeaf[id]===undefined)return;if(EXTGLOB.test(pattern))always.push(id);else if(GLOB.test(pattern))wild.push({id,test:undefined,pattern});else literal.set(pattern,id);});
 const configs=new Set(index.configs??[]),manifestNames=new Set(P.manifestNames),size=index.patterns.length;
 return Object.freeze({
  owners:names.length,generation:index.generation,manifest:index.manifest,
  /** 🎯️ The projects the changed files touch and every project that depends on one of them, sorted as the neutral answer is; `unknown` lists changed owner manifests the generation does not hold (a project that may not be in the index). */
  query(files){
   const touched=new Set(),unknown=[],touch=position=>{if(position!==undefined)touched.add(position);},expand=id=>{for(const position of direct[id]??[])touched.add(position);for(const key of viaLeaf[id]??[])for(const position of leafOwners.get(key)??[])touched.add(position);};
   if(files.includes(P.rootFile))names.forEach((_,position)=>touched.add(position));
   else if(files.length){
    const matched=new Set(always);
    for(const file of files){
     touch(owner(file));const id=literal.get(file);if(id!==undefined)matched.add(id);
     for(const row of wild){row.test??=glob(row.pattern);if(!matched.has(row.id)&&row.test(file))matched.add(row.id);}
     const base=file.slice(file.lastIndexOf("/")+1);if(manifestNames.has(base)&&!configs.has(file))unknown.push(file);
    }
    for(const id of matched)if(id<size)expand(id);
   }
   const queue=[...touched];for(let head=0;head<queue.length;head++)for(const from of dependents[queue[head]])if(!touched.has(from)){touched.add(from);queue.push(from);}
   return{projects:[...touched].map(position=>names[position]).sort(),unknown};
  }
 });
}

const pathOf=(root,digest)=>join(root,P.directory,digest+P.extension);

/** 📖️ Reads the stored index of one sealed generation; undefined when it is absent, unreadable, of another generation or expanded with other declared named inputs. */
export async function readStoredAffectedIndexV1({fs,root,digest,declared}){
 const bytes=await fs.read(pathOf(root,digest));if(!bytes)return undefined;
 try{const index=readAffectedIndexV1(unpack(bytes,P.maximumDocumentBytes));return index.manifest===digest&&index.namedInputs===sha(canonicalJsonV1(declared??{}))?index:undefined;}catch{return undefined;}
}

/** 💾️ Gives the index of a sealed generation: the stored one, or one derived from the newest older index (only the owners whose fragment changed are read) and stored beside the generation under its manifest digest. Superseded index files go once they are older than the grace window; a failure to store only costs the next question the derivation.
 * @see ./🧬️schema/🔣️.json */
export async function ensureAffectedIndexV1({fs,root,sealed,declared,readFragment,readGlobal,leafFiles,signal,now=()=>Date.now()}){
 const{manifest,digest}=sealed,stored=await readStoredAffectedIndexV1({fs,root,digest,declared});
 if(stored)return{index:stored,derived:false};
 const directory=join(root,P.directory),listed=(await fs.list(directory)).filter(file=>file.name.endsWith(P.extension)&&file.name.slice(0,-P.extension.length)!==digest).sort((a,b)=>b.modifiedMs-a.modifiedMs);
 let previous;for(const file of listed.slice(0,2)){previous=await readStoredAffectedIndexV1({fs,root,digest:file.name.slice(0,-P.extension.length),declared});if(previous)break;}
 const started=now(),{index,stats}=await deriveAffectedIndexV1({manifest,digest,previous,declared,readFragment,readGlobal,leafFiles,signal}),bytes=packGenerationDocumentV1(index,P.maximumDocumentBytes);
 await fs.write(pathOf(root,digest),bytes,{ifAbsent:true}).catch(()=>false);
 const keep=new Set([digest,...listed.slice(0,P.retainIndexes-1).map(file=>file.name.slice(0,-P.extension.length))]),cutoff=now()-P.graceMilliseconds;
 for(const file of listed)if(!keep.has(file.name.slice(0,-P.extension.length))&&file.modifiedMs<cutoff)await fs.remove(join(directory,file.name)).catch(()=>undefined);
 return{index,derived:true,stats:{...stats,bytes:bytes.length,milliseconds:now()-started}};
}
