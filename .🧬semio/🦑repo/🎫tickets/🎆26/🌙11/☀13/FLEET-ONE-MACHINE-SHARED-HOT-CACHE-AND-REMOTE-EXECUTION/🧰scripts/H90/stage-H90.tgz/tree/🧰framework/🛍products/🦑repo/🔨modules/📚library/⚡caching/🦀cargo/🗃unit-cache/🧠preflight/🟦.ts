import {existsSync,readdirSync,readFileSync,statSync} from "node:fs";
import {dirname,join} from "node:path";
import schema from "./🧬️schema/🔣️.json" with {type:"json"};
import admissionSchema from "../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🧬️schema/🔣️.json" with {type:"json"};
import {carvingOfUnitV1,decideGrantGrowthV1,hostHoldableMegabytesV1,unitBudgetKindV1,type CompileBudgetKindV1,type CompileBudgetPolicyV1,type GrantGrowthVerdictV1,type GrowthHostV1} from "../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🏔️ceiling/🟦️.ts";

/** 🧠️ The early memory check policy: texts, bounds and plans, authored in the schema.
 * @see ./🧬️schema/🔣️.json */
export const MEMORY_PREFLIGHT_POLICY_V1=schema.definitions.Policy.const;
export type PreflightSourceV1="telemetry"|"warden"|"carving";
export type PreflightPlanV1="constrained-threads"|"serial-backend"|"beyond-host"|"unbuildable";
export type PreflightPeakV1=Readonly<{crate:string;target:string;kind:CompileBudgetKindV1;peakMegabytes:number;source:PreflightSourceV1}>;
export type PreflightRowV1=Readonly<{unit:string;kind:CompileBudgetKindV1;peakMegabytes:number;budgetMegabytes:number;source:PreflightSourceV1;listed:boolean;plan:PreflightPlanV1;waits:boolean;holdableMegabytes:number;largestMegabytes?:number;largestOrigin?:string}>;

const MEBI=1048576;

/** 📈️ The highest recorded peak of every unit (`<crate>|<target>`) of the telemetry rows of this machine for one build mode (`-` rows and rows of an unknown mode filter match everything); the kind is the budget kind of the key.
 * @see ../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🏔️ceiling/🟦️.ts (`unitBudgetKindV1`) */
export function telemetryPeaksV1(rows:Iterable<Readonly<{key:string;peakRssBytes:number}>>,mode?:string):readonly PreflightPeakV1[]{
 const best=new Map<string,PreflightPeakV1>();
 for(const row of rows){
  const [identity="",target="",profile=""]=row.key.split("|"),crate=identity.slice(identity.indexOf("@")+1);
  if(!identity.includes("@")||!crate||!target||!Number.isFinite(row.peakRssBytes)||row.peakRssBytes<=0)continue;
  if(mode!==undefined&&profile!==mode&&profile!=="-")continue;
  const peak=Math.ceil(row.peakRssBytes/MEBI),id=crate+"|"+target,before=best.get(id);
  if(before===undefined||before.peakMegabytes<peak)best.set(id,Object.freeze({crate,target,kind:unitBudgetKindV1(row.key),peakMegabytes:peak,source:"telemetry"}));
 }
 return Object.freeze([...best.values()]);
}

/** 🛡️ The peaks the host wardens reported as ceiling alarms (`lastAlarms` of their `memory.json`) that are not older than the policy bound: `megabytes` of the alarm is the peak, `ceiling.unit` names `<crate>|<target>`.
 * @see ../../../../../../../../🔨️modules/🏃️process/🏗️build/🌡️host-capacity/🛡️warden/🔁️loop/🟦️.ts (`readHostWardenStateV1`) */
export function wardenPeaksV1(states:readonly unknown[],nowMs:number):readonly PreflightPeakV1[]{
 const best=new Map<string,PreflightPeakV1>(),policy=MEMORY_PREFLIGHT_POLICY_V1;
 for(const state of states){
  const alarms=state!==null&&typeof state==="object"?(state as {lastAlarms?:unknown}).lastAlarms:undefined;
  if(!Array.isArray(alarms))continue;
  for(const alarm of alarms as readonly Record<string,unknown>[]){
   const ceiling=alarm?.["ceiling"] as {unit?:unknown;kind?:unknown}|undefined,unit=ceiling?.unit,peak=alarm?.["megabytes"],at=alarm?.["atMs"];
   if(alarm?.["reason"]!==policy.alarmReason||typeof unit!=="string"||typeof peak!=="number"||!Number.isFinite(peak)||peak<=0||typeof at!=="number"||nowMs-at>policy.maximumAlarmAgeMilliseconds)continue;
   const cut=unit.lastIndexOf("|");
   if(cut<1||cut===unit.length-1)continue;
   const crate=unit.slice(0,cut),target=unit.slice(cut+1),before=best.get(unit),megabytes=Math.ceil(peak);
   if(before===undefined||before.peakMegabytes<megabytes)best.set(unit,Object.freeze({crate,target,kind:ceiling?.kind==="final"?"final":"library",peakMegabytes:megabytes,source:"warden"}));
  }
 }
 return Object.freeze([...best.values()]);
}

/** 🪚️ The measured peaks of the carving list (units only; the shard families name no unit); a carved unit carries the library budget until a measured source names it a final.
 * @see ../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🧬️schema/🔣️.json (`Policy.unitCeiling.carving`) */
export function carvingPeaksV1(policy:CompileBudgetPolicyV1):readonly PreflightPeakV1[]{
 return Object.freeze(policy.carving.map(entry=>Object.freeze({crate:entry.crate,target:entry.target,kind:"library" as const,peakMegabytes:Math.ceil(entry.measuredMegabytes),source:"carving" as const})));
}

/** 🧮️ The highest peak per unit over several sources; the source of the highest wins, the kind comes from a measured source (telemetry or warden) before the carving list. */
export function mergePreflightPeaksV1(...lists:readonly (readonly PreflightPeakV1[])[]):readonly PreflightPeakV1[]{
 const best=new Map<string,PreflightPeakV1>(),measured=new Map<string,CompileBudgetKindV1>();
 for(const list of lists)for(const peak of list){
  const id=peak.crate+"|"+peak.target,before=best.get(id);
  if(peak.source!=="carving"&&(measured.get(id)===undefined||peak.kind==="final"))measured.set(id,peak.kind);
  if(before===undefined||before.peakMegabytes<peak.peakMegabytes)best.set(id,peak);
 }
 return Object.freeze([...best.entries()].map(([id,peak])=>Object.freeze({...peak,kind:measured.get(id)??peak.kind})));
}

/** 🗺️ The plan of every unit above the budget of its kind: the verdict of the grant-growth law of the admission broker for a peak against that budget, so the early check and the running build can never disagree. Rows are ordered by peak, highest first; `scope` limits the units to a dependency closure (`undefined`: every known unit).
 * @see ../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🏔️ceiling/🟦️.ts (`decideGrantGrowthV1`) */
export function planMemoryPreflightV1(input:Readonly<{peaks:readonly PreflightPeakV1[];policy:CompileBudgetPolicyV1;local:GrowthHostV1;fleet:readonly GrowthHostV1[]|undefined;scope?:ReadonlySet<string>}>):readonly PreflightRowV1[]{
 const budgets=input.policy.classes[input.policy.workerClass];
 if(!budgets)throw Error("Known worker class required");
 const rows:PreflightRowV1[]=[];
 for(const peak of input.peaks){
  if(input.scope!==undefined&&!input.scope.has(peak.crate))continue;
  const budget=peak.kind==="final"?budgets.finalMegabytes:budgets.libraryMegabytes;
  if(peak.peakMegabytes<=budget)continue;
  const verdict:GrantGrowthVerdictV1=decideGrantGrowthV1({needMegabytes:peak.peakMegabytes,grantMegabytes:budget,local:input.local,fleet:input.fleet});
  if(verdict.kind==="fits")continue;
  const plan:PreflightPlanV1=verdict.kind==="beyond-host"?"beyond-host":verdict.kind==="refused"?"unbuildable":peak.kind==="final"?"serial-backend":"constrained-threads";
  rows.push(Object.freeze({unit:peak.crate+"|"+peak.target,kind:peak.kind,peakMegabytes:peak.peakMegabytes,budgetMegabytes:budget,source:peak.source,listed:carvingOfUnitV1(input.policy,peak)!==undefined,plan,waits:verdict.kind==="wait",holdableMegabytes:hostHoldableMegabytesV1(input.local),...verdict.kind==="beyond-host"||verdict.kind==="refused"?{largestMegabytes:verdict.largestMegabytes,largestOrigin:verdict.largestOrigin}:{}}));
 }
 return Object.freeze(rows.sort((left,right)=>right.peakMegabytes-left.peakMegabytes||(left.unit<right.unit?-1:left.unit>right.unit?1:0)));
}

const fill=(template:string,values:Readonly<Record<string,string|number>>)=>template.replace(/\{([a-z]+)\}/gu,(match,key:string)=>key in values?String(values[key]):match);

/** 📣️ The bilingual warning of a plan: nothing for no rows, else the header, one line per unit (at most `maximumRows`, then the number of the rest) and a note while free memory is short. */
export function memoryPreflightLinesV1(rows:readonly PreflightRowV1[],language:"en"|"de",host:Readonly<{totalMegabytes:number;holdableMegabytes:number}>):readonly string[]{
 if(rows.length===0)return Object.freeze([]);
 const texts=MEMORY_PREFLIGHT_POLICY_V1.texts[language],shown=rows.slice(0,MEMORY_PREFLIGHT_POLICY_V1.maximumRows),lines=[fill(texts.header,{count:rows.length,total:host.totalMegabytes,holdable:host.holdableMegabytes})];
 for(const row of shown)lines.push(fill(texts[row.plan],{unit:row.unit,peak:row.peakMegabytes,budget:row.budgetMegabytes,source:row.source,largest:row.largestMegabytes??0,origin:row.largestOrigin??"-"}));
 if(rows.length>shown.length)lines.push(fill(texts.more,{more:rows.length-shown.length}));
 if(rows.some(row=>row.waits))lines.push(texts.waits);
 return Object.freeze(lines);
}

/** 🗄️ The telemetry file of this machine below a cache root (`<cache>/<storeDirectory>/units-<platform>-<architecture>.jsonl`, the path of `localUnitHistoryPathV1`, spelled here from the admission schema so that the check does not load the admission module).
 * @see ../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🟦️.ts (`localUnitHistoryPathV1`) */
export function telemetryPathV1(cacheRoot:string,platform:string=process.platform,architecture:string=process.arch):string{
 return join(cacheRoot,admissionSchema.definitions.Policy.const.storeDirectory,`units-${platform}-${architecture}.jsonl`);
}

/** 📖️ The complete records (`key` and `peakRssBytes`) of a telemetry file: the unterminated tail of an interrupted append and every line that is not JSON are dropped, a file above `maximumBytes` is not read. */
export function readTelemetryRowsV1(path:string,maximumBytes:number):readonly Readonly<{key:string;peakRssBytes:number}>[]{
 if(!existsSync(path)||statSync(path).size>maximumBytes)return Object.freeze([]);
 const text=readFileSync(path,"utf8"),rows:Readonly<{key:string;peakRssBytes:number}>[]=[];
 for(const line of text.slice(0,text.lastIndexOf("\n")+1).split("\n")){
  if(!line)continue;
  try{const row=JSON.parse(line) as {key?:unknown;peakRssBytes?:unknown};if(typeof row.key==="string"&&typeof row.peakRssBytes==="number")rows.push({key:row.key,peakRssBytes:row.peakRssBytes});}catch{}
 }
 return Object.freeze(rows);
}

/** 🔒️ The package names of the dependency closure of `roots` in the text of a `Cargo.lock`, spelled as crate names (hyphens as underscores); `undefined` when a root is not in the lock, so a caller never narrows a build by a lock that does not describe it. */
export function lockClosureV1(lock:string,roots:readonly string[]):ReadonlySet<string>|undefined{
 const graph=new Map<string,string[]>();
 let name:string|undefined,listing=false;
 for(const line of lock.split("\n")){
  if(line==="[[package]]"){name=undefined;listing=false;continue;}
  const named=/^name = "([^"]+)"$/u.exec(line);
  if(named){name=named[1]!;if(!graph.has(name))graph.set(name,[]);continue;}
  if(line.startsWith("dependencies = [")){listing=!line.endsWith("]");const inline=/"([^"]+)"/gu;for(let found=inline.exec(line);found;found=inline.exec(line))graph.get(name??"")?.push(found[1]!.split(" ")[0]!);continue;}
  if(listing){if(line.startsWith("]")){listing=false;continue;}const item=/^\s*"([^"]+)",?$/u.exec(line);if(item&&name!==undefined)graph.get(name)?.push(item[1]!.split(" ")[0]!);}
 }
 if(roots.some(root=>!graph.has(root)))return undefined;
 const seen=new Set<string>(),pending=[...roots];
 for(let next=pending.pop();next!==undefined;next=pending.pop()){if(seen.has(next))continue;seen.add(next);for(const dependency of graph.get(next)??[])if(!seen.has(dependency))pending.push(dependency);}
 return new Set([...seen].map(value=>value.replaceAll("-","_")));
}

/** 🔭️ Reads the facts the plan needs and returns the lines to print; every unreadable source only narrows the evidence. The caller wraps it in `reportMemoryPreflightV1`, which never lets a failure reach the build. */
export async function collectMemoryPreflightV1(input:Readonly<{lockPath?:string;roots?:readonly string[];mode?:string;environment:Readonly<Record<string,string|undefined>>;language:"en"|"de";nowMs?:number;localHost:()=>GrowthHostV1;fleetHosts:()=>readonly GrowthHostV1[]|undefined;wardenState:()=>unknown;historyPath:string;policy:CompileBudgetPolicyV1}>):Promise<readonly string[]>{
 const nowMs=input.nowMs??Date.now(),policy=MEMORY_PREFLIGHT_POLICY_V1;
 let telemetry:readonly Readonly<{key:string;peakRssBytes:number}>[]=[];
 try{telemetry=readTelemetryRowsV1(input.historyPath,policy.maximumTelemetryBytes);}catch{}
 const states:unknown[]=[];
 try{states.push(input.wardenState());}catch{}
 const store=input.environment["SEMIO_FLEET_STORE_ROOT"];
 if(store){try{const base=join(store,"v1","origins");for(const origin of readdirSync(base)){try{const file=join(base,origin,"memory.json");if(statSync(file).size<=policy.maximumTelemetryBytes)states.push(JSON.parse(readFileSync(file,"utf8")));}catch{}}}catch{}}
 let scope:ReadonlySet<string>|undefined;
 try{if(input.lockPath!==undefined&&input.roots!==undefined&&input.roots.length>0&&existsSync(input.lockPath)&&statSync(input.lockPath).size<=policy.maximumLockBytes)scope=lockClosureV1(readFileSync(input.lockPath,"utf8"),input.roots);}catch{}
 const local=input.localHost(),peaks=mergePreflightPeaksV1(telemetryPeaksV1(telemetry,input.mode),wardenPeaksV1(states,nowMs),carvingPeaksV1(input.policy)),rows=planMemoryPreflightV1({peaks,policy:input.policy,local,fleet:input.fleetHosts(),...scope===undefined?{}:{scope}});
 return memoryPreflightLinesV1(rows,input.language,{totalMegabytes:local.totalMegabytes,holdableMegabytes:hostHoldableMegabytesV1(local)});
}

/** 🧯️ The early check as the launcher calls it: the lines to print, or one bilingual `unavailable` line when anything fails, because monitoring and estimation never fail a build. */
export async function reportMemoryPreflightV1(input:Parameters<typeof collectMemoryPreflightV1>[0],report:(line:string)=>void):Promise<void>{
 try{for(const line of await collectMemoryPreflightV1(input))report(line);}
 catch(error){try{report(fill(MEMORY_PREFLIGHT_POLICY_V1.texts[input.language].unavailable,{reason:error instanceof Error?error.message:String(error)}));}catch{}}
}

/** 🦀️ The early check of one Cargo launch: wires the live sources (the admission telemetry of this machine, the warden, the capacity port with its fleet view, the lock of the manifest) into `reportMemoryPreflightV1`; the packages named with `-p` narrow the units to their dependency closure. Never throws.
 * @see ../../../../🏃️process/🦀️cargo/🚪️launcher/🟦️.ts */
export async function reportMemoryPreflightForCargoV1(input:Readonly<{workspace:string;manifest:string;args:readonly string[];storeRoot:string;mode:string;environment:Readonly<Record<string,string|undefined>>;language:"en"|"de"}>,report:(line:string)=>void):Promise<void>{
 try{
  const [capacity,warden,profile,ceiling]=await Promise.all([import("../../../../🏗️build/🌡️host-capacity/🟦️.ts"),import("../../../../../../../../🔨️modules/🏃️process/🏗️build/🌡️host-capacity/🛡️warden/🔁️loop/🟦️.ts"),import("../../../../🏗️build/🎚️mode/🦀️profile/🟦️.ts"),import("../../../../../../../../🔨️modules/🏃️process/📦️artifacts/🏗️native-build/🎟️admission/🏔️ceiling/🟦️.ts")]);
  const port=capacity.createGrantGrowthPortV1({environment:input.environment as NodeJS.ProcessEnv}),cacheRoot=join(input.storeRoot,"components"),lockPath=[join(dirname(input.manifest),"Cargo.lock"),join(input.workspace,"Cargo.lock")].find(path=>existsSync(path)),roots=profile.selectedCargoProfileCompositionsV1(input.args);
  await reportMemoryPreflightV1({historyPath:telemetryPathV1(cacheRoot),mode:input.mode,environment:input.environment,language:input.language,localHost:()=>{const host=port.local();if(host===undefined)throw Error("host memory facts unknown");return host;},fleetHosts:()=>port.fleet(),wardenState:()=>warden.readHostWardenStateV1(),policy:ceiling.UNIT_CEILING_POLICY_V1,...lockPath===undefined?{}:{lockPath},...roots===undefined?{}:{roots}},report);
 }catch{}
}
