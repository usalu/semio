/** 🧮️ Contract: the reverse index answers exactly what the neutral traversal over the whole graph answers (`affectedBuildProjectsV1`) and what a naive brute force written from the rule answers, on 300 random worlds with cycles, nested roots, a root project, named inputs, filesets, extended globs, closure leaves, global edges, new, deleted and manifest files. */
import {expect,test} from "bun:test";
import {createRequire} from "node:module";
import {affectedBuildProjectsV1} from "../../../../🧭️selection/🟦️.ts";
import {GlobV1} from "../../../../../../../../../📦️packages/🟦️typescript/⚙️runtime/🌐️glob/🟦️.ts";
import {changeSets,makeWorld,portsOf,random,worldGeneration,worldGraph,type WorldV1} from "../🧰️synthetic/🟦️.ts";

const target=process.env.AFFECTED_INDEX_MODULE??"../../🟨️.mjs",module_=await import(target) as typeof import("../../🟨️.mjs");
const picomatch=createRequire(process.env.R227_LIVE?process.env.R227_LIVE+"/package.json":new URL("../../../../../../../../../../package.json",import.meta.url).pathname)("picomatch") as (pattern:string,options?:object)=>(file:string)=>boolean;

const derive=async(world:WorldV1)=>{const generation=worldGeneration(world);return module_.deriveAffectedIndexV1({manifest:generation.manifest as never,digest:generation.digest,declared:world.declared as never,...portsOf(world,generation)});};

function brute(world:WorldV1,files:readonly string[]):string[]{
 const expand=(inputs:readonly unknown[],named:Record<string,readonly unknown[]>,seen:string[]):string[]=>inputs.flatMap(input=>{
  if(typeof input==="string"){if(input in named)return seen.includes(input)?[]:expand(named[input]!,named,[...seen,input]);return input.startsWith("{workspaceRoot}/")?[input.slice(16)]:[];}
  const object=input as {env?:string;fileset?:string};
  if(typeof object.env==="string"&&world.leaves.has(object.env))return world.leaves.get(object.env)!;
  return typeof object.fileset==="string"&&object.fileset.startsWith("{workspaceRoot}/")?[object.fileset.slice(16)]:[];
 });
 const hits=new Set<string>();
 if(files.includes("nx.json"))for(const project of world.projects)hits.add(project.name);
 else if(files.length)for(const project of world.projects){
  const named={...world.declared,...project.namedInputs} as Record<string,readonly unknown[]>,patterns=Object.values(project.targets).flatMap(entry=>entry.inputs?expand(entry.inputs,named,[]):[]);
  for(const file of files){
   const owners=world.projects.filter(other=>other.root==="."||file.startsWith(other.root+"/")).sort((a,b)=>Math.max(b.root.length,0)-a.root.length||(a.name<b.name?-1:1));
   if(owners[0]===project)hits.add(project.name);
   if(patterns.some(pattern=>/[?*+@!]\(/u.test(pattern)||(/[*?\[\]{}()!\\]/u.test(pattern)?picomatch(pattern,{dot:true})(file):pattern===file)))hits.add(project.name);
  }
 }
 const edges=[...world.projects.flatMap(project=>project.edges),...world.globalEdges].filter(edge=>world.projects.some(project=>project.name===edge.source)&&world.projects.some(project=>project.name===edge.target));
 for(let changed=true;changed;){changed=false;for(const edge of edges)if(hits.has(edge.target)&&!hits.has(edge.source)){hits.add(edge.source);changed=true;}}
 return[...hits].sort();
}

test("300 random worlds: index equals the neutral traversal and the brute force",async()=>{
 let asked=0,nonEmpty=0;
 for(let seed=1;seed<=300;seed++){
  const next=random(seed),world=makeWorld(seed,{projects:3+Math.floor(next()*14),rootProject:seed%5===0,edgesPerProject:Math.floor(next()*4),filesPerLeaf:1+Math.floor(next()*5)}),{index}=await derive(world),open=module_.openAffectedIndexV1(index),graph=worldGraph(world);
  for(const files of changeSets(world,12,seed)){
   const answer=open.query(files).projects,neutral=affectedBuildProjectsV1(graph,files),naive=brute(world,files);
   expect(answer).toEqual(neutral);expect(answer).toEqual(naive);asked++;if(answer.length)nonEmpty++;
  }
 }
 expect(asked).toBe(3600);expect(nonEmpty).toBeGreaterThan(1500);
},180000);

test("a changed file maps to exactly the projects that own it, read it through inputs or depend on them",async()=>{
 const world:WorldV1={declared:{},leaves:new Map([["SEMIO_SOURCE_CLOSURE_"+"a".repeat(64),["shared/lib.rs"]]]),globalEdges:[],files:[],projects:[
  {name:"app",root:"apps/app",targets:{build:{inputs:[]}},edges:[{source:"app",target:"core",type:"static"}]},
  {name:"core",root:"libs/core",targets:{build:{inputs:[]}},edges:[]},
  {name:"nested",root:"libs/core/nested",targets:{build:{inputs:[]}},edges:[]},
  {name:"rust",root:"crates/rust",targets:{build:{inputs:[{env:"SEMIO_SOURCE_CLOSURE_"+"a".repeat(64)},"{workspaceRoot}/schema/x.json"]}},edges:[]},
  {name:"web",root:"apps/web",targets:{build:{inputs:[]}},edges:[{source:"web",target:"rust",type:"static"}]},
  {name:"lonely",root:"apps/lonely",targets:{build:{inputs:[]}},edges:[]}]};
 const open=module_.openAffectedIndexV1((await derive(world)).index),ask=(...files:string[])=>open.query(files).projects;
 expect(ask("libs/core/src/a.ts")).toEqual(["app","core"]);
 expect(ask("libs/core/nested/src/a.ts")).toEqual(["nested"]);
 expect(ask("shared/lib.rs")).toEqual(["rust","web"]);
 expect(ask("schema/x.json")).toEqual(["rust","web"]);
 expect(ask("apps/lonely/deleted.ts")).toEqual(["lonely"]);
 expect(ask("apps/brand-new/file.ts")).toEqual([]);
 expect(ask()).toEqual([]);
 expect(ask("nx.json")).toEqual(["app","core","lonely","nested","rust","web"]);
 expect(open.query(["apps/new/📋️project.json"]).unknown).toEqual(["apps/new/📋️project.json"]);
 expect(open.query(["libs/core/src/a.ts"]).unknown).toEqual([]);
});

test("cross-language edge: a Rust closure leaf names a file of a TypeScript project, the dependents of the Rust project follow",async()=>{
 const key="SEMIO_SOURCE_CLOSURE_"+"b".repeat(64),world:WorldV1={declared:{},leaves:new Map([[key,["web/schema.json"]]]),globalEdges:[{source:"cli",target:"crate",type:"implicit"}],files:[],projects:[
  {name:"web",root:"web",targets:{build:{inputs:[]}},edges:[]},{name:"crate",root:"crates/c",targets:{build:{inputs:[{env:key}]}},edges:[]},{name:"cli",root:"cli",targets:{build:{inputs:[]}},edges:[]}]};
 expect(module_.openAffectedIndexV1((await derive(world)).index).query(["web/schema.json"]).projects).toEqual(["cli","crate","web"]);
});

test("literal patterns agree with the glob matcher and a third-party matcher",()=>{
 const next=random(9),parts=["a","b.ts","c-d","@s","x+y","docs","e.json","日本"],pattern=()=>Array.from({length:1+Math.floor(next()*3)},()=>parts[Math.floor(next()*parts.length)]).join("/");
 for(let round=0;round<2000;round++){const literal=pattern(),file=next()<0.5?literal:pattern();expect(new GlobV1(literal).match(file)).toBe(literal===file);expect(picomatch(literal)(file)).toBe(literal===file);}
});
