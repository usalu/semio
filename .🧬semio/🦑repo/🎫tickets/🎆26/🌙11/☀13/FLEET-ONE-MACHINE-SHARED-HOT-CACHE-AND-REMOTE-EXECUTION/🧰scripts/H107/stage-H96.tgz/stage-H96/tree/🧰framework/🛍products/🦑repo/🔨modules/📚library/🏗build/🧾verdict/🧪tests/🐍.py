#!/usr/bin/env python3
"""🐍️ Independent model of the verdict (standard library only): `failures <schema> <corpus>` extracts the first failure of every tail of the corpus, `check <schema> <verdicts>` re-measures the UTF-8 size of verdict documents and their invariants."""
import json, re, sys

schema = json.load(open(sys.argv[2], encoding="utf-8"))["definitions"]
limits = schema["Limits"]["const"]
ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def short(text, n):
    flat = " ".join(text.split())
    return flat if len(flat) <= n else flat[: n - 1] + "…"


def relpath(path, root):
    path = path.replace("file://", "", 1) if path.startswith("file://") else path
    path = path.replace("\\", "/")
    base = (root or "").replace("\\", "/").rstrip("/")
    if base and path.startswith(base + "/"):
        path = path[len(base) + 1:]
    return path if len(path) <= limits["pathCharacters"] else "…" + path[len(path) - limits["pathCharacters"] + 1:]


def first_failure(lines, own, root):
    msg = lambda t: short(t, limits["messageCharacters"])
    loc = lambda p, l, c: {"file": relpath(p, root), "line": int(l), "column": int(c)}
    for line in lines:
        m = re.match(r"^(.+?)\((\d+),(\d+)\): error (TS\d+): (.*)$", line) or re.match(r"^(.+?):(\d+):(\d+) - error (TS\d+): (.*)$", line)
        if m:
            return {**loc(m[1], m[2], m[3]), "message": msg(m[4] + ": " + m[5])}
    for i, line in enumerate(lines):
        e = re.match(r"^error(?:\[(E\d+)\])?: (.*)$", line)
        if e and not re.match(r"^error: (aborting due to|could not compile|process didn't exit|test failed|\d+ previous error)", line):
            for j in range(i + 1, min(len(lines) - 1, i + 4) + 1):
                a = re.match(r"^\s*--> (.+?):(\d+):(\d+)\s*$", lines[j])
                if a:
                    return {**loc(a[1], a[2], a[3]), "message": msg((e[1] + ": " if e[1] else "") + e[2])}
        o = re.search(r"panicked at '(.*)', (.+?):(\d+):(\d+)\s*$", line)
        if o:
            return {**loc(o[2], o[3], o[4]), "message": msg(o[1])}
        p = re.search(r"panicked at (.+?):(\d+):(\d+):?\s*$", line)
        if p:
            return {**loc(p[1], p[2], p[3]), "message": msg(lines[i + 1] if i + 1 < len(lines) else "panicked")}
    mine = relpath(own, root) if own else None
    for i, line in enumerate(lines):
        e = re.match(r"^\s*error: (.*)$", line)
        if not e:
            continue
        extra = [l.strip() for l in lines[i + 1: i + 5] if re.match(r"^\s*(Expected|Received)\b", l)]
        frames = []
        for l in lines[i + 1:]:
            if re.match(r"^\s*error: ", l) or re.match(r"^\s*\((?:fail|pass)\)", l):
                break
            f = re.match(r"^\s*at (?:.*? \()?(.+?):(\d+):(\d+)\)?\s*$", l)
            if f and "node_modules" not in f[1] and not f[1].startswith("bun:"):
                frames.append(f)
        chosen = next((f for f in frames if mine and relpath(f[1], root).endswith(mine)), None) or (frames[0] if frames else None)
        return {**(loc(chosen[1], chosen[2], chosen[3]) if chosen else {}), "message": msg("; ".join([e[1]] + extra))}
    bad = next((l for l in lines if re.search(r"error|fail|panic|exception|expected", l, re.I)), None)
    if bad is None:
        bad = next((l for l in reversed(lines) if l.strip()), None)
    return None if bad is None else {"message": msg(bad)}


if sys.argv[1] == "failures":
    out = []
    for item in json.load(open(sys.argv[3], encoding="utf-8"))["failures"]:
        lines = [ANSI.sub("", l) for l in "\n".join(item["tail"]).split("\n")]
        out.append(first_failure(lines, item.get("file"), item.get("root")))
    print(json.dumps(out, ensure_ascii=False))
else:
    out = []
    for verdict in json.load(open(sys.argv[3], encoding="utf-8")):
        size = len(json.dumps(verdict, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
        files = verdict["files"]
        out.append({"bytes": size, "ok": size <= limits["maximumBytes"] and len(files) <= limits["maximumFiles"] and len(verdict["origin"]["hosts"]) <= limits["maximumHosts"] and all(len(r["file"]) <= limits["pathCharacters"] for r in files) and verdict["counts"]["failed"] >= sum(1 for r in files if r["status"] == "failed"), "omitted": verdict.get("omitted", {}).get("files", 0) + len(files)})
    print(json.dumps(out))
