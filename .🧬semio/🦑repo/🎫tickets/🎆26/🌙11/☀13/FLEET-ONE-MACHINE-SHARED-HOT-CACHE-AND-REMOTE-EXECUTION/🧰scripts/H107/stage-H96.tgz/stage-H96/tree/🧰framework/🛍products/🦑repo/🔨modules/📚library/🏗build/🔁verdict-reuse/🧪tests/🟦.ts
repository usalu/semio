/** ♻️ Contract: the reuse key of a test file changes with its content, its import closure, the files of its member, declared fixtures, toolchain and envelope and with nothing else, and is the same on another checkout location; a passed verdict is reused, a failed or empty or damaged or expired one never is, an unreachable store never blocks, the opt-out always runs; the key equals an independent Python model and the import scan equals the TypeScript compiler's.
 * @see ../🧬️schema/🔣️.json */
import Ajv from "ajv";
import {afterAll,expect,test} from "bun:test";
import {cpSync,mkdirSync,mkdtempSync,realpathSync,rmSync,writeFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {dirname,join} from "node:path";
import {fileURLToPath} from "node:url";
import ts from "typescript";
import {validateJsonSchemaSubset} from "../../../../../../../🔨️modules/🧬️schema/✅️validator/📦️packages/🟦️typescript/🟦️.ts";
import {testPythonV1} from "../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🧪️testing/🧰️toolchain/🟦️.ts";
import {VERDICT_REUSE_FILE_SYSTEM_V1,VERDICT_REUSE_POLICY_V1,canonicalJsonV1,createDirectoryVerdictCachePortV1,decodeVerdictReuseRecordV1,encodeVerdictReuseRecordV1,importClosureOfFileV1,importSpecifiersOfTextV1,lookupVerdictReuseV1,renderVerdictReuseV1,reuseOrRunV1,storeVerdictReuseV1,verdictReuseAddressV1,verdictReuseEnvelopeV1,verdictReuseKeyV1,verdictReuseOptedOutV1,type VerdictCachePortV1,type VerdictReuseKeyV1} from "../🟦️.ts";
import schema from "../🧬️schema/🔣️.json";
import corpus from "./🔣️.json";

const here=dirname(fileURLToPath(import.meta.url)),schemaPath=join(here,"..","🧬️schema","🔣️.json"),python=testPythonV1();
const ajv=new Ajv({strict:false,allowUnionTypes:true}),definitions=schema.definitions,compile=(name:string)=>ajv.compile({$schema:schema.$schema,definitions,$ref:`#/definitions/${name}`});
const inRepo=(name:string,value:unknown)=>validateJsonSchemaSubset({$ref:`#/definitions/${name}`},value,schema as never);
const scratch:string[]=[];afterAll(()=>{for(const directory of scratch)rmSync(directory,{recursive:true,force:true});});
const world=()=>{const root=realpathSync(mkdtempSync(join(tmpdir(),"h96-reuse-")));scratch.push(root);return root;};
const put=(root:string,path:string,text:string)=>{mkdirSync(dirname(join(root,path)),{recursive:true});writeFileSync(join(root,path),text);};
const grow=(root:string)=>{
 put(root,"bun.lock","lock-1");
 put(root,"m/🧪️tests/🟦️.ts","import {a} from \"../🟦️.ts\";\nimport {h} from \"./🧫️helper.ts\";\nimport Ajv from \"ajv\";\nimport fs from \"node:fs\";\n");
 put(root,"m/🟦️.ts","import {s} from \"../shared/🟦️.ts\";\nexport const a=s;\n");
 put(root,"m/🧪️tests/🧫️helper.ts","export const h=1;\n");
 put(root,"m/🧪️tests/🐍️.py","print(1)\n");
 put(root,"shared/🟦️.ts","import data from \"./deep.json\" with {type:\"json\"};\nexport const s=data;\n");
 put(root,"shared/deep.json","{\"v\":1}");
 put(root,"other/🟦️.ts","export const o=1;\n");
 put(root,"fixtures/data.txt","fixture-1");
};
const ports={...VERDICT_REUSE_FILE_SYSTEM_V1,resolveBare:undefined};
const toolchain={runtime:"bun",runtimeVersion:"1.3.14",lockfile:"abc"},envelope={platform:"darwin",arch:"arm64",runner:"bun-test"};
const keyOf=(root:string,options:{fixtures?:string[];toolchain?:Record<string,string>;envelope?:Record<string,string>}={})=>{
 const found=verdictReuseKeyV1({file:join(root,"m/🧪️tests/🟦️.ts"),root,fixtures:options.fixtures??[],toolchain:options.toolchain??toolchain,envelope:options.envelope??envelope,ports});
 if(found.kind!=="key")throw Error(JSON.stringify(found));return found;
};

test("policy, inputs and record satisfy the closed schema under both validators and mutations are rejected by both",()=>{
 const root=world();grow(root);const found=keyOf(root);
 const record=JSON.parse(Buffer.from(encodeVerdictReuseRecordV1({key:found.key,file:"m",at:5,origin:"g1-m13",result:{pass:3,fail:0,skipped:1,seconds:1.5}})).toString()) as Record<string,unknown>;
 for(const [name,value] of Object.entries({Policy:VERDICT_REUSE_POLICY_V1,Inputs:found.inputs,Record:record})){
  expect(inRepo(name,value),name).toEqual([]);expect(compile(name)(value),name).toBe(true);
 }
 const mutations:[string,unknown][]=[["Record",{...record,extra:1}],["Record",{...record,key:"xyz"}],["Record",{...record,result:{pass:0,fail:0,skipped:0,seconds:1}}],["Record",{...record,result:{pass:1,fail:1,skipped:0,seconds:1}}],["Inputs",{...found.inputs,fileDigest:"nope"}],["Inputs",{...found.inputs,extra:true}]];
 for(const [name,value] of mutations){expect(compile(name)(value),JSON.stringify(value)).toBe(false);expect(inRepo(name,value).length,JSON.stringify(value)).toBeGreaterThan(0);}
 for(const key of Object.keys(schema.definitions.Texts.const))expect(schema.definitions.Texts.const[key as keyof typeof schema.definitions.Texts.const].de.length>0,key).toBe(true);
});

test("canonical JSON digests and the full key equal the independent Python model",()=>{
 expect(python,"python3 is required for the independent model").toBeTruthy();
 const root=world();grow(root);
 const directory=world();
 for(const item of corpus.documents){
  const path=join(directory,"doc.json");writeFileSync(path,JSON.stringify(item.document));
  const model=Bun.spawnSync([python!,"-I",join(here,"🐍️.py"),"canonical",schemaPath,path]).stdout.toString().trim();
  expect(new Bun.CryptoHasher("sha256").update(canonicalJsonV1(item.document)).digest("hex"),item.name).toBe(model);
 }
 const extra=join(directory,"extra.json");
 for(const fixtures of[[],["fixtures"]]){
  writeFileSync(extra,JSON.stringify({fixtures,toolchain,envelope}));
  const model=JSON.parse(Bun.spawnSync([python!,"-I",join(here,"🐍️.py"),"key",schemaPath,root,join(root,"m/🧪️tests/🟦️.ts"),extra]).stdout.toString()) as {key:string;address:string};
  const found=keyOf(root,{fixtures});
  expect(found.key,JSON.stringify(fixtures)).toBe(model.key);expect(verdictReuseAddressV1(found.key)).toBe(model.address);
 }
});

test("the import scan equals the TypeScript compiler's on a literal corpus and over approximates comments",()=>{
 for(const item of corpus.specifiers){
  const oracle=ts.preProcessFile(item.text,true,true).importedFiles.map(file=>file.fileName).sort();
  expect(importSpecifiersOfTextV1(item.text)).toEqual(oracle);expect(oracle).toEqual(item.specifiers);
 }
 expect(importSpecifiersOfTextV1("// import x from \"./commented\"\n")).toContain("./commented");
 const root=world();grow(root);
 const closure=importClosureOfFileV1(join(root,"m/🧪️tests/🟦️.ts"),root,ports);
 expect(closure.files.map(file=>file.slice(root.length+1))).toEqual(["m/🟦️.ts","m/🧪️tests/🧫️helper.ts","shared/deep.json","shared/🟦️.ts"].sort());
 expect(closure.externals).toEqual(["ajv"]);expect(closure.unresolved).toEqual([]);
});

test("the key changes with every input it must depend on and with nothing else, and is the same on another checkout location",()=>{
 const root=world();grow(root);const base=keyOf(root).key;
 const changed=(mutate:(root:string)=>void,options?:Parameters<typeof keyOf>[1])=>{const copy=world();cpSync(root,copy,{recursive:true});mutate(copy);return keyOf(copy,options).key!==base;};
 expect(changed(copy=>put(copy,"m/🧪️tests/🟦️.ts","import {a} from \"../🟦️.ts\";\nimport {h} from \"./🧫️helper.ts\";\nimport Ajv from \"ajv\";\nimport fs from \"node:fs\";\n//x\n")),"test file").toBe(true);
 expect(changed(copy=>put(copy,"shared/deep.json","{\"v\":2}")),"transitive import (json)").toBe(true);
 expect(changed(copy=>put(copy,"shared/🟦️.ts","export const s=2;\n")),"transitive import (module)").toBe(true);
 expect(changed(copy=>put(copy,"m/🧪️tests/🐍️.py","print(2)\n")),"member file read at run time").toBe(true);
 expect(changed(copy=>put(copy,"m/new.json","{}")),"new member file").toBe(true);
 expect(changed(copy=>put(copy,"fixtures/data.txt","fixture-2"),{fixtures:["fixtures"]}),"declared fixture").toBe(true);
 expect(changed(copy=>put(copy,"fixtures/data.txt","fixture-2")),"undeclared fixture").toBe(false);
 expect(changed(()=>undefined,{toolchain:{...toolchain,runtimeVersion:"1.4.0"}}),"toolchain").toBe(true);
 expect(changed(()=>undefined,{envelope:{...envelope,platform:"linux"}}),"envelope").toBe(true);
 expect(changed(copy=>put(copy,"other/🟦️.ts","export const o=2;\n")),"unrelated file").toBe(false);
 expect(changed(copy=>put(copy,"other/new.ts","x")),"unrelated new file").toBe(false);
 expect(changed(()=>undefined),"another location").toBe(false);
 expect(changed(copy=>put(copy,"m/🧪️tests/🟦️.ts","import {a} from \"../🟦️.ts\";\nimport {h} from \"./🧫️helper.ts\";\nimport Ajv from \"ajv\";\nimport fs from \"node:fs\";\nimport \"./missing\";\n")),"unresolved import").toBe(true);
 expect(()=>verdictReuseEnvelopeV1({HOME:"/x"})).toThrow(/not allowed .* \/ .* nicht erlaubt/u);
});

test("bounds make a test ineligible instead of keying it wrongly",()=>{
 const root=world();grow(root);const file=join(root,"m/🧪️tests/🟦️.ts");
 const kind=(policy:typeof VERDICT_REUSE_POLICY_V1):VerdictReuseKeyV1=>verdictReuseKeyV1({file,root,toolchain,envelope,ports,policy});
 expect(kind({...VERDICT_REUSE_POLICY_V1,maximumMemberFiles:2})).toEqual({kind:"ineligible",reason:"too-many-files"});
 expect(kind({...VERDICT_REUSE_POLICY_V1,maximumClosureFiles:1})).toEqual({kind:"ineligible",reason:"too-many-files"});
 expect(kind({...VERDICT_REUSE_POLICY_V1,maximumHashBytes:10})).toEqual({kind:"ineligible",reason:"too-large"});
});

const memoryPort=():VerdictCachePortV1&{map:Map<string,Uint8Array>}=>{const map=new Map<string,Uint8Array>();return{map,read:async hash=>map.get(hash),write:async(hash,bytes)=>{map.set(hash,bytes);}};};
const passed={status:"passed",seconds:1.234,pass:5,fail:0};

test("only a passed verdict is stored and reused; failed, empty, damaged, foreign and expired records are misses; a down or slow store never blocks",async()=>{
 const key="a".repeat(64),port=memoryPort();let clock=1_000_000;const now=()=>clock;
 expect(await lookupVerdictReuseV1({key,port,now})).toEqual({kind:"miss",reason:"absent"});
 expect(await storeVerdictReuseV1({key,file:"f",origin:"g1-m13",row:{status:"failed",seconds:1,pass:3,fail:1},port,now})).toEqual({kind:"skipped",reason:"not-passed"});
 expect(await storeVerdictReuseV1({key,file:"f",origin:"g1-m13",row:{status:"passed",seconds:1,pass:0,fail:0},port,now})).toEqual({kind:"skipped",reason:"empty"});
 expect(port.map.size).toBe(0);
 expect(await storeVerdictReuseV1({key,file:"f",origin:"g1-m13",row:passed,port,now})).toEqual({kind:"stored"});
 const hit=await lookupVerdictReuseV1({key,port,now:()=>clock+90_000});
 expect(hit.kind).toBe("hit");if(hit.kind==="hit"){expect(hit.ageMs).toBe(90_000);expect(hit.record.result).toEqual({pass:5,fail:0,skipped:0,seconds:1.23});}
 expect(await lookupVerdictReuseV1({key,port,now,optOut:true})).toEqual({kind:"miss",reason:"opted-out"});
 expect(await lookupVerdictReuseV1({key,port,now:()=>clock+VERDICT_REUSE_POLICY_V1.maximumAgeMs+1})).toEqual({kind:"miss",reason:"expired"});
 const address=verdictReuseAddressV1(key),good=port.map.get(address)!;
 port.map.set(address,Buffer.from(Buffer.from(good).toString().replace("\"pass\":5","\"pass\":6")));
 expect(await lookupVerdictReuseV1({key,port,now})).toEqual({kind:"miss",reason:"corrupt"});
 port.map.set(address,Buffer.from("{"));expect(await lookupVerdictReuseV1({key,port,now})).toEqual({kind:"miss",reason:"corrupt"});
 port.map.set(address,encodeVerdictReuseRecordV1({key:"b".repeat(64),file:"f",at:clock,origin:"x",result:{pass:1,fail:0,skipped:0,seconds:0}}));
 expect(await lookupVerdictReuseV1({key,port,now})).toEqual({kind:"miss",reason:"key-mismatch"});
 const failedRecord=encodeVerdictReuseRecordV1({key,file:"f",at:clock,origin:"x",result:{pass:1,fail:1 as never,skipped:0,seconds:0}});
 port.map.set(address,failedRecord);expect(await lookupVerdictReuseV1({key,port,now})).toEqual({kind:"miss",reason:"not-passed"});
 port.map.set(address,encodeVerdictReuseRecordV1({key,file:"f",at:clock,origin:"x",result:{pass:0,fail:0,skipped:0,seconds:0}}));
 expect(await lookupVerdictReuseV1({key,port,now})).toEqual({kind:"miss",reason:"empty"});
 expect(decodeVerdictReuseRecordV1(Buffer.from("[]"),key)).toBe("corrupt");
 const down:VerdictCachePortV1={read:async()=>{throw Error("down");},write:async()=>{throw Error("down");}};
 expect(await lookupVerdictReuseV1({key,port:down,now})).toEqual({kind:"miss",reason:"store-down"});
 expect(await storeVerdictReuseV1({key,file:"f",origin:"x",row:passed,port:down,now})).toEqual({kind:"skipped",reason:"store-down"});
 const slow:VerdictCachePortV1={read:()=>new Promise(()=>undefined),write:()=>new Promise(()=>undefined)};
 const started=performance.now();
 expect(await lookupVerdictReuseV1({key,port:slow,now,policy:{...VERDICT_REUSE_POLICY_V1,storeTimeoutMs:50}})).toEqual({kind:"miss",reason:"store-down"});
 expect(performance.now()-started).toBeLessThan(1500);
});

test("an unchanged test is run once and then reused by any agent, a changed one runs again, a failure is never reused and a file edited during the run is never filed",async()=>{
 const root=world();grow(root);const directory=world(),port=createDirectoryVerdictCachePortV1(join(directory,"cache")),file=join(root,"m/🧪️tests/🟦️.ts");
 const keyFor=()=>verdictReuseKeyV1({file,root,toolchain,envelope,ports});
 let runs=0,result:Record<string,unknown>=passed;
 const go=(optOut=false)=>reuseOrRunV1({file:"m/🧪️tests/🟦️.ts",keyOf:keyFor,port,origin:"g1-m13",optOut,run:async()=>{runs++;return result as typeof passed;}});
 const first=await go();expect(first.kind).toBe("ran");expect(runs).toBe(1);if(first.kind==="ran"){expect(first.miss).toBe("absent");expect(first.stored).toBe(true);}
 const second=await go();expect(second.kind).toBe("reused");expect(runs).toBe(1);if(second.kind==="reused")expect(second.record.origin).toBe("g1-m13");
 const forced=await go(true);expect(forced.kind).toBe("ran");expect(runs).toBe(2);
 put(root,"shared/deep.json","{\"v\":3}");
 expect((await go()).kind).toBe("ran");expect(runs).toBe(3);
 put(root,"shared/deep.json","{\"v\":4}");result={status:"failed",seconds:1,pass:2,fail:1};
 const failed=await go();expect(failed.kind).toBe("ran");if(failed.kind==="ran")expect(failed.stored).toBe(false);
 const again=await go();expect(again.kind).toBe("ran");expect(runs).toBe(5);
 put(root,"shared/deep.json","{\"v\":5}");result=passed;
 const edited=await reuseOrRunV1({file:"f",keyOf:keyFor,port,origin:"x",run:async()=>{put(root,"shared/deep.json","{\"v\":6}");return passed;}});
 expect(edited.kind==="ran"&&edited.stored).toBe(false);
 const tiny={...VERDICT_REUSE_POLICY_V1,maximumMemberFiles:1};let ran=0;
 const inel=await reuseOrRunV1({file:"f",keyOf:()=>verdictReuseKeyV1({file,root,toolchain,envelope,ports,policy:tiny}),port,origin:"x",run:async()=>{ran++;return passed;}});
 expect(inel).toMatchObject({kind:"ran",miss:"too-many-files",stored:false});expect(ran).toBe(1);
});

test("opt-out by flag or variable, and the messages render in both languages",()=>{
 expect(verdictReuseOptedOutV1(["--no-reuse"],{})).toBe(true);
 for(const value of["0","off","FALSE"," never "])expect(verdictReuseOptedOutV1([],{SEMIO_TEST_REUSE:value}),value).toBe(true);
 expect(verdictReuseOptedOutV1([],{})).toBe(false);expect(verdictReuseOptedOutV1(["--bail"],{SEMIO_TEST_REUSE:"on"})).toBe(false);
 const record=decodeVerdictReuseRecordV1(encodeVerdictReuseRecordV1({key:"c".repeat(64),file:"f",at:1,origin:"g1-m13",result:{pass:1,fail:0,skipped:0,seconds:1}}),"c".repeat(64));
 if(typeof record==="string")throw Error(record);
 expect(renderVerdictReuseV1("en","f.test.ts",{kind:"reused",record,ageMs:125_000})).toBe("reused passed verdict of f.test.ts from g1-m13, 2 min 05 s old (key cccccccccccc)");
 expect(renderVerdictReuseV1("de","f.test.ts",{kind:"reused",record,ageMs:125_000})).toBe("bestandenes Urteil von f.test.ts wiederverwendet von g1-m13, 2 min 05 s alt (Schlüssel cccccccccccc)");
 expect(renderVerdictReuseV1("en","f.test.ts",{kind:"miss",reason:"expired"})).toBe("f.test.ts: stored verdict is older than 24 h 00 min, running");
 expect(renderVerdictReuseV1("de","f.test.ts",{kind:"miss",reason:"not-passed"})).toBe("f.test.ts: gespeichertes Urteil war nicht bestanden, Lauf");
 for(const reason of schema.definitions.MissReason.enum)expect(renderVerdictReuseV1("en","f",{kind:"miss",reason:reason as never}).length,reason).toBeGreaterThan(3);
});
