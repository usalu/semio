/** 🧯️ An EPERM of the resident service below a macOS-protected folder is named as the missing file access consent in both languages, with a reference and the log; every other failure keeps its former refusal. */
import {expect,test} from "bun:test";
import {readFileSync} from "node:fs";
import {accessDeniedOfV1,failureRefusalV1,heavyRefusalOfV1,wantedRefusalOfV1} from "../../🏛️service/🧯️failure/🟨️.mjs";
import schema from "../../🧬️schema/🔣️.json" with {type:"json"};

const perm=Object.assign(new Error("Relative filesystem fstatat failed (EPERM)"),{code:"EPERM"}),home="/Users/worker",logs:string[]=[];
const refuse=(error:unknown,options:{root:string;platform?:string})=>failureRefusalV1(error,{log:(event,detail)=>{logs.push(event+" "+detail);},logPath:"/log",home,platform:"darwin",...options});

test("EPERM below Documents, Desktop or Downloads of the user on macOS is the access consent, anywhere else it is internal",()=>{
  for(const folder of ["Documents","Desktop","Downloads"])expect(accessDeniedOfV1(perm,{root:`${home}/${folder}/semio/deep`,platform:"darwin",home})).toBe(folder);
  for(const root of [`${home}/semio`,"/Users/Shared/semio",`${home}/DocumentsOther/semio`,"/Users/other/Documents/semio"])expect(accessDeniedOfV1(perm,{root,platform:"darwin",home}),root).toBeUndefined();
  expect(accessDeniedOfV1(perm,{root:`${home}/Documents/semio`,platform:"linux",home})).toBeUndefined();
  expect(accessDeniedOfV1(new Error("Relative filesystem fstatat failed (ENOENT)"),{root:`${home}/Documents/semio`,platform:"darwin",home})).toBeUndefined();
  expect(accessDeniedOfV1(new Error("Relative filesystem fstatat failed (EPERM)"),{root:`${home}/Documents/semio`,platform:"darwin",home})).toBe("Documents");
});

test("the refusal carries folder, reference and log, keeps the retry advice of the caller and the log holds the failure under the same reference",()=>{
  const refusal=refuse(perm,{root:`${home}/Documents/semio`});
  expect(refusal).toMatchObject({code:"consent",key:"access-denied",retry:"later",fields:{folder:"Documents",log:"/log"}});
  expect(refusal.fields.identity).toContain("semio/launcher/bin/repo");
  expect(logs.at(-1)).toContain(refusal.fields.reference);
  expect(refuse(perm,{root:"/Users/Shared/semio"})).toMatchObject({code:"internal",key:"internal",retry:"later"});
  expect(refuse(Object.assign(new Error("database or disk is full"),{code:"ENOSPC"}),{root:`${home}/Documents/semio`}).code).toBe("disk");
});

test("the text exists in English and German with the same placeholders and names the settings, the identity and the alternative",()=>{
  const texts=schema.$defs?.Texts ?? (schema as any).definitions?.Texts;
  const all=JSON.parse(readFileSync(new URL("../../🧬️schema/🔣️.json",import.meta.url),"utf8"));
  const find=(node:any):any=>node&&typeof node==="object"?(node.en&&node.de&&node.en["access-denied"]?node:Object.values(node).map(find).find(Boolean)):undefined;
  const table=find(all) ?? find(texts);
  const holes=(value:string)=>[...value.matchAll(/\{([a-z]+)\}/gu)].map(match=>match[1]).sort();
  expect(holes(table.de["access-denied"])).toEqual(holes(table.en["access-denied"]));
  expect(table.en["access-denied"]).toContain("Files & Folders");
  expect(table.de["access-denied"]).toContain("Dateien & Ordner");
  expect(table.en["access-denied"]).toContain("{identity}");
});

test("the graph-wanted refusal keeps its numbers through values, message text and cause, and every other failure is not one",()=>{
  const values={wanted:703,arrived:0,seconds:902,missing:703,local:192},fields={wanted:"703",arrived:"0",seconds:"902",missing:"703",local:"192",heavy:""};
  const message="unserved build.graph.wanted-expired "+JSON.stringify(values);
  expect(wantedRefusalOfV1(Object.assign(new Error(message),{name:"RepoError",key:"build.graph.wanted-expired",values}))).toEqual(fields);
  expect(wantedRefusalOfV1(new Error(message))).toEqual(fields);
  expect(wantedRefusalOfV1(new Error("outer",{cause:new Error(message)}))).toEqual(fields);
  expect(wantedRefusalOfV1(new Error("secret"))).toBeUndefined();
  expect(refuse(new Error(message),{root:"/Users/Shared/semio"})).toEqual({code:"unserved",key:"host-graph-wanted-expired",fields,retry:"later"});
});

test("a graph-wanted refusal that waited for heavy projects keeps the sentence naming them through values and message text",()=>{
  const heavy=", among them the too heavy project(s) workspace (about 6200 MB) (this machine can give about 4790 MB per project)",values={wanted:2,arrived:0,seconds:300,missing:2,local:192,heavy},message="unserved build.graph.wanted-expired "+JSON.stringify(values);
  const fields={wanted:"2",arrived:"0",seconds:"300",missing:"2",local:"192",heavy};
  expect(wantedRefusalOfV1(Object.assign(new Error(message),{name:"RepoError",key:"build.graph.wanted-expired",values}))).toEqual(fields);
  expect(wantedRefusalOfV1(new Error(message))).toEqual(fields);
  const shown=refuse(new Error(message),{root:"/Users/Shared/semio"});
  expect(shown.fields).toEqual(fields);
  expect(readFileSync(new URL("../../🧬️schema/🔣️.json",import.meta.url),"utf8").match(/"host-graph-wanted-expired": "[^"]*\{heavy\}/gu)).toHaveLength(2);
});

test("a graph read that stopped projects too heavy for the machine keeps its words through values, message text and cause, and its refusal is retried later in both languages",()=>{
  const values={named:"@semio-tech/s-dev-composition (about 28000 MB)",limit:2396,megabytes:14000},message="unserved build.graph.owner-too-heavy "+JSON.stringify(values),fields={named:values.named,limit:"2396"};
  expect(heavyRefusalOfV1(Object.assign(new Error(message),{name:"RepoError",key:"build.graph.owner-too-heavy",values}))).toEqual(fields);
  expect(heavyRefusalOfV1(new Error(message))).toEqual(fields);
  expect(heavyRefusalOfV1(new Error("outer",{cause:new Error(message)}))).toEqual(fields);
  expect(heavyRefusalOfV1(new Error("secret"))).toBeUndefined();expect(wantedRefusalOfV1(new Error(message))).toBeUndefined();
  expect(refuse(new Error(message),{root:"/Users/Shared/semio"})).toEqual({code:"unserved",key:"host-graph-owner-too-heavy",fields,retry:"later"});
  const text=readFileSync(new URL("../../🧬️schema/🔣️.json",import.meta.url),"utf8");
  expect(text.match(/"host-graph-owner-too-heavy": "[^"]*\{named\}[^"]*\{limit\}/gu)).toHaveLength(2);
});
