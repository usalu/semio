import {mkdirSync,readFileSync,renameSync,writeFileSync} from "node:fs";
import {dirname} from "node:path";
import schema from "./🧬️schema/🔣️.json" with {type:"json"};

export type ProgressRateLanguageV1="en"|"de";
export type ProgressRatePolicyV1=Readonly<typeof schema.definitions.Policy.const>;
export type ProgressRateHistoryRunV1=Readonly<{ms:number;items?:number}>;
export type ProgressRateHistoryV1=Readonly<{version:1;keys:Readonly<Record<string,readonly ProgressRateHistoryRunV1[]>>}>;
export type ProgressRateEstimateV1=Readonly<{done:number;total?:number;elapsedMs:number;rate:number|null;etaMs:number|null;source:"plan"|"history"|"none";stalled:boolean;stalledForMs:number}>;
export type ProgressRateMcpV1=Readonly<{progress:number;total?:number;message:string}>;
export type ProgressRateRowV1=Readonly<{phase?:string;done:number;total?:number}>;

/** 📈️ The declared numbers: sliding window, stall threshold, ETA cap and history bounds; the schema file is the single source.
 * @see ./🧬️schema/🔣️.json */
export const PROGRESS_RATE_POLICY_V1:ProgressRatePolicyV1=Object.freeze({...schema.definitions.Policy.const});
const texts=schema.definitions.Texts.const as Readonly<Record<string,Readonly<Record<ProgressRateLanguageV1,string>>>>;

/** 📈️ Tracks one progress stream: `observe(done,total?)` returns the rate over the sliding window (items per second, `null` while fewer than two samples span `minimumSpanMs`, `0` once nothing advanced for a whole window), the ETA (remaining work from the plan `total` and the measured rate, else from measured history of an earlier identical run) and `stalled` once the rate has been 0 for `stalledMs`. A stalled stream has no ETA, a finished one has ETA 0. Pure: the clock is injected.
 * @see https://github.com/modelcontextprotocol/specification (progress notifications) */
export function createProgressRateV1(input:Readonly<{policy?:ProgressRatePolicyV1;now?:()=>number;history?:ProgressRateHistoryRunV1}>={}){
 const policy=input.policy??PROGRESS_RATE_POLICY_V1,now=input.now??Date.now,samples:{at:number;done:number}[]=[];
 let startedAt:number|undefined,lastAdvanceAt=0,highest=-Infinity;
 return Object.freeze({
  observe(done:number,total?:number,at:number=now()):ProgressRateEstimateV1{
   if(startedAt===undefined){startedAt=at;lastAdvanceAt=at;}
   if(done>highest){if(highest!==-Infinity)lastAdvanceAt=at;highest=done;}
   samples.push({at,done});
   const edge=at-policy.windowMs;let drop=0;
   while(drop+1<samples.length&&samples[drop+1]!.at<=edge)drop++;
   if(drop>0)samples.splice(0,drop);
   const anchor=samples[0]!,span=at-anchor.at,finished=total!==undefined&&done>=total,idle=at-lastAdvanceAt;
   const rate=finished?null:idle>=policy.windowMs?0:samples.length<2||span<policy.minimumSpanMs?null:Math.max(0,(done-anchor.done)*1000/span);
   const stalledForMs=!finished&&rate===0?idle:0,stalled=stalledForMs>=policy.stalledMs,elapsedMs=at-startedAt;
   let etaMs:number|null=null,source:ProgressRateEstimateV1["source"]="none";
   if(finished){etaMs=0;source="plan";}
   else if(!stalled){
    if(total!==undefined&&rate!==null&&rate>0){etaMs=Math.round((total-done)*1000/rate);source="plan";}
    else if(input.history!==undefined&&rate!==null&&rate>0&&total===undefined&&input.history.items!==undefined){etaMs=Math.round(Math.max(0,input.history.items-done)*1000/rate);source="history";}
    else if(input.history!==undefined){etaMs=Math.max(0,Math.round(input.history.ms-elapsedMs));source="history";}
   }
   if(etaMs!==null&&etaMs>policy.maximumEtaMs){etaMs=null;source="none";}
   return Object.freeze({done,...total===undefined?{}:{total},elapsedMs,rate:rate===null?null:Math.round(rate*1000)/1000,etaMs,source,stalled,stalledForMs});
  },
 });
}

/** 🧮️ Tracks many streams keyed by their phase name and decorates the existing `{phase,done,total}` rows of the task view, the scheduler and the units with rate, ETA and stalled, so every producer needs one line: `const rated=createProgressRatesV1(); onProgress=row=>emit(rated.decorate(row))`. */
export function createProgressRatesV1(input:Readonly<{policy?:ProgressRatePolicyV1;now?:()=>number;history?:(phase:string)=>ProgressRateHistoryRunV1|undefined}>={}){
 const trackers=new Map<string,ReturnType<typeof createProgressRateV1>>();
 return Object.freeze({
  decorate<T extends ProgressRateRowV1>(row:T,at?:number):T&{estimate:ProgressRateEstimateV1}{
   const key=row.phase??"",history=input.history?.(key);
   let tracker=trackers.get(key);
   if(tracker===undefined){tracker=createProgressRateV1({...input.policy?{policy:input.policy}:{},...input.now?{now:input.now}:{},...history?{history}:{}});trackers.set(key,tracker);}
   return{...row,estimate:tracker.observe(row.done,row.total,at)};
  },
 });
}

const fill=(template:string,values:Readonly<Record<string,string|number>>)=>template.replace(/\{(\w+)\}/gu,(_,name:string)=>String(values[name]??""));
const text=(language:ProgressRateLanguageV1,key:string,values:Readonly<Record<string,string|number>>={})=>fill(texts[key]![language],values);
const decimal=(language:ProgressRateLanguageV1,value:string)=>language==="de"?value.replace(".",","):value;

/** ⏱️ A duration as `23 s`, `4 min 05 s` or `1 h 02 min` in the chosen language. */
export function progressDurationTextV1(language:ProgressRateLanguageV1,milliseconds:number):string{
 const seconds=Math.max(0,Math.round(milliseconds/1000)),unit=(key:string)=>texts[key]![language],two=(value:number)=>String(value).padStart(2,"0");
 if(seconds<60)return`${seconds} ${unit("unit.seconds")}`;
 if(seconds<3600)return`${Math.floor(seconds/60)} ${unit("unit.minutes")} ${two(seconds%60)} ${unit("unit.seconds")}`;
 return`${Math.floor(seconds/3600)} ${unit("unit.hours")} ${two(Math.floor(seconds%3600/60))} ${unit("unit.minutes")}`;
}

/** 🔢️ A rate as `37`, `3.2` (German `3,2`) or `<0.1`. */
export function progressRateTextV1(language:ProgressRateLanguageV1,rate:number):string{
 if(rate>=10)return String(Math.round(rate));
 if(rate>=0.1)return decimal(language,rate.toFixed(1));
 return rate>0?decimal(language,"<0.1"):"0";
}

/** 🖨️ One progress line: `label done/total (37 %), 3.2 items/s, ETA 23 s`, or the stalled note instead of the ETA; German decimal comma and `Elemente`. */
export function renderProgressRateV1(language:ProgressRateLanguageV1,label:string,estimate:ProgressRateEstimateV1,unit?:string):string{
 const count=estimate.total===undefined?text(language,"count.open",{done:estimate.done}):text(language,"count.total",{done:estimate.done,total:estimate.total});
 const percent=estimate.total!==undefined&&estimate.total>0?text(language,"percent",{percent:Math.min(100,Math.floor(estimate.done*100/estimate.total))}):"";
 const rate=estimate.rate!==null&&estimate.rate>0?text(language,"rate",{rate:progressRateTextV1(language,estimate.rate),unit:unit??text(language,"unit.default")}):"";
 const finished=estimate.total!==undefined&&estimate.done>=estimate.total;
 const tail=estimate.stalled?text(language,"stalled",{duration:progressDurationTextV1(language,estimate.stalledForMs)}):finished?"":estimate.etaMs===null?text(language,"eta.unknown"):text(language,"eta",{duration:progressDurationTextV1(language,estimate.etaMs)});
 return`${label} ${count}${percent}${rate}${tail}`.trim();
}

/** 📡️ The MCP progress notification of an estimate: `progress` is the done count, `total` only when the plan knows it, the message is the rendered line (≤ 240 characters). */
export function mcpProgressOfRateV1(language:ProgressRateLanguageV1,label:string,estimate:ProgressRateEstimateV1,unit?:string):ProgressRateMcpV1{
 return Object.freeze({progress:estimate.done,...estimate.total===undefined?{}:{total:estimate.total},message:renderProgressRateV1(language,label,estimate,unit).slice(0,240)});
}

/** 📚️ The median of a non-empty number list (lower middle for even counts, so a history never claims more than it measured). */
export const progressMedianV1=(values:readonly number[])=>{const sorted=[...values].sort((a,b)=>a-b);return sorted[Math.floor((sorted.length-1)/2)]!;};

/** 🕰️ Adds one finished run of `key` (newest last, `historyKeep` per key, `historyKeys` keys, the oldest key dropped first). */
export function recordProgressHistoryV1(history:ProgressRateHistoryV1,key:string,run:ProgressRateHistoryRunV1,policy:ProgressRatePolicyV1=PROGRESS_RATE_POLICY_V1):ProgressRateHistoryV1{
 const {[key]:previous=[],...rest}=history.keys,runs=[...previous,{ms:Math.max(0,Math.round(run.ms)),...run.items===undefined?{}:{items:Math.max(0,Math.round(run.items))}}].slice(-policy.historyKeep);
 const keys=Object.entries({...rest,[key]:runs}),kept=keys.slice(Math.max(0,keys.length-policy.historyKeys));
 return{version:1,keys:Object.fromEntries(kept)};
}

/** 🕰️ The measured history of `key`: the median duration and, when every run counted items, the median item count. */
export function progressHistoryOfV1(history:ProgressRateHistoryV1,key:string):ProgressRateHistoryRunV1|undefined{
 const runs=history.keys[key];if(runs===undefined||runs.length===0)return undefined;
 const items=runs.flatMap(run=>run.items===undefined?[]:[run.items]);
 return{ms:progressMedianV1(runs.map(run=>run.ms)),...items.length===runs.length?{items:progressMedianV1(items)}:{}};
}

/** 💾️ Reads the history document; a missing, unreadable or foreign file is an empty history, never an error. */
export function readProgressHistoryV1(path:string):ProgressRateHistoryV1{
 try{const value=JSON.parse(readFileSync(path,"utf8")) as ProgressRateHistoryV1;if(value?.version===1&&typeof value.keys==="object"&&value.keys!==null)return value;}catch{}
 return{version:1,keys:{}};
}

/** 💾️ Writes the history atomically (temporary file beside the target, then rename). */
export function writeProgressHistoryV1(path:string,history:ProgressRateHistoryV1):void{
 mkdirSync(dirname(path),{recursive:true});
 const temporary=`${path}.${process.pid}.tmp`;
 writeFileSync(temporary,JSON.stringify(history));renameSync(temporary,path);
}
