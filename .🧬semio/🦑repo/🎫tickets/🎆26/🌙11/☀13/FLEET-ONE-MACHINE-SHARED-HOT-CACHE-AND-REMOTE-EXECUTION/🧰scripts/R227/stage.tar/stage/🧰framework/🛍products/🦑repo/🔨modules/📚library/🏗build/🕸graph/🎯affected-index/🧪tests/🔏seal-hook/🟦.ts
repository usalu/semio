/** 🔏️ Contract: the generation store tells `afterSeal` once per published generation; the hook stores the index beside the generation, the index answers what the neutral traversal answers over the assembled graph, the second generation reads only the changed fragment, and a hook that throws never fails or delays the seal. */
import {expect,test} from "bun:test";
import {existsSync,mkdtempSync,realpathSync,rmSync,writeFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {affectedBuildProjectsV1} from "../../../../🧭️selection/🟦️.ts";
import {createFileLeasePortV1,createGenerationStoreV1} from "../../../🕰️generations/🟨️.mjs";
import {IMPLEMENTATION,IDENTITY,createCompute,createHolds,createMembership,ringFiles,seed} from "../../../🕰️generations/🧪️tests/🏃️world/🟦️.ts";
import {AFFECTED_INDEX_POLICY_V1 as P,ensureAffectedIndexV1,openAffectedIndexV1} from "../../🟨️.mjs";

const scratch=()=>mkdtempSync(join(realpathSync(tmpdir()),"affected-seal-"));
const neutral=(graph:any,files:string[])=>affectedBuildProjectsV1({...graph,projects:Object.fromEntries(Object.entries(graph.projects).map(([name,project]:any)=>[name,{...project,targets:{}}]))} as never,files);
const make=(dir:string,afterSeal:unknown)=>{
 const root=join(dir,".gen"),store=createGenerationStoreV1({root,lease:createFileLeasePortV1(join(dir,".leases")),holds:createHolds(dir),resources:{facts:"repository-graph-facts:synthetic",builder:"repository-graph-build:synthetic"},afterSeal:afterSeal as never} as never),log:never[]=[];
 return{root,store,refresh:()=>store.refresh({identity:IDENTITY,implementation:IMPLEMENTATION,membership:createMembership(dir),compute:createCompute(dir,log)})};
};

test("the seal stores the index, it equals the neutral answer, the next seal reads one fragment",async()=>{
 const dir=scratch();
 try{
  await seed(dir,ringFiles(6));let sealed=0,read=0;const{createNodeFilePortV1}=await import("../../../🕰️generations/🟨️.mjs");
  const world=make(dir,async(seal:{manifest:never;digest:string;readFragment(row:never):Promise<unknown>;readGlobal(manifest:never):Promise<unknown>})=>{sealed++;await ensureAffectedIndexV1({fs:createNodeFilePortV1(),root:world.root,sealed:{manifest:seal.manifest,digest:seal.digest},declared:{},readFragment:row=>{read++;return seal.readFragment(row) as never;},readGlobal:seal.readGlobal as never,leafFiles:async()=>undefined});});
  const first=await world.refresh();
  expect(sealed).toBe(1);expect(read).toBe(6);expect(existsSync(join(world.root,P.directory,first.current.pointer.manifest+P.extension))).toBe(true);
  const stored=await import("../../🟨️.mjs").then(module=>module.readStoredAffectedIndexV1({fs:createNodeFilePortV1(),root:world.root,digest:first.current.pointer.manifest!,declared:{}}));
  const graph=await world.store.assemble(first.current),open=openAffectedIndexV1(stored!);
  for(const file of["pkg/p0/src/index.ts","pkg/p3/src/x.ts","pkg/p5/project.json","shared/common.json","pkg/none/a.ts"])expect(open.query([file]).projects).toEqual(neutral(graph,[file]));
  writeFileSync(join(dir,"pkg/p2/src/index.ts"),'import "@syn/p3";\nexport const v2=22;\n');read=0;
  const second=await world.refresh();
  expect(second.built).toBe(true);expect(sealed).toBe(2);expect(read).toBe(1);
  const next=await import("../../🟨️.mjs").then(module=>module.readStoredAffectedIndexV1({fs:createNodeFilePortV1(),root:world.root,digest:second.current.pointer.manifest!,declared:{}}));
  expect(openAffectedIndexV1(next!).query(["pkg/p2/src/index.ts"]).projects).toEqual(neutral(await world.store.assemble(second.current),["pkg/p2/src/index.ts"]));
 }finally{rmSync(dir,{recursive:true,force:true});}
},120000);

test("a hook that throws does not fail the seal",async()=>{
 const dir=scratch();
 try{await seed(dir,ringFiles(3));const world=make(dir,async()=>{throw Error("hook");});const result=await world.refresh();expect(result.published).toBe(true);}finally{rmSync(dir,{recursive:true,force:true});}
},60000);
