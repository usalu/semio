"""🔬️ Independent Python oracle of the debug level the profile policy gives each request (standard library only): reads the settings table of the policy schema and prints the debug value of every case as JSON."""
import json, sys

corpus = json.load(open(sys.argv[1], encoding="utf-8"))
settings = json.load(open(sys.argv[2], encoding="utf-8"))["definitions"]["PolicyProtocol"]["const"]["settings"]
print(json.dumps({case["name"]: settings[case["settings"]]["debug"] for case in corpus["cases"]}))
