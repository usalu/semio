import {createHash} from "node:crypto";
import {existsSync,statSync} from "node:fs";
import {readdir} from "node:fs/promises";
import {homedir} from "node:os";
import {join} from "node:path";
import {resolveLanguageV1} from "../../../../../../../../📦️packages/🟦️typescript/⚙️runtime/🗣️language/🟦️.ts";
import {CATALOG_LANGUAGES_V1} from "../../../../../../../../🔨️modules/🏃️process/📦️packages/🟦️typescript/🏗️build/🗣️language/📖️catalog/🟦️.ts";
import {remoteCacheFetchV1} from "../../../🌐️remote-cache/🛰️fleet/🟦️.ts";
import {graphFleetClientV1} from "../../../🪪️graph-state/🛰️exchange/🟦️.ts";
import {graphFleetSettingsV1} from "../../../🪪️graph-state/🧶️nx/🟦️.ts";
import {graphPlatformV1} from "../../../🪪️graph-state/🟦️.ts";
import {createGraphReadWatchV1,graphReadEndTextV1,runWantedServerV1,wantedServerPolicyV1,type WantedInferV1,type WantedServerPolicyV1} from "../../../🪪️graph-state/🙋️wanted/🛠️server/🟦️.ts";
import {readRemoteExecutionHostViewV1,remoteExecutionOriginV1} from "../../🌡️load/🟦️.ts";
import {sleep,type RemoteExecutionSidecarContextV1} from "../🧰️shared/🟦️.ts";

/** 🔌️ The environment the graph server and its reads run in: the one of the agent without the explicit remote cache overrides (`SEMIO_REMOTE_CACHE_ENDPOINT`, `_ACCESS`, `_INSTANCE`, `_TOKEN`, `SEMIO_FLEET_CACHE_ENDPOINT`), so the graph exchange uses the cache and instance the fleet announces, exactly as the workers do (their bootstrap unsets the same variables); an agent that carries the instance `semio` would otherwise look for requests in another instance than the one the workers write them to. */
export function graphExchangeEnvironmentV1(environment:Readonly<Record<string,string|undefined>>):Record<string,string|undefined>{
 const rest={...environment};
 for(const name of["SEMIO_REMOTE_CACHE_ENDPOINT","SEMIO_REMOTE_CACHE_ACCESS","SEMIO_REMOTE_CACHE_INSTANCE","SEMIO_REMOTE_CACHE_TOKEN","SEMIO_FLEET_CACHE_ENDPOINT"])delete rest[name];
 return rest;
}

/** 🧰️ The `repo` executable a graph read is started with: the one named by `SEMIO_REPO_BIN`, else the installed one in the user's `.local/bin`, else the one on the path. */
export function graphServerCommandV1(environment:Readonly<Record<string,string|undefined>>):string{
 const named=environment.SEMIO_REPO_BIN;if(named!==undefined&&named!=="")return named;
 const installed=join(homedir(),".local","bin",process.platform==="win32"?"repo.exe":"repo");
 return existsSync(installed)?installed:"repo";
}

/** 🪶️ The headroom a machine offers the graph server: its available memory, or none at all when its physical memory is below `serveTotalMegabytes`. */
export function graphServerHeadroomV1<Pressure>(host:Readonly<{totalMegabytes:number;availableMegabytes:number;pressure:Pressure}>,serveTotalMegabytes:number):{freeMegabytes:number;pressure:Pressure}{
 return{freeMegabytes:host.totalMegabytes<serveTotalMegabytes?0:Math.max(0,Math.round(host.availableMegabytes)),pressure:host.pressure};
}

/** 🔭️ One graph read of the server: `repo show projects` as a background refresh (it gives way between waves, `SEMIO_GRAPH_BACKGROUND=1`, and neither asks the fleet nor waits for it), watched by its progress and not by a fixed budget: it runs for as long as it publishes waves, and is stopped with SIGINT (SIGKILL ten seconds later) only after `inferStallMilliseconds` without one or after `inferMaximumMilliseconds`; what is published stays, so the next read starts from it. The stderr is read as it arrives, the last line of a failed read and the generation of the newest wave are the answer. */
export async function inferGraphReadV1(input:Readonly<{command:string;cwd:string;environment:Readonly<Record<string,string|undefined>>;reason:"request"|"refresh";signal:AbortSignal|undefined;language:"en"|"de";steerDirectory?:string;policy?:WantedServerPolicyV1;now?:()=>number}>):Promise<WantedInferV1>{
 const policy=input.policy??wantedServerPolicyV1,now=input.now??Date.now,started=now(),watch=createGraphReadWatchV1(policy,now);
 const child=Bun.spawn([input.command,"show","projects"],{cwd:input.cwd,stdin:"ignore",stdout:"ignore",stderr:"pipe",env:{...input.environment,SEMIO_GRAPH_FLEET_READ:"off",SEMIO_GRAPH_BACKGROUND:"1",...input.steerDirectory===undefined?{}:{SEMIO_GRAPH_STEER_DIRECTORY:input.steerDirectory}} as Record<string,string>});
 const stop=()=>{try{child.kill("SIGINT");}catch{}setTimeout(()=>{try{child.kill("SIGKILL");}catch{}},10_000).unref();};
 let ended:"stalled"|"too-long"|undefined,tail="";
 const timer=setInterval(()=>{const verdict=watch.verdict();if(verdict!=="go"&&ended===undefined){ended=verdict;stop();}},policy.watchMilliseconds);
 input.signal?.addEventListener("abort",stop,{once:true});
 try{
  const decoder=new TextDecoder(),pump=(async()=>{for await(const chunk of child.stderr){const text=decoder.decode(chunk,{stream:true});watch.feed(text);tail=(tail+text).slice(-4096);}})();
  const[,status]=await Promise.all([pump,child.exited]);
  return{ok:status===0&&ended===undefined,status,seconds:(now()-started)/1000,generation:watch.generation(),detail:ended!==undefined?graphReadEndTextV1(ended,input.language,policy):status===0?input.reason:tail.trim().split("\n").at(-1)?.slice(0,200)??""};
 }finally{clearInterval(timer);input.signal?.removeEventListener("abort",stop);}
}


/** 🕸️ The graph server of a machine: runs {@link runWantedServerV1} in its own supervised process (a graph read holds gigabytes and must never take the build agent down). A machine whose physical memory is below `serveTotalMegabytes` reports no headroom, so it neither serves requests nor refreshes: a full graph read does not fit beside its own work. Its reads are ordinary `repo show projects` commands, so inference runs under the fleet claims and the host capacity gate, and records and the generation reach the fleet cache through the paths every read already uses. A machine without a fleet cache waits and looks again. */
export async function runGraph(context:RemoteExecutionSidecarContextV1):Promise<void>{
 const environment=graphExchangeEnvironmentV1({...context.environment,SEMIO_WORKSPACE_ROOT:context.root}),language=resolveLanguageV1(CATALOG_LANGUAGES_V1,[],environment).language as "en"|"de",origin=remoteExecutionOriginV1(context.root,environment),policy=wantedServerPolicyV1;
 let settings=graphFleetSettingsV1(context.root,environment);
 while(settings===undefined&&!context.signal.aborted){context.write("graph-server: no fleet cache yet");await sleep(60_000,context.signal);settings=graphFleetSettingsV1(context.root,environment);}
 if(settings===undefined)return;
 const client=graphFleetClientV1(settings,{fetch:remoteCacheFetchV1(environment,{root:context.root})}),store=environment.SEMIO_FLEET_STORE_ROOT,steerDirectory=join(context.root,".cache","f","graph-server");
 const infer=async(reason:"request"|"refresh",signal:AbortSignal|undefined):Promise<WantedInferV1>=>{
  return inferGraphReadV1({command:graphServerCommandV1(environment),cwd:context.root,environment,reason,signal,language,steerDirectory});
 };
 await runWantedServerV1({client,owner:origin,platform:graphPlatformV1(),language,steerDirectory,signal:context.signal,say:context.write,sleep,infer,
  requesters:async()=>store===undefined?[]:(await readdir(join(store,"v1","origins"))).filter(name=>name!==origin),
  async headroom(){return graphServerHeadroomV1((await readRemoteExecutionHostViewV1(environment)).host,policy.serveTotalMegabytes);},
  async mayServe(){return(await readRemoteExecutionHostViewV1(environment)).host.totalMegabytes>=policy.serveTotalMegabytes;},
  async mayRefresh(){const key=createHash("sha256").update(JSON.stringify(["graph-refresh",graphPlatformV1()])).digest("hex");return(await client.claim(key,origin,policy.refreshIntervalMilliseconds).catch(()=>({state:"fault"}))).state==="granted";},
  async quietMilliseconds(){try{return Math.max(0,Date.now()-statSync(join(context.root,".cache","f","state.wal")).mtimeMs);}catch{return 0;}}});
}

/** 🛡️ Runs the graph server beside another role of the same process (the build agent, which every machine runs): a failure or a missing fleet cache only schedules another start after `pauseMilliseconds`, it never reaches the role it runs beside, and `SEMIO_GRAPH_SERVER=off` keeps the machine from serving. */
export async function superviseGraphServerV1(context:RemoteExecutionSidecarContextV1,run:(context:RemoteExecutionSidecarContextV1)=>Promise<void>=runGraph,pauseMilliseconds=30_000):Promise<void>{
 if(context.environment.SEMIO_GRAPH_SERVER==="off")return;
 while(!context.signal.aborted){
  try{await run(context);}catch(error){context.write(`graph-server stopped: ${(error as Error).message}`);}
  await sleep(pauseMilliseconds,context.signal);
 }
}
