/** 🔍️ Law: a verify hook that fails says why. Its reason travels to the report and to the refusal of the setup in both languages (before: the hook error was dropped and a provisioned tool reported only `-`), and every tool is named before it is verified so a silent probe is never anonymous. */
import {expect,test} from "bun:test";
import {readFileSync} from "node:fs";
import {join} from "node:path";
import {setupToolsV1,toolRowV1,toolSetupMessageV1,verifyToolV1,type ToolContextV1} from "../../🟦️.ts";

const signal=new AbortController().signal,row=toolRowV1("node-native-core");
const machine=(hook:ToolContextV1["hook"],environment:Record<string,string|undefined>={})=>({root:"/x",toolsRoot:"/x/t",platform:"linux",environment:{SEMIO_LANGUAGE:"en",...environment},home:"/h",read:()=>"{\"definitions\":{\"Protocol\":{\"const\":{\"version\":7}}}}",exists:()=>false,list:()=>[],resolvePackage:()=>"",capture:async()=>"",provisioned:()=>undefined,hook}) as unknown as ToolContextV1;
const failing=async()=>({found:null,location:null,reason:"Process exited with status 1: core file missing"});

test("the reason of a failed hook is the message of a missing tool in the report",async()=>{
 expect(await verifyToolV1(row,machine(failing),signal)).toMatchObject({status:"missing",found:null,message:"Process exited with status 1: core file missing"});
 expect(await verifyToolV1(row,machine(async()=>({found:null,location:null})),signal)).not.toHaveProperty("message");
});

test("a provisioned tool that still fails its verification names the reason in the refusal, in English and in German",async()=>{
 await expect(setupToolsV1([row],machine(failing),async()=>undefined,signal,()=>undefined)).rejects.toThrow(/reports -, not the pin 7\. Its verification said: Process exited with status 1: core file missing/u);
 await expect(setupToolsV1([row],machine(failing,{SEMIO_LANGUAGE:"de"}),async()=>undefined,signal,()=>undefined)).rejects.toThrow(/Seine Prüfung meldete: Process exited with status 1: core file missing/u);
});

test("every tool is named before its verification starts",async()=>{
 const lines:string[]=[];
 await setupToolsV1([row],machine(async(_row,pin)=>({found:pin,location:"s"})),async()=>undefined,signal,line=>lines.push(line));
 expect(lines).toEqual(["Verifying node-native-core against its pin.","node-native-core 7 already matches its pin."]);
 const german:string[]=[];
 await setupToolsV1([row],machine(async(_row,pin)=>({found:pin,location:"s"}),{SEMIO_LANGUAGE:"de"}),async()=>undefined,signal,line=>german.push(line));
 expect(german[0]).toBe("Prüfe node-native-core gegen seinen Pin.");
});

test("the system hook keeps the failure of the verify command instead of dropping it",()=>{
 const source=readFileSync(join(import.meta.dir,"../../⌨️command/🟦️.ts"),"utf8");
 expect(source).toContain("return {found: null, location: null, reason: (error as Error).message.slice(0, 600)};");
});

test("the setup says how many tools it starts with before it opens anything, in both languages",()=>{
 const source=readFileSync(join(import.meta.dir,"../../⌨️command/🟦️.ts"),"utf8");
 expect(source).toContain('console.log(toolSetupMessageV1("starting", {count: rows.length}, context.environment));');
 expect(source.indexOf('toolSetupMessageV1("starting"')).toBeLessThan(source.indexOf("const inStore"));
 expect(toolSetupMessageV1("starting",{count:3},{SEMIO_LANGUAGE:"en"})).toBe("Setting up 3 pinned tool(s).");
 expect(toolSetupMessageV1("starting",{count:3},{SEMIO_LANGUAGE:"de"})).toBe("Richte 3 gepinnte(s) Werkzeug(e) ein.");
});
