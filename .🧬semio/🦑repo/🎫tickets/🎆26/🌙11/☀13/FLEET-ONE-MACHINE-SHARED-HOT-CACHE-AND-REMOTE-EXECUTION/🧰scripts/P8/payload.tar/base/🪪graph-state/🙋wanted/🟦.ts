import{createHash}from"node:crypto";
import schema from"./🧬️schema/🔣️.json"with{type:"json"};
import type{GraphStateV1}from"../🟦️.ts";
import{fetchGraphEntryV1,publishGraphEntryV1,type GraphFleetClientV1}from"../🛰️exchange/🟦️.ts";
import{validateJsonSchemaSubset}from"../../../../../../../🔨️modules/🧬️schema/✅️validator/📦️packages/🟦️typescript/🟦️.ts";

/** 📏️ The measured numbers a read decides by: the memory of a base read and of one wave, the wave size, how many waves one machine may run, the bounded wait and the age of a request. See `./🧬️schema/🔣️.json`. */
export const wantedPolicyV1=Object.freeze({...schema.definitions.Policy.const});
export type WantedPolicyV1=typeof wantedPolicyV1;
export type WantedRequestV1=Readonly<{version:1;requester:string;platform:string;graphKey:string;projects:readonly string[];createdMs:number;expiresMs:number}>;
export type WantedPlanV1=Readonly<{mode:"local"|"fleet";waveProjects:number;localProjects:number;takenProjects:number;wantedProjects:number}>;
const ZERO="0".repeat(64),sha=(text:string)=>createHash("sha256").update(text).digest("hex");

/** 🧮️ How many projects one wave may hold in `admittedMegabytes` (at most the declared wave, zero below the useful minimum) and how many projects the machine infers before it asks the fleet: the waves it may run in the time the wait allows. */
export function inferableProjectsV1(admittedMegabytes:number,policy:WantedPolicyV1=wantedPolicyV1):Readonly<{waveProjects:number;projects:number}>{
 const perProject=(policy.waveMegabytes-policy.baseMegabytes)/policy.waveProjects,fit=Number.isFinite(admittedMegabytes)?Math.floor((admittedMegabytes-policy.baseMegabytes)/perProject):0,wave=Math.min(policy.waveProjects,Math.max(0,fit));
 return wave<policy.minimumWaveProjects?{waveProjects:0,projects:0}:{waveProjects:wave,projects:wave*policy.maximumLocalWaves};
}

/** 🧭️ The decision of a read that found `stale` projects of which the fleet already had `taken`: infer the rest here when the admitted memory carries it, else ask the fleet for all the rest and infer here only what still fits afterwards. */
export function planStaleReadV1(input:Readonly<{stale:number;taken:number;admittedMegabytes:number}>,policy:WantedPolicyV1=wantedPolicyV1):WantedPlanV1{
 const rest=Math.max(0,input.stale-input.taken),fit=inferableProjectsV1(input.admittedMegabytes,policy);
 return rest<=fit.projects?{mode:"local",waveProjects:fit.waveProjects,localProjects:rest,takenProjects:input.taken,wantedProjects:0}:{mode:"fleet",waveProjects:fit.waveProjects,localProjects:fit.projects,takenProjects:input.taken,wantedProjects:Math.min(rest,policy.maximumProjects)};
}

/** 🔑️ The exchange state a machine's request lives under: one slot per requester and platform, so a newer request replaces the older one and a reader finds it by the requester alone. */
export function wantedStateV1(requester:string,platform:string):GraphStateV1{
 return Object.freeze({version:1,frame:Object.freeze({kind:"project-inference" as const,tooling:sha("project-wanted"),implementation:sha(requester),platform,extra:Object.freeze({wanted:"1"})}),names:ZERO,content:ZERO,files:0,contentFiles:0,digest:sha(JSON.stringify(["project-wanted",requester,platform]))}) as GraphStateV1;
}

/** 🙋️ Publishes the request: the projects of the graph state `graphKey` this machine cannot infer. False when the fleet cannot take it (the caller waits for nothing then). */
export async function publishWantedV1(input:Readonly<{client:GraphFleetClientV1;requester:string;platform:string;graphKey:string;projects:readonly string[];now?:()=>number;policy?:WantedPolicyV1}>):Promise<boolean>{
 const policy=input.policy??wantedPolicyV1,now=(input.now??Date.now)(),request:WantedRequestV1={version:1,requester:input.requester,platform:input.platform,graphKey:input.graphKey,projects:[...input.projects].sort().slice(0,policy.maximumProjects),createdMs:now,expiresMs:now+policy.ttlMilliseconds};
 return publishGraphEntryV1({client:input.client,state:wantedStateV1(input.requester,input.platform),owner:input.requester,documents:[{name:"wanted",bytes:Buffer.from(JSON.stringify(request))}]});
}

/** 👀️ The live request of one requester, or undefined when there is none, it expired, it is damaged or the fleet cannot answer. */
export async function readWantedV1(input:Readonly<{client:GraphFleetClientV1;requester:string;platform:string;now?:()=>number}>):Promise<WantedRequestV1|undefined>{
 const found=await fetchGraphEntryV1(input.client,wantedStateV1(input.requester,input.platform));
 if(found===undefined||found==="fault")return undefined;
 try{
  const document=found.documents.find(row=>row.name==="wanted");if(document===undefined)return undefined;
  const request=JSON.parse(Buffer.from(document.bytes).toString("utf8")) as WantedRequestV1;
  if(validateJsonSchemaSubset({$ref:"#/definitions/WantedRequest"},request,schema).length)return undefined;
  return request.requester===input.requester&&request.platform===input.platform&&request.expiresMs>(input.now??Date.now)()?request:undefined;
 }catch{return undefined;}
}

export type WantedProgressV1=Readonly<{arrived:number;wanted:number;waitedMilliseconds:number}>;
/** ⏳️ Waits for the records of `projects`, taking each as soon as the fleet has it: `take(name)` answers whether the record is now installed here. The wait is bound by progress, not by a fixed time: it ends when no record arrived for `waitMilliseconds` (the first arrival has the same bound), when the server showed no sign of life (`alive()` answers the time of its newest answer) for `silenceMilliseconds`, or after `waitMaximumMilliseconds` altogether; every round reports progress, and it stops at once on cancellation or when `settled(missing)` says the rest is little enough for the caller. Returns the projects still missing. */
export async function awaitWantedV1(input:Readonly<{projects:readonly string[];take(name:string):Promise<boolean>;alive?():number|undefined;signal?:AbortSignal;progress?(progress:WantedProgressV1):void;settled?(missing:number):boolean;sleep?(milliseconds:number):Promise<void>;now?:()=>number;policy?:WantedPolicyV1}>):Promise<readonly string[]>{
 const policy=input.policy??wantedPolicyV1,now=input.now??Date.now,sleep=input.sleep??(milliseconds=>new Promise<void>(resolve=>setTimeout(resolve,milliseconds))),started=now();
 let missing=[...input.projects],best=0,arrivalAt=started,aliveAt=started,heard:number|undefined;
 for(;;){
  const still:string[]=[];
  for(const name of missing){input.signal?.throwIfAborted();if(!await input.take(name).catch(()=>false))still.push(name);}
  missing=still;
  const arrived=input.projects.length-missing.length,sign=input.alive?.();
  if(arrived>best){best=arrived;arrivalAt=now();aliveAt=arrivalAt;}
  if(sign!==undefined&&sign!==heard){heard=sign;aliveAt=now();}
  input.progress?.({arrived,wanted:input.projects.length,waitedMilliseconds:now()-started});
  const at=now();
  if(!missing.length||input.settled?.(missing.length)===true||at-arrivalAt>=policy.waitMilliseconds||at-aliveAt>=policy.silenceMilliseconds||at-started>=policy.waitMaximumMilliseconds)return missing;
  input.signal?.throwIfAborted();
  await sleep(policy.pollMilliseconds);
 }
}

export type WantedHeadroomV1=Readonly<{freeMegabytes:number;pressure:"normal"|"warn"|"critical"}>;
/** 🔑️ The claim key of one request: requester, graph state and creation time, so a newer request of the same requester is a new piece of work. */
export const wantedClaimKeyV1=(request:WantedRequestV1):string=>createHash("sha256").update(JSON.stringify(["serve",request.requester,request.graphKey,request.createdMs])).digest("hex");

/** 🙋️ The live requests of the other machines that this machine takes over: for each requester of the fleet (never itself), the live request of the same graph state (when `graphKey` is given) whose claim this machine gets and has not got yet (`known` says which it holds). Nobody else serves a request this machine holds, and a request another machine holds is left to it. */
export async function claimWantedV1(input:Readonly<{client:GraphFleetClientV1;owner:string;platform:string;requesters:readonly string[];known(key:string):boolean;graphKey?():Promise<string>;signal?:AbortSignal;now?:()=>number;policy?:WantedPolicyV1}>):Promise<readonly WantedRequestV1[]>{
 const policy=input.policy??wantedPolicyV1,taken:WantedRequestV1[]=[];
 for(const requester of input.requesters){
  input.signal?.throwIfAborted();
  if(requester===input.owner)continue;
  const request=await readWantedV1({client:input.client,requester,platform:input.platform,...(input.now===undefined?{}:{now:input.now})});
  if(request===undefined||(input.graphKey!==undefined&&request.graphKey!==await input.graphKey()))continue;
  const key=wantedClaimKeyV1(request);
  if(input.known(key))continue;
  if((await input.client.claim(key,input.owner,policy.ttlMilliseconds)).state==="granted")taken.push(request);
 }
 return taken;
}

export type WantedServedV1=Readonly<{version:1;requester:string;platform:string;server:string;projects:readonly string[];generation:number|null;atMs:number}>;
/** 🔑️ The exchange state of the answer to one requester: the projects the serving machine finished for it, replaced by every newer answer. */
export function servedStateV1(requester:string,platform:string):GraphStateV1{
 return Object.freeze({version:1,frame:Object.freeze({kind:"project-inference" as const,tooling:sha("project-served"),implementation:sha(requester),platform,extra:Object.freeze({served:"1"})}),names:ZERO,content:ZERO,files:0,contentFiles:0,digest:sha(JSON.stringify(["project-served",requester,platform]))}) as GraphStateV1;
}

/** 📣️ Tells the requester which of its projects are done (their records and the generation are in the fleet cache). False when the fleet cannot take it. */
export async function publishServedV1(input:Readonly<{client:GraphFleetClientV1;server:string;request:WantedRequestV1;projects:readonly string[];generation:number|null;now?:()=>number}>):Promise<boolean>{
 const served:WantedServedV1={version:1,requester:input.request.requester,platform:input.request.platform,server:input.server,projects:[...input.projects].sort(),generation:input.generation,atMs:(input.now??Date.now)()};
 return publishGraphEntryV1({client:input.client,state:servedStateV1(input.request.requester,input.request.platform),owner:input.server,documents:[{name:"served",bytes:Buffer.from(JSON.stringify(served))}]});
}

/** 👂️ The newest answer to this requester, or undefined when there is none, it is damaged or the fleet cannot answer. */
export async function readServedV1(input:Readonly<{client:GraphFleetClientV1;requester:string;platform:string}>):Promise<WantedServedV1|undefined>{
 const found=await fetchGraphEntryV1(input.client,servedStateV1(input.requester,input.platform));
 if(found===undefined||found==="fault")return undefined;
 try{
  const document=found.documents.find(row=>row.name==="served");if(document===undefined)return undefined;
  const served=JSON.parse(Buffer.from(document.bytes).toString("utf8")) as WantedServedV1;
  if(validateJsonSchemaSubset({$ref:"#/definitions/Served"},served,schema).length)return undefined;
  return served.requester===input.requester&&served.platform===input.platform?served:undefined;
 }catch{return undefined;}
}

/** 🗣️ One message of the texts table in one language. */
export function wantedTextV1(key:keyof typeof schema.definitions.Texts.const.en,language:"en"|"de",fields:Readonly<Record<string,string|number>>={}):string{
 return schema.definitions.Texts.const[language][key].replace(/\{(\w+)\}/gu,(_all,name:string)=>String(fields[name]??""));
}
