import type {GenerationManifestV1,GenerationFragmentV1,GenerationFilePortV1} from "../🕰️generations/🟨️.mjs";
/** 📏️ The declared limits and names of the affected index. */
export interface AffectedIndexPolicyV1{readonly version:1;readonly directory:string;readonly extension:string;readonly workspacePrefix:string;readonly rootProject:string;readonly rootFile:string;readonly manifestNames:readonly string[];readonly maximumOwners:number;readonly maximumPatterns:number;readonly maximumLeaves:number;readonly maximumDocumentBytes:number;readonly maximumProjects:number;readonly retainIndexes:number;readonly graceMilliseconds:number;readonly readConcurrency:number}
export const AFFECTED_INDEX_POLICY_V1:AffectedIndexPolicyV1;
export type AffectedMessageKeyV1="answered"|"derived"|"noGeneration"|"unknownOwner"|"tooLarge"|"leafMissing"|"tooMany"|"failed";
export const AFFECTED_MESSAGES_V1:Readonly<Record<"en"|"de",Readonly<Record<AffectedMessageKeyV1,string>>>>;
export function renderAffectedMessageV1(key:AffectedMessageKeyV1,fields:Readonly<Record<string,string|number>>,language:"en"|"de"):string;
/** 🧮️ The workspace files and globs of the target inputs of one project node and the closure leaves they name. */
export function affectedInputsOfNodeV1(node:unknown,declared?:Readonly<Record<string,readonly unknown[]>>):{patterns:string[];leaves:string[]};
export interface AffectedOwnerRowV1{readonly n:string;readonly r:string;readonly f:string;readonly c?:string;readonly p:readonly number[];readonly l:readonly string[];readonly d:readonly string[];readonly x?:readonly (readonly [string,string])[]}
export interface AffectedIndexV1{readonly version:1;readonly manifest:string;readonly generation:number;readonly global:string;readonly namedInputs:string;readonly patterns:readonly string[];readonly owners:readonly AffectedOwnerRowV1[];readonly leaves:Readonly<Record<string,readonly number[]>>;readonly edges:readonly (readonly [string,string])[];readonly configs?:readonly string[]}
/** 🔢️ Admits one closed index document. */
export function readAffectedIndexV1(value:unknown):AffectedIndexV1;
export function decodeAffectedIndexV1(index:AffectedIndexV1):{rows:Map<string,{n:string;r:string;f:string;c?:string;patterns:string[];l:readonly string[];d:readonly string[];x?:readonly (readonly [string,string])[]}>;leaves:Map<string,string[]>;edges:readonly (readonly [string,string])[]};
export interface AffectedDerivationV1{manifest:Pick<GenerationManifestV1,"owners"|"generation"|"global">;digest:string;previous?:AffectedIndexV1;declared?:Readonly<Record<string,readonly unknown[]>>;readFragment(row:GenerationManifestV1["owners"][string]):Promise<Pick<GenerationFragmentV1,"node"|"edges">|undefined>;readGlobal(manifest:never):Promise<{readonly edges?:readonly {source:string;target:string}[]}>;leafFiles(key:string):Promise<readonly string[]|undefined>;signal?:AbortSignal;concurrency?:number}
/** 🏗️ Derives the reverse index of one sealed generation from its manifest, the changed fragments and the unknown leaves. */
export function deriveAffectedIndexV1(input:AffectedDerivationV1):Promise<{index:AffectedIndexV1;stats:{read:number;owners:number}}>;
export interface AffectedQueryV1{readonly owners:number;readonly generation:number;readonly manifest:string;query(files:readonly string[]):{projects:string[];unknown:string[]}}
/** 🔎️ Opens an index for questions. */
export function openAffectedIndexV1(index:AffectedIndexV1,options?:{glob?:(pattern:string)=>(file:string)=>boolean}):AffectedQueryV1;
/** 📖️ Reads the stored index of one sealed generation. */
export function readStoredAffectedIndexV1(input:{fs:Pick<GenerationFilePortV1,"read">;root:string;digest:string;declared?:Readonly<Record<string,readonly unknown[]>>}):Promise<AffectedIndexV1|undefined>;
/** 💾️ Gives the index of a sealed generation: the stored one or a derived and stored one. */
export function ensureAffectedIndexV1(input:Omit<AffectedDerivationV1,"manifest"|"digest"|"previous">&{fs:GenerationFilePortV1;root:string;sealed:{manifest:AffectedDerivationV1["manifest"];digest:string};now?:()=>number}):Promise<{index:AffectedIndexV1;derived:boolean;stats?:{read:number;owners:number;bytes:number;milliseconds:number}}>;
