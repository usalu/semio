/** 📏️ Contract: on a synthetic workspace of 4785 owners the stored index stays far below its document bound, opens and answers in milliseconds, and a second derivation after one changed fragment reads exactly that fragment. */
import {expect,test} from "bun:test";
import {brotliDecompressSync} from "node:zlib";
import {canonicalJsonV1,packGenerationDocumentV1} from "../../../🕰️generations/🟨️.mjs";
import {AFFECTED_INDEX_POLICY_V1 as P,deriveAffectedIndexV1,openAffectedIndexV1} from "../../🟨️.mjs";
import {leafKey,random,sha} from "../🧰️synthetic/🟦️.ts";

function big(owners:number,filesPerLeaf:number,patterns:number,edges:number){
 const next=random(42),universe=Array.from({length:owners*40},(_,at)=>`pkg/g${at%97}/p${Math.floor(at/40)}/src/f${at}.ts`),fragments=new Map<string,unknown>(),rows:Record<string,unknown>={},leaves=new Map<string,string[]>();
 const keys=Array.from({length:Math.floor(owners*1.3)},(_,at)=>{const key=leafKey("SOURCE_CLOSURE","big"+at),start=Math.floor(next()*(universe.length-filesPerLeaf));leaves.set(key,universe.slice(start,start+filesPerLeaf));return key;});
 for(let at=0;at<owners;at++){
  const name="@w/p"+at,inputs:unknown[]=[{env:keys[at]},{env:keys[Math.floor(next()*keys.length)]},"{workspaceRoot}/🔣️policy.json","{workspaceRoot}/nx.json"];
  for(let step=0;step<patterns;step++)inputs.push("{workspaceRoot}/"+universe[Math.floor(next()*universe.length)]);
  const fragment={node:{name,root:"pkg/p"+at,targets:{build:{inputs}}},edges:Array.from({length:edges},()=>({source:name,target:"@w/p"+Math.floor(next()*owners),type:"static"}))},digest=sha(fragment);
  fragments.set(digest,fragment);rows[name]={root:"pkg/p"+at,kind:"project",fragment:digest,bytes:1,edgesEnv:sha("e"),targets:["build"],config:"pkg/p"+at+"/📋️project.json"};
 }
 const manifest={generation:1,global:sha("g"),owners:rows};
 return{manifest,fragments,leaves,universe,ports:{readFragment:async(row:{fragment:string})=>fragments.get(row.fragment) as never,readGlobal:async()=>({edges:[]}),leafFiles:async(key:string)=>leaves.get(key)}};
}

for(const[label,files,patterns,edges]of[["typical",150,12,6],["stress",600,40,12]] as const)test(`${label}: 4785 owners`,async()=>{
 const world=big(4785,files,patterns,edges),started=performance.now(),{index,stats}=await deriveAffectedIndexV1({manifest:world.manifest as never,digest:sha("m"),declared:{},...world.ports} as never),derived=performance.now()-started;
 const bytes=packGenerationDocumentV1(index,P.maximumDocumentBytes),expanded=Buffer.byteLength(canonicalJsonV1(index));
 const openAt=performance.now(),open=openAffectedIndexV1(index),opened=performance.now()-openAt,changed=Array.from({length:30},(_,at)=>world.universe[at*997]!),askAt=performance.now();let hits=0;for(let round=0;round<20;round++)hits+=open.query(changed).projects.length;const asked=(performance.now()-askAt)/20;
 console.log(JSON.stringify({label,owners:index.owners.length,patterns:index.patterns.length,leaves:Object.keys(index.leaves).length,edges:index.owners.reduce((sum,row)=>sum+row.d.length,0),expandedMB:+(expanded/1048576).toFixed(2),packedMB:+(bytes.length/1048576).toFixed(2),limitMB:P.maximumDocumentBytes/1048576,deriveMs:Math.round(derived),openMs:Math.round(opened),queryMs:+asked.toFixed(2),hits:hits/20}));
 expect(stats.read).toBe(4785);expect(bytes.length).toBeLessThan(P.maximumDocumentBytes/4);expect(brotliDecompressSync(bytes).length).toBeLessThan(P.maximumDocumentBytes);
 expect(opened).toBeLessThan(2000);expect(asked).toBeLessThan(100);
 const[name,row]=Object.entries(world.manifest.owners)[7]!,fragment={...(world.fragments.get((row as {fragment:string}).fragment) as object),edges:[]},digest=sha(fragment);world.fragments.set(digest,fragment);
 const next={...world.manifest,generation:2,owners:{...world.manifest.owners,[name]:{...(row as object),fragment:digest}}};let read=0,leaves=0;
 const again=await deriveAffectedIndexV1({manifest:next as never,digest:sha("m2"),previous:index,declared:{},readFragment:async(entry:{fragment:string})=>{read++;return world.ports.readFragment(entry);},readGlobal:world.ports.readGlobal,leafFiles:async(key:string)=>{leaves++;return world.ports.leafFiles(key);}} as never);
 expect(read).toBe(1);expect(leaves).toBe(0);expect(again.index.owners.length).toBe(4785);
},300000);

test("an index over the owner bound is refused with a typed code",async()=>{
 const owners=Object.fromEntries(Array.from({length:P.maximumOwners+1},(_,at)=>["p"+at,{root:"r"+at,kind:"project",fragment:sha("f"),bytes:1,edgesEnv:sha("e"),targets:[]}]));
 await expect(deriveAffectedIndexV1({manifest:{generation:1,global:sha("g"),owners} as never,digest:sha("m"),readFragment:async()=>undefined,readGlobal:async()=>({}),leafFiles:async()=>[]})).rejects.toMatchObject({code:"AFFECTED_TOO_LARGE"});
});
