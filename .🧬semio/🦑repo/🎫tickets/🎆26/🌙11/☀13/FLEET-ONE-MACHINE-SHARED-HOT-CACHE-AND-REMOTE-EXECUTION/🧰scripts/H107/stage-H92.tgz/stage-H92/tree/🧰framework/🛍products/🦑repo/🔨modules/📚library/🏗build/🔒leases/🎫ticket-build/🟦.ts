import {createHash,randomBytes} from "node:crypto";
import {existsSync,mkdirSync,readFileSync,readdirSync,rmSync,statSync,writeFileSync} from "node:fs";
import {isAbsolute,join,relative,resolve,sep} from "node:path";
import {machinePathV1} from "../../../../../../../🔨️modules/🏃️process/🏗️build/🏠️machine-state/🟦️.ts";
import {bindCatalogV1,handleTextV1} from "../../../../../../../🔨️modules/🏃️process/🏗️build/🗣️language/📖️catalog/🟦️.ts";
import {validateJsonSchemaSubset} from "../../../../../../../🔨️modules/🧬️schema/✅️validator/📦️packages/🟦️typescript/🟦️.ts";
import schema from "./🧬️schema/🔣️.json" with {type:"json"};

const P=schema.definitions.Policy.const;

/** 📐️ The closed policy of the ticket build lease: where the leases live, how a ticket is named, which commands are heavy and how long a build may wait.
 * @see ./🧬️schema/🔣️.json */
export const TICKET_BUILD_LEASE_POLICY_V1=P;
/** 🗣️ The bilingual catalog of the lease messages. */
export const TICKET_BUILD_LEASE_TEXTS_V1=bindCatalogV1("ticket-build-lease",schema.definitions.Messages.const);
/** 🎟️ A held lease; `release` is idempotent, `reentrant` tells that a build nested in the holder passed without taking it. */
export type TicketBuildLeaseV1=Readonly<{ticket:string;reentrant:boolean;release():Promise<void>}>;
/** 🔌️ The seams of the lease; tests replace the clock, the liveness check and the sleep. */
export type TicketBuildLeaseOptionsV1=Readonly<{cwd?:string;environment?:NodeJS.ProcessEnv;signal?:AbortSignal;notice?:(line:string)=>void;language?:"en"|"de"|"both";now?:()=>number;alive?:(pid:number)=>boolean;sleep?:(milliseconds:number)=>Promise<void>;policy?:typeof P}>;

type HolderV1={version:1;ticket:string;pid:number;token:string;operation:string;startedAtMs:number};
const strip=(segment:string):string=>segment.replace(/^[^\p{L}\p{N}]+/u,"");
const defaultAlive=(pid:number):boolean=>{try{process.kill(pid,0);return true;}catch(error){return (error as NodeJS.ErrnoException).code==="EPERM";}};
const defaultSleep=(milliseconds:number):Promise<void>=>new Promise(done=>setTimeout(done,milliseconds));

/** 🏷️ The ticket a build works for: the explicit `SEMIO_TICKET` (`YY/MM/DD/SLUG`), else the ticket folder the working directory lies in; a build outside every ticket has none. Emoji prefixes of the dated folders are ignored, so both spellings name one ticket. */
export function ticketOfBuildV1(root:string,cwd:string,environment:NodeJS.ProcessEnv=process.env,rules:typeof P=P):string|undefined{
 const explicit=environment[rules.environment.ticket];
 if(explicit!==undefined&&explicit!==""){const parts=explicit.split("/").map(strip);return parts.length===rules.ticketLevels&&parts.every(Boolean)?parts.join("/"):undefined;}
 const inside=relative(resolve(root,...rules.ticketsDirectory),resolve(cwd));
 if(inside===""||inside===".."||inside.startsWith(".."+sep)||isAbsolute(inside))return undefined;
 const parts=inside.split(sep).slice(0,rules.ticketLevels).map(strip);
 return parts.length===rules.ticketLevels&&parts.every(Boolean)?parts.join("/"):undefined;
}

/** 🏋️ Tells whether a command line is a heavy build (cargo, run-many or a whole-graph affected run); help and dry runs are not. */
export function ticketBuildHeavyV1(args:readonly string[],rules:typeof P=P):boolean{
 const boundary=args.indexOf("--"),head=args.slice(0,boundary<0?undefined:boundary);
 return (rules.heavyCommands as readonly string[]).includes(head[0]??"")&&!head.some(argument=>(rules.lightFlags as readonly string[]).some(flag=>argument===flag||argument.startsWith(flag+"=")));
}

/** 🗂️ The machine-local folder of the lease of one ticket (holder file and arrival queue). */
export function ticketBuildLeaseDirectoryV1(root:string,ticket:string,rules:typeof P=P):string{
 return machinePathV1(root,...rules.directory,createHash("sha256").update(ticket).digest("hex").slice(0,16));
}

/** 🛂️ Validates a holder file against its closed schema; the problems are returned. */
export function validateTicketBuildHolderV1(value:unknown):readonly string[]{
 return validateJsonSchemaSubset({$ref:"#/definitions/Holder"},value,schema as never).map(error=>String(typeof error==="string"?error:(error as {message?:string}).message??JSON.stringify(error)));
}

const readHolder=(path:string):HolderV1|"unreadable"|undefined=>{
 let text:string;
 try{text=readFileSync(path,"utf8");}catch{return undefined;}
 try{const value=JSON.parse(text) as unknown;return validateTicketBuildHolderV1(value).length?"unreadable":value as HolderV1;}catch{return "unreadable";}
};

/** 🎟️ Takes the heavy build lease of a ticket, queueing behind every earlier arrival (FIFO) while another live build of the same ticket holds it: the wait announces itself in English and German at once and every `progressMilliseconds`, ends with a bilingual refusal after `maximumWaitMilliseconds` or when the signal cancels, and takes over a lease whose holder is gone or older than `maximumHoldMilliseconds`. A build that inherits the holder's token (a nested `repo run`) passes without waiting.
 * @see ./🧪️tests/🟦️.ts */
export async function acquireTicketBuildLeaseV1(root:string,ticket:string,operation:string,options:TicketBuildLeaseOptionsV1={}):Promise<TicketBuildLeaseV1>{
 const rules=options.policy??P,environment=options.environment??process.env,now=options.now??Date.now,alive=options.alive??defaultAlive,sleep=options.sleep??defaultSleep,language=options.language??"both",notice=options.notice??(()=>{});
 const say=(key:string,values:Record<string,string|number>):string=>{
  const one=(lang:"en"|"de")=>handleTextV1(TICKET_BUILD_LEASE_TEXTS_V1,key,lang,values);
  return language==="both"?one("en")+" / "+one("de"):one(language);
 };
 const directory=ticketBuildLeaseDirectoryV1(root,ticket,rules),queue=join(directory,"queue"),holderPath=join(directory,"holder.json"),variable=rules.environment.token,inherited=environment[variable];
 mkdirSync(queue,{recursive:true});
 const current=readHolder(holderPath);
 if(inherited!==undefined&&current!==undefined&&current!=="unreadable"&&current.token===inherited&&alive(current.pid))return Object.freeze({ticket,reentrant:true,release:async()=>{}});
 const me=String(now()).padStart(15,"0")+"-"+process.pid+"-"+randomBytes(4).toString("hex"),mine=join(queue,me),began=now(),minutes=Math.round(rules.maximumWaitMilliseconds/60000);
 writeFileSync(mine,JSON.stringify({pid:process.pid}));
 let told=Number.NEGATIVE_INFINITY;
 const token=randomBytes(16).toString("hex");
 try{
  for(;;){
   if(options.signal?.aborted)throw Error(say("queue.cancelled",{ticket}));
   const waiting:string[]=[];
   for(const name of readdirSync(queue).sort()){
    const pid=Number(name.split("-")[1]);
    if(name!==me&&!alive(pid))rmSync(join(queue,name),{force:true});else waiting.push(name);
   }
   if(!waiting.includes(me)){writeFileSync(mine,JSON.stringify({pid:process.pid}));waiting.push(me);waiting.sort();}
   const holder=readHolder(holderPath);
   if(holder==="unreadable"){
    let age=0;try{age=now()-statSync(holderPath).mtimeMs;}catch{}
    if(age>10000)rmSync(holderPath,{force:true});
   }else if(holder!==undefined&&(!alive(holder.pid)||now()-holder.startedAtMs>rules.maximumHoldMilliseconds)){
    notice(say("queue.taken-over",{ticket,holder:holder.pid}));
    rmSync(holderPath,{force:true});continue;
   }else if(holder===undefined&&waiting[0]===me){
    const row:HolderV1={version:1,ticket,pid:process.pid,token,operation,startedAtMs:now()};
    try{writeFileSync(holderPath,JSON.stringify(row),{flag:"wx"});break;}catch(error){if((error as NodeJS.ErrnoException).code!=="EEXIST")throw error;}
   }
   if(now()-began>rules.maximumWaitMilliseconds){
    throw Error(say("queue.timeout",{ticket,holder:holder!==undefined&&holder!=="unreadable"?holder.pid:0,minutes}));
   }
   if(now()-told>=rules.progressMilliseconds){
    told=now();
    notice(say("queue.waiting",{ticket,operation:holder!==undefined&&holder!=="unreadable"?holder.operation:"?",holder:holder!==undefined&&holder!=="unreadable"?holder.pid:0,seconds:holder!==undefined&&holder!=="unreadable"?Math.round((now()-holder.startedAtMs)/1000):0,command:operation,position:waiting.indexOf(me)+1}));
   }
   await sleep(rules.pollMilliseconds);
  }
 }finally{rmSync(mine,{force:true});}
 const waited=Math.round((now()-began)/1000);
 if(told>Number.NEGATIVE_INFINITY)notice(say("queue.acquired",{ticket,seconds:waited}));
 environment[variable]=token;
 let released=false;
 return Object.freeze({ticket,reentrant:false,release:async()=>{
  if(released)return;
  released=true;
  if(inherited===undefined)delete environment[variable];else environment[variable]=inherited;
  const holder=readHolder(holderPath);
  if(holder!==undefined&&holder!=="unreadable"&&holder.token===token)rmSync(holderPath,{force:true});
 }});
}

/** 🚦️ Runs a build body under the lease of its ticket when the command is heavy and the build works for a ticket; every other build runs at once and unlimited. */
export async function withTicketBuildLeaseV1<T>(root:string,args:readonly string[],work:()=>Promise<T>,options:TicketBuildLeaseOptionsV1={}):Promise<T>{
 const rules=options.policy??P,ticket=ticketOfBuildV1(root,options.cwd??process.cwd(),options.environment??process.env,rules);
 if(ticket===undefined||!ticketBuildHeavyV1(args,rules))return work();
 const lease=await acquireTicketBuildLeaseV1(root,ticket,args[0]!,options);
 try{return await work();}finally{await lease.release();}
}

/** 🔎️ Tells whether a ticket holds a heavy build lease right now (a live holder), for status views. */
export function ticketBuildLeaseHeldV1(root:string,ticket:string,alive:(pid:number)=>boolean=defaultAlive,rules:typeof P=P):boolean{
 const holder=readHolder(join(ticketBuildLeaseDirectoryV1(root,ticket,rules),"holder.json"));
 return holder!==undefined&&holder!=="unreadable"&&alive(holder.pid)&&existsSync(ticketBuildLeaseDirectoryV1(root,ticket,rules));
}
