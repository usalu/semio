/** 🏗 Composition root of `repo service host --foreground`: binds the graph loader to the per-host service and ties its lifetime to the process signals. */
import {spawn,spawnSync} from "node:child_process";
import {createHash} from "node:crypto";
import {join} from "node:path";
import {mkdirSync,openSync,readdirSync,rmSync} from "node:fs";
import {homedir} from "node:os";
import {createHostServiceV1} from "../../🏛️service/🌐️host/🟨️.mjs";
import {createGraphPlannerPortV1} from "../../🔌️ports/🧭️plan/🟨️.mjs";
import {HOST_POLICY_V1} from "../../📨️protocol/🎚️policy/🟨️.mjs";
import {hostEndpointsV1} from "../../📨️protocol/📍️endpoint/🏠️host/🟨️.mjs";
import {graphServiceHeapBytesV1,GRAPH_MEMORY_POLICY_V1} from "../../../🧠️memory/🟨️.mjs";
import {settleGraphMemoryV1} from "../../../🧠️memory/🧽️settle/🟨️.mjs";
import {placeServiceOutsideJobsV1,prepareServiceGroupV1,releaseOwnServiceGroupV1,runsInServiceGroupV1,serviceLaunchArgumentsV1,sweepEmptyServiceGroupsV1} from "../../../🧱️job-limits/🐧️cgroup/🟦️.ts";
import {appendServiceExitRowV1} from "../../🧾️exit-log/🟨️.mjs";
import {accessDirectoryV1,consentIdentityV1,launcherDigestV1,probeConsentV1,protectedFolderOfV1,writeAccessReceiptV1} from "../../🔐️consent/🟨️.mjs";
import {ensureLauncherConsentV1,launchdRouteV1,startViaLaunchdV1} from "./🍎️launchd/🟨️.mjs";
import {fileURLToPath} from "node:url";

/** 🪵️ One service log line on stderr, which the detached service redirects to its log file. */
export function writeHostServiceLogV1(event,detail){process.stderr.write(new Date().toISOString()+" "+event+(detail===undefined?"":" "+detail)+"\n");}

const receiptOfV1=({environment,platform,access,state,folder,error})=>{
 const root=access.root??process.cwd(),accessPlatform=access.platform??platform,home=access.home??homedir(),identity=consentIdentityV1({platform:accessPlatform,home,environment});
 const directory=access.directory??accessDirectoryV1(root,{platform:accessPlatform,home,environment});
 try{
  if(state==="unprotected")rmSync(join(directory,"service.json"),{force:true});
  else writeAccessReceiptV1(directory,{version:1,role:"service",pid:process.pid,state,root,folder,identity:identity?.path??"",at:Date.now(),...error?{error}:{},...identity&&launcherDigestV1(identity.path)?{launcherSha256:launcherDigestV1(identity.path)}:{}});
 }catch{}
};

/** 🔐️ Probes the checkout before anything is bound: a service without the macOS file access consent leaves its receipt and a typed exit row (`access-denied`, the state, the folder and the checkout, read by the client that waits for it) and ends with exit status 4 instead of staying alive in a denied state; with the consent it leaves the receipt that says so and goes on (`undefined`), where none is needed it removes an old receipt and goes on. `access` = `{root,platform,home,directory,probe,timeoutMilliseconds}` replaces the working directory, the system, the receipt folder and the probe in tests. */
async function gateConsentV1({runtime,environment,platform,log,access}){
 const root=access.root??process.cwd(),accessPlatform=access.platform??platform,home=access.home??homedir();
 const found=await(access.probe??(path=>probeConsentV1(path,{platform:accessPlatform,home,timeoutMilliseconds:access.timeoutMilliseconds})))(root);
 receiptOfV1({environment,platform,access,state:found.state,folder:found.folder,error:found.error});
 if(found.state!=="denied"&&found.state!=="waiting")return undefined;
 log("access-denied",found.state+" "+found.folder+" "+root);
 try{mkdirSync(runtime.directory,{recursive:true,mode:0o700});}catch{}
 appendServiceExitRowV1(runtime.directory,{event:"exit",at:Date.now(),pid:process.pid,reason:"access-denied",code:4,tag:runtime.tag,state:found.state,folder:found.folder,root});
 return 4;
}

/** ▶ Runs the host service until it closes; resolves the exit code (75 when the memory bound forced a restart, else 0). `loadGraph({root,signal})` returns the neutral build graph of one workspace. */
export async function runHostForegroundV1({implementation,loadGraph,loadSlice,identify,stale,capture,taskState,environment=process.env,platform=process.platform,policy,signal,log=()=>{},admission,workerMemory=()=>[],workerBusy=()=>0,cache,access={}}){
 const runtime=hostEndpointsV1(implementation,environment,platform);
 const gate=await gateConsentV1({runtime,environment,platform,log,access});
 if(gate!==undefined)return gate;
 const service=createHostServiceV1({runtime:{...runtime},implementation,policy,log,ports:{planner:createGraphPlannerPortV1({loadGraph,loadSlice,identify,stale,capture,taskState}),...(admission?{admission}:{}),settle:()=>settleGraphMemoryV1(),workers:{memory:workerMemory,active:workerBusy},cache:cache??{tick:async signal=>{const[{casEnforceTickV1},{casRootV1}]=await Promise.all([import("../../../🗄️cas/🚦️guard/🟦️.ts"),import("../../../🗄️cas/🗃️store/🟦️.ts")]);await casEnforceTickV1({root:casRootV1(environment,platform),signal});}}}});
 let stopping,recorded=false;
 const record=row=>{if(recorded)return;recorded=true;const usage=process.memoryUsage();appendServiceExitRowV1(runtime.directory,{event:"exit",at:Date.now(),pid:process.pid,rssMegabytes:Math.round(usage.rss/1048576),heapMegabytes:Math.round(usage.heapUsed/1048576),workers:workerMemory(),workersBusy:workerBusy(),...row});releaseOwnServiceGroupV1();};
 const crash=error=>{record({reason:"crash",error:error?.stack??String(error)});};
 process.once("uncaughtException",error=>{crash(error);process.exit(1);});process.once("unhandledRejection",crash);
 process.once("exit",code=>record({reason:"exit",code}));
 const stop=reason=>{record({reason:"stop:"+reason});stopping??=service.stop(reason);void stopping.catch(()=>{});};
 const terminate=()=>stop("SIGTERM"),interrupt=()=>stop("SIGINT"),abort=()=>stop("cancelled");
 process.once("SIGTERM",terminate);process.once("SIGINT",interrupt);signal?.addEventListener("abort",abort,{once:true});
 try{
  try{await service.start();}catch(error){if(error?.code==="running"){record({reason:"adopted",code:0});return 0;}throw error;}
  const reason=await service.closed,code=reason==="memory"?75:reason==="access-denied"?4:0;
  record({reason:String(reason),code});
  if(reason==="access-denied")receiptOfV1({environment,platform,access,state:"denied",folder:protectedFolderOfV1(access.root??process.cwd(),{platform:access.platform??platform,home:access.home??homedir()})??""});
  return code;
 }finally{
  signal?.removeEventListener("abort",abort);process.off("SIGTERM",terminate);process.off("SIGINT",interrupt);
  await (stopping??service.stop("settled"));
 }
}

/** 🧷️ What belongs to the client that happened to start the service and must not follow it: its capacity grant (released when the client ends) and the plan child of its own run. */
const CLIENT_BOUND_ENVIRONMENT_V1=Object.freeze(["SEMIO_HOST_CAPACITY_GRANT","SEMIO_HOST_CAPACITY_PLAN","SEMIO_HOST_CAPACITY_PHASE_MARKS","SEMIO_BUILD_GRAPH_PLAN_OUT","SEMIO_BUILD_GRAPH_YIELD_TICKET","SEMIO_BUILD_REUSE_GRAPH","SEMIO_BUILD_GRAPH_PATH","SEMIO_BUILD_GRAPH_DIGEST"]);

/** 🙋️ Whether the calling process itself can list the checkout (a real read under the identity of the caller: the app that runs `repo` may hold the consent that the launcher does not hold yet). */
function callerCanReadV1(root){
 try{readdirSync(root);return true;}catch(error){return!(error?.code==="EPERM"||error?.code==="EACCES");}
}

/** 🚀 Starts the service detached from this process (on macOS, for a checkout below Documents, Desktop or Downloads, in this order: (a) as a launchd job whose program is the launcher `repo` when the launcher holds the consent; (b) when the launcher has no consent yet but the caller can read the checkout itself, directly, under the access of the caller, with one bilingual line that says what to click to make the service independent (the consent probe keeps waiting for that click, and a later service starts as (a)); (c) when neither can read, the client ends with exit 4 and the consent text; any failure of the launchd route spawns the service directly): `command` is the argument vector that runs the foreground host (`repo service host --foreground`); output goes to the service log. */
export function spawnHostServiceV1({command,environment=process.env,cwd=process.cwd(),launchd={}}){
 return({runtime})=>{
  mkdirSync(runtime.directory,{recursive:true,mode:0o700});
  const env={...environment,BUN_JSC_forceRAMSize:String(graphServiceHeapBytesV1()),[HOST_POLICY_V1.memoryPurge.environmentVariable]:String(HOST_POLICY_V1.memoryPurge.delayMilliseconds)};
  for(const name of CLIENT_BOUND_ENVIRONMENT_V1)delete env[name];
  const linux=process.platform==="linux",name="graph-"+createHash("sha256").update(runtime.directory).digest("hex").slice(0,12),service={name,limitMegabytes:GRAPH_MEMORY_POLICY_V1.serviceLimitMegabytes,softRatioBasisPoints:9000};
  if(linux)sweepEmptyServiceGroupsV1("graph-",undefined);
  const group=linux?prepareServiceGroupV1(service):undefined,argv=group?serviceLaunchArgumentsV1(join(group,"cgroup.procs"),command):command;
  const route=launchdRouteV1({command,environment,cwd,runtimeDirectory:runtime.directory,tag:runtime.tag,...launchd.route});
  if(route){
   const run=launchd.run??((program,args)=>{const result=spawnSync(program,args,{encoding:"utf8",timeout:10000});return{status:result.status??1,stdout:result.stdout??""};});
   const consent=(launchd.ensure??ensureLauncherConsentV1)({root:cwd,probeScript:fileURLToPath(new URL("../../🔐️consent/🔎️probe/🟨️.mjs",import.meta.url)),run,environment,...launchd.consent});
   if(consent.state==="waiting"){
    if((launchd.callerCanRead??callerCanReadV1)(cwd)){
     process.stderr.write("The graph service runs under the access of the calling app because repo has no consent for "+(protectedFolderOfV1(cwd)??"this folder")+" yet; click Allow on the dialog \"repo would like to access files in your "+(protectedFolderOfV1(cwd)??"")+" folder\" to make it independent / Der Graphdienst läuft mit dem Zugriff der aufrufenden App, weil repo noch keine Erlaubnis für "+(protectedFolderOfV1(cwd)??"diesen Ordner")+" hat; klicke bei der Abfrage „repo möchte auf Dateien in deinem Ordner "+(protectedFolderOfV1(cwd)??"")+" zugreifen“ auf „Erlauben“, damit er unabhängig wird\n");
    }else{
     appendServiceExitRowV1(runtime.directory,{event:"exit",at:Date.now(),pid:process.pid,reason:"access-denied",code:4,tag:runtime.tag,state:"waiting",folder:protectedFolderOfV1(cwd)??"",root:cwd,...consent.changed?{changed:true}:{}});
     return;
    }
   }
   const outcome=consent.state==="waiting"?{started:false,reason:"the launcher has no consent yet"}:consent.state==="failed"?{started:false,reason:"the consent probe failed: "+consent.reason}:startViaLaunchdV1(route,{environment:env,log:runtime.log,run,...launchd.options});
   if(outcome.started){appendServiceExitRowV1(runtime.directory,{event:"start",at:Date.now(),via:"launchd",label:route.label,placed:false});return;}
   if(consent.state!=="waiting")process.stderr.write("launchd did not run the graph service ("+outcome.reason+"); starting it directly / launchd hat den Graphdienst nicht gestartet ("+outcome.reason+"); er wird direkt gestartet\n");
  }
  const log=openSync(runtime.log,"a",0o600),child=spawn(argv[0],argv.slice(1),{cwd,env,stdio:["ignore",log,log],detached:true,windowsHide:true});
  child.unref();
  if(child.pid===undefined)return;
  let placed=group!==undefined&&runsInServiceGroupV1(child.pid,group);
  for(let wait=0;group!==undefined&&!placed&&wait<20;wait++){Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,10);placed=runsInServiceGroupV1(child.pid,group);}
  if(group!==undefined&&!placed)placed=placeServiceOutsideJobsV1(child.pid,service);
  appendServiceExitRowV1(runtime.directory,{event:"start",at:Date.now(),pid:child.pid,...placed&&group?{cgroup:group,limitMegabytes:service.limitMegabytes}:{placed:false}});
 };
}
