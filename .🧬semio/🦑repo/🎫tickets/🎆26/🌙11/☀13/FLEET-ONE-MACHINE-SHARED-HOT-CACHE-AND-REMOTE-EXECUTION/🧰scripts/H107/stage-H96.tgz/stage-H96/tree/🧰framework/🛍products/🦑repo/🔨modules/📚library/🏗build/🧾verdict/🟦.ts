import schema from "./🧬️schema/🔣️.json" with {type:"json"};

export type VerdictLanguageV1="en"|"de";
export type VerdictCommandV1="test-file"|"run"|"cargo"|"typecheck";
export type VerdictStatusV1="passed"|"failed"|"cancelled"|"refused";
export type VerdictRowStatusV1="passed"|"failed"|"skipped"|"not-run";
export type VerdictFailureV1=Readonly<{file?:string;line?:number;column?:number;message:string}>;
export type VerdictFileV1=Readonly<{file:string;status:VerdictRowStatusV1;seconds?:number;pass?:number;fail?:number;first?:VerdictFailureV1;class?:string;ranOn?:string;reused?:boolean}>;
export type VerdictV1=Readonly<{version:1;command:VerdictCommandV1;status:VerdictStatusV1;seconds:number;counts:Readonly<{passed:number;failed:number;skipped:number;notRun:number}>;tests?:Readonly<{passed:number;failed:number}>;diagnostics?:number;failureClass?:string;files:readonly VerdictFileV1[];omitted?:Readonly<{files:number}>;origin:Readonly<{local:number;offloaded:number;hosts:readonly string[]}>;cache:Readonly<{hits:number;misses:number;reused:number}>;log:Readonly<{reference:string;bytes:number}>}>;
export type VerdictRowInputV1=Readonly<{file:string;status:VerdictRowStatusV1;seconds?:number;pass?:number;fail?:number;tail?:string;error?:string;first?:VerdictFailureV1;ranOn?:string;reused?:boolean}>;
export type VerdictClassifierV1=(lines:readonly string[])=>Readonly<{class:string}>|undefined;
export type VerdictInputV1=Readonly<{command:VerdictCommandV1;status?:VerdictStatusV1;seconds:number;rows:readonly VerdictRowInputV1[];diagnostics?:number;log?:Readonly<{reference:string;bytes:number}>;cache?:Readonly<{hits:number;misses:number}>;root?:string;localHost?:string;classify?:VerdictClassifierV1;failureClass?:string}>;

/** 🧾️ The declared limits (4 KB, 24 file rows, message and path lengths); the schema file is the single source.
 * @see ./🧬️schema/🔣️.json */
export const VERDICT_LIMITS_V1=Object.freeze({...schema.definitions.Limits.const});
const texts=schema.definitions.Texts.const as Readonly<Record<string,Readonly<Record<VerdictLanguageV1,string>>>>;
const ansi=/\u001b\[[0-9;?]*[A-Za-z]/gu,bunError=/^\s*error: (.*)$/u,frame=/^\s*at (?:.*? \()?(.+?):(\d+):(\d+)\)?\s*$/u;
const tscParenthesis=/^(.+?)\((\d+),(\d+)\): error (TS\d+): (.*)$/u,tscColon=/^(.+?):(\d+):(\d+) - error (TS\d+): (.*)$/u;
const rustError=/^error(?:\[(E\d+)\])?: (.*)$/u,rustArrow=/^\s*--> (.+?):(\d+):(\d+)\s*$/u,rustPanic=/panicked at (.+?):(\d+):(\d+):?\s*$/u,rustOldPanic=/panicked at '(.*)', (.+?):(\d+):(\d+)\s*$/u;
const rustNoise=/^error: (aborting due to|could not compile|process didn't exit|test failed|\d+ previous error)/u;

const cut=(value:string,characters:number)=>{const flat=value.replace(/\s+/gu," ").trim();return flat.length<=characters?flat:flat.slice(0,Math.max(0,characters-1))+"…";};
const tailCut=(value:string,characters:number)=>value.length<=characters?value:"…"+value.slice(value.length-characters+1);
const withoutFile=(failure:VerdictFailureV1):VerdictFailureV1=>({...failure.line===undefined?{}:{line:failure.line},...failure.column===undefined?{}:{column:failure.column},message:failure.message});
const bytesOf=(value:unknown)=>Buffer.byteLength(JSON.stringify(value),"utf8");

/** 🛤️ Repo relative, slash separated path: backslashes and `file://` are normalised, a path below `root` is made relative, an over long path keeps its tail. */
export function verdictPathV1(path:string,root?:string):string{
 let value=path.replace(/^file:\/\//u,"").replace(/\\/gu,"/");
 const base=root?.replace(/\\/gu,"/").replace(/\/+$/u,"");
 if(base!==undefined&&base.length>0&&value.startsWith(base+"/"))value=value.slice(base.length+1);
 return tailCut(value,VERDICT_LIMITS_V1.pathCharacters);
}

/** 🔬️ The lines of a captured output without terminal colour codes. */
export function verdictLinesV1(text:string):string[]{return text.replace(ansi,"").split(/\r?\n/u);}

/** 🎯️ The first failure of an output: a TypeScript diagnostic (`file(l,c): error TS…` or `file:l:c - error TS…`), a rustc error with its `-->` location or a panic location, or a bun test error with its first stack frame (the frame inside `file` is preferred, `node_modules` frames never win); else the first line that reads like an error, without a location. */
export function firstFailureOfLinesV1(lines:readonly string[],context:Readonly<{file?:string;root?:string}>={}):VerdictFailureV1|undefined{
 const where=(path:string,line:string,column:string)=>({file:verdictPathV1(path,context.root),line:Number(line),column:Number(column)});
 const message=(value:string)=>cut(value,VERDICT_LIMITS_V1.messageCharacters);
 for(const line of lines){
  const match=tscParenthesis.exec(line)??tscColon.exec(line);
  if(match)return{...where(match[1]!,match[2]!,match[3]!),message:message(`${match[4]}: ${match[5]}`)};
 }
 for(let at=0;at<lines.length;at++){
  const error=rustError.exec(lines[at]!);
  if(error&&!rustNoise.test(lines[at]!)){
   for(let ahead=at+1;ahead<=Math.min(lines.length-1,at+4);ahead++){
    const arrow=rustArrow.exec(lines[ahead]!);
    if(arrow)return{...where(arrow[1]!,arrow[2]!,arrow[3]!),message:message(`${error[1]?error[1]+": ":""}${error[2]}`)};
   }
  }
  const old=rustOldPanic.exec(lines[at]!);
  if(old)return{...where(old[2]!,old[3]!,old[4]!),message:message(old[1]!)};
  const panic=rustPanic.exec(lines[at]!);
  if(panic)return{...where(panic[1]!,panic[2]!,panic[3]!),message:message(lines[at+1]??"panicked")};
 }
 const own=context.file===undefined?undefined:verdictPathV1(context.file,context.root);
 for(let at=0;at<lines.length;at++){
  const error=bunError.exec(lines[at]!);
  if(!error)continue;
  const extra=lines.slice(at+1,at+5).filter(line=>/^\s*(Expected|Received)\b/u.test(line)).map(line=>line.trim());
  const frames=[];
  for(let ahead=at+1;ahead<lines.length;ahead++){
   if(bunError.test(lines[ahead]!)||/^\s*\((?:fail|pass)\)/u.test(lines[ahead]!))break;
   const found=frame.exec(lines[ahead]!);
   if(found&&!found[1]!.includes("node_modules")&&!found[1]!.startsWith("bun:"))frames.push(found);
  }
  const chosen=(own===undefined?undefined:frames.find(found=>verdictPathV1(found[1]!,context.root).endsWith(own)))??frames[0];
  return{...chosen?where(chosen[1]!,chosen[2]!,chosen[3]!):{},message:message([error[1]!,...extra].join("; "))};
 }
 const failing=lines.find(line=>/error|fail|panic|exception|expected/iu.test(line))??[...lines].reverse().find(line=>line.trim().length>0);
 return failing===undefined?undefined:{message:message(failing)};
}

/** 🧭️ Every distinct file with a diagnostic of a compiler output, in output order, with its first diagnostic and the total diagnostic count (TypeScript and rustc formats). */
export function diagnosticFilesOfLinesV1(lines:readonly string[],root?:string):Readonly<{files:readonly VerdictFailureV1[];count:number}>{
 const files=new Map<string,VerdictFailureV1>();let count=0;
 for(let at=0;at<lines.length;at++){
  const line=lines[at]!,ts=tscParenthesis.exec(line)??tscColon.exec(line);
  let found:VerdictFailureV1|undefined;
  if(ts)found={file:verdictPathV1(ts[1]!,root),line:Number(ts[2]),column:Number(ts[3]),message:cut(`${ts[4]}: ${ts[5]}`,VERDICT_LIMITS_V1.messageCharacters)};
  else{
   const error=rustError.exec(line);
   if(error&&!rustNoise.test(line))for(let ahead=at+1;ahead<=Math.min(lines.length-1,at+4);ahead++){const arrow=rustArrow.exec(lines[ahead]!);if(arrow){found={file:verdictPathV1(arrow[1]!,root),line:Number(arrow[2]),column:Number(arrow[3]),message:cut(`${error[1]?error[1]+": ":""}${error[2]}`,VERDICT_LIMITS_V1.messageCharacters)};break;}}
  }
  if(found){count++;if(!files.has(found.file!))files.set(found.file!,found);}
 }
 return{files:[...files.values()],count};
}

/** 🔢️ The `test result: … N passed; M failed` totals of cargo output and the `N pass`/`N fail` totals of bun output. */
export function testTotalsOfLinesV1(lines:readonly string[]):Readonly<{passed:number;failed:number}>|undefined{
 let passed=0,failed=0,seen=false;
 for(const line of lines){
  const cargo=/^test result: \w+\. (\d+) passed; (\d+) failed;/u.exec(line);
  if(cargo){passed+=Number(cargo[1]);failed+=Number(cargo[2]);seen=true;continue;}
  const bun=/^\s*(\d+) (pass|fail)\s*$/u.exec(line);
  if(bun){if(bun[2]==="pass")passed+=Number(bun[1]);else failed+=Number(bun[1]);seen=true;}
 }
 return seen?{passed,failed}:undefined;
}

const shrinks:readonly((files:readonly VerdictFileV1[])=>readonly VerdictFileV1[])[]=[
 files=>files.filter(row=>row.status!=="passed"),
 files=>files.map(row=>row.first?{...row,first:{...row.first,message:cut(row.first.message,VERDICT_LIMITS_V1.shrunkMessageCharacters)}}:row),
 files=>files.map(({ranOn:_ranOn,seconds:_seconds,reused:_reused,...row})=>row),
 files=>files.map(row=>row.first?{...row,first:{message:cut(row.first.message,40),...row.first.file===undefined?{}:{file:row.first.file},...row.first.line===undefined?{}:{line:row.first.line}}}:row),
];

/** 🧾️ Builds the verdict of a command from its file rows: counts, the first failure per failed file (location and message from the captured tail), the failure class from the injected classifier (H91 `failureClassOfLinesV1` fits), where the files ran, cache and reuse counts and the reference of the full log. The result is at most `maximumBytes` of JSON: failed rows come first, passed rows are dropped first, then messages shrink, then rows are cut from the end and counted in `omitted`; the counts always stay exact. */
export function buildVerdictV1(input:VerdictInputV1):VerdictV1{
 const limits=VERDICT_LIMITS_V1,rank={failed:0,"not-run":1,skipped:2,passed:3} as const;
 const rows:VerdictFileV1[]=input.rows.map(row=>{
  const lines=verdictLinesV1([row.error,row.tail].filter(Boolean).join("\n")),failed=row.status==="failed";
  const first=row.first??(failed?firstFailureOfLinesV1(lines,{file:row.file,...input.root?{root:input.root}:{}}):undefined),kind=failed?input.classify?.(lines)?.class:undefined;
  const file=verdictPathV1(row.file,input.root),located=first!==undefined&&first.file===file?withoutFile(first):first;
  return{file,status:row.status,...row.seconds===undefined?{}:{seconds:Math.round(row.seconds*100)/100},...row.pass===undefined?{}:{pass:row.pass},...row.fail===undefined?{}:{fail:row.fail},...located?{first:located}:{},...kind?{class:kind}:{},...row.ranOn?{ranOn:cut(row.ranOn,64)}:{},...row.reused?{reused:true}:{}};
 });
 const counts={passed:0,failed:0,skipped:0,notRun:0};
 for(const row of rows)counts[row.status==="passed"?"passed":row.status==="failed"?"failed":row.status==="skipped"?"skipped":"notRun"]++;
 const measured=input.rows.filter(row=>row.pass!==undefined||row.fail!==undefined),tests=measured.length===0?undefined:{passed:measured.reduce((sum,row)=>sum+(row.pass??0),0),failed:measured.reduce((sum,row)=>sum+(row.fail??0),0)};
 const local=input.localHost,remote=rows.filter(row=>row.ranOn!==undefined&&row.ranOn!==local&&row.ranOn!=="local"),hosts=[...new Set(remote.map(row=>row.ranOn!))].sort().slice(0,limits.maximumHosts);
 const status=input.status??(counts.failed>0?"failed":"passed"),failureClass=rows.find(row=>row.class!==undefined)?.class??input.failureClass;
 const ordered=rows.map((row,index)=>({row,index})).sort((a,b)=>rank[a.row.status]-rank[b.row.status]||a.index-b.index).map(item=>item.row);
 const make=(files:readonly VerdictFileV1[]):VerdictV1=>({version:1,command:input.command,status,seconds:Math.round(input.seconds*100)/100,counts,...tests?{tests}:{},...input.diagnostics===undefined?{}:{diagnostics:input.diagnostics},...failureClass?{failureClass}:{},files,...files.length<rows.length?{omitted:{files:rows.length-files.length}}:{},origin:{local:rows.length-remote.length,offloaded:remote.length,hosts},cache:{hits:input.cache?.hits??0,misses:input.cache?.misses??0,reused:rows.filter(row=>row.reused).length},log:{reference:tailCut(input.log?.reference??"",240),bytes:input.log?.bytes??0}});
 let files:readonly VerdictFileV1[]=ordered.slice(0,limits.maximumFiles),verdict=make(files);
 for(const shrink of shrinks){if(bytesOf(verdict)<=limits.maximumBytes)break;files=shrink(files);verdict=make(files);}
 while(bytesOf(verdict)>limits.maximumBytes&&files.length>0){files=files.slice(0,Math.floor(files.length/2));verdict=make(files);}
 return verdict;
}

/** 📦️ The compact JSON text of a verdict (what the commands print last and what MCP returns as structured content). */
export function verdictJsonV1(verdict:VerdictV1):string{return JSON.stringify(verdict);}

/** 📏️ Size of a verdict in UTF-8 bytes. */
export function verdictBytesV1(verdict:VerdictV1):number{return bytesOf(verdict);}

const fill=(template:string,values:Readonly<Record<string,string|number>>)=>template.replace(/\{(\w+)\}/gu,(_,name:string)=>String(values[name]??""));
const text=(language:VerdictLanguageV1,key:string,values:Readonly<Record<string,string|number>>={})=>fill(texts[key]![language],values);

/** 🖨️ The verdict as text lines in one language: header, tests, one line per failed file with `file:line`, class and host, origin, cache, omitted rows and the log reference. */
export function renderVerdictV1(language:VerdictLanguageV1,verdict:VerdictV1):string[]{
 const lines=[text(language,"head",{status:text(language,"status."+verdict.status),command:verdict.command,files:verdict.files.length+(verdict.omitted?.files??0),failed:verdict.counts.failed,seconds:verdict.seconds})];
 if(verdict.tests)lines.push(text(language,"tests",verdict.tests));
 if(verdict.diagnostics!==undefined)lines.push(text(language,"diagnostics",{count:verdict.diagnostics}));
 for(const row of verdict.files.filter(item=>item.status==="failed")){
  const place=row.first?.file??row.file,where=row.first?.line===undefined?place:`${place}:${row.first.line}`;
  lines.push(text(language,"failure",{where,message:row.first?.message??""})+[row.class?` [${text(language,"class",{class:row.class})}]`:"",row.ranOn?` (${text(language,"on",{host:row.ranOn})})`:""].join(""));
 }
 if(verdict.origin.offloaded>0)lines.push(text(language,"origin",{local:verdict.origin.local,offloaded:verdict.origin.offloaded,hosts:verdict.origin.hosts.join(", ")||text(language,"none")}));
 if(verdict.cache.hits+verdict.cache.misses+verdict.cache.reused>0)lines.push(text(language,"cache",verdict.cache));
 if(verdict.omitted)lines.push(text(language,"omitted",verdict.omitted));
 if(verdict.log.reference.length>0)lines.push(text(language,"log",verdict.log));
 return lines;
}

/** 🏁️ Verdict of a `repo test-file` result (`TestFileResultV1`): rows carry their pass/fail counts, tail, error and host; reused rows (see the verdict reuse member) count as reused. */
export function verdictOfTestFileResultV1(result:Readonly<{status:"passed"|"failed";seconds:number;files:readonly Readonly<{file:string;status:VerdictRowStatusV1;seconds:number;pass?:number;fail?:number;error?:string;tail?:string;ranOn?:string;reused?:boolean}>[]}>,extra:Omit<VerdictInputV1,"command"|"seconds"|"rows"|"status">={}):VerdictV1{
 return buildVerdictV1({...extra,command:"test-file",status:result.status,seconds:result.seconds,rows:result.files});
}

/** 🏁️ Verdict of a captured `repo typecheck`, `repo cargo` or `repo run` output: failed files come from compiler diagnostics (first diagnostic per file, total in `diagnostics`), the totals from `test result:`/bun summary lines; a failing exit without any location is one row named `-` carrying the first error-like line. */
export function verdictOfCommandV1(input:Readonly<{command:Exclude<VerdictCommandV1,"test-file">;exit:number|null;seconds:number;output:string;cancelled?:boolean;refused?:boolean;log?:Readonly<{reference:string;bytes:number}>;cache?:Readonly<{hits:number;misses:number}>;root?:string;ranOn?:string;classify?:VerdictClassifierV1}>):VerdictV1{
 const lines=verdictLinesV1(input.output),found=diagnosticFilesOfLinesV1(lines,input.root),totals=testTotalsOfLinesV1(lines);
 const status:VerdictStatusV1=input.refused?"refused":input.cancelled?"cancelled":input.exit===0?"passed":"failed";
 const rows:VerdictRowInputV1[]=found.files.map(failure=>({file:failure.file!,status:"failed" as const,first:failure,...input.ranOn?{ranOn:input.ranOn}:{}}));
 if(status==="failed"&&rows.length===0)rows.push({file:"-",status:"failed",tail:lines.filter(line=>line.trim().length>0).slice(-VERDICT_LIMITS_V1.tailLines).join("\n"),...input.ranOn?{ranOn:input.ranOn}:{}});
 const kind=status==="failed"?input.classify?.(lines)?.class:undefined,verdict=buildVerdictV1({command:input.command,status,seconds:input.seconds,rows,...kind?{failureClass:kind}:{},...found.count>0?{diagnostics:found.count}:{},...input.log?{log:input.log}:{},...input.cache?{cache:input.cache}:{},...input.root?{root:input.root}:{},...input.classify?{classify:input.classify}:{}});
 return totals?{...verdict,tests:totals}:verdict;
}
