import type {HostEndpointsV1} from "../../📨️protocol/📍️endpoint/🏠️host/🟨️.mjs";
import type {PlanTaskV1} from "../../🏛️service/🌐️host/🟨️.mjs";
type Environment=Readonly<Record<string,string|undefined>>;
export interface HostProgressV1{phase:string;done:number;total:number;message:Record<string,string>}
export class HostUnavailableErrorV1 extends Error{readonly reason:string}
export class PlanRefusedErrorV1 extends Error{readonly code:string;readonly retry:string}
export function connectHostV1(options:{implementation:string;environment?:Environment;platform?:string;spawnService?:(request:{runtime:HostEndpointsV1;implementation:string;environment:Environment})=>unknown;signal?:AbortSignal;onProgress?:(frame:HostProgressV1)=>void;languages?:readonly string[]}):Promise<{socket:import("node:net").Socket;runtime:HostEndpointsV1;started:boolean}>;
export interface PlanResultV1{reply:{slice?:{hash:string;size:number};revision:string;manifest?:string;pin?:{version:1;revision:string;holder:string;expiresMs:number};plan:{tasks:readonly PlanTaskV1[]}|{ref:{hash:string;size:number}};progress:readonly {phase:string;ms:number}[];cacheHits:number};welcome:{service:{pid:number}};runtime:HostEndpointsV1;plan:{tasks:readonly PlanTaskV1[]}}
export function requestPlanV1(options:{root:string;implementation:string;targets:readonly string[];agent:string;priority?:number;revision?:string;parent?:string;dirty?:{paths:readonly string[];overflow?:boolean;cursor?:string};arguments?:readonly string[];tool?:string;graphPolicy?:"fresh"|"current";language:"en"|"de";signal?:AbortSignal;onProgress?:(frame:HostProgressV1)=>void;environment?:Environment;platform?:string;spawnService?:Parameters<typeof connectHostV1>[0]["spawnService"];attempts?:number;deadlineMs?:number}):Promise<PlanResultV1>;
export function resolvePlanV1(reply:PlanResultV1["reply"],runtime:HostEndpointsV1):{tasks:readonly PlanTaskV1[]};
export function requestHostStatusV1(options:{implementation:string;environment?:Environment;platform?:string}):Promise<{pid:number;rssMb:number;indexBytes:number;indexes:number;workspaces:readonly {id:string;root:string;indexKey:string;lastUsedAt:number;plans:number}[];clients:number;queue:number;inFlight:number}|undefined>;

export function holdHostV1(options:{implementation:string;environment?:Environment;platform?:string;agent?:string}):Promise<()=>Promise<void>>;
export function retireHostServiceV1(options:{implementation:string;environment?:Environment;platform?:string;timeoutMilliseconds?:number;status?:(options:{implementation:string;environment?:Environment;platform?:string})=>Promise<{pid:number}|undefined>;kill?:(pid:number,signal:string)=>unknown;pause?:(milliseconds:number)=>Promise<void>}):Promise<{pid:number|undefined;retired:boolean}>;
