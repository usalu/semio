/** 🧭️ Types of the script-inputs component: command closures stay structural data (their rows are untrusted until a producer admits them). */
export type ScriptInputsValueV1 = any;
export const component: "script-inputs";
export function wire(registry: ScriptInputsValueV1): void;
export function createScriptInputCache(context?: ScriptInputsValueV1): ScriptInputsValueV1;
export function scriptProviderPortsV1(text: string): readonly string[];
export function designatedPortsV1(cache: ScriptInputsValueV1, ports: readonly string[]): readonly string[];
export function buildImportResourceV1(containing: string, specifier: string): { readonly specifier: string; readonly suffix: string; readonly source: boolean };
export function declaredInputPatternV1(input: ScriptInputsValueV1, projectRoot: string): ScriptInputsValueV1;
export function declaredModuleGlobsV1(inputs: ScriptInputsValueV1, workspaceRoot: string, projectRoot: string, environment: ScriptInputsValueV1): ScriptInputsValueV1;
export function declaredTypeScriptProjectsV1(inputs: ScriptInputsValueV1, workspaceRoot: string, projectRoot: string, environment: ScriptInputsValueV1): ScriptInputsValueV1;
export function relativeScriptInputs(entries: ScriptInputsValueV1, workspaceRoot: string, cache?: ScriptInputsValueV1, requiredSources?: boolean, resourceEntries?: ScriptInputsValueV1, commands?: ReadonlyMap<string, readonly string[]>): Promise<ScriptInputsValueV1>;
export function withoutSchedulingV1(closure: readonly ScriptInputsValueV1[], prefixes?: readonly string[]): ScriptInputsValueV1[];
export function nativeCommandInputs(workspaceRoot: string, scripts: ScriptInputsValueV1): Promise<ScriptInputsValueV1>;
export function targetScriptSources(target: ScriptInputsValueV1, workspaceRoot: string, scripts: ScriptInputsValueV1, projectRoot?: string, nativeManifest?: ScriptInputsValueV1): Promise<ScriptInputsValueV1>;
export function ownerCommandChildV1(options: ScriptInputsValueV1, bound: ScriptInputsValueV1): { readonly cwd: string; readonly command: string } | undefined;
export function targetScriptClosure(target: ScriptInputsValueV1, workspaceRoot: string, scripts: ScriptInputsValueV1, projectRoot?: string): Promise<ScriptInputsValueV1>;
export function nativeLockInputs(command: ScriptInputsValueV1): ScriptInputsValueV1;
export function nativeTargetCommandInputs(target: ScriptInputsValueV1, workspaceRoot: string, fallback: ScriptInputsValueV1, scripts: ScriptInputsValueV1, projectRoot?: string): Promise<ScriptInputsValueV1>;
export function genericTargetCommandInputs(target: ScriptInputsValueV1, workspaceRoot: string, fallback: ScriptInputsValueV1, scripts?: ScriptInputsValueV1, projectRoot?: string): Promise<ScriptInputsValueV1>;
export function genericCommandFallbackInputs(workspaceRoot: string): ScriptInputsValueV1;
export function closureRecipeByKeyV1(key: string): ScriptInputsValueV1;
export function closureRecipeKeyV1(recipe: ScriptInputsValueV1): string;
export function closureHandleFromRecipeV1(recipe: ScriptInputsValueV1): ScriptInputsValueV1;
export function closureHandleOfV1(value: unknown): ScriptInputsValueV1;
export function registerClosureQueryV1(name: string, query: ScriptInputsValueV1): void;
export function bindClosureScriptsV1(workspaceRoot: string, scripts: ScriptInputsValueV1): void;
export function resetClosureEntriesV1(entryBytes?: number): void;
export function closureEntryCountsV1(): { derived: number; loaded: number; stale: number; checked: number };
export function closureStoreDirectoryV1(workspaceRoot: string): string | undefined;
export function bindClosureStoreV1(workspaceRoot: string, directory: string, writable?: boolean): void;
export function closureApiV1(scripts: ScriptInputsValueV1, workspaceRoot: string): ScriptInputsValueV1;
export function derivedWalkAnswerV1(value: unknown): string;
export function expandedCommandInputsV1<T>(value: T, workspaceRoot: string, scripts?: ScriptInputsValueV1): Promise<T>;
export function resolveCommandWalkV1(workspaceRoot: string, entries: readonly string[], cache: ScriptInputsValueV1): Promise<{ readonly value: readonly string[]; readonly rows: readonly ScriptInputsValueV1[]; readonly derived: readonly { readonly row: ScriptInputsValueV1; readonly support: readonly ScriptInputsValueV1[] }[] }>;
export function yieldInferenceV1(context: ScriptInputsValueV1, phase: string, index: number, force?: boolean): Promise<void>;
export function withClosurePassV1<T>(compute:()=>Promise<T>|T):Promise<T>;

/** 📋️ The recipes every owner reads and none depends on its own target. */
export function sharedClosureRecipesV1(scripts: ScriptInputsValueV1): readonly Record<string, unknown>[];
/** 🧰️ Derives the shared closure entries once, in order, before the owners start. */
export function primeSharedClosuresV1(workspaceRoot: string, scripts: ScriptInputsValueV1, options?: { signal?: AbortSignal; progress?: (event: { done: number; total: number }) => unknown; recipes?: readonly Record<string, unknown>[] }): Promise<{ recipes: number; derived: number; loaded: number; stale: number }>;

/** 🚚️ The closure entries of a project record as portable bundles and back. */
export const closureTravelV1: Readonly<{ export(workspaceRoot: string, image: string): Promise<readonly Readonly<{ recipeKey: string; bundle: unknown }>[]>; import(workspaceRoot: string, bundles: readonly Readonly<{ recipeKey: string; bundle: unknown }>[]): Promise<number> }>;

/** 🫧️ Releases what one finished owner left in the shared script input cache. */
export function releaseOwnerStateV1(scripts: ScriptInputsValueV1): void;
