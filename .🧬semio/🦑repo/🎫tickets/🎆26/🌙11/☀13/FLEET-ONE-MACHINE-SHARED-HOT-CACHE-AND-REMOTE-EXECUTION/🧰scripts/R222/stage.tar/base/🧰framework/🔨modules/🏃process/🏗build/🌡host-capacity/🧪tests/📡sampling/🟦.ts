import {expect,test} from "bun:test";
import {spawnSync} from "node:child_process";
import {freemem,totalmem} from "node:os";
import {formatHostCapacityErrorV1,readHostCapacityPolicyV1,resolveHostCapacityLanguageV1,type HostCommandRunnerV1} from "../../🟦️.ts";
import {observeTreeMegabytesV1,parseDarwinCountersV1,parseLinuxCountersV1,parseProcessTableV1,parseWindowsCountersV1,readHostCountersV1,WINDOWS_COUNTERS_COMMAND,readHostSampleV1,reduceHostSampleV1,simulatedHostTotalV1,treeMegabytesV1,wholeHostProbeV1} from "../../📡️sampling/🟦️.ts";
import decisionFixture from "../🧫️fixtures/🔣️.json";
import fixture from "./🧫️fixtures/🔣️.json";

const policy=readHostCapacityPolicyV1(decisionFixture.policy);

test("macOS counters parse from vm_stat, vm.swapusage and the pressure level exactly",()=>{
 for(const item of fixture.darwin)expect(parseDarwinCountersV1(item.vmStat,item.swapUsage,item.pressureLevel,item.filesTable,item.imageInfo),item.name).toEqual(item.expect as never);
});

test("Windows counters parse from the one PowerShell command and read through an injected port",async()=>{
 for(const item of fixture.windows)expect(parseWindowsCountersV1(item.json),item.name).toEqual(item.expect as never);
 const calls:string[]=[];
 expect(await readHostCountersV1({platform:"win32",run:async(command,args)=>{calls.push([command,...args].join(" "));return fixture.windows[0]!.json;},read:async()=>null})).toEqual(fixture.windows[0]!.expect as never);
 expect(calls).toEqual(["powershell.exe -NoProfile -NonInteractive -Command "+WINDOWS_COUNTERS_COMMAND]);
});

test("Linux counters parse from meminfo, vmstat, PSI and the cgroup v2 limit files exactly",()=>{
 for(const item of fixture.linux)expect(parseLinuxCountersV1(item.meminfo,item.vmstat,item.pressure,item.cgroupMaximum,item.cgroupCurrent,item.fileNr),item.name).toEqual(item.expect as never);
});

test("Counters reduce to one host sample: the worst of the platform level and the free share wins, the container limit caps the host and the swap rate needs a predecessor",()=>{
 for(const item of fixture.reduce)expect(reduceHostSampleV1(policy,{platform:item.platform as never,cores:item.cores,totalMegabytes:item.totalMegabytes,atMs:item.atMs,load:item.load},item.counters as never,item.previous??undefined),item.name).toEqual(item.expect as never);
});

test("The process tree sums a process and all descendants from a ps table and answers null for an unknown pid",()=>{
 const rows=parseProcessTableV1(fixture.tree.table);
 expect(rows.length).toBe(6);
 for(const [pid,megabytes] of Object.entries(fixture.tree.expect))expect(treeMegabytesV1(rows,Number(pid)),pid).toBe(megabytes);
});

test("Every platform reads through injected ports, so Linux and Windows parse on any machine",async()=>{
 const files=new Map<string,string>([["/proc/meminfo",fixture.linux[0]!.meminfo],["/proc/vmstat",fixture.linux[0]!.vmstat],["/proc/pressure/memory",fixture.linux[0]!.pressure!],["/sys/fs/cgroup/memory.max",fixture.linux[0]!.cgroupMaximum!],["/sys/fs/cgroup/memory.current",fixture.linux[0]!.cgroupCurrent!],["/proc/sys/fs/file-nr",fixture.linux[0]!.fileNr!]]);
 const counters=await readHostCountersV1({platform:"linux",run:async()=>{throw Error("no command expected");},read:async path=>files.get(path)??null});
 expect(counters).toEqual(fixture.linux[0]!.expect as never);
 const calls:string[]=[],run:HostCommandRunnerV1=async(command,args)=>{calls.push([command,...args].join(" "));return command==="vm_stat"?fixture.darwin[0]!.vmStat:command==="/usr/bin/hdiutil"?fixture.darwin[0]!.imageInfo!:args.includes("kern.num_files")?fixture.darwin[0]!.filesTable:args.includes("vm.swapusage")?fixture.darwin[0]!.swapUsage:fixture.darwin[0]!.pressureLevel;};
 expect(await readHostCountersV1({platform:"darwin",run,read:async()=>null})).toEqual(fixture.darwin[0]!.expect as never);
 expect(calls.sort()).toEqual(["/usr/bin/hdiutil info","sysctl -n kern.memorystatus_vm_pressure_level","sysctl -n vm.swapusage","sysctl kern.num_files kern.maxfiles","vm_stat"]);
 expect(await observeTreeMegabytesV1(102,async()=>fixture.tree.table,"darwin")).toBe(22);
 expect(await observeTreeMegabytesV1(102,async()=>{throw Error("no powershell");},"win32",undefined,()=>undefined)).toBeNull();
});

test("The optional open file table and image count fall back to unknown when their probes fail, and never fail the sample",async()=>{
 const run:HostCommandRunnerV1=async(command,args)=>{if(command==="/usr/bin/hdiutil"||args.includes("kern.num_files"))throw Error("stalled");return command==="vm_stat"?fixture.darwin[0]!.vmStat:args.includes("vm.swapusage")?fixture.darwin[0]!.swapUsage:fixture.darwin[0]!.pressureLevel;};
 expect(await readHostCountersV1({platform:"darwin",run,read:async()=>null})).toMatchObject({openFiles:null,openFilesMaximum:null,attachedImages:null,availableBytes:fixture.darwin[0]!.expect.availableBytes});
 const only=new Map<string,string>([["/proc/meminfo",fixture.linux[0]!.meminfo],["/proc/vmstat",fixture.linux[0]!.vmstat]]);
 expect(await readHostCountersV1({platform:"linux",run:async()=>"",read:async path=>only.get(path)??null})).toMatchObject({openFiles:null,openFilesMaximum:null,attachedImages:null});
 expect(await readHostCountersV1({platform:"win32",run:async()=>{throw Error("no powershell");},read:async()=>null,notify:()=>undefined})).toMatchObject({openFiles:null,openFilesMaximum:null,attachedImages:null,swapUsedBytes:null});
});

test("A missing Linux counter file fails closed",async()=>{
 await expect(readHostCountersV1({platform:"linux",run:async()=>"",read:async()=>null})).rejects.toThrow(formatHostCapacityErrorV1(resolveHostCapacityLanguageV1(process.env),"countersUnavailable"));
});

test.skipIf(process.platform!=="darwin")("macOS live sample is conservative against the kernel's own memory_pressure and consistent with os.freemem",async()=>{
 const first=await readHostSampleV1(policy,{platform:"darwin",run:async(command,args)=>{const out=spawnSync(command,[...args],{encoding:"utf8"});if(out.status!==0)throw Error(out.stderr);return out.stdout;},read:async()=>null});
 const kernel=spawnSync("memory_pressure",[],{encoding:"utf8"}).stdout,percent=Number(/System-wide memory free percentage: (\d+)%/u.exec(kernel)?.[1]),host=first.host;
 expect(host.totalMegabytes).toBe(Math.floor(totalmem()/1048576));
 expect(host.availableMegabytes).toBeGreaterThanOrEqual(Math.floor(freemem()/1048576)*0.5);
 expect(host.availableMegabytes).toBeLessThanOrEqual(host.totalMegabytes);
 expect(Number.isFinite(percent)).toBe(true);
 expect(host.availableMegabytes/host.totalMegabytes*100,"ours must not exceed the kernel's free share").toBeLessThanOrEqual(percent+5);
 const level=Number(spawnSync("sysctl",["-n","kern.memorystatus_vm_pressure_level"],{encoding:"utf8"}).stdout.trim());
 expect(host.pressure===(level===4?"critical":level===2?"warn":"normal")||host.pressure!=="normal").toBe(true);
 expect(host.load).toBeGreaterThanOrEqual(0);
 const files=spawnSync("sysctl",["-n","kern.num_files"],{encoding:"utf8"}).stdout.trim(),maximum=spawnSync("sysctl",["-n","kern.maxfiles"],{encoding:"utf8"}).stdout.trim();
 expect(host.openFilesMaximum).toBe(Number(maximum));
 expect(Math.abs(host.openFiles!-Number(files))).toBeLessThan(Number(maximum)/20);
 const plist=spawnSync("/usr/bin/hdiutil",["info","-plist"],{encoding:"utf8"}).stdout,independent=Number(spawnSync("plutil",["-extract","images","raw","-o","-","-"],{input:plist,encoding:"utf8"}).stdout.trim());
 expect(Number.isFinite(independent)).toBe(true);
 expect(Math.abs(host.attachedImages!-independent),"attached images agree with plutil's count of hdiutil's plist").toBeLessThanOrEqual(1);
});

test("A simulated host total shrinks the host: total is the smaller size, the available memory is capped at it, malformed values mean the real host",async()=>{
 const key="SEMIO_HOST_CAPACITY_TOTAL_MEGABYTES";
 for(const [text,expected] of [["16384",16384],["1000",1000],["999",null],["016384",null],["16 GB",null],["-1",null],["",null],[undefined,null]] as const)expect(simulatedHostTotalV1({[key]:text}),String(text)).toBe(expected);
 const item=fixture.linux[0]!,probe={platform:"linux" as const,run:async()=>"",read:async(path:string)=>path==="/proc/meminfo"?item.meminfo:path==="/proc/vmstat"?item.vmstat:path==="/proc/pressure/memory"?item.pressure:path==="/proc/sys/fs/file-nr"?item.fileNr:null};
 const real=Math.floor(totalmem()/1048576),limit=Math.floor(real/2),plain=(await readHostSampleV1(policy,probe,undefined,()=>0,{})).host,small=(await readHostSampleV1(policy,probe,undefined,()=>0,{[key]:String(limit)})).host,larger=(await readHostSampleV1(policy,probe,undefined,()=>0,{[key]:String(real*2)})).host;
 expect(small.totalMegabytes).toBe(limit);
 expect(small.availableMegabytes).toBe(Math.min(limit,plain.availableMegabytes));
 expect(larger.totalMegabytes,"a simulated total never grows the host").toBe(plain.totalMegabytes);
 expect(larger.availableMegabytes).toBe(plain.availableMegabytes);
});

test("A process in a memory-limited cgroup samples the whole machine through the whole-host probe: the limit that bounds the caller is not read, so a reservation is measured against the host",async()=>{
 const gigabyte=1073741824,files=new Map<string,string>([["/proc/meminfo",fixture.linux[0]!.meminfo],["/proc/vmstat",fixture.linux[0]!.vmstat],["/proc/self/cgroup","0::/service"],["/sys/fs/cgroup/service/memory.max",String(4*gigabyte)],["/sys/fs/cgroup/service/memory.current",String(gigabyte)],["/sys/fs/cgroup/memory.max","max"],["/sys/fs/cgroup/memory.current",String(gigabyte)]]);
 const probe={platform:"linux" as const,run:async()=>{throw Error("no command expected");},read:async(path:string)=>files.get(path)??null};
 const limited=await readHostCountersV1(probe),whole=await readHostCountersV1(wholeHostProbeV1(probe));
 expect(limited.constrainedBytes).not.toBeNull();expect(whole.constrainedBytes).toBeNull();
 expect(whole.availableBytes).toBeGreaterThanOrEqual(limited.availableBytes!);
});
