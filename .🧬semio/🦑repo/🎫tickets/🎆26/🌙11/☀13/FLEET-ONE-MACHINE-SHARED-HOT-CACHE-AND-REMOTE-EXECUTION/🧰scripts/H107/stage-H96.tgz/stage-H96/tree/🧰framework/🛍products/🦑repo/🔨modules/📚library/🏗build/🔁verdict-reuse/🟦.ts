import {createHash} from "node:crypto";
import {mkdirSync,readFileSync,readdirSync,renameSync,writeFileSync} from "node:fs";
import {dirname,isAbsolute,join,relative,resolve,sep} from "node:path";
import {progressDurationTextV1} from "../📈️progress-rate/🟦️.ts";
import schema from "./🧬️schema/🔣️.json" with {type:"json"};

export type VerdictReuseLanguageV1="en"|"de";
export type VerdictReusePolicyV1=Readonly<typeof schema.definitions.Policy.const>;
export type VerdictReuseEntryV1=Readonly<{path:string;digest:string}>;
export type VerdictReuseInputsV1=Readonly<{version:1;file:string;fileDigest:string;closure:readonly VerdictReuseEntryV1[];unresolved:readonly string[];externals:readonly string[];member:readonly VerdictReuseEntryV1[];fixtures:readonly VerdictReuseEntryV1[];toolchain:Readonly<Record<string,string>>;envelope:Readonly<Record<string,string>>}>;
export type VerdictReuseResultV1=Readonly<{pass:number;fail:0;skipped:number;seconds:number}>;
export type VerdictReuseRecordV1=Readonly<{version:1;key:string;file:string;at:number;origin:string;result:VerdictReuseResultV1;sum:string}>;
export type VerdictReuseMissV1="opted-out"|"absent"|"expired"|"not-passed"|"empty"|"corrupt"|"key-mismatch"|"store-down"|"too-large"|"too-many-files";
export type VerdictReuseKeyV1=Readonly<{kind:"key";key:string;inputs:VerdictReuseInputsV1}>|Readonly<{kind:"ineligible";reason:"too-large"|"too-many-files"}>;
export type VerdictReuseLookupV1=Readonly<{kind:"hit";record:VerdictReuseRecordV1;ageMs:number}>|Readonly<{kind:"miss";reason:VerdictReuseMissV1}>;
export type VerdictCachePortV1=Readonly<{read:(hash:string,signal?:AbortSignal)=>Promise<Uint8Array|undefined>;write:(hash:string,bytes:Uint8Array,signal?:AbortSignal)=>Promise<void>}>;
export type VerdictReusePortsV1=Readonly<{read:(path:string)=>Uint8Array|undefined;list:(directory:string)=>readonly Readonly<{name:string;directory:boolean}>[]|undefined;resolveBare?:(specifier:string,directory:string)=>string|undefined}>;
export type VerdictReuseRowV1=Readonly<{status:string;seconds:number;pass?:number;fail?:number}>;

/** ♻️ The declared numbers: key prefix, maximum age, bounds, what counts as member and closure, the opt-out switches and the allowed envelope keys; the schema file is the single source.
 * @see ./🧬️schema/🔣️.json */
export const VERDICT_REUSE_POLICY_V1:VerdictReusePolicyV1=Object.freeze({...schema.definitions.Policy.const});
const texts=schema.definitions.Texts.const as Readonly<Record<string,Readonly<Record<VerdictReuseLanguageV1,string>>>>;

const sha=(value:Uint8Array|string)=>createHash("sha256").update(value).digest("hex");
const slash=(path:string)=>path.split(sep).join("/");
const sortedObject=(value:unknown):unknown=>Array.isArray(value)?value.map(sortedObject):value!==null&&typeof value==="object"?Object.fromEntries(Object.entries(value as Record<string,unknown>).sort(([a],[b])=>a<b?-1:a>b?1:0).map(([key,item])=>[key,sortedObject(item)])):value;

/** 🧮️ Canonical JSON: keys sorted by code point at every depth, no whitespace; equal documents give equal text on every machine. */
export function canonicalJsonV1(value:unknown):string{return JSON.stringify(sortedObject(value));}

/** 🗂️ The real file system: missing or unreadable files read as `undefined`, a missing directory lists as `undefined`. */
export const VERDICT_REUSE_FILE_SYSTEM_V1:VerdictReusePortsV1=Object.freeze({
 read:path=>{try{return readFileSync(path);}catch{return undefined;}},
 list:directory=>{try{return readdirSync(directory,{withFileTypes:true}).map(entry=>({name:entry.name,directory:entry.isDirectory()}));}catch{return undefined;}},
 resolveBare:(specifier,directory)=>{try{const found=(globalThis as {Bun?:{resolveSync:(name:string,from:string)=>string}}).Bun?.resolveSync(specifier,directory);return found;}catch{return undefined;}},
});

const importPatterns=[/\b(?:import|export)\s+(?:type\s+)?(?:[^"'`;]*?\sfrom\s*)?["']([^"'\n]+)["']/gu,/\bimport\s*\(\s*["']([^"'\n]+)["']\s*\)/gu,/\brequire\s*\(\s*["']([^"'\n]+)["']\s*\)/gu];

/** 🔎️ Every module specifier a source text names with a string literal: `import … from`, `export … from`, side effect imports, `import("x")` and `require("x")`. Specifiers inside comments are included (over approximation is safe for a key). */
export function importSpecifiersOfTextV1(text:string):string[]{
 const found=new Set<string>();
 for(const pattern of importPatterns){pattern.lastIndex=0;for(let match=pattern.exec(text);match;match=pattern.exec(text))found.add(match[1]!);}
 return[...found].sort();
}

const packageName=(specifier:string)=>specifier.startsWith("@")?specifier.split("/").slice(0,2).join("/"):specifier.split("/")[0]!;
const builtin=(specifier:string)=>specifier.startsWith("node:")||specifier.startsWith("bun:")||specifier==="bun";

/** 🎯️ The file a relative specifier names: exact name, the policy extensions, the TypeScript `.js` to `.ts` spelling, then the index names of a directory; `undefined` when nothing exists. */
export function resolveRelativeSpecifierV1(directory:string,specifier:string,ports:VerdictReusePortsV1=VERDICT_REUSE_FILE_SYSTEM_V1,policy:VerdictReusePolicyV1=VERDICT_REUSE_POLICY_V1):string|undefined{
 const base=resolve(directory,specifier),swapped=base.replace(/\.js$/u,".ts").replace(/\.mjs$/u,".mts").replace(/\.cjs$/u,".cts");
 for(const candidate of[base,swapped])for(const extension of policy.extensions)if(ports.read(candidate+extension)!==undefined)return candidate+extension;
 for(const name of policy.indexNames)if(ports.read(join(base,name))!==undefined)return join(base,name);
 return undefined;
}

/** 🕸️ The import closure of a test file: every file reachable through string literal specifiers (relative ones resolved on disk, bare ones through `resolveBare` and kept only when they land inside the checkout and outside `node_modules`), bounded by `maximumClosureFiles`. Bare package names that stay outside the checkout are listed as `externals` (their content is covered by the toolchain lockfile digest), relative specifiers that resolve to nothing as `unresolved`. */
export function importClosureOfFileV1(file:string,root:string,ports:VerdictReusePortsV1=VERDICT_REUSE_FILE_SYSTEM_V1,policy:VerdictReusePolicyV1=VERDICT_REUSE_POLICY_V1):Readonly<{files:readonly string[];unresolved:readonly string[];externals:readonly string[];truncated:boolean}>{
 const seen=new Set<string>([file]),queue=[file],unresolved=new Set<string>(),externals=new Set<string>();let truncated=false;
 for(let at=0;at<queue.length;at++){
  const current=queue[at]!,bytes=ports.read(current);if(bytes===undefined)continue;
  for(const specifier of importSpecifiersOfTextV1(Buffer.from(bytes).toString("utf8"))){
   let target:string|undefined;
   if(specifier.startsWith(".")){target=resolveRelativeSpecifierV1(dirname(current),specifier,ports,policy);if(target===undefined){unresolved.add(`${slash(relative(root,current))} -> ${specifier}`);continue;}}
   else if(isAbsolute(specifier))target=resolveRelativeSpecifierV1("/",specifier,ports,policy);
   else if(builtin(specifier))continue;
   else{
    const found=ports.resolveBare?.(specifier,dirname(current));
    if(found===undefined||found.split(sep).includes("node_modules")||relative(root,found).startsWith(".."))externals.add(packageName(specifier));
    else target=found;
   }
   if(target===undefined||seen.has(target))continue;
   if(seen.size>=policy.maximumClosureFiles){truncated=true;continue;}
   seen.add(target);queue.push(target);
  }
 }
 seen.delete(file);
 return{files:[...seen].sort(),unresolved:[...unresolved].sort(),externals:[...externals].sort(),truncated};
}

const entryOf=(path:string,root:string,bytes:Uint8Array|undefined):VerdictReuseEntryV1=>({path:slash(relative(root,path)),digest:bytes===undefined?"0".repeat(64):sha(bytes)});

/** 📁️ Digests of every file below a directory (or of one file), sorted by path, skipping the policy folders; `truncated` when the file or byte bound is exceeded. */
export function digestTreeV1(path:string,root:string,ports:VerdictReusePortsV1=VERDICT_REUSE_FILE_SYSTEM_V1,policy:VerdictReusePolicyV1=VERDICT_REUSE_POLICY_V1,limit:number=policy.maximumMemberFiles):Readonly<{entries:readonly VerdictReuseEntryV1[];bytes:number;truncated:boolean}>{
 const entries:VerdictReuseEntryV1[]=[];let bytes=0,truncated=false;
 const walk=(current:string)=>{
  const listing=ports.list(current);
  if(listing===undefined){const data=ports.read(current);if(entries.length>=limit){truncated=true;return;}if(data!==undefined)bytes+=data.length;entries.push(entryOf(current,root,data));return;}
  for(const item of[...listing].sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0)){
   if(item.directory&&policy.skipFolders.includes(item.name))continue;
   if(item.directory)walk(join(current,item.name));
   else{if(entries.length>=limit){truncated=true;return;}const data=ports.read(join(current,item.name));if(data!==undefined)bytes+=data.length;entries.push(entryOf(join(current,item.name),root,data));}
  }
 };
 walk(path);
 return{entries:entries.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0),bytes,truncated:truncated||bytes>policy.maximumHashBytes};
}

/** 🏠️ The member directory a test file belongs to: the parent of the first `🧪️tests` folder of its path, else its own directory. Any change below it re-runs the test, which makes files read at run time (oracles, fixtures, spawned module files) part of the key without a declaration. */
export function memberDirectoryOfTestV1(file:string,policy:VerdictReusePolicyV1=VERDICT_REUSE_POLICY_V1):string{
 const parts=file.split(sep),at=parts.indexOf(policy.testsFolder);
 return at>0?parts.slice(0,at).join(sep)||sep:dirname(file);
}

/** 🧰️ The toolchain facts that change a verdict: runtime name and version and the digest of the lockfile (which pins every external package); all strings. */
export function detectVerdictToolchainV1(root:string,ports:VerdictReusePortsV1=VERDICT_REUSE_FILE_SYSTEM_V1):Readonly<Record<string,string>>{
 const bun=(globalThis as {Bun?:{version:string}}).Bun?.version,lock=ports.read(join(root,"bun.lock"));
 return{runtime:bun===undefined?"node":"bun",runtimeVersion:bun??process.version,...lock===undefined?{}:{lockfile:sha(lock)}};
}

/** 🌍️ The envelope facts of this machine (platform, architecture, runner); keys outside the policy are refused so no accidental variable can make every key unique. */
export function verdictReuseEnvelopeV1(extra:Readonly<Record<string,string>>={},policy:VerdictReusePolicyV1=VERDICT_REUSE_POLICY_V1):Readonly<Record<string,string>>{
 const envelope={platform:process.platform,arch:process.arch,runner:"bun-test",...extra};
 for(const key of Object.keys(envelope))if(!policy.envelopeKeys.includes(key))throw Error(`Envelope key ${key} is not allowed (allowed: ${policy.envelopeKeys.join(", ")}) / Umgebungsschlüssel ${key} ist nicht erlaubt (erlaubt: ${policy.envelopeKeys.join(", ")})`);
 return envelope;
}

/** 🔑️ The reuse key of one test file: SHA-256 of the canonical JSON of its inputs document (file digest, import closure, member files, declared fixtures, toolchain, envelope); every path is relative to the checkout root so machines with different checkout locations agree. A test whose inputs exceed the bounds is `ineligible` and always runs. */
export function verdictReuseKeyV1(input:Readonly<{file:string;root:string;fixtures?:readonly string[];toolchain?:Readonly<Record<string,string>>;envelope?:Readonly<Record<string,string>>;ports?:VerdictReusePortsV1;policy?:VerdictReusePolicyV1}>):VerdictReuseKeyV1{
 const ports=input.ports??VERDICT_REUSE_FILE_SYSTEM_V1,policy=input.policy??VERDICT_REUSE_POLICY_V1,file=resolve(input.file),root=resolve(input.root);
 const own=ports.read(file),closure=importClosureOfFileV1(file,root,ports,policy);
 if(closure.truncated)return{kind:"ineligible",reason:"too-many-files"};
 const member=digestTreeV1(memberDirectoryOfTestV1(file,policy),root,ports,policy);
 const memberPaths=new Set(member.entries.map(entry=>entry.path));
 const closureEntries=closure.files.filter(path=>!memberPaths.has(slash(relative(root,path)))).map(path=>entryOf(path,root,ports.read(path)));
 const fixtureTrees=(input.fixtures??[]).map(path=>digestTreeV1(resolve(root,path),root,ports,policy));
 const fixtures=fixtureTrees.flatMap(tree=>tree.entries).sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
 if(member.truncated||fixtureTrees.some(tree=>tree.truncated))return{kind:"ineligible",reason:member.bytes>policy.maximumHashBytes?"too-large":"too-many-files"};
 const inputs:VerdictReuseInputsV1={version:1,file:slash(relative(root,file)),fileDigest:own===undefined?"0".repeat(64):sha(own),closure:closureEntries,unresolved:closure.unresolved,externals:closure.externals,member:member.entries,fixtures,toolchain:input.toolchain??detectVerdictToolchainV1(root,ports),envelope:input.envelope??verdictReuseEnvelopeV1()};
 return{kind:"key",key:sha(canonicalJsonV1(inputs)),inputs};
}

/** 🏷️ The cache address of a key: SHA-256 of the key prefix and the key (the fleet action cache and the local directory store both address by it). */
export function verdictReuseAddressV1(key:string,policy:VerdictReusePolicyV1=VERDICT_REUSE_POLICY_V1):string{return sha(policy.keyPrefix+key);}

/** 🚫️ Whether reuse is switched off: the `--no-reuse` flag or `SEMIO_TEST_REUSE` set to `0`, `off`, `false` or `never`. */
export function verdictReuseOptedOutV1(argv:readonly string[],environment:Readonly<Record<string,string|undefined>>=process.env,policy:VerdictReusePolicyV1=VERDICT_REUSE_POLICY_V1):boolean{
 return argv.includes(policy.optOutFlag)||policy.optOutValues.includes((environment[policy.optOutVariable]??"").trim().toLowerCase());
}

const sumOf=(record:Omit<VerdictReuseRecordV1,"sum">)=>sha(canonicalJsonV1(record));

/** 📦️ Encodes a passed result as a record (canonical JSON with its own checksum). */
export function encodeVerdictReuseRecordV1(input:Readonly<{key:string;file:string;at:number;origin:string;result:VerdictReuseResultV1}>):Uint8Array{
 const body={version:1 as const,key:input.key,file:input.file,at:Math.round(input.at),origin:input.origin.slice(0,64),result:input.result};
 return Buffer.from(canonicalJsonV1({...body,sum:sumOf(body)}));
}

/** 📦️ Decodes and checks a record: shape, checksum, key; anything else is `corrupt` or `key-mismatch`. */
export function decodeVerdictReuseRecordV1(bytes:Uint8Array,key:string):VerdictReuseRecordV1|"corrupt"|"key-mismatch"{
 let record:VerdictReuseRecordV1;
 try{record=JSON.parse(Buffer.from(bytes).toString("utf8")) as VerdictReuseRecordV1;}catch{return"corrupt";}
 const result=record?.result;
 if(record===null||typeof record!=="object"||record.version!==1||typeof record.key!=="string"||typeof record.file!=="string"||!Number.isInteger(record.at)||typeof record.origin!=="string"||typeof record.sum!=="string"||result===undefined||result===null||!Number.isInteger(result.pass)||!Number.isInteger(result.fail)||!Number.isInteger(result.skipped)||typeof result.seconds!=="number")return"corrupt";
 const {sum,...body}=record;
 if(sumOf(body)!==sum)return"corrupt";
 return record.key===key?record:"key-mismatch";
}

const withTimeout=async<T>(work:(signal:AbortSignal)=>Promise<T>,milliseconds:number):Promise<T>=>{
 const control=new AbortController();let timer:ReturnType<typeof setTimeout>|undefined;
 try{return await Promise.race([work(control.signal),new Promise<never>((_,reject)=>{timer=setTimeout(()=>{control.abort();reject(Error("verdict store timeout"));},milliseconds);})]);}
 finally{if(timer!==undefined)clearTimeout(timer);}
};

/** 🔍️ Looks a key up: a stored verdict is a hit only when it decodes, belongs to the key, passed with at least one test and no failure, and is younger than the maximum age; an opt-out, a failed record, a damaged record or an unreachable store is a miss with its reason (the caller then runs the test). Never throws. */
export async function lookupVerdictReuseV1(input:Readonly<{key:string;port:VerdictCachePortV1;optOut?:boolean;now?:()=>number;policy?:VerdictReusePolicyV1}>):Promise<VerdictReuseLookupV1>{
 const policy=input.policy??VERDICT_REUSE_POLICY_V1,now=(input.now??Date.now)();
 if(input.optOut)return{kind:"miss",reason:"opted-out"};
 let bytes:Uint8Array|undefined;
 try{bytes=await withTimeout(signal=>input.port.read(verdictReuseAddressV1(input.key,policy),signal),policy.storeTimeoutMs);}catch{return{kind:"miss",reason:"store-down"};}
 if(bytes===undefined)return{kind:"miss",reason:"absent"};
 const record=decodeVerdictReuseRecordV1(bytes,input.key);
 if(typeof record==="string")return{kind:"miss",reason:record};
 if(record.result.fail!==0)return{kind:"miss",reason:"not-passed"};
 if(record.result.pass<1)return{kind:"miss",reason:"empty"};
 const ageMs=Math.max(0,now-record.at);
 return ageMs>policy.maximumAgeMs?{kind:"miss",reason:"expired"}:{kind:"hit",record,ageMs};
}

/** 💾️ Stores a passed result under its key; a failed, skipped or empty result is never stored. A store that is down or too slow is reported and never blocks. */
export async function storeVerdictReuseV1(input:Readonly<{key:string;file:string;origin:string;row:VerdictReuseRowV1&Readonly<{skipped?:number}>;port:VerdictCachePortV1;now?:()=>number;policy?:VerdictReusePolicyV1}>):Promise<Readonly<{kind:"stored"}|{kind:"skipped";reason:"not-passed"|"empty"|"store-down"}>>{
 const policy=input.policy??VERDICT_REUSE_POLICY_V1,row=input.row;
 if(row.status!=="passed"||(row.fail??0)!==0)return{kind:"skipped",reason:"not-passed"};
 if((row.pass??0)<1)return{kind:"skipped",reason:"empty"};
 const bytes=encodeVerdictReuseRecordV1({key:input.key,file:input.file,at:(input.now??Date.now)(),origin:input.origin,result:{pass:row.pass!,fail:0,skipped:row.skipped??0,seconds:Math.round(row.seconds*100)/100}});
 try{await withTimeout(signal=>input.port.write(verdictReuseAddressV1(input.key,policy),bytes,signal),policy.storeTimeoutMs);return{kind:"stored"};}catch{return{kind:"skipped",reason:"store-down"};}
}

/** ♻️ Runs a test file unless an unchanged passed verdict exists: the key is computed before the run (an ineligible test just runs), a hit returns the stored result without calling `run`, a miss runs and stores the verdict only when it passed and the key computed again after the run is still the same (a file edited during the run is never filed under the old key). A failed verdict is never reused. */
export async function reuseOrRunV1<Row extends VerdictReuseRowV1>(input:Readonly<{file:string;keyOf:()=>VerdictReuseKeyV1;port:VerdictCachePortV1;origin:string;optOut?:boolean;now?:()=>number;policy?:VerdictReusePolicyV1;run:()=>Promise<Row>}>):Promise<Readonly<{kind:"reused";record:VerdictReuseRecordV1;ageMs:number;key:string}>|Readonly<{kind:"ran";row:Row;miss:VerdictReuseMissV1;stored:boolean;key?:string}>>{
 const before=input.keyOf();
 if(before.kind==="ineligible")return{kind:"ran",row:await input.run(),miss:before.reason,stored:false};
 const found=await lookupVerdictReuseV1({key:before.key,port:input.port,...input.optOut?{optOut:true}:{},...input.now?{now:input.now}:{},...input.policy?{policy:input.policy}:{}});
 if(found.kind==="hit")return{kind:"reused",record:found.record,ageMs:found.ageMs,key:before.key};
 const row=await input.run(),after=input.keyOf();
 if(after.kind!=="key"||after.key!==before.key)return{kind:"ran",row,miss:found.reason,stored:false,key:before.key};
 const stored=await storeVerdictReuseV1({key:before.key,file:input.file,origin:input.origin,row,port:input.port,...input.now?{now:input.now}:{},...input.policy?{policy:input.policy}:{}});
 return{kind:"ran",row,miss:found.reason,stored:stored.kind==="stored",key:before.key};
}

/** 🗄️ A verdict cache port over a directory (the machine hot cache and the test double of the fleet cache): two level fan-out by address, atomic writes (temporary file then rename). The fleet adapter has the same two functions over the action cache, the way the checkout test chunks are carried (`stderr_raw` of an action result under the address). */
export function createDirectoryVerdictCachePortV1(directory:string):VerdictCachePortV1{
 const path=(hash:string)=>join(directory,hash.slice(0,2),hash);
 return Object.freeze({
  read:async hash=>{try{return readFileSync(path(hash));}catch{return undefined;}},
  write:async(hash,bytes)=>{const target=path(hash);mkdirSync(dirname(target),{recursive:true});const temporary=`${target}.${process.pid}.tmp`;writeFileSync(temporary,bytes);renameSync(temporary,target);},
 });
}

const fill=(template:string,values:Readonly<Record<string,string|number>>)=>template.replace(/\{(\w+)\}/gu,(_,name:string)=>String(values[name]??""));

/** 🖨️ The one line that tells an agent what happened: `reused passed verdict of <file> from <host>, 2 min 05 s old (key abcdef012345)`, or the reason a test had to run. */
export function renderVerdictReuseV1(language:VerdictReuseLanguageV1,file:string,outcome:Readonly<{kind:"reused";record:VerdictReuseRecordV1;ageMs:number}>|Readonly<{kind:"miss";reason:VerdictReuseMissV1}>,policy:VerdictReusePolicyV1=VERDICT_REUSE_POLICY_V1):string{
 if(outcome.kind==="reused")return fill(texts.reused![language],{file,origin:outcome.record.origin,age:progressDurationTextV1(language,outcome.ageMs),key:outcome.record.key.slice(0,12)});
 return fill(texts[`miss.${outcome.reason}`]![language],{file,age:progressDurationTextV1(language,policy.maximumAgeMs)});
}

