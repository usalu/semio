/** 🖥️ `ModelStage`: the interactive 3D view of one asset as plain DOM — a toolbar, the owned WebGL2 `ModelViewer` on a canvas, a progress bar with cancel while the model is prepared, and the notes and alerts that say what is going on. The React figure and the `<staffage-figure>` element both mount this one class, so they behave and read the same.
 *
 * The stage follows its options: the representation is a variant of the model, the pose or clip and the scale decide which model is built (see {@link ../🟦️.ts}), the camera is a preset the reader can leave by orbiting, the environment and analytic settings colour the thermal and force variants. Time is never the stage's own: the shared {@link StaffageClock} drives the viewer (play, pause, scrub and rate stay the one transport of the 2D drawing), and Space on the canvas toggles that clock.
 * Where WebGL2 is missing or the context cannot be restored the viewer draws in software and says so; a model that cannot be shown is explained in an alert, never a blank box.
 *
 * Accessibility: native buttons with names and a visible focus ring, `aria-pressed` presets, a canvas with role, name, instructions and a translated text alternative of the state (asset, pose or clip, representation, scale, camera), polite status and live regions. Customisation: the custom properties `--staffage-model-background`, `--staffage-model-foreground`, `--staffage-model-border`, `--staffage-model-accent`, `--staffage-model-focus`, `--staffage-model-panel`, `--staffage-model-min-height` and `--staffage-model-target` (the minimum size of a control); the picture's own colour is read by the viewer, so give a colour as hex, `rgb()` or `rgba()`. Forced colours, increased contrast and reduced motion are honoured.
 *
 * @see ../🏭️prepare/🟦️.ts — the model pipeline
 * @see ../../../../../../../🧰️framework/🔨️modules/🧊️3d/🗿️model/🖥️viewer/🕹️controller/🟦️.ts — the viewer
 */
import { ModelViewer, PRESETS, projectionMatrix, viewMatrix, type BackendFactory, type CameraPreset, type ViewerStatus } from "../../../../../../../../🧰️framework/🔨️modules/🧊️3d/🗿️model/🖥️viewer/🟦️.ts";
import type { Asset, FlowField, Language, View } from "@teaching/staffage";
import { CSS_PX_PER_MM, VIEWS, authoredScales, modeOf } from "@teaching/staffage";
import type { StaffageClock } from "../../⏱️clock/🧱️core/🟦️.ts";
import { translator, type Key } from "../../🌐️i18n/🟦️.ts";
import { VIEW_NAMES } from "../../🗣️labels/🟦️.ts";
import { PREPARE_PHASES, phaseStart, prepareModel, type PreparePhase } from "../🏭️prepare/🟦️.ts";
import { flowsIn } from "../../🌊️flow/🟦️.ts";
import type { FlowProjection } from "../../🌊️flow/🖌️overlay/🟦️.ts";
import { FlowStage } from "../../🌊️flow/🖥️stage/🟦️.ts";
import { CAMERA_PRESETS, describeModel, modelKey, sceneOf, scaleChoices, variantOf, type CameraPresetName, type ScaleChoice, type SpatialRequest } from "../🟦️.ts";

/** 🧾️ Where the stage is: nothing yet, preparing the model, showing it, cancelled by the reader, failed, or refused because the asset has no 3D model at the requested scale (no authored volume there; no other scale stands in). */
export type StagePhase = "idle" | "preparing" | "ready" | "cancelled" | "error" | "unavailable";

/** 📤️ What a stage reports about itself. */
export type StageState = { readonly phase: StagePhase; readonly backend: "webgl2" | "software" | "none"; readonly fraction: number; readonly message: string };

/** ⚙️ What a stage shows and how it behaves. */
export type StageOptions = SpatialRequest & {
  readonly asset: Asset;
  readonly clock?: StaffageClock | null;
  readonly preset: CameraPresetName;
  readonly background?: string | null;
  readonly toolbar?: boolean;
  readonly framed?: boolean;
  readonly reducedMotion?: boolean;
  readonly onPreset?: (preset: CameraPresetName) => void;
  readonly onScale?: (scale: number) => void;
  readonly onView?: (view: View) => void;
  readonly onState?: (state: StageState) => void;
  readonly onFlow?: (flow: FlowField | null) => void;
  readonly backend?: BackendFactory;
  readonly settleMs?: number;
  readonly restoreMs?: number;
};

/** 🔭️ How far the camera steps back when the air flow is first shown over a model (a zoom factor below 1), so the air around and above the asset is in the picture. */
export const FLOW_ZOOM = 0.42;

/** 🔎️ The size of the flow marks of the 3D view relative to their paper size at print zoom. */
export const FLOW_MARK_SCALE = 1.5;

const STYLE = `
.semio-stage{--semio-edge:var(--staffage-model-border,currentColor);position:relative;display:flex;flex-direction:column;gap:0;box-sizing:border-box;inline-size:100%;block-size:100%;min-block-size:var(--staffage-model-min-height,18rem);color:var(--staffage-model-foreground,inherit);font:inherit;font-size:.8125rem}
.semio-stage *{box-sizing:border-box}
.semio-stage[data-framed]{border:1px solid var(--semio-edge)}
.semio-stage-row{display:flex;flex-wrap:wrap;align-items:stretch;clip-path:inset(1px 0 0 1px)}
.semio-stage-block:not([hidden])~.semio-stage-row{clip-path:inset(0 0 0 1px)}
.semio-stage-block:not([hidden])~.semio-stage-view{border-block-start:1px solid var(--semio-edge)}
.semio-stage-group{display:flex;flex:1 1 auto;flex-wrap:wrap}
.semio-stage-row>:is(button,.semio-stage-cell),.semio-stage-group>button{flex:1 1 auto;margin:0;border:0;border-inline-start:1px solid var(--semio-edge);border-block-start:1px solid var(--semio-edge);border-radius:0}
.semio-stage-group:empty{display:none}
.semio-stage button{min-block-size:var(--staffage-model-target,1.75rem);min-inline-size:var(--staffage-model-target,1.75rem);padding:.125rem .625rem;background:var(--staffage-model-panel,transparent);color:inherit;font:inherit;cursor:pointer}
.semio-stage-cell{display:flex;align-items:center;padding:.375rem .5rem;background:var(--staffage-model-panel,transparent)}
.semio-stage button:hover{background:color-mix(in srgb,var(--staffage-model-accent,currentColor) 18%,transparent)}
.semio-stage button[aria-disabled="true"]{opacity:.65;cursor:not-allowed}
.semio-stage button[aria-pressed="true"]{background:var(--staffage-model-accent,Highlight);color:var(--staffage-model-accent-foreground,HighlightText);font-weight:600}
.semio-stage button:focus-visible,.semio-stage canvas:focus-visible{outline:2px solid var(--staffage-model-focus,var(--staffage-model-accent,Highlight));outline-offset:-2px}
.semio-stage-view{position:relative;flex:1 1 auto;min-block-size:12rem;background:var(--staffage-model-background,transparent)}
.semio-stage[data-ground="transparent"] .semio-stage-view{background-color:#fff;background-image:conic-gradient(#c9c9c9 25%,transparent 0 50%,#c9c9c9 0 75%,transparent 0);background-size:16px 16px}
.semio-stage canvas{display:block;inline-size:100%;block-size:100%;min-block-size:12rem;outline:none;--semio-viewer-background:var(--staffage-model-background,#f7f3e3)}
.semio-stage-progress{align-items:stretch}
.semio-stage-progress .semio-stage-cell:first-child{flex:1 1 8rem}
.semio-stage-progress progress{flex:1 1 auto;min-inline-size:6rem;block-size:.5rem;accent-color:var(--staffage-model-accent,Highlight)}
.semio-stage-notice b{display:block}
.semio-stage-note{margin:0;padding:.375rem .5rem 0;font-size:.75rem;opacity:.85}
.semio-stage [hidden]{display:none!important}
.semio-stage .semio-sr{position:absolute;inline-size:1px;block-size:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;border:0}
@media (prefers-contrast:more){.semio-stage{--semio-edge:CanvasText}}
@media (prefers-reduced-motion:reduce){.semio-stage *{transition:none!important;animation:none!important}}
@media (forced-colors:active){.semio-stage button[aria-pressed="true"]{forced-color-adjust:none;background:Highlight;color:HighlightText}.semio-stage{--semio-edge:CanvasText}.semio-stage canvas:focus-visible,.semio-stage button:focus-visible{outline-color:Highlight}}
`;

const ZOOM_STEP = 1.25;
let counter = 0;
const adopted = new WeakMap<Document | ShadowRoot, CSSStyleSheet>();

/** 🎨️ Gives the stage its style: one constructable stylesheet adopted by the document or shadow root the stage lives in (a Content-Security-Policy that forbids inline `<style>` elements, like the site's release policy, does not block it); where the platform has none, a `<style>` element in the stage. */
function styled(host: HTMLElement, root: HTMLElement): void {
  const scope = host.getRootNode();
  const container = scope instanceof ShadowRoot || scope instanceof Document ? scope : null;
  if (container !== null && "adoptedStyleSheets" in container && typeof CSSStyleSheet === "function" && "replaceSync" in CSSStyleSheet.prototype) {
    let sheet = adopted.get(container);
    if (sheet === undefined) {
      sheet = new CSSStyleSheet();
      sheet.replaceSync(STYLE);
      adopted.set(container, sheet);
    }
    if (!container.adoptedStyleSheets.includes(sheet)) container.adoptedStyleSheets = [...container.adoptedStyleSheets, sheet];
    return;
  }
  const style = root.ownerDocument.createElement("style");
  style.textContent = STYLE;
  root.prepend(style);
}

const presetOfCamera = (camera: { yaw: number; pitch: number; projection: string }): CameraPresetName | null =>
  CAMERA_PRESETS.find((name) => Math.abs(PRESETS[name].yaw - camera.yaw) < 1e-6 && Math.abs(PRESETS[name].pitch - camera.pitch) < 1e-6 && PRESETS[name].projection === camera.projection) ?? null;

const isAbort = (error: unknown): boolean => (error instanceof DOMException && error.name === "AbortError") || (error instanceof Error && error.name === "AbortError");

/** 🌟️ The stage. Construct it over an empty host element, call {@link ModelStage.update} when options change and {@link ModelStage.dispose} when done. */
export class ModelStage {
  readonly #host: HTMLElement;
  readonly #root: HTMLElement;
  readonly #view: HTMLElement;
  readonly #bar: HTMLElement;
  readonly #scales: HTMLElement;
  readonly #modes: HTMLElement;
  readonly #presets: HTMLElement;
  readonly #hints: HTMLElement;
  readonly #announce: HTMLElement;
  readonly #progress: HTMLElement;
  readonly #bar2: HTMLProgressElement;
  readonly #progressText: HTMLElement;
  readonly #notice: HTMLElement;
  readonly #note: HTMLElement;
  readonly #description: HTMLElement;
  readonly #id = `semio-stage-${++counter}`;
  #options: StageOptions;
  #viewer: ModelViewer | null = null;
  #canvas: HTMLCanvasElement | null = null;
  #unsubscribe: (() => void) | null = null;
  #clock: StaffageClock | null = null;
  #job: AbortController | null = null;
  #timer: ReturnType<typeof setTimeout> | null = null;
  #lostTimer: ReturnType<typeof setTimeout> | null = null;
  #software = false;
  #loaded = "";
  #requested = "";
  #noticeKey = "";
  #phase: StagePhase = "idle";
  #fraction = 0;
  #message = "";
  #wanted: CameraPresetName | null = null;
  #shown: CameraPresetName | null = null;
  #variant = "";
  #scene = "";
  #selection = "";
  #disposed = false;
  #ready = false;
  #flow: FlowStage | null = null;
  #flowFramed = "";
  readonly #matrices = { view: new Float32Array(16), projection: new Float32Array(16) };

  constructor(host: HTMLElement, options: StageOptions) {
    this.#host = host;
    this.#options = options;
    const doc = host.ownerDocument;
    const make = <K extends keyof HTMLElementTagNameMap>(tag: K, className: string, parent: HTMLElement): HTMLElementTagNameMap[K] => {
      const element = doc.createElement(tag);
      element.className = className;
      parent.append(element);
      return element;
    };
    this.#root = doc.createElement("div");
    this.#root.className = "semio-stage";
    this.#root.setAttribute("part", "stage");
    this.#root.setAttribute("data-model-stage", "");
    this.#bar = make("div", "semio-stage-block semio-stage-row semio-stage-bar", this.#root);
    this.#bar.setAttribute("part", "toolbar");
    this.#bar.setAttribute("role", "group");
    this.#scales = make("div", "semio-stage-group", this.#bar);
    this.#scales.setAttribute("role", "group");
    this.#scales.setAttribute("data-group", "scale");
    this.#modes = make("div", "semio-stage-group", this.#bar);
    this.#modes.setAttribute("role", "group");
    this.#modes.setAttribute("data-group", "mode");
    this.#presets = make("div", "semio-stage-group", this.#bar);
    this.#presets.setAttribute("role", "group");
    this.#view = make("div", "semio-stage-block semio-stage-view", this.#root);
    this.#progress = make("div", "semio-stage-block semio-stage-row semio-stage-progress", this.#root);
    this.#bar2 = make("progress", "", make("div", "semio-stage-cell", this.#progress));
    this.#bar2.max = 100;
    this.#progressText = make("span", "semio-stage-cell", this.#progress);
    this.#notice = make("div", "semio-stage-block semio-stage-row semio-stage-notice", this.#root);
    this.#note = make("p", "semio-stage-note", this.#root);
    this.#note.setAttribute("role", "status");
    this.#description = make("div", "semio-sr", this.#root);
    this.#description.id = `${this.#id}-state`;
    this.#hints = make("div", "semio-sr", this.#root);
    this.#announce = make("div", "semio-sr", this.#root);
    this.#announce.setAttribute("role", "status");
    this.#announce.setAttribute("aria-live", "polite");
    this.#announce.setAttribute("data-announce", "");
    this.#buildBar();
    host.replaceChildren(this.#root);
    styled(host, this.#root);
    this.#bindClock(options.clock ?? null);
    this.#mountViewer();
    this.#refresh();
    this.#requested = modelKey(options.asset, options);
    this.#schedule(0);
  }

  /** 🧭️ The state of the stage. */
  get state(): StageState {
    return { phase: this.#phase, backend: this.#viewer === null ? "none" : this.#viewer.backendKind === "webgl2" ? "webgl2" : "software", fraction: this.#fraction, message: this.#message };
  }

  /** 👁️ The viewer, once mounted (tests and hosts that want its events). */
  get viewer(): ModelViewer | null {
    return this.#viewer;
  }

  /** 🔄️ Applies changed options: the representation and the camera at once, a new model after a short settle (so dragging a slider does not build a model per tick). */
  update(patch: Partial<StageOptions>): void {
    if (this.#disposed) return;
    const before = this.#options;
    const next = { ...before, ...patch } as StageOptions;
    this.#options = next;
    if (next.clock !== before.clock) this.#bindClock(next.clock ?? null);
    if (next.language !== before.language) {
      this.#buildBar();
      this.#mountViewer();
      this.#loaded = "";
      this.#requested = "";
    }
    const key = modelKey(next.asset, next);
    if (this.#phase === "unavailable" && this.#loaded === "" && authoredScales(next.asset.volumes).includes(next.scale)) {
      this.#requested = key;
      this.#schedule(0);
    } else if (key !== this.#requested) {
      this.#requested = key;
      this.#schedule(this.#loaded === "" ? 0 : (next.settleMs ?? 200));
    }
    this.#applyLook();
    this.#refresh();
    this.#syncFlow();
  }

  /** 🛑️ Cancels a running preparation; the stage says so and offers a retry. */
  cancel(): void {
    if (this.#phase !== "preparing") return;
    const job = this.#job;
    this.#job = null;
    job?.abort();
    this.#viewer?.cancelPreparation();
    this.#ready = this.#loaded !== "";
    this.#set("cancelled", 0, "");
  }

  /** 🔁️ Prepares the model again after a cancellation or a failure. */
  retry(): void {
    this.#schedule(0);
  }

  /** 🧹️ Stops everything and empties the host. */
  dispose(): void {
    this.#disposed = true;
    this.#job?.abort();
    this.#job = null;
    if (this.#timer !== null) clearTimeout(this.#timer);
    if (this.#lostTimer !== null) clearTimeout(this.#lostTimer);
    this.#unsubscribe?.();
    this.#unsubscribe = null;
    this.#flow?.dispose();
    this.#flow = null;
    this.#viewer?.dispose();
    this.#viewer = null;
    this.#host.replaceChildren();
  }

  get #t() {
    const t = translator(this.#options.language);
    return (key: Key, params?: Record<string, string | number>): string => t(key, params);
  }

  #buildBar(): void {
    const t = this.#t;
    const doc = this.#host.ownerDocument;
    this.#root.setAttribute("lang", this.#options.language);
    this.#bar.setAttribute("aria-label", t("model.toolbar"));
    this.#presets.setAttribute("aria-label", t("model.camera"));
    this.#scales.setAttribute("aria-label", t("model.scale"));
    this.#scales.title = t("model.scaleHelp");
    this.#modes.setAttribute("aria-label", t("model.mode"));
    this.#modes.title = t("model.modeHelp");
    this.#hints.replaceChildren();
    this.#scales.replaceChildren(
      ...scaleChoices(this.#options.asset, this.#options.language).map((choice) => {
        const button = doc.createElement("button");
        button.type = "button";
        button.textContent = `1:${choice.scale}`;
        button.setAttribute("data-scale", String(choice.scale));
        button.addEventListener("click", () => this.#pickScale(choice));
        button.addEventListener("keydown", (event) => this.#arrow(event, this.#scales));
        if (!choice.available) {
          const hint = doc.createElement("span");
          hint.id = `${this.#id}-scale-${choice.scale}`;
          hint.textContent = t("model.scaleUnavailable", { scale: choice.scale, reason: choice.reason });
          this.#hints.append(hint);
          button.setAttribute("aria-disabled", "true");
          button.setAttribute("data-unavailable", "");
          button.setAttribute("aria-describedby", hint.id);
          button.title = hint.textContent;
        }
        return button;
      }),
    );
    this.#modes.replaceChildren(
      ...VIEWS.map((view) => {
        const button = doc.createElement("button");
        button.type = "button";
        button.textContent = VIEW_NAMES[view][this.#options.language];
        button.title = `${button.textContent} · ${t(`model.mode.${modeOf(view)}` as Key)}`;
        button.setAttribute("data-view", view);
        button.addEventListener("click", () => this.#pickView(view));
        button.addEventListener("keydown", (event) => this.#arrow(event, this.#modes));
        return button;
      }),
    );
    this.#markChoices();
    this.#presets.replaceChildren(
      ...CAMERA_PRESETS.map((name) => {
        const button = doc.createElement("button");
        button.type = "button";
        button.textContent = t(`model.camera.${name}` as Key);
        button.setAttribute("data-preset", name);
        button.setAttribute("aria-pressed", String(this.#shown === name));
        button.addEventListener("click", () => this.#choose(name));
        return button;
      }),
    );
    for (const old of this.#bar.querySelectorAll("[data-action]")) old.remove();
    const action = (name: "zoom-out" | "zoom-in" | "reset", label: string, text: string, run: () => void): void => {
      const button = doc.createElement("button");
      button.type = "button";
      button.setAttribute("data-action", name);
      button.setAttribute("aria-label", label);
      button.title = label;
      button.textContent = text;
      button.addEventListener("click", run);
      this.#bar.append(button);
    };
    action("zoom-out", t("model.zoomOut"), "−", () => this.#viewer?.zoomBy(1 / ZOOM_STEP));
    action("zoom-in", t("model.zoomIn"), "+", () => this.#viewer?.zoomBy(ZOOM_STEP));
    action("reset", t("model.reset"), "⟲", () => this.#reset());
    const cancel = this.#progress.querySelector("button");
    cancel?.remove();
    const button = doc.createElement("button");
    button.type = "button";
    button.setAttribute("data-action", "cancel");
    button.textContent = t("model.cancel");
    button.addEventListener("click", () => this.cancel());
    this.#progress.append(button);
    this.#bar2.setAttribute("aria-label", t("model.progress"));
    this.#noticeKey = "";
  }

  #pickScale(choice: ScaleChoice): void {
    if (!choice.available) {
      this.#announce.textContent = this.#t("model.scaleUnavailable", { scale: choice.scale, reason: choice.reason });
      return;
    }
    this.#announce.textContent = "";
    this.update({ scale: choice.scale });
    this.#options.onScale?.(choice.scale);
  }

  #pickView(view: View): void {
    this.#announce.textContent = "";
    this.update({ view });
    this.#options.onView?.(view);
  }

  #arrow(event: KeyboardEvent, group: HTMLElement): void {
    const buttons = [...group.querySelectorAll("button")];
    const at = buttons.indexOf(event.currentTarget as HTMLButtonElement);
    const last = buttons.length - 1;
    const to = event.key === "ArrowRight" || event.key === "ArrowDown" ? (at + 1) % buttons.length : event.key === "ArrowLeft" || event.key === "ArrowUp" ? (at + last) % buttons.length : event.key === "Home" ? 0 : event.key === "End" ? last : -1;
    if (to < 0) return;
    event.preventDefault();
    event.stopPropagation();
    buttons[to]?.focus();
  }

  #markChoices(): void {
    for (const button of this.#scales.querySelectorAll("button")) button.setAttribute("aria-pressed", String(button.getAttribute("data-scale") === String(this.#options.scale)));
    for (const button of this.#modes.querySelectorAll("button")) button.setAttribute("aria-pressed", String(button.getAttribute("data-view") === this.#options.view));
  }

  #choose(name: CameraPresetName): void {
    this.#wanted = name;
    this.#applyPreset(name);
    this.#options.onPreset?.(name);
  }

  #reset(): void {
    const preset = this.#wanted ?? this.#options.preset;
    this.#viewer?.setPreset(preset as CameraPreset);
    this.#shown = preset;
    this.#markPresets();
  }

  #applyPreset(name: CameraPresetName): void {
    if (this.#viewer === null || !this.#ready) return;
    this.#viewer.setPreset(name as CameraPreset);
    this.#shown = name;
    this.#markPresets();
  }

  #markPresets(): void {
    for (const button of this.#presets.querySelectorAll("button")) button.setAttribute("aria-pressed", String(button.getAttribute("data-preset") === this.#shown));
  }

  #bindClock(clock: StaffageClock | null): void {
    this.#unsubscribe?.();
    this.#unsubscribe = null;
    this.#clock = clock;
    this.#unsubscribe = clock?.subscribe(() => this.#tick()) ?? null;
  }

  #timeS(): number {
    const clock = this.#clock;
    if (clock !== null) return clock.state.frame / clock.state.fps;
    return this.#options.query.kind === "clip" ? this.#options.query.timeS : 0;
  }

  #tick(): void {
    if (this.#disposed || !this.#ready || this.#viewer === null || this.#options.query.kind !== "clip") return;
    this.#viewer.seek(this.#timeS());
    if (this.#clock?.state.playing !== true) this.#refresh();
  }

  #mountViewer(): void {
    const doc = this.#host.ownerDocument;
    this.#flow?.dispose();
    this.#flow = null;
    this.#viewer?.dispose();
    this.#view.replaceChildren();
    this.#ready = false;
    const canvas = doc.createElement("canvas");
    this.#canvas = canvas;
    this.#view.append(canvas);
    const t = this.#t;
    const options = this.#options;
    const name = (key: "camera" | "view" | "clip" | "pose", id: string): string =>
      key === "camera" ? t(`model.camera.${id}` as Key) : key === "view" ? (VIEW_NAMES[id as keyof typeof VIEW_NAMES]?.[options.language] ?? id) : key === "clip" ? (this.#options.asset.clips.find((clip) => clip.id === id)?.title[options.language] ?? id) : (this.#options.asset.poses.find((pose) => pose.id === id)?.title[options.language] ?? id);
    const status = (s: ViewerStatus): string => {
      switch (s.kind) {
        case "ready": return t("model.status.ready");
        case "preset": return t("model.status.preset", { camera: name("camera", s.preset) });
        case "fit": return t("model.status.fit");
        case "playing": return t("model.status.playing");
        case "paused": return t("model.status.paused");
        case "scene": {
          const found = /^s(\d+)-(body|thermal|structure)$/u.exec(s.scene);
          return found === null ? s.scene : t("model.status.scene", { scale: Number(found[1]), mode: t(`model.mode.${found[2] as "body"}` as Key), representation: name("view", this.#options.view) });
        }
        case "variant": return s.variant === null ? "" : t("model.status.variant", { representation: name("view", s.variant) });
        case "animation": return s.animation === null ? "" : t("model.status.animation", { clip: name("clip", s.animation) });
        case "pose": return s.pose === null ? "" : t("model.status.pose", { pose: name("pose", s.pose) });
        case "orbit": return t("model.status.orbit");
        case "pan": return t("model.status.pan");
        case "zoom": return t("model.status.zoom");
      }
    };
    if (options.background === undefined) canvas.style.removeProperty("--semio-viewer-background");
    const viewer = new ModelViewer({
      canvas,
      strings: { label: t("model.label", { title: options.asset.title[options.language] }), roleDescription: t("model.roleDescription"), description: t("model.instructions"), status },
      ...(this.#software ? { backend: () => { throw new Error("software"); } } : options.backend === undefined ? {} : { backend: options.backend }),
      fallback: true,
      background: null,
      autoplay: false,
      preset: this.#shown ?? options.preset,
      ...(options.reducedMotion === undefined ? {} : { reducedMotion: options.reducedMotion }),
    });
    this.#viewer = viewer;
    this.#applyBackground();
    viewer.on("camera", ({ camera }) => {
      if (!this.#ready) return;
      const found = presetOfCamera(camera);
      this.#shown = found;
      this.#markPresets();
      if (found !== null && found !== this.#wanted) {
        this.#wanted = found;
        this.#options.onPreset?.(found);
      }
      this.#refresh();
      this.#flow?.redraw();
    });
    viewer.on("backend", ({ status: state }) => this.#backend(state));
    viewer.on("issues", () => this.#note.setAttribute("data-issues", ""));
    viewer.on("error", ({ error }) => this.#fail(error));
    viewer.on("ready", () => {
      this.#ready = true;
      this.#syncFlow();
    });
    this.#view.addEventListener(
      "keydown",
      (event) => {
        if (event.key !== " " || this.#clock === null || this.#options.query.kind !== "clip") return;
        event.preventDefault();
        event.stopPropagation();
        this.#clock.toggle();
      },
      true,
    );
    canvas.setAttribute("aria-describedby", `${canvas.getAttribute("aria-describedby") ?? ""} ${this.#description.id}`.trim());
    this.#refresh();
  }

  /** 🌊️ The projection of a staffage world point (ahead x, up y, left z) through the viewer's camera to the pixels of the stage view; marks keep their paper size at print zoom. */
  #projection(): FlowProjection | null {
    const viewer = this.#viewer;
    const canvas = this.#canvas;
    if (viewer === null || canvas === null || !this.#ready || canvas.clientWidth === 0 || canvas.clientHeight === 0) return null;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    const camera = viewer.getCamera();
    const view = viewMatrix(camera, this.#matrices.view) as Float32Array;
    const projection = projectionMatrix(camera, width / height, this.#matrices.projection) as Float32Array;
    return {
      pxPerMm: CSS_PX_PER_MM * FLOW_MARK_SCALE,
      project: (at, out) => {
        const x = at.z, y = at.y, z = at.x;
        const ex = view[0]! * x + view[4]! * y + view[8]! * z + view[12]!;
        const ey = view[1]! * x + view[5]! * y + view[9]! * z + view[13]!;
        const ez = view[2]! * x + view[6]! * y + view[10]! * z + view[14]!;
        const w = projection[11]! * ez + projection[15]!;
        if (w <= 1e-6) return false;
        out[0] = ((projection[0]! * ex) / w / 2 + 0.5) * width;
        out[1] = (0.5 - (projection[5]! * ey) / w / 2) * height;
        return true;
      },
    };
  }

  /** 🌊️ Mounts, updates or removes the air flow layer: it belongs to the thermal view of an asset that moves air and is shown once the model is. */
  #syncFlow(): void {
    const options = this.#options;
    const layers = options.flow ?? [];
    const wanted = !this.#disposed && this.#ready && layers.length > 0 && flowsIn(options.asset, options.view) && options.query.kind !== "transition";
    if (!wanted) {
      if (this.#flow !== null) options.onFlow?.(null);
      this.#flow?.dispose();
      this.#flow = null;
      return;
    }
    const flowOptions = { asset: options.asset, query: options.query, environment: options.environment ?? options.asset.thermal.environment, clock: this.#clock, layers, theme: options.theme ?? "light", range: options.range ?? ({ mode: "auto" } as const), scale: options.scale, language: options.language, projection: () => this.#projection(), ...(options.onFlow === undefined ? {} : { onFlow: options.onFlow }) };
    if (this.#flow === null) {
      this.#flow = new FlowStage(this.#view, flowOptions);
      if (this.#flowFramed !== this.#loaded) {
        this.#flowFramed = this.#loaded;
        this.#viewer?.zoomBy(FLOW_ZOOM);
      }
    } else this.#flow.update(flowOptions);
  }

  #backend(status: "ready" | "lost" | "restored"): void {
    const t = this.#t;
    if (this.#lostTimer !== null) clearTimeout(this.#lostTimer);
    this.#lostTimer = null;
    if (status === "lost") {
      this.#note.textContent = t("model.contextLost");
      this.#lostTimer = setTimeout(() => this.#toSoftware(), this.#options.restoreMs ?? 4000);
    } else if (status === "restored") this.#note.textContent = t("model.contextRestored");
    else this.#refresh();
  }

  #toSoftware(): void {
    if (this.#disposed || this.#software) return;
    this.#software = true;
    this.#mountViewer();
    this.#note.textContent = this.#t("model.contextSwitched");
    this.#loaded = "";
    this.#schedule(0);
  }

  #schedule(delayMs: number): void {
    if (this.#timer !== null) clearTimeout(this.#timer);
    this.#timer = setTimeout(() => {
      this.#timer = null;
      void this.#prepare();
    }, delayMs);
  }

  async #prepare(): Promise<void> {
    if (this.#disposed || this.#viewer === null) return;
    const options = this.#options;
    const asset = options.asset;
    const t = this.#t;
    if (authoredScales(asset.volumes).length === 0) return this.#set("unavailable", 0, t("model.noVolume"));
    if (!authoredScales(asset.volumes).includes(options.scale)) return this.#set("unavailable", 0, t("model.noScale", { scale: String(options.scale), scales: authoredScales(asset.volumes).map((s) => `1:${s}`).join(", ") }));
    if (options.query.kind === "transition") return this.#set("unavailable", 0, t("model.noVolume"));
    const key = modelKey(asset, options);
    if (key === this.#loaded && this.#phase === "ready") return;
    this.#job?.abort();
    this.#viewer.cancelPreparation();
    const job = new AbortController();
    this.#job = job;
    this.#ready = false;
    this.#set("preparing", 0, "");
    try {
      const document = await prepareModel(asset, options, { signal: job.signal, progress: (fraction, phase) => this.#advance(job, fraction, phase) });
      if (this.#job !== job) return;
      const viewer = this.#viewer;
      if (viewer === null) return;
      let scene = false;
      const stop = viewer.on("progress", ({ fraction }) => this.#advance(job, phaseStart("scene") + 0.15 * fraction, "scene"));
      const ready = viewer.on("ready", () => (scene = true));
      try {
        await viewer.setDocument(document, job.signal);
      } finally {
        stop();
        ready();
      }
      if (this.#job !== job || !scene) return;
      this.#job = null;
      this.#loaded = key;
      this.#variant = "";
      this.#scene = "";
      this.#selection = "";
      this.#wanted = options.preset;
      this.#shown = null;
      this.#set("ready", 1, "");
      this.#applyLook(true);
      this.#refresh();
    } catch (error) {
      if (this.#job !== job) return;
      this.#job = null;
      this.#ready = this.#loaded !== "";
      if (isAbort(error)) return this.#set("cancelled", 0, "");
      this.#fail(error);
    }
  }

  #advance(job: AbortController, fraction: number, phase: PreparePhase): void {
    if (this.#job !== job) return;
    this.#set("preparing", fraction, this.#t(`model.phase.${phase}` as Key));
  }

  #fail(error: unknown): void {
    this.#viewer?.cancelPreparation();
    this.#set("error", 0, error instanceof Error ? error.message : String(error));
  }

  #applyBackground(): void {
    const canvas = this.#canvas;
    if (canvas === null) return;
    const { background } = this.#options;
    if (background === undefined || background === null) canvas.style.removeProperty("--semio-viewer-background");
    else canvas.style.setProperty("--semio-viewer-background", background);
    this.#root.setAttribute("data-ground", background === "transparent" ? "transparent" : "solid");
    this.#viewer?.requestRender();
  }

  #applyLook(force = false): void {
    const viewer = this.#viewer;
    const options = this.#options;
    this.#applyBackground();
    if (viewer === null || !this.#ready) return;
    try {
      const scales = authoredScales(options.asset.volumes);
      if (!scales.includes(options.scale)) return this.#set("unavailable", 0, this.#t("model.noScale", { scale: String(options.scale), scales: scales.map((s) => `1:${s}`).join(", ") }));
      if (this.#phase === "unavailable") this.#set("ready", 1, "");
      const variant = variantOf(options.view);
      if (force || variant !== this.#variant) {
        viewer.setVariant(variant);
        this.#variant = variant;
      }
      const scene = sceneOf(options);
      if (force || scene !== this.#scene) {
        viewer.setScene(scene);
        this.#scene = scene;
      }
      const query = options.query;
      const selection = query.kind === "pose" ? `pose:${query.pose}` : query.kind === "clip" ? `clip:${query.clip}` : "";
      if (force || selection !== this.#selection) {
        if (query.kind === "pose") viewer.setPose(query.pose);
        else if (query.kind === "clip") {
          viewer.setAnimation(query.clip, this.#timeS());
          viewer.setLoop(this.#clock?.state.loop ?? null);
        }
        this.#selection = selection;
      }
      if (force || selection !== this.#selection || options.query.kind !== "clip") viewer.setFollow(query.kind === "clip" ? "bounds" : "off");
      if (query.kind === "clip") viewer.seek(this.#timeS());
      if (force || options.preset !== this.#wanted) {
        this.#wanted = options.preset;
        if (options.preset !== this.#shown) this.#applyPreset(options.preset);
      }
    } catch (error) {
      this.#fail(error);
    }
  }

  #set(phase: StagePhase, fraction: number, message: string): void {
    this.#phase = phase;
    this.#fraction = fraction;
    this.#message = message;
    this.#refresh();
    this.#options.onState?.(this.state);
  }

  #refresh(): void {
    if (this.#disposed) return;
    const t = this.#t;
    const phase = this.#phase;
    const options = this.#options;
    this.#root.setAttribute("data-state", phase);
    this.#root.setAttribute("data-backend", this.state.backend);
    this.#root.setAttribute("data-asset", options.asset.id);
    this.#root.setAttribute("data-view", options.view);
    this.#root.setAttribute("data-scale", String(options.scale));
    this.#markChoices();
    this.#root.setAttribute("data-preset", this.#shown ?? "free");
    this.#progress.hidden = phase !== "preparing";
    if (phase === "preparing") {
      const percent = Math.round(this.#fraction * 100);
      this.#bar2.value = percent;
      this.#progressText.textContent = `${this.#message === "" ? t("model.progress") : this.#message} · ${t("model.progressValue", { percent })}`;
    }
    this.#bar.hidden = options.toolbar === false;
    this.#root.toggleAttribute("data-framed", options.framed !== false);
    this.#notice.hidden = phase === "preparing" || phase === "ready" || phase === "idle";
    const noticeKey = `${phase}|${this.#message}|${options.language}`;
    if (noticeKey !== this.#noticeKey) {
      this.#noticeKey = noticeKey;
      this.#notice.replaceChildren();
      if (!this.#notice.hidden) {
        const doc = this.#host.ownerDocument;
        const box = doc.createElement("div");
        box.className = "semio-stage-cell";
        const title = doc.createElement("b");
        const body = doc.createElement("span");
        box.setAttribute("role", phase === "error" ? "alert" : "status");
        title.textContent = phase === "cancelled" ? t("model.cancelled") : phase === "unavailable" ? (this.#message === "" ? t("model.noVolume") : this.#message) : t("model.error");
        body.textContent = phase === "error" ? t("model.errorBody", { message: this.#message }) : "";
        box.append(title, body);
        this.#notice.append(box);
        if (phase !== "unavailable") {
          const button = doc.createElement("button");
          button.type = "button";
          button.setAttribute("data-action", "retry");
          button.textContent = t("model.retry");
          button.addEventListener("click", () => this.retry());
          this.#notice.append(button);
        }
      }
    }
    this.#view.hidden = phase === "unavailable";
    this.#note.hidden = false;
    const software = this.state.backend === "software" && phase !== "idle";
    if (this.#viewer !== null && this.#note.textContent !== t("model.contextLost") && this.#note.textContent !== t("model.contextSwitched")) this.#note.textContent = software ? t("model.backend.software") : "";
    this.#note.hidden = this.#note.textContent === "";
    this.#description.textContent = describeModel(options.asset, { ...options, timeS: this.#timeS() }, this.#shown, options.language);
    this.#canvas?.setAttribute("aria-label", t("model.label", { title: options.asset.title[options.language] }));
  }
}
