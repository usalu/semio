use super::*;
use geo::BoundingRect;
use semio_plugin::{ArtifactInferenceExecutionRequest, ArtifactInferenceServiceRegistry, WireArtifactInferenceBudget, WireArtifactInferenceCacheMode};
use semio_framework_test_fixtures::fixture_text;

fn feature_vector(value: &serde_json::Value) -> Vec<MapFeature> {
    <Vec<MapFeature> as semio_framework_value::FromValue>::from_value(semio_framework_value::DslValue::from(value.clone())).expect("feature vector")
}

fn in_turn<T>(operation: impl FnOnce(&mut semio_framework_job::StepContext<'_>) -> T) -> T {
    let stock = semio_framework_value::RetainedCloneGrant { maximum_items: 100_000, maximum_copy_bytes: 1 << 24, maximum_capacity_bytes: 1 << 24, maximum_release_bytes: 1 << 24, maximum_depth: 128 };
    let mut caller = semio_framework_job::OriginalJobFixtureCaller::admit(semio_framework_job::OperationId(17), semio_framework_job::Generation(9), stock, || Some(12000), 1_000_000, 1_000_000);
    let (mut operation, mut output) = (Some(operation), None);
    caller.turn(stock, |cx| { output = Some((operation.take().expect("single turn"))(cx)); Ok(()) }).unwrap();
    output.expect("turn ran")
}

fn vector_snapshot(case: &serde_json::Value) -> GisMapSnapshot {
    let snapshot = &case["snapshot"];
    gis_map_snapshot_with_derived_children(GisMapSnapshot {
        positions: feature_vector(&snapshot["positions"]),
        routes: feature_vector(&snapshot["routes"]),
        regions: feature_vector(&snapshot["regions"]),
        ..Default::default()
    })
}

fn execute(
    snapshot: &GisMapSnapshot,
    budgets: &WireArtifactInferenceBudget,
    cancellation_id: &str,
    cache_mode: WireArtifactInferenceCacheMode,
) -> Result<semio_plugin::ArtifactInferenceExecution, semio_plugin::ArtifactInferenceExecutionError> {
    let pack = <GisMapSnapshot as pack::snapshot::ArtifactPack>::encode_pack(snapshot);
    in_turn(|cx| gis_map_inference_service().infer(&ArtifactInferenceExecutionRequest { operation:17,generation:9,cancelled:false, retained:semio_framework_value::retained_clone::RetainedCloneGrant{maximum_items:1,maximum_copy_bytes:4096,maximum_capacity_bytes:1048576,maximum_release_bytes:1048576,maximum_depth:128}, policy: b"gis-map-v1", budgets, cancellation_id, previous_state: None, requested_cache_mode: cache_mode, canonical_payload: &pack, dependencies: &[] }, cx)).map(|step| step.execution.expect("terminal execution"))
}

#[semio_framework_async_macros::async_test]
async fn map_artifact_kind_matches_the_map_out_interchange_kind() {
    let kind = artifact_kind();
    assert_eq!(kind.id, GISMAP_DIALECT.artifact_kind);
    assert_eq!(kind.schema, GIS_MAP_SCHEMA);
}

#[semio_framework_async_macros::async_test]
async fn the_map_snapshot_defaults_to_empty_feature_collections() {
    let document = GisMapSnapshot::default();
    assert!(document.positions.is_empty());
    assert!(document.routes.is_empty());
    assert!(document.regions.is_empty());
}

#[semio_framework_async_macros::async_test]
async fn inference_service_exposes_whole_map_metadata() {
    let service = gis_map_inference_service();
    let metadata = service.metadata();
    assert_eq!(metadata.owner, "gis");
    assert_eq!(metadata.artifact_kind, "s.gis.gismap");
    assert_eq!(metadata.artifact_schema, "s.gis.gismap");
    assert_eq!(metadata.inference_schema, "s.gis.gismap.inference");
    let mut registry = ArtifactInferenceServiceRegistry::new();
    registry.register(service).expect("service registers");
    definition().expect("service-bearing definition builds");
}

#[semio_framework_async_macros::async_test]
async fn declaration_exposes_one_executable_whole_map_inference() {
    declaration().expect("service-bearing declaration builds");
}

#[semio_framework_async_macros::async_test]
async fn language_neutral_vectors_match_geo_bounding_rect_oracle_and_stable_payload() {
    let vectors: serde_json::Value = serde_json::from_str(fixture_text!("../../🏅️standards/🔖️1/🪆️subsets/✳️any/🧪️tests/🧫️fixtures/📐️infer-gismap-1/🔣️.json")).expect("language-neutral inference vectors");
    assert_eq!(vectors["subjectSchema"], "../../../🧬️schema/💡️inferences/🔣️.json");
    assert_eq!(vectors["inferenceSchema"], "s.gis.gismap.inference");
    assert_eq!(vectors["schemaVersion"], 1);
    let budgets = WireArtifactInferenceBudget { allocation_bytes: 1_000_000, work_units: 1_000, recursion_depth: 32 };
    for case in vectors["cases"].as_array().expect("cases") {
        let snapshot = vector_snapshot(case);
        let first = execute(&snapshot, &budgets, case["id"].as_str().expect("case id"), WireArtifactInferenceCacheMode::Cold).expect("inference succeeds");
        let second = execute(&snapshot, &budgets, &format!("{}-repeat", case["id"].as_str().expect("case id")), WireArtifactInferenceCacheMode::Cold).expect("repeat succeeds");
        assert_eq!(first.canonical_payload, second.canonical_payload);
        assert_eq!(first.validity, "valid");
        assert_eq!(first.quality, "exact");
        assert!(first.complete);
        let inference =
            <standards::v1::subsets::any::schema::inferences::GisMapInference as semio_framework_value::FromValue>::from_value(semio_os_kernel::pack_rt::decode_wire_value(first.canonical_payload.as_ref().expect("payload")).expect("canonical inference payload"))
                .expect("typed inference");
        let expected = &case["expected"];
        assert_eq!(inference.position_count as u64, expected["positionCount"].as_u64().expect("position count"));
        assert_eq!(inference.route_count as u64, expected["routeCount"].as_u64().expect("route count"));
        assert_eq!(inference.region_count as u64, expected["regionCount"].as_u64().expect("region count"));
        let oracle_points = case["oracleCoordinates"].as_array().expect("oracle coordinates").iter().map(|point| geo::Point::new(point[0].as_f64().expect("longitude"), point[1].as_f64().expect("latitude"))).collect::<geo::MultiPoint>();
        let oracle = oracle_points.bounding_rect();
        match (inference.bounds, oracle, expected["bounds"].as_object()) {
            (None, None, None) => {}
            (Some(actual), Some(oracle), Some(expected)) => {
                assert_eq!(actual.lon_min, oracle.min().x);
                assert_eq!(actual.lon_max, oracle.max().x);
                assert_eq!(actual.lat_min, oracle.min().y);
                assert_eq!(actual.lat_max, oracle.max().y);
                assert_eq!(actual.lon_min, expected["lonMin"].as_f64().expect("lon min"));
                assert_eq!(actual.lon_max, expected["lonMax"].as_f64().expect("lon max"));
                assert_eq!(actual.lat_min, expected["latMin"].as_f64().expect("lat min"));
                assert_eq!(actual.lat_max, expected["latMax"].as_f64().expect("lat max"));
            }
            state => panic!("vector, subject, and geo oracle disagree: {state:?}"),
        }
    }
}

#[semio_framework_async_macros::async_test]
async fn malformed_snapshot_is_a_structured_execution_error() {
    let budgets = WireArtifactInferenceBudget { allocation_bytes: 1_000, work_units: 10, recursion_depth: 4 };
    let error = in_turn(|cx| gis_map_inference_service()
        .infer(&ArtifactInferenceExecutionRequest { operation:17,generation:9,cancelled:false, retained:semio_framework_value::retained_clone::RetainedCloneGrant{maximum_items:1,maximum_copy_bytes:4096,maximum_capacity_bytes:1048576,maximum_release_bytes:1048576,maximum_depth:128},
            policy: &[],
            budgets: &budgets,
            cancellation_id: "malformed",
            previous_state: None,
            requested_cache_mode: WireArtifactInferenceCacheMode::Cold,
            canonical_payload: b"not-a-gismap-pack",
            dependencies: &[],
        }, cx)
        .err())
        .expect("malformed snapshot must fail");
    assert_eq!(error.code, "gis.gismap.inference.snapshot-decode");
}

#[semio_framework_async_macros::async_test]
async fn service_enforces_work_recursion_and_cancellation_identity() {
    let snapshot = GisMapSnapshot { positions: vec![MapFeature { id: "nested".into(), data: semio_framework_value::DslValue::from(serde_json::json!({ "geometry": { "lon": 1.0, "lat": 2.0 } })) }], ..Default::default() };
    let no_work = WireArtifactInferenceBudget { allocation_bytes: 1_000_000, work_units: 1, recursion_depth: 32 };
    assert_eq!(execute(&snapshot, &no_work, "work", WireArtifactInferenceCacheMode::Cold).err().expect("work budget").code, "gis.gismap.inference.budget");
    let no_allocation = WireArtifactInferenceBudget { allocation_bytes: 1, work_units: 1_000, recursion_depth: 32 };
    assert_eq!(execute(&snapshot, &no_allocation, "allocation", WireArtifactInferenceCacheMode::Cold).err().expect("allocation budget").code, "gis.gismap.inference.budget");
    let no_depth = WireArtifactInferenceBudget { allocation_bytes: 1_000_000, work_units: 1_000, recursion_depth: 1 };
    assert_eq!(execute(&snapshot, &no_depth, "depth", WireArtifactInferenceCacheMode::Cold).err().expect("recursion budget").code, "gis.gismap.inference.budget");
    let valid = WireArtifactInferenceBudget { allocation_bytes: 1_000_000, work_units: 1_000, recursion_depth: 32 };
    assert_eq!(execute(&snapshot, &valid, "", WireArtifactInferenceCacheMode::Cold).err().expect("cancellation identity").code, "gis.gismap.inference.cancellation");
    assert_eq!(execute(&snapshot, &valid, "incremental", WireArtifactInferenceCacheMode::Incremental).err().expect("unsupported incremental cache").code, "gis.gismap.inference.cache-mode");
    assert_eq!(execute(&snapshot, &valid, "bypass", WireArtifactInferenceCacheMode::Bypass).expect("bypass succeeds").actual_cache_mode, WireArtifactInferenceCacheMode::Bypass);
}
