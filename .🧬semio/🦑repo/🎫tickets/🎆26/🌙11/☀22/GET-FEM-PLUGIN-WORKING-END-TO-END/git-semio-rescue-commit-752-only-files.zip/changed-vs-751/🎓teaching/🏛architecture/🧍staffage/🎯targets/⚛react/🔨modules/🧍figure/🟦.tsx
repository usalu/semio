/** 🧍️ `StaffageFigure`: one evaluated asset drawn as inline SVG in true paper size or fitted to its parent, with hover and keyboard inspection and a table alternative to colour; or, for the viewpoint `model`, shown as an interactive 3D model.
 *
 * The planar viewpoints (`elevation`, `front`, `plan`) and `axonometric` are drawings made by the library's `depict`; the axonometric drawing is made by the library like the others and names in words why an asset without volume has none. `model` mounts the owned WebGL2 viewer (loaded on demand): the representation is a variant of the model, the pose or clip is the query, the clock drives the time,
 * the scale is the level of detail and the environment colours the thermal view; see {@link ../🧊️spatial/🖥️stage/🟦️.ts}.
 *
 * `fit="paper"` sizes the element to the scene in CSS millimetres times `zoom` (zoom 1 is print size on screen); `fit="contain"` fills the parent box and never reports the scene's size back to it, so a walking figure cannot resize the card around it.
 * Only analytic views solve thermal or structural analyses; results are memoised by (asset, query, time, environment) across all figures.
 *
 * @see ../⏱️clock/🟦️.ts — the shared time source
 * @see ../🧮️pipeline/🟦️.ts — the memoised evaluator
 * @see ../🗣️labels/🟦️.ts — the spoken description
 */
import { Component, useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, KeyboardEvent, PointerEvent, ReactElement, ReactNode } from "react";
import type { SceneFrame } from "../🧮️pipeline/🟦️.ts";
import { axonometricCamera, project } from "@teaching/staffage";
import type { Asset, DepictionOptions, DisplayRange, DrawingScale, DrawingScene, Environment, EvaluatedState, EvaluationQuery, FlowField, FlowLayer, ForceQuantity, ItemValue, Language, RepresentationSelector, StructuralResult, ThermalField, ThermalQuantity, View, Viewpoint } from "@teaching/staffage";
import type { StaffageClock } from "../⏱️clock/🧱️core/🟦️.ts";
import { useHeldTime } from "../⏱️clock/🟦️.ts";
import { useSvgMarkup } from "../🧮️pipeline/🧬️svg/🟦️.ts";
import { describeScene, valueText, valuedItems, word } from "../🗣️labels/🟦️.ts";
import { translator } from "../🌐️i18n/🟦️.ts";
import { defaultQuery, figureFrame, inlineSvg, queryAt, sceneExtent } from "../🧮️pipeline/🟦️.ts";
import { flowFrameOf, flowsIn, unionFrame } from "../🌊️flow/🟦️.ts";
import { FlowStage, type FlowStageOptions } from "../🌊️flow/🖥️stage/🟦️.ts";
import { ViewpointGate } from "../🧮️pipeline/🦥️lazy/⚛️hook/🟦️.tsx";
import { SpatialFigure } from "../🧊️spatial/🚪️gate/🟦️.tsx";
import type { CameraPresetName } from "../🧊️spatial/🟦️.ts";
import { DEFAULT_CAMERA } from "../🧊️spatial/🟦️.ts";
import { refusalOf, type ViewpointKey } from "../🔭️viewpoints/🟦️.ts";

/** ⚙️ The props of {@link StaffageFigure}. */
export type StaffageFigureProps = {
  asset: Asset;
  query?: EvaluationQuery;
  clock?: StaffageClock;
  view: View;
  scale: DrawingScale;
  viewpoint: ViewpointKey;
  preset?: CameraPresetName;
  onPreset?: (preset: CameraPresetName) => void;
  onScale?: (scale: number) => void;
  onView?: (view: View) => void;
  background?: string | null;
  toolbar?: boolean;
  representation?: RepresentationSelector;
  theme?: "light" | "dark";
  frame?: SceneFrame;
  language: Language;
  zoom?: number;
  fit?: "paper" | "contain";
  transparent?: boolean;
  annotations?: Partial<DepictionOptions["annotations"]>;
  thermalQuantity?: ThermalQuantity;
  forceQuantity?: ForceQuantity;
  range?: DisplayRange;
  patterns?: boolean;
  diagrams?: Partial<DepictionOptions["diagrams"]>;
  environment?: Environment;
  /** 🌊️ The layers of the air flow drawn over the thermal view (none by default); the figure then takes the paper the flow needs around the asset. */
  flow?: readonly FlowLayer[];
  onFlow?: (flow: FlowField | null) => void;
  onEvaluated?: (frame: { state: EvaluatedState; thermal: ThermalField; structure: StructuralResult; scene: DrawingScene }) => void;
  onInspect?: (value: ItemValue | null, item: { bone?: string; region?: string } | null) => void;
  className?: string;
  title?: string;
  live?: boolean;
};

const HIDDEN: CSSProperties = { position: "absolute", width: 1, height: 1, margin: -1, padding: 0, overflow: "hidden", clip: "rect(0 0 0 0)", whiteSpace: "nowrap", border: 0 };

/** ♿️ The visually hidden table of the analytic values of a scene, the accessible alternative to colour. */
export function StaffageValueTable({ scene, language, id, className }: { scene: DrawingScene; language: Language; id?: string; className?: string }): ReactElement | null {
  const rows = useMemo(() => valuedItems(scene), [scene]);
  if (rows.length === 0) return null;
  return (
    <table id={id} className={className} lang={language} style={HIDDEN}>
      <caption>{word("values", language)}</caption>
      <thead>
        <tr>
          <th scope="col">{word("item", language)}</th>
          <th scope="col">{word("quantity", language)}</th>
          <th scope="col">{word("value", language)}</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((row) => (
          <tr key={row.id}>
            <th scope="row">{row.value.label[language]}</th>
            <td>{row.value.quantity}</td>
            <td>{valueText(row.value, language)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function useVisible(live: boolean): [React.RefObject<HTMLDivElement | null>, boolean] {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const element = ref.current;
    if (live || element === null || typeof IntersectionObserver !== "function") return;
    const observer = new IntersectionObserver((entries) => setVisible(entries.at(-1)?.isIntersecting ?? true));
    observer.observe(element);
    return () => observer.disconnect();
  }, [live]);
  return [ref, live || visible];
}

const svgId = (id: string): string => id.replace(/[^A-Za-z0-9_.-]/gu, "-");

function match(target: EventTarget | null, ids: ReadonlySet<string>, root: HTMLElement): string | null {
  for (let node = target instanceof Element ? target : null; node !== null && node !== root; node = node.parentElement) {
    const id = node.getAttribute("id");
    if (id !== null && ids.has(id)) return id;
  }
  return null;
}

/** 🚫️ Shows the named, bilingual refusal of a depiction that cannot be made (an axonometric view of an asset without volume) in place of the drawing; any other error goes on to the next boundary. */
class Refusals extends Component<{ readonly language: Language; readonly viewpoint: Viewpoint; readonly children: ReactNode }, { readonly error: unknown }> {
  override state = { error: null as unknown };

  static getDerivedStateFromError(error: unknown): { error: unknown } {
    return { error };
  }

  override render(): ReactNode {
    const { error } = this.state;
    if (error === null) return this.props.children;
    const reason = refusalOf(error, this.props.viewpoint);
    if (reason === null) throw error;
    const t = translator(this.props.language);
    return (
      <div role="alert" lang={this.props.language} data-refusal={this.props.viewpoint} data-staffage-figure="" style={{ display: "block", padding: "0.5em", background: "color-mix(in srgb, currentColor 8%, transparent)" }}>
        <b>{t("viewpoints.unavailable", { view: t(`viewpoints.phrase.${this.props.viewpoint}`) })}</b>
        <p style={{ margin: 0 }}>{reason[this.props.language]}</p>
        <p style={{ margin: 0 }}>{t("viewpoints.nothingInstead")}</p>
      </div>
    );
  }
}

/** 📏️ Renders one staffage asset in one view at one scale, as a drawing or, for the viewpoint `model`, as an interactive 3D model. */
export function StaffageFigure(props: StaffageFigureProps): ReactElement {
  const { viewpoint, preset, onPreset, onScale, onView, background, toolbar, ...drawn } = props;
  if (viewpoint === "model") return <ModelFace {...props} />;
  return (
    <ViewpointGate viewpoint={viewpoint} language={props.language}>
      <Refusals key={`${props.asset.id}:${viewpoint}`} language={props.language} viewpoint={viewpoint}>
        <DrawnFigure {...drawn} viewpoint={viewpoint} />
      </Refusals>
    </ViewpointGate>
  );
}

/** 🧊️ The interactive 3D model of a figure: pose or clip from the query (the asset's default clip when a clock runs, else its default pose), time from the clock, everything else from the props. */
function ModelFace(props: StaffageFigureProps): ReactElement {
  const { asset, clock, language, fit = "paper", className } = props;
  const query = props.query ?? defaultQuery(asset, clock === undefined ? null : 0);
  const sized: CSSProperties = fit === "paper" ? { position: "relative", inlineSize: "100%", blockSize: "var(--staffage-model-height, 24rem)" } : { position: "absolute", inset: 0, inlineSize: "100%", blockSize: "100%" };
  return (
    <div className={className} lang={language} data-staffage-figure="" data-fit={fit} data-asset={asset.id} data-view={props.view} data-viewpoint="model" style={{ display: "block", minInlineSize: 0, ...sized }}>
      <SpatialFigure
        asset={asset}
        query={query}
        clock={clock ?? null}
        view={props.view}
        scale={props.scale.denominator}
        language={language}
        preset={props.preset ?? DEFAULT_CAMERA}
        {...(props.onPreset === undefined ? {} : { onPreset: props.onPreset })}
        {...(props.onScale === undefined ? {} : { onScale: props.onScale })}
        {...(props.onView === undefined ? {} : { onView: props.onView })}
        {...(props.environment === undefined ? {} : { environment: props.environment })}
        {...(props.thermalQuantity === undefined ? {} : { thermalQuantity: props.thermalQuantity })}
        {...(props.forceQuantity === undefined ? {} : { forceQuantity: props.forceQuantity })}
        {...(props.range === undefined ? {} : { range: props.range })}
        {...(props.theme === undefined ? {} : { theme: props.theme })}
        {...(props.flow === undefined ? {} : { flow: props.flow })}
        {...(props.onFlow === undefined ? {} : { onFlow: props.onFlow })}
        {...(props.background === undefined ? {} : { background: props.background })}
        {...(props.toolbar === undefined ? {} : { toolbar: props.toolbar })}
      />
    </div>
  );
}

type DrawnProps = Omit<StaffageFigureProps, "viewpoint" | "preset" | "onPreset" | "onScale" | "onView" | "background" | "toolbar"> & { viewpoint: Viewpoint };

/** 🖼️ A drawing of one staffage asset in one view at one scale. */
function DrawnFigure(props: DrawnProps): ReactElement {
  const { asset, clock, language, zoom = 1, fit = "paper", live = false, onEvaluated, onInspect, className, title } = props;
  const [ref, visible] = useVisible(live);
  const timeS = useHeldTime(clock, visible && props.query?.kind !== "pose");
  const request = {
    view: props.view,
    scale: props.scale,
    language,
    viewpoint: props.viewpoint,
    ...(props.representation === undefined ? {} : { representation: props.representation }),
    ...(props.theme === undefined ? {} : { theme: props.theme }),
    ...(props.transparent === undefined ? {} : { transparent: props.transparent }),
    ...(props.annotations === undefined ? {} : { annotations: props.annotations }),
    ...(props.thermalQuantity === undefined ? {} : { thermalQuantity: props.thermalQuantity }),
    ...(props.forceQuantity === undefined ? {} : { forceQuantity: props.forceQuantity }),
    ...(props.range === undefined ? {} : { range: props.range }),
    ...(props.patterns === undefined ? {} : { patterns: props.patterns }),
    ...(props.diagrams === undefined ? {} : { diagrams: props.diagrams }),
    ...(props.environment === undefined ? {} : { environment: props.environment }),
  };
  const requestKey = JSON.stringify(request);
  const query = useMemo(() => queryAt(props.query ?? defaultQuery(asset, timeS), timeS), [asset, props.query, timeS]);
  const frame = useMemo(() => figureFrame(asset, query, request), [asset, query, requestKey]);
  const { scene } = frame;
  const flowLayers = props.flow !== undefined && props.flow.length > 0 && flowsIn(asset, props.view) && query.kind !== "transition" ? props.flow : null;
  const flowing = flowLayers !== null;
  const paperWindow = useMemo(() => props.frame ?? (flowing ? unionFrame(sceneExtent(scene), flowFrameOf(frame.state, props.viewpoint, scene.metadata.mmPerMetre, props.viewpoint === "axonometric" ? axonometricCamera() : undefined)) : undefined), [props.frame, flowing, scene, frame.state, props.viewpoint]);
  const frameKey = paperWindow === undefined ? "" : JSON.stringify(paperWindow);
  const markup = useMemo(() => inlineSvg(scene, paperWindow), [scene, frameKey]);
  const inkRef = useRef<HTMLDivElement | null>(null);
  useSvgMarkup(inkRef, markup);
  const widthMm = paperWindow === undefined ? scene.widthMm : paperWindow.maxX - paperWindow.minX;
  const heightMm = paperWindow === undefined ? scene.heightMm : paperWindow.maxY - paperWindow.minY;
  const flowStage = useRef<FlowStage | null>(null);
  const placing = useRef({ scene, paperWindow, viewpoint: props.viewpoint });
  placing.current = { scene, paperWindow, viewpoint: props.viewpoint };
  const flowOptions = (): FlowStageOptions => ({
    asset,
    query: props.query ?? defaultQuery(asset, clock === undefined ? null : 0),
    environment: props.environment ?? asset.thermal.environment,
    clock: clock ?? null,
    layers: flowLayers ?? [],
    theme: props.theme ?? "light",
    range: props.range ?? { mode: "shared" },
    scale: props.scale.denominator,
    language,
    projection: () => {
      const host = ref.current;
      const { scene: drawn, paperWindow: box, viewpoint } = placing.current;
      if (host === null || host.clientWidth === 0 || host.clientHeight === 0) return null;
      const view = box === undefined ? { x: 0, y: 0, w: drawn.widthMm, h: drawn.heightMm } : { x: drawn.metadata.origin.xMm + box.minX, y: drawn.metadata.origin.yMm + box.minY, w: box.maxX - box.minX, h: box.maxY - box.minY };
      const pxPerMm = Math.min(host.clientWidth / view.w, host.clientHeight / view.h);
      const left = (host.clientWidth - view.w * pxPerMm) / 2;
      const top = (host.clientHeight - view.h * pxPerMm) / 2;
      const camera = viewpoint === "axonometric" ? axonometricCamera() : undefined;
      const k = drawn.metadata.mmPerMetre;
      return {
        pxPerMm,
        project: (at, out) => {
          const q = project(viewpoint, at, camera);
          out[0] = left + (drawn.metadata.origin.xMm + q.x * k - view.x) * pxPerMm;
          out[1] = top + (drawn.metadata.origin.yMm - q.y * k - view.y) * pxPerMm;
          return true;
        },
      };
    },
    ...(props.onFlow === undefined ? {} : { onFlow: props.onFlow }),
  });
  useEffect(() => {
    if (!flowing || ref.current === null) return;
    const mounted = new FlowStage(ref.current, flowOptions());
    flowStage.current = mounted;
    return () => {
      mounted.dispose();
      flowStage.current = null;
      props.onFlow?.(null);
    };
  }, [flowing]);
  useEffect(() => flowStage.current?.update(flowOptions()));
  const showValues = props.annotations?.legend !== false || onInspect !== undefined;
  const items = useMemo(() => (showValues ? valuedItems(scene) : []), [scene, showValues]);
  const ids = useMemo(() => new Set(items.map((item) => svgId(item.id))), [items]);
  const [focused, setFocused] = useState(-1);
  const tableId = useRef(`staffage-values-${Math.random().toString(36).slice(2, 9)}`).current;
  const noteId = `${tableId}-fidelity`;
  const symbolic = scene.metadata.fidelity === "conventional-symbol";

  useEffect(() => {
    onEvaluated?.(frame);
  }, [frame]);

  const inspect = (index: number): void => {
    const item = items[index];
    setFocused(index);
    onInspect?.(item?.value ?? null, item === undefined ? null : { ...(item.bone === undefined ? {} : { bone: item.bone }), ...(item.region === undefined ? {} : { region: item.region }) });
  };
  const onPointer = (event: PointerEvent<HTMLDivElement>): void => {
    if (onInspect === undefined) return;
    const id = match(event.target, ids, event.currentTarget);
    inspect(id === null ? -1 : items.findIndex((item) => svgId(item.id) === id));
  };
  const onKey = (event: KeyboardEvent<HTMLDivElement>): void => {
    if (items.length === 0) return;
    const step = event.key === "ArrowRight" || event.key === "ArrowDown" ? 1 : event.key === "ArrowLeft" || event.key === "ArrowUp" ? -1 : 0;
    if (step !== 0) {
      event.preventDefault();
      inspect((focused + step + items.length) % items.length);
    } else if (event.key === "Escape") inspect(-1);
  };

  const size: CSSProperties =
    fit === "paper"
      ? { position: "relative", width: `${widthMm * zoom}mm`, height: `${heightMm * zoom}mm`, overflow: "hidden", flex: "none" }
      : { position: "absolute", inset: 0, width: "100%", height: "100%", minWidth: 0, minHeight: 0, overflow: "hidden", flex: "none" };
  const label = title ?? describeScene(scene, language);
  const current = items[focused];

  return (
    <>
    <div
      ref={ref}
      className={className}
      role="img"
      tabIndex={items.length > 0 ? 0 : undefined}
      lang={language}
      aria-label={label}
      aria-describedby={[items.length > 0 ? tableId : null, symbolic ? noteId : null].filter((id) => id !== null).join(" ") || undefined}
      data-fidelity={scene.metadata.fidelity}
      data-staffage-figure=""
      data-fit={fit}
      data-asset={asset.id}
      data-view={props.view}
      data-viewpoint={props.viewpoint}
      data-time={scene.metadata.timeS}
      data-width-mm={widthMm}
      data-height-mm={heightMm}
      style={{ display: "block", ...(paperWindow !== undefined && scene.background !== null ? { background: scene.background } : {}), ...size }}
      onPointerMove={onPointer}
      onPointerLeave={() => onInspect !== undefined && inspect(-1)}
      onKeyDown={onKey}
      onBlur={() => focused >= 0 && inspect(-1)}
    >
      <div ref={inkRef} style={{ position: "absolute", inset: 0 }} />
      {symbolic ? <span id={noteId} data-fidelity-note="" style={{ position: "absolute", left: 2, bottom: 2, padding: "0 3px", fontSize: 10, lineHeight: 1.4, background: "rgba(127,127,127,0.25)", color: "inherit" }}>{word("conventionalSymbol", language)}</span> : null}
    </div>
    {showValues ? <StaffageValueTable scene={scene} language={language} id={tableId} /> : null}
    <span role="status" aria-live="polite" style={HIDDEN}>
      {current === undefined ? "" : `${current.value.label[language]}: ${valueText(current.value, language)}`}
    </span>
    </>
  );
}
