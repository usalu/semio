/** 🖥️ The viewer: one asset on a pannable stage with every control synchronized to one state — scale, view, pose or clip, time, background, zoom, analytic options and environment — plus inspector and legends.
 *
 * The whole state is a {@link ViewerState}: the page keeps it in the address, so a link reproduces the view, the instant and the analytic settings. Time is the state of one {@link StaffageClock}; the address follows it only while it is
 * paused or scrubbed, never per frame. Scale (paper) and zoom (screen) are separate controls. Analytic views follow the site theme unless the reader overrides it.
 *
 * @see ./🗺️stage/🟦️.tsx — pan and zoom
 * @see ../🗺️routing/🟦️.ts — `ViewerState` and its parameters
 */
import { useEffect, useMemo, useRef, useState, useSyncExternalStore, type ReactElement } from "react";
import { FORCE_QUANTITIES, SCALE_PRESETS, THERMAL_QUANTITIES, VIEWS, axonometricCamera, flowDetailOf, flowLegends, flowMarks, flowPaint, formatNumber, mmPerMetre, sectionOf, viewpointCaption } from "@teaching/staffage";
import type { Asset, AuthoredRepresentation, DrawingScene, Environment, EvaluatedState, EvaluationQuery, FlowField, ItemValue, StructuralResult, ThermalField, View, PlanarViewpoint, Viewpoint } from "@teaching/staffage";
import { ENVIRONMENT_PRESETS } from "../🌤️environments/🟦️.ts";
import { ALL_FLOW_LAYERS, flowFrameOf, flowsIn, unionFrame } from "../🌊️flow/🟦️.ts";
import type { ViewpointKey } from "../🔭️viewpoints/🟦️.ts";
import { StaffageClock } from "../⏱️clock/🟦️.ts";
import { useBreakpoint } from "../🥞️levels/🟦️.tsx";
import { useArchive } from "../🧭️context/🟦️.tsx";
import { Bar, Button, ButtonGroup, CheckField, Cell, Column, Group, Note, Notice, NumberField, Segmented, SelectField, SliderField, Tag, cn } from "../🪟️chrome/🟦️.tsx";
import { FigureBoundary, useDarkSurface } from "../🖼️previews/🟦️.tsx";
import { Transport } from "../⏯️transport/🟦️.tsx";
import { scaleChoices } from "../🧊️spatial/🟦️.ts";
import { depictionOptions, evaluateState, frameOf, sceneOf, type SceneFrame } from "../🧮️pipeline/🟦️.ts";
import { useViewpointReady } from "../🧮️pipeline/🦥️lazy/⚛️hook/🟦️.tsx";
import type { Selection } from "../💾️persistence/🟦️.ts";
import type { ViewerState } from "../🗺️routing/🟦️.ts";
import { VIEW_NAMES } from "../🗣️labels/🟦️.ts";
import { namedPoses } from "../🔎️search/🟦️.ts";
import { FIGURE_CHOICES, VIEWPOINT_NAMES, VIEWPOINT_PHRASES, isDrawn, resolveFigure, sheetOf, viewpointWord } from "../🔭️viewpoints/🟦️.ts";
import { StaffageFigure } from "../🧍️figure/🟦️.tsx";
import { ViewpointSelector } from "../🔭️viewpoints/🎚️selector/🟦️.tsx";
import { ThreeViewSheet } from "../🔭️viewpoints/🪟️sheet/🟦️.tsx";
import { RangeControl } from "./📏️range/🟦️.tsx";
import { GROUND_COLOURS, Stage } from "./🗺️stage/🟦️.tsx";
import { Inspector, Legends, type Inspected } from "./🧾️reading/🟦️.tsx";

/** 🧾️ What the page needs back from the viewer: the evaluated instant with its analyses and the effective environment and clock. */
export type ViewerFrame = { readonly state: EvaluatedState; readonly thermal: ThermalField; readonly structure: StructuralResult; readonly scene: DrawingScene; readonly environment: Environment; readonly clock: StaffageClock };

/** ⚙️ The props of {@link Viewer}. */
export type ViewerProps = { readonly asset: Asset; readonly viewer: ViewerState; readonly onChange: (patch: Partial<ViewerState>, replace?: boolean) => void; readonly onFrame?: (frame: ViewerFrame) => void; readonly interactive?: boolean };

const ANALYTIC_VIEWS: readonly View[] = ["thermal", "forces", "moments"];
const DARK_VIEWS: readonly View[] = ["dark-line", "dark-solid"];
const SHEET_SAMPLES = 8;
const selectionKey = (selection: Selection | null): string => (selection === null ? "default" : selection.kind === "pose" ? `pose:${selection.pose}` : `clip:${selection.clip}`);
const keyToSelection = (key: string): Selection | null => (key === "default" ? null : key.startsWith("pose:") ? { kind: "pose", pose: key.slice(5) } : { kind: "clip", clip: key.slice(5) });

/** 🕰️ The clip whose time the clock follows. */
function clipOf(asset: Asset, selection: Selection | null) {
  const id = selection?.kind === "clip" ? selection.clip : asset.presentation.defaultClip;
  return asset.clips.find((clip) => clip.id === id) ?? asset.clips[0]!;
}

/** 🎛️ The viewer. */
export function Viewer(props: ViewerProps): ReactElement {
  const { asset, viewer, onChange } = props;
  const { t, language, reducedMotion } = useArchive();
  const phone = useBreakpoint() === "mobile";
  const dark = useDarkSurface();
  const [scene, setScene] = useState<DrawingScene | null>(null);
  const [inspected, setInspected] = useState<Inspected | null>(null);
  const clip = clipOf(asset, viewer.selection);
  const isPose = viewer.selection?.kind === "pose";
  const clipKey = `${asset.id}:${clip.id}`;
  const clock = useMemo(() => new StaffageClock({ fps: Math.min(clip.fps, 30), durationS: clip.durationS, loop: clip.loop && viewer.loop, rate: viewer.rate, playing: false, reducedMotion: true }), [clipKey]);
  const initial = useRef(viewer.timeS);
  useEffect(() => {
    if (initial.current !== null) {
      clock.seek(initial.current);
      clock.pause();
    } else if (!reducedMotion && !phone) clock.play();
    return () => clock.dispose();
  }, [clock]);
  useEffect(() => {
    if (reducedMotion) clock.pause();
  }, [reducedMotion, clock]);
  useEffect(() => {
    clock.setRate(viewer.rate);
    clock.setLoop(clip.loop && viewer.loop);
  }, [clock, viewer.rate, viewer.loop]);
  const playing = useSyncExternalStore(clock.subscribe, () => clock.state.playing, () => false);
  useEffect(() => {
    if (playing && viewer.timeS !== null) onChange({ timeS: null }, true);
  }, [playing]);
  const poseId = viewer.selection?.kind === "pose" ? viewer.selection.pose : null;
  const query: EvaluationQuery = useMemo(() => (poseId === null ? { kind: "clip", clip: clip.id, timeS: 0 } : { kind: "pose", pose: poseId }), [poseId, clip.id]);
  const analytic = ANALYTIC_VIEWS.includes(viewer.view);
  const flowable = flowsIn(asset, viewer.view);
  const flowLayers = flowable && viewer.flow.length > 0 ? viewer.flow : undefined;
  const [flow, setFlow] = useState<FlowField | null>(null);
  const theme = viewer.theme === "auto" ? (dark ? "dark" : "light") : viewer.theme;
  const drawnViewpoint: Viewpoint = isDrawn(viewer.viewpoint) ? viewer.viewpoint : "elevation";
  const model = viewer.viewpoint === "model" && viewer.layout !== "all";
  const planarFocus: PlanarViewpoint = viewer.viewpoint === "front" || viewer.viewpoint === "plan" ? viewer.viewpoint : "elevation";
  const drawable = useViewpointReady(drawnViewpoint);
  const frames = useMemo(() => {
    if (!isDrawn(viewer.viewpoint) || !drawable) return undefined;
    try {
      const state = evaluateState(asset, query);
      const baseScene = sceneOf(state, depictionOptions({ view: "dark-line", viewpoint: drawnViewpoint, scale: { denominator: viewer.scale }, language, theme, transparent: true }));
      const activeScene = viewer.view === "dark-line" ? baseScene : sceneOf(state, depictionOptions({ view: viewer.view, viewpoint: drawnViewpoint, scale: { denominator: viewer.scale }, language, theme, transparent: true }));
      const drawn = frameOf([baseScene, activeScene]);
      const active = flowLayers === undefined ? drawn : unionFrame(drawn, flowFrameOf(state, drawnViewpoint, baseScene.metadata.mmPerMetre, drawnViewpoint === "axonometric" ? axonometricCamera() : undefined));
      return { base: frameOf([baseScene]), byView: { [viewer.view]: active } as Record<View, SceneFrame> };
    } catch {
      return undefined;
    }
  }, [asset, query, viewer.scale, viewer.view, viewer.viewpoint, drawnViewpoint, drawable, language, theme, flowLayers === undefined]);
  const resolutions = useMemo(() => resolveFigure(asset, viewer.scale, language), [asset, viewer.scale, language]);
  const all = viewer.layout === "all";
  const sheetQueries = useMemo(() => (query.kind === "clip" ? Array.from({ length: SHEET_SAMPLES }, (_, index): EvaluationQuery => ({ kind: "clip", clip: query.clip, timeS: (clip.durationS * index) / SHEET_SAMPLES })) : [query]), [query, clip.durationS]);
  const sheet = useMemo(() => (all ? sheetOf(asset, sheetQueries, { view: viewer.view, denominator: viewer.scale, language, theme }) : undefined), [all, asset, sheetQueries, viewer.view, viewer.scale, language, theme]);
  const reasoned = viewer.environment;
  const base = asset.thermal.environment;
  const environment: Environment = useMemo(() => ({ ...base, ...reasoned }), [base, JSON.stringify(reasoned)]);
  const overridden = Object.keys(reasoned).length > 0;
  const flowScene = useMemo(() => {
    if (flow === null || flowLayers === undefined) return null;
    const legends = flowLegends(flow, flowMarks(flow, flow.timeS, flowDetailOf(viewer.scale)), flowPaint(theme, flow, viewer.range), flowLayers);
    return legends.length === 0 ? null : legends;
  }, [flow, flowLayers, viewer.scale, theme, JSON.stringify(viewer.range)]);
  const presetKey = !overridden ? "own" : (ENVIRONMENT_PRESETS.find((preset) => (["airTempC", "meanRadiantTempC", "relativeHumidity", "windMS", "solarWM2"] as const).every((key) => reasoned[key] === preset.environment[key]))?.id ?? "custom");
  const bg = viewer.background === "auto" ? (DARK_VIEWS.includes(viewer.view) ? "dark" : analytic && theme === "dark" ? "dark" : "light") : viewer.background;
  const explicit = viewer.background !== "auto";
  const mismatch = explicit && viewer.background !== "transparent" && ((DARK_VIEWS.includes(viewer.view) && viewer.background !== "dark") || (viewer.view.startsWith("light") && viewer.background === "dark"));
  const latest = useRef<ViewerFrame | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fitZoom = useRef(1);
  const hasValues = analytic || (scene?.legends.length ?? 0) > 0;
  const emit = (): void => {
    timer.current = null;
    const current = latest.current;
    if (current === null) return;
    setScene((previous) => (previous !== null && previous.metadata.view === current.scene.metadata.view && previous.metadata.viewpoint === current.scene.metadata.viewpoint && JSON.stringify(previous.legends) === JSON.stringify(current.scene.legends) ? previous : current.scene));
    props.onFrame?.(current);
  };
  useEffect(
    () => () => {
      if (timer.current !== null) clearTimeout(timer.current);
      timer.current = null;
    },
    [],
  );
  const onEvaluated = (frame: { state: EvaluatedState; thermal: ThermalField; structure: StructuralResult; scene: DrawingScene }): void => {
    latest.current = {
      get state() {
        return frame.state;
      },
      get thermal() {
        return frame.thermal;
      },
      get structure() {
        return frame.structure;
      },
      scene: frame.scene,
      environment,
      clock,
    };
    if (scene === null || scene.metadata.view !== frame.scene.metadata.view || scene.metadata.viewpoint !== frame.scene.metadata.viewpoint) setScene(frame.scene);
    if (timer.current === null) timer.current = setTimeout(emit, 400);
  };
  const zoomText = viewer.zoom === "fit" ? t("viewer.zoomFit") : `${Math.round(viewer.zoom * 100)} %`;
  const printSize = viewer.zoom === 1;
  const reference100 = asset.dimensions.heightM * mmPerMetre({ denominator: viewer.scale });
  const customScale = !(SCALE_PRESETS as readonly number[]).includes(viewer.scale);
  const authored = useMemo(() => {
    const candidates = Object.values(asset.representations).filter((rep): rep is AuthoredRepresentation => rep.status === "authored");
    return candidates.find((rep) => rep.denominator === viewer.scale) ?? candidates.find((rep) => rep.validRange.minDenominator <= viewer.scale && viewer.scale <= rep.validRange.maxDenominator);
  }, [asset, viewer.scale]);
  const viewpointName = (viewpoint: ViewpointKey): string => {
    if (viewpoint === "model" || viewpoint === "axonometric") return VIEWPOINT_NAMES[viewpoint][language];
    const section = sectionOf(authored, viewpoint);
    return section === undefined ? t(`viewer.viewpoint.${viewpoint}`) : viewpointCaption(viewpoint, section, language);
  };
  const sectionNames = (["elevation", "front", "plan"] as const).flatMap((viewpoint) => (sectionOf(authored, viewpoint) === undefined ? [] : [[viewpoint, viewpointName(viewpoint)] as const]));
  const unavailable = !all ? resolutions[viewer.viewpoint] : undefined;
  const groundColour = bg === "transparent" ? "transparent" : GROUND_COLOURS[bg];
  const poseOptions = [{ value: "default", label: t("viewer.selection.default", { title: clip.title[language] }) }, ...asset.clips.map((candidate) => ({ value: `clip:${candidate.id}`, label: `${t("viewer.selection.clip")}: ${candidate.title[language]}` })), ...namedPoses(asset).map((pose) => ({ value: `pose:${pose.id}`, label: `${t("viewer.selection.pose")}: ${pose.title[language]}` }))];
  const reasons = useMemo(() => new Map(scaleChoices(asset, language).flatMap((choice) => (choice.available ? [] : [[choice.scale, t("model.scaleUnavailable", { scale: choice.scale, reason: choice.reason })] as const]))), [asset, language]);
  const patch = (next: Partial<ViewerState>, replace = true): void => onChange(next, replace);
  const setEnv = (key: keyof Environment, value: number): void => patch({ environment: { ...viewer.environment, [key]: value } });
  return (
    <Bar below="tablet" data-viewer="" className="items-stretch">
      <Column className="min-w-0 flex-1">
        <Bar>
          <Cell className="flex-1 items-center text-xs">
            <Tag>{`1:${formatNumber(viewer.scale, Number.isInteger(viewer.scale) ? 0 : 1, language)}`}</Tag>
            <Tag>{VIEW_NAMES[viewer.view][language]}</Tag>
            <Tag>{all ? VIEWPOINT_PHRASES.all[language] : viewpointName(viewer.viewpoint)}</Tag>
            <span className="text-muted-foreground">{t("viewer.onPaper", { height: formatNumber(reference100, 1, language), mm: "mm", metres: formatNumber(asset.dimensions.heightM, 2, language) })}</span>
            {model ? <Tag>{t(`model.camera.${viewer.camera}`)}</Tag> : null}
          </Cell>
          {model ? null : (
            <>
              <ButtonGroup below={phone ? "never" : "mobile"}>
                <Button grouped icon="minus" aria-label={t("viewer.zoomOut")} title={t("viewer.zoomOut")} onClick={() => patch({ zoom: Math.max(0.05, Number(((viewer.zoom === "fit" ? fitZoom.current : viewer.zoom) / 1.25).toFixed(3))) })} />
                <output data-shared-border-cell="" className="inline-flex min-w-16 items-center justify-center font-mono" aria-label={t("viewer.zoom")}>{zoomText}</output>
                <Button grouped icon="plus" aria-label={t("viewer.zoomIn")} title={t("viewer.zoomIn")} onClick={() => patch({ zoom: Math.min(64, Number(((viewer.zoom === "fit" ? fitZoom.current : viewer.zoom) * 1.25).toFixed(3))) })} />
              </ButtonGroup>
              <ButtonGroup below={phone ? "never" : "mobile"}>
                <Button grouped aria-pressed={viewer.zoom === "fit"} onClick={() => patch({ zoom: "fit", pan: { xMm: 0, yMm: 0 } })} icon="maximize-2">{t("viewer.fit")}</Button>
                <Button grouped aria-pressed={printSize} onClick={() => patch({ zoom: printSize ? "fit" : 1 })} icon="scaling" title={t("viewer.printSizeHelp")}>{t("viewer.printSize")}</Button>
                <Button grouped icon="crosshair" aria-label={t("viewer.centre")} title={t("viewer.centre")} onClick={() => patch({ pan: { xMm: 0, yMm: 0 } })} />
              </ButtonGroup>
            </>
          )}
        </Bar>
        {unavailable !== undefined && !unavailable.available ? (
          <Notice kind="unavailable" title={viewpointWord("viewpoints.unavailable", language, { view: VIEWPOINT_PHRASES[viewer.viewpoint][language] })}>
            <p className="m-0">{unavailable.message[language]}</p>
            <p className="m-0 text-muted-foreground">{viewpointWord("viewpoints.nothingInstead", language)}</p>
          </Notice>
        ) : model ? (
          <div role="group" aria-label={t("model.viewerStage", { title: asset.title[language] })} aria-describedby={`${asset.id}-model-help`} data-stage="" data-model="" data-shared-border-cell="" data-border-probe-art="" className="relative h-[clamp(22rem,64vh,42rem)] w-full">
            <span id={`${asset.id}-model-help`} className="sr-only">{t("model.viewerHelp")}</span>
            <FigureBoundary resetKey={asset} fallback={(message) => <Notice kind="error" title={asset.title[language]}>{message}</Notice>}>
              <StaffageFigure asset={asset} query={query} clock={clock} view={viewer.view} viewpoint="model" scale={{ denominator: viewer.scale }} language={language} theme={theme} fit="contain" preset={viewer.camera} onPreset={(camera) => patch({ camera })} onScale={(scale) => patch({ scale })} onView={(view) => patch({ view })} background={groundColour} thermalQuantity={viewer.thermalQuantity} forceQuantity={viewer.forceQuantity} range={viewer.range} {...(overridden ? { environment } : {})} {...(flowLayers === undefined ? {} : { flow: flowLayers })} onFlow={setFlow} live />
            </FigureBoundary>
          </div>
        ) : (
        <Stage
          asset={asset}
          query={query}
          clock={clock}
          view={viewer.view}
          viewpoint={drawnViewpoint}
          scale={viewer.scale}
          language={language}
          theme={theme}
          ground={bg}
          transparent={explicit}
          frame={frames?.byView[viewer.view]}
          anchor={frames?.base}
          zoom={viewer.zoom}
          pan={viewer.pan}
          onZoom={(zoom) => patch({ zoom })}
          onPan={(pan) => patch({ pan })}
          onFit={(value) => void (fitZoom.current = value)}
          label={t("viewer.stage", { title: asset.title[language] })}
          help={t("viewer.stageHelp")}
          thermalQuantity={viewer.thermalQuantity}
          forceQuantity={viewer.forceQuantity}
          range={viewer.range}
          patterns={viewer.patterns}
          diagrams={viewer.diagrams}
          environment={overridden ? environment : undefined}
          {...(flowLayers === undefined ? {} : { flow: flowLayers })}
          onFlow={setFlow}
          onEvaluated={onEvaluated}
          onInspect={(value: ItemValue | null, item) => setInspected(value === null ? null : { value, item })}
          {...(sheet === undefined
            ? {}
            : {
                sheet: {
                  widthMm: sheet.layout.widthMm,
                  heightMm: sheet.layout.heightMm,
                  render: (zoom: number) => (
                    <ThreeViewSheet
                      asset={asset}
                      query={query}
                      clock={clock}
                      view={viewer.view}
                      scale={{ denominator: viewer.scale }}
                      language={language}
                      sheet={sheet}
                      zoom={zoom}
                      focus={planarFocus}
                      onFocus={(viewpoint) => patch({ viewpoint })}
                      onEvaluated={onEvaluated}
                      figure={{ theme, transparent: explicit, thermalQuantity: viewer.thermalQuantity, forceQuantity: viewer.forceQuantity, range: viewer.range, patterns: viewer.patterns, diagrams: viewer.diagrams, ...(overridden ? { environment } : {}), onInspect: (value: ItemValue | null, item: { bone?: string; region?: string } | null) => setInspected(value === null ? null : { value, item }) }}
                    />
                  ),
                },
              })}
        />
        )}
        {mismatch ? <Notice kind="info" compact title={t("viewer.contrast")} /> : null}
        {isPose && flowLayers !== undefined ? (
          <>
            <Notice kind="info" compact title={t("flow.poseClock", { title: (asset.poses.find((pose) => pose.id === (viewer.selection as { pose: string }).pose)?.title ?? { en: "", de: "" })[language] })} />
            <Transport clock={clock} label={t("viewer.transport")} onRate={(rate) => patch({ rate })} onLoop={(loop) => patch({ loop })} />
          </>
        ) : isPose ? (
          <Notice kind="info" compact title={t("viewer.poseStatic", { title: (asset.poses.find((pose) => pose.id === (viewer.selection as { pose: string }).pose)?.title ?? { en: "", de: "" })[language] })} />
        ) : (
          <Transport clock={clock} label={t("viewer.transport")} onUserTime={(timeS) => patch({ timeS })} onRate={(rate) => patch({ rate })} onLoop={(loop) => patch({ loop })} />
        )}
        {model ? (analytic ? <Notice kind="info" compact title={t("model.analyticNote")} /> : null) : <Inspector inspected={inspected} language={language} hasValues={hasValues} asset={asset} />}
        {model ? (flowScene === null ? null : <Legends scene={null} legends={flowScene} language={language} patterns={false} />) : <Legends scene={scene} {...(flowScene === null || scene === null ? {} : { legends: [...scene.legends, ...flowScene] })} language={language} patterns={viewer.patterns} />}
      </Column>
      <Column as="form" aria-label={t("viewer.controls")} onSubmit={(event) => event.preventDefault()} className="w-full bg-panel lg:w-[21rem] lg:shrink-0">
        <Segmented label={t("viewer.view")} value={viewer.view} onChange={(view) => patch({ view })} options={VIEWS.map((view) => ({ value: view, label: VIEW_NAMES[view][language], title: VIEW_NAMES[view][language] }))} />
        <ViewpointSelector value={all ? "all" : viewer.viewpoint} focus={planarFocus} language={language} choices={FIGURE_CHOICES} resolutions={resolutions} names={Object.fromEntries(sectionNames)} onChange={(choice) => patch(choice === "all" ? { layout: "all" } : { viewpoint: choice, layout: "single" })} />
        <Segmented label={t("viewer.scale")} value={customScale ? -1 : viewer.scale} onChange={(scale) => scale > 0 && patch({ scale })} options={[...SCALE_PRESETS.map((scale) => ({ value: scale as number, label: `1:${scale}`, ...(model && reasons.has(scale) ? { unavailable: reasons.get(scale)! } : {}) })), { value: -1, label: t("viewer.scaleCustom"), title: t("viewer.scaleCustomHelp") }]} />
        <Bar>
          <NumberField label={t("viewer.scaleDenominator")} unit={t("viewer.scaleUnit")} min={1} max={100000} value={viewer.scale} onChange={(scale) => scale !== null && scale >= 1 && patch({ scale })} />
        </Bar>
        <Bar>
          <SelectField label={t("viewer.selection")} value={selectionKey(viewer.selection)} options={poseOptions} onChange={(key) => patch({ selection: keyToSelection(key), timeS: null, pan: viewer.pan })} />
        </Bar>
        <Segmented label={t("viewer.background")} value={viewer.background} onChange={(background) => patch({ background })} options={[{ value: "auto", label: t("viewer.background.auto") }, { value: "dark", label: t("viewer.background.dark") }, { value: "light", label: t("viewer.background.light") }, { value: "paper", label: t("viewer.background.paper") }, { value: "transparent", label: t("viewer.background.transparent") }]} />
        <Segmented label={t("viewer.theme")} value={viewer.theme} onChange={(next) => patch({ theme: next })} options={[{ value: "auto", label: t("viewer.theme.auto") }, { value: "light", label: t("viewer.theme.light") }, { value: "dark", label: t("viewer.theme.dark") }]} />
        <Group stacked legend={t("viewer.analytics")} className={cn(!analytic && "opacity-70")}>
          {!analytic ? <Note className="text-[0.65rem]">{t("viewer.analyticsOnly")}</Note> : null}
          <Bar><SelectField label={t("viewer.thermalQuantity")} value={viewer.thermalQuantity} disabled={viewer.view !== "thermal"} onChange={(thermalQuantity) => patch({ thermalQuantity })} options={THERMAL_QUANTITIES.map((quantity) => ({ value: quantity, label: t(`viewer.thermal.${quantity}`) }))} /></Bar>
          <Bar><SelectField label={t("viewer.forceQuantity")} value={viewer.forceQuantity} disabled={viewer.view !== "forces"} onChange={(forceQuantity) => patch({ forceQuantity })} options={FORCE_QUANTITIES.map((quantity) => ({ value: quantity, label: t(`viewer.force.${quantity}`) }))} /></Bar>
          <RangeControl range={viewer.range} {...(scene?.legends[0] === undefined ? {} : { legend: scene.legends[0] })} onChange={(range) => patch({ range })} />
          <Bar><CheckField label={t("viewer.patterns")} checked={viewer.patterns} onChange={(patterns) => patch({ patterns })} /></Bar>
          <Group stacked legend={t("viewer.diagrams")}>
            {(["axial", "shear", "moment", "freeBody"] as const).map((key) => (
              <CheckField key={key} label={t(`viewer.diagram.${key}`)} checked={viewer.diagrams[key]} onChange={(checked) => patch({ diagrams: { ...viewer.diagrams, [key]: checked } })} />
            ))}
          </Group>
        </Group>
        <Group stacked legend={t("flow.layers")} className={cn(viewer.view !== "thermal" && "opacity-70")}>
          <Note className="text-[0.65rem]">{t(viewer.view !== "thermal" ? "flow.onlyThermal" : flowable ? "flow.help" : "flow.none")}</Note>
          {ALL_FLOW_LAYERS.map((layer) => (
            <CheckField key={layer} label={t(`flow.layer.${layer}`)} checked={viewer.flow.includes(layer)} disabled={!flowable} onChange={(checked) => patch({ flow: ALL_FLOW_LAYERS.filter((candidate) => (candidate === layer ? checked : viewer.flow.includes(candidate))) })} />
          ))}
        </Group>
        <Group stacked legend={t("viewer.environment")}>
          <Note className="text-[0.65rem]">{t(viewer.view === "thermal" ? "viewer.environmentHelp" : "viewer.environmentOnlyThermal")}</Note>
          <Bar><SelectField label={t("viewer.env.preset")} value={presetKey} options={[{ value: "own", label: t("viewer.env.presetOwn") }, ...ENVIRONMENT_PRESETS.map((preset) => ({ value: preset.id, label: preset.title[language] })), ...(presetKey === "custom" ? [{ value: "custom", label: t("viewer.env.presetCustom") }] : [])]} onChange={(id) => { const preset = ENVIRONMENT_PRESETS.find((candidate) => candidate.id === id); if (id === "own") patch({ environment: {} }); else if (preset !== undefined) patch({ environment: { airTempC: preset.environment.airTempC, meanRadiantTempC: preset.environment.meanRadiantTempC, relativeHumidity: preset.environment.relativeHumidity, windMS: preset.environment.windMS, solarWM2: preset.environment.solarWM2 } }); }} /></Bar>
          <SliderField label={t("viewer.env.air")} min={-30} max={45} step={0.5} value={environment.airTempC} text={`${formatNumber(environment.airTempC, 1, language)} °C`} onChange={(value) => setEnv("airTempC", value)} />
          <SliderField label={t("viewer.env.radiant")} min={-30} max={60} step={0.5} value={environment.meanRadiantTempC} text={`${formatNumber(environment.meanRadiantTempC, 1, language)} °C`} onChange={(value) => setEnv("meanRadiantTempC", value)} />
          <SliderField label={t("viewer.env.humidity")} min={0} max={100} step={1} value={Math.round(environment.relativeHumidity * 100)} text={`${Math.round(environment.relativeHumidity * 100)} %`} onChange={(value) => setEnv("relativeHumidity", value / 100)} />
          <SliderField label={t("viewer.env.wind")} min={0} max={15} step={0.1} value={environment.windMS} text={`${formatNumber(environment.windMS, 1, language)} m/s`} onChange={(value) => setEnv("windMS", value)} />
          <SliderField label={t("viewer.env.solar")} min={0} max={1000} step={10} value={environment.solarWM2} text={`${Math.round(environment.solarWM2)} W/m²`} onChange={(value) => setEnv("solarWM2", value)} />
          <Bar><Button grouped icon="rotate-ccw" disabled={!overridden} onClick={() => patch({ environment: {} })}>{t("viewer.env.reset")}</Button></Bar>
        </Group>
      </Column>
    </Bar>
  );
}
