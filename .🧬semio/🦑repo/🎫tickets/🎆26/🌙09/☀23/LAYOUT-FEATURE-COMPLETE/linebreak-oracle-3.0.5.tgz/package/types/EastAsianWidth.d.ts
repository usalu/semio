export const version: "16.0.0";
export const inputFileDate: Date;
export const etag: {
    "EastAsianWidth.txt": string;
};
export const lastModified: {
    "EastAsianWidth.txt": string;
};
export const generatedDate: Date;
export const EastAsianWidth: UnicodeTrie;
/**
 * @type {Record<string, number>}
 */
export const names: Record<string, number>;
export const values: string[];
import { UnicodeTrie } from "@cto.af/unicode-trie-runtime";
