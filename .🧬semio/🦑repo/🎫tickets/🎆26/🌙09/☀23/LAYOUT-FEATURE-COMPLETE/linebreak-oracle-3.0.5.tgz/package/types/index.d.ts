export function LB02(state: BreakerState): RuleResultsEnum;
export function LB03(state: BreakerState): RuleResultsEnum;
export function LB04(state: BreakerState): RuleResultsEnum;
export function LB05(state: BreakerState): RuleResultsEnum;
export function LB06(state: BreakerState): RuleResultsEnum;
export function LBspacesStop(state: BreakerState): RuleResultsEnum;
export function LB07(state: BreakerState): RuleResultsEnum;
export function LB08(state: BreakerState): RuleResultsEnum;
export function LB08a(state: BreakerState): RuleResultsEnum;
export function LB09(state: BreakerState): RuleResultsEnum;
export function LB10(state: BreakerState): RuleResultsEnum;
export function LB11(state: BreakerState): RuleResultsEnum;
export function LB12(state: BreakerState): RuleResultsEnum;
export function LB12a(state: BreakerState): RuleResultsEnum;
export function LB13(state: BreakerState): RuleResultsEnum;
export function LB14(state: BreakerState): RuleResultsEnum;
export function LB15a(state: BreakerState): RuleResultsEnum;
export function LB15b(state: BreakerState): RuleResultsEnum;
export function LB15c(state: BreakerState): RuleResultsEnum;
export function LB15d(state: BreakerState): RuleResultsEnum;
export function LB16(state: BreakerState): RuleResultsEnum;
export function LB17(state: BreakerState): RuleResultsEnum;
export function LB18(state: BreakerState): RuleResultsEnum;
export function LB19(state: BreakerState): RuleResultsEnum;
export function LB19a(state: BreakerState): RuleResultsEnum;
export function LB20(state: BreakerState): RuleResultsEnum;
export function LB20a(state: BreakerState): RuleResultsEnum;
export function LB21(state: BreakerState): RuleResultsEnum;
export function LB21a(state: BreakerState): RuleResultsEnum;
export function LB21b(state: BreakerState): RuleResultsEnum;
export function LB22(state: BreakerState): RuleResultsEnum;
export function LB23(state: BreakerState): RuleResultsEnum;
export function LB23a(state: BreakerState): RuleResultsEnum;
export function LB24(state: BreakerState): RuleResultsEnum;
export function LB25(state: BreakerState): RuleResultsEnum;
export function LB26(state: BreakerState): RuleResultsEnum;
export function LB27(state: BreakerState): RuleResultsEnum;
export function LB28(state: BreakerState): RuleResultsEnum;
export function LB28a(state: BreakerState): RuleResultsEnum;
export function LB29(state: BreakerState): RuleResultsEnum;
export function LB30(state: BreakerState): RuleResultsEnum;
export function LB30a(state: BreakerState): RuleResultsEnum;
export function LB30b(state: BreakerState): RuleResultsEnum;
export function LB31(state: BreakerState): RuleResultsEnum;
/**
 * @template T
 * @typedef {ValuesWithKeys<T, keyof T>} EnumValues
 */
/**
 * @template T
 * @template {keyof T} K
 * @typedef {T[K]} ValuesWithKeys
 */
/**
 * This rule has no opinion.
 */
export const PASS: unique symbol;
/**
 * This rule asserts that there must not be a break after the current
 * code point.
 */
export const NO_BREAK: unique symbol;
/**
 * This rule asserts that there may be a break after the current code point.
 */
export const MAY_BREAK: unique symbol;
/**
 * This rule asserts that there must be a line break after the current code point.
 */
export const MUST_BREAK: unique symbol;
export namespace RuleResults {
    export { PASS };
    export { NO_BREAK };
    export { MAY_BREAK };
    export { MUST_BREAK };
}
/**
 * Options for how rules are applied.
 *
 * @typedef {object} RulesOptions
 * @prop {boolean} [string=false] Extract strings from input, rather than just
 *   returning char offsets.
 * @prop {boolean} [verbose=false] Turn on some verbose logging that is
 *   useful for debug.
 */
export class Rules {
    /**
     *
     * @param {RulesOptions} opts
     */
    constructor(opts?: RulesOptions);
    /**
     * Copy of rules, safe to tweak.
     *
     * @type {BreakRule[]}
     */
    rules: BreakRule[];
    /**
     * Remove the rules with names as indicated.
     *
     * @param  {...string} names
     * @returns {BreakRule[]} The deleted rules
     */
    removeRule(...names: string[]): BreakRule[];
    /**
     * Add rules after the one named `name`.
     *
     * @param {string} name The name of the rule before.
     * @param {...BreakRule} newRules
     * @returns {number} Index of start of the new rules
     */
    addRuleAfter(name: string, ...newRules: BreakRule[]): number;
    /**
     * Add rules before the one named `name`.
     *
     * @param {string} name The name of the rule before.
     * @param {...BreakRule} newRules
     * @returns {number} Index of start of the new rules
     */
    addRuleBefore(name: string, ...newRules: BreakRule[]): number;
    /**
     * Replace the rule named `name` with the given rules.
     *
     * @param {string} name The name of the rule before.
     * @param {...BreakRule} newRules
     * @returns {BreakRule[]} The replaced rules.
     */
    replaceRule(name: string, ...newRules: BreakRule[]): BreakRule[];
    /**
     * Enumerate all of the potential line breaks.
     *
     * @param {string} str
     */
    breaks(str: string): Generator<Break, void, unknown>;
    #private;
}
export type RuleResultsEnum = EnumValues<typeof RuleResults>;
/**
 * A rule that impacts linebreaking.  Looking ahead and behind one code point
 * is fast, using `state.prev` and `state.next` respectively.  Looking ahead
 * more code points is possible with `*BreakerState.codePoints()`, but be
 * careful of causing ReDos vulnerabilities.
 */
export type BreakRule = (state: BreakerState) => RuleResultsEnum;
export type EnumValues<T> = ValuesWithKeys<T, keyof T>;
export type ValuesWithKeys<T, K extends keyof T> = T[K];
/**
 * Options for how rules are applied.
 */
export type RulesOptions = {
    /**
     * Extract strings from input, rather than just
     * returning char offsets.
     */
    string?: boolean | undefined;
    /**
     * Turn on some verbose logging that is
     * useful for debug.
     */
    verbose?: boolean | undefined;
};
import { BreakerState } from "./state.js";
import { Break } from "./break.js";
import { EastAsianWidth } from "./EastAsianWidth.js";
import { LineBreak } from "./LineBreak.js";
import { names as LineBreakClasses } from "./LineBreak.js";
import { eot } from "./state.js";
import { sot } from "./state.js";
export { Break, BreakerState, EastAsianWidth, LineBreak, LineBreakClasses, eot, sot };
