# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio',
 'semio.extension',
 'semio.extension.adapter',
 'semio.extension.adapter.v1',
 'semio.extension.converter',
 'semio.extension.converter.v1',
 'semio.extension.transformer',
 'semio.extension.transformer.v1',
 'semio.manager',
 'semio.manager.v1',
 'semio.model',
 'semio.model.v1',
 'semio.server',
 'semio.server.v1',
 'semio.translator',
 'semio.translator.v1']

package_data = \
{'': ['*']}

install_requires = \
['grpcio', 'protobuf']

setup_kwargs = {
    'name': 'semio',
    'version': '0.0.1',
    'description': 'Use this package to develop Semio APIs in Python.',
    'long_description': '# Semio\n\n\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/usalu/semio',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
