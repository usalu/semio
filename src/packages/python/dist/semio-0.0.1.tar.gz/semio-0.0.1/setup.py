# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio',
 'semio.assembler',
 'semio.assembler.v1',
 'semio.extension',
 'semio.extension.adapter',
 'semio.extension.adapter.v1',
 'semio.extension.converter',
 'semio.extension.converter.v1',
 'semio.extension.transformer',
 'semio.extension.transformer.v1',
 'semio.extension.translator',
 'semio.extension.translator.v1',
 'semio.extension.v1',
 'semio.gateway',
 'semio.gateway.v1',
 'semio.geometry',
 'semio.geometry.v1',
 'semio.google.api',
 'semio.manager',
 'semio.manager.v1',
 'semio.model',
 'semio.model.v1',
 'semio.protoc_gen_openapiv2.options',
 'semio.utils']

package_data = \
{'': ['*']}

install_requires = \
['grpcio-reflection>=1.51.1,<2.0.0',
 'grpcio>=1.51.1,<2.0.0',
 'mathutils>=3.3.0,<4.0.0',
 'multipledispatch>=0.6.0,<0.7.0',
 'numpy>=1.24.2,<2.0.0',
 'protobuf>=4.22.0,<5.0.0',
 'pydantic>=1.10.5,<2.0.0']

setup_kwargs = {
    'name': 'semio',
    'version': '0.0.1',
    'description': 'Use this package to develop Semio APIs in Python.',
    'long_description': '# Semio\n\n\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/usalu/semio',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
