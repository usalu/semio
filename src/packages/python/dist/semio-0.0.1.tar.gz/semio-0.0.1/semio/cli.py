from pydantic import BaseModel, Field
from constants import ASSEMBLER_NAME,ASSEMBLER_PORT, MANAGER_NAME, MANAGER_PORT
from argparse import ArgumentParser, Namespace

class ArgumentParserManager(BaseModel):
    argumentParser : ArgumentParser
    
    def addAssemblerDependency(self):
        self.argumentParser.add_argument('-aa','--assemblerBaseAddress', const=ASSEMBLER_NAME
                                          help = 'The (base) address of the assembler service. \nExamples: localhost, 192.168.1.1, your.service.domain, ... \nDefault: {ASSEMBLER_NAME} ')
        self.argumentParser.add_argument('-ap','--assemblerPort', const=ASSEMBLER_PORT
                                         help = f'The port of the assembler service.\nDefault: {ASSEMBLER_PORT} ')

    def addManagerDependency(self):
        self.argumentParser.add_argument('-ma','--managerBaseAddress', help = 'The (base) address of the manager service. \nExamples: localhost, 192.168.1.1, your.service.domain, ... \nDefault: {MANAGER_NAME} ')
        self.argumentParser.add_argument('-mp','--managerPort',help = f'The port of the manager service.\nDefault: {MANAGER_PORT} ')

    def addExternalDependency(self):
        self.argumentParser.add_argument('-aa','--managerBaseAddress', help = 'The (base) address of the manager service. \nExamples: localhost, 192.168.1.1, your.service.domain, ... \nDefault: {MANAGER_NAME} ')
        self.argumentParser.add_argument('-ap','--managerPort',help = f'The port of the manager service.\nDefault: {MANAGER_PORT} ')


