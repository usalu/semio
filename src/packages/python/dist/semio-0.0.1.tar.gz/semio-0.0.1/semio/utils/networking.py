def getAddressFromBaseAndPort(base:str, port:int):
    return base + ':' + str(port)