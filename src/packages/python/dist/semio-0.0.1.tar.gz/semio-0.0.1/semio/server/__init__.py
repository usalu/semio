# TODO File should be automatically generated.
import sys
from os import path
from pathlib import Path,PurePath
sys.path.append(str(PurePath(Path(path.dirname(__file__)).parent)))

from .v1.server_pb2 import *
from .v1.server_pb2_grpc import *