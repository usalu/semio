from concurrent import futures
import logging

import grpc

from semio.model import Design,Element

from .gen.server_pb2_grpc import ServerServicer, add_ServerServicer_to_server

class Server(ServerServicer):
    def LayoutDesign(self, request, context):
        elements =  []
        design = Design(elements)
        raise NotImplementedError('Method not implemented!')


def serve():
    port = '50000'
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    add_ServerServicer_to_server(Server(), server)
    server.add_insecure_port('[::]:' + port)
    server.start()
    print("Server started, listening on " + port)
    server.wait_for_termination()

if __name__ == '__main__':
    logging.basicConfig()
    serve()