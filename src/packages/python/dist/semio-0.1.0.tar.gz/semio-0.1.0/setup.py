# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio',
 'semio.extensionservices',
 'semio.extensionservices.adapter',
 'semio.extensionservices.adapter.gen',
 'semio.extensionservices.converter',
 'semio.extensionservices.converter.gen',
 'semio.extensionservices.transformer',
 'semio.extensionservices.transformer.gen',
 'semio.manager',
 'semio.model',
 'semio.model.gen',
 'semio.server',
 'semio.server.gen']

package_data = \
{'': ['*']}

install_requires = \
['dacite>=1.6.0,<2.0.0',
 'grpcio>=1.51.1,<2.0.0',
 'mathutils>=3.3.0,<4.0.0',
 'multipledispatch>=0.6.0,<0.7.0',
 'networkx>=2.8.8,<3.0.0',
 'numpy>=1.23.5,<2.0.0',
 'protobuf>=4.21.12,<5.0.0',
 'pydantic>=1.10.2,<2.0.0',
 'pytest-lazy-fixture>=0.6.3,<0.7.0',
 'pytest>=7.2.0,<8.0.0']

setup_kwargs = {
    'name': 'semio',
    'version': '0.1.0',
    'description': 'Semio allows designers to explicitly formalize design intent. This allows reuse, to split and parallelize work, producing more flexible systems.',
    'long_description': '# semio.py\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
