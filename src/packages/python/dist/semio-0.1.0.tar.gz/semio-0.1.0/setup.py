# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio',
 'semio.extension',
 'semio.extension.adapter',
 'semio.extension.adapter.gen',
 'semio.extension.converter',
 'semio.extension.converter.gen',
 'semio.extension.transformer',
 'semio.extension.transformer.gen',
 'semio.manager',
 'semio.model',
 'semio.model.gen',
 'semio.server',
 'semio.server.gen']

package_data = \
{'': ['*']}

install_requires = \
['grpcio>=1.51.1,<2.0.0', 'protobuf>=4.21.12,<5.0.0']

setup_kwargs = {
    'name': 'semio',
    'version': '0.1.0',
    'description': 'Semio enables designers to explicitly formalize design intent leading to a new way of designing.',
    'long_description': '# semio.py\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
