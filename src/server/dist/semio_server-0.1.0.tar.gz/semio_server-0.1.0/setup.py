# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio', 'semio.backend']

package_data = \
{'': ['*']}

install_requires = \
['mathutils',
 'networkx',
 'pydantic',
 'semio @ '
 'file:///C:/Git/Studium/PhD/semio/src/packages/python/dist/semio-0.1.0-py3-none-any.whl']

setup_kwargs = {
    'name': 'semio-server',
    'version': '0.1.0',
    'description': 'A backend server for semio.',
    'long_description': '# semio.py\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
