# TODO Automate that only classes from protobuf are imported
from .gen.model_pb2 import Point