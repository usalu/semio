# TODO Automate those imports
from gen.converter_pb2 import RepresentationConversionRequest
from gen.converter_pb2_grpc import ConverterServicer, add_ConverterServicer_to_server