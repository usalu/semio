# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio', 'semio.extensions.grasshopper']

package_data = \
{'': ['*']}

install_requires = \
['compute-rhino3d>=0.12.2,<0.13.0',
 'pydantic>=1.10.5,<2.0.0',
 'rhino3dm>=7.15.0,<8.0.0',
 'semio @ '
 'git+https://github.com/usalu/semio.git#subdirectory=src/packages/python']

entry_points = \
{'console_scripts': ['main = semio.extensions.grasshopper:main']}

setup_kwargs = {
    'name': 'semio-gh',
    'version': '0.0.1',
    'description': 'A semio extension for Grasshopper through Compute.',
    'long_description': '# semio.py\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '==3.10.10',
}


setup(**setup_kwargs)
