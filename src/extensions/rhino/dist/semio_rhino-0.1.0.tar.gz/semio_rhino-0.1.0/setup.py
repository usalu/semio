# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio', 'semio.rhino']

package_data = \
{'': ['*']}

install_requires = \
['compute-rhino3d>=0.12.2,<0.13.0',
 'dacite>=1.6.0,<2.0.0',
 'mathutils>=3.3.0,<4.0.0',
 'multipledispatch>=0.6.0,<0.7.0',
 'numpy>=1.23.5,<2.0.0',
 'pydantic>=1.10.4,<2.0.0',
 'pytest-lazy-fixture>=0.6.3,<0.7.0',
 'pytest>=7.2.0,<8.0.0',
 'rhino3dm>=7.15.0,<8.0.0',
 'semio @ ../../core']

setup_kwargs = {
    'name': 'semio-rhino',
    'version': '0.1.0',
    'description': 'A semio extension for Rhino including Grasshopper through Compute.',
    'long_description': '# semio.py\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
