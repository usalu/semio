# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio', 'semio.rhino']

package_data = \
{'': ['*']}

install_requires = \
['compute-rhino3d',
 'pydantic',
 'rhino3dm',
 'semio @ '
 'file:///C:/Git/Studium/PhD/semio/src/packages/python/dist/semio-0.1.0-py3-none-any.whl']

setup_kwargs = {
    'name': 'semio-rhino',
    'version': '0.1.0',
    'description': 'A semio extension for Rhino including Grasshopper through Compute.',
    'long_description': '# semio.py\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
