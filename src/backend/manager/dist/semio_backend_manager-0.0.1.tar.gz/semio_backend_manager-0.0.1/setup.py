# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio', 'semio.backend.manager']

package_data = \
{'': ['*']}

install_requires = \
['pydantic',
 'semio @ '
 'file:///C:/Git/Studium/PhD/semio/src/packages/python/dist/semio-0.0.1-py3-none-any.whl']

entry_points = \
{'console_scripts': ['my-script = manager:main']}

setup_kwargs = {
    'name': 'semio-backend-manager',
    'version': '0.0.1',
    'description': 'A manager for the backend of semio.',
    'long_description': '# semio.py\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
