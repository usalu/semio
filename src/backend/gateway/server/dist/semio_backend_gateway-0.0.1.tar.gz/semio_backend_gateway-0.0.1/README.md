# semio.py
