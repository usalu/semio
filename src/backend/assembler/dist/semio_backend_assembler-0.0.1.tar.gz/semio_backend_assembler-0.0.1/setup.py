# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['semio', 'semio.backend.assembler']

package_data = \
{'': ['*']}

install_requires = \
['networkx>=3.0,<4.0',
 'numpy>=1.24.2,<2.0.0',
 'pydantic>=1.10.5,<2.0.0',
 'semio @ '
 'file:///C:/Git/Studium/PhD/semio/src/packages/python/dist/semio-0.0.1-py3-none-any.whl']

setup_kwargs = {
    'name': 'semio-backend-assembler',
    'version': '0.0.1',
    'description': 'An assembler for the backend of semio.',
    'long_description': '# semio.py\n',
    'author': 'Ueli Saluz',
    'author_email': 'semio@posteo.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
